using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Configuration;


namespace Bayer.BCS.ContractExpressSystem
{
    public class ApprovalReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            //TODO: No aplica, eliminar
            string contactMailAdres = ConfigurationManager.AppSettings["Support Contact Mail address"];

            try
            {

                SPList ecLst = ECContext.Current.Lists.ExpressContract;
                ecLst.EventReceivers.Add(SPEventReceiverType.ItemUpdated, "Bayer.BCS.ContractExpressSystem, Version=1.0.0.0, Culture=neutral, PublicKeyToken=9747fdf77c58e4f0", "Bayer.BCS.ContractExpressSystem.ContractApprovalReceiver");
                ecLst.Update();
                

                SPList acLst = ECContext.Current.Lists.ArchivedContracts;
                acLst.EventReceivers.Add(SPEventReceiverType.ItemUpdated, "Bayer.BCS.ContractExpressSystem, Version=1.0.0.0, Culture=neutral, PublicKeyToken=9747fdf77c58e4f0", "Bayer.BCS.ContractExpressSystem.ArchivedContractsReceiver");
                acLst.Update();

                //SPList tmplLst = ECContext.Current.Lists.ContractTemplate;
                //tmplLst.EventReceivers.Add(SPEventReceiverType.ItemDeleting, "Bayer.BCS.ContractExpressSystem, Version=1.0.0.0, Culture=neutral, PublicKeyToken=9747fdf77c58e4f0", "Bayer.BCS.ContractExpressSystem.TemplateCleanUpReceiver");
                //tmplLst.Update();

                
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                throw;
            }
        }

        /// <summary>
        /// Occurs when a Feature is deactivated.
        /// </summary>
        /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPList ecLst = ECContext.Current.Lists.ExpressContract;
            SPList tmplLst = ECContext.Current.Lists.ContractTemplate;
            SPList acLst = ECContext.Current.Lists.ArchivedContracts;

            SPEventReceiverDefinition update = null;
            SPEventReceiverDefinition deleteAc = null;
            SPEventReceiverDefinition delete = null;
 
            foreach (SPEventReceiverDefinition item in ecLst.EventReceivers)
                if (item.Class == "Bayer.BCS.ContractExpressSystem.ContractApprovalReceiver")
                {
                    update = item;
                    break;
                }

            foreach (SPEventReceiverDefinition item in tmplLst.EventReceivers)
                if (item.Class == "Bayer.BCS.ContractExpressSystem.TemplateCleanUpReceiver")
                {
                    delete = item;
                    break;
                }

            foreach (SPEventReceiverDefinition item in acLst.EventReceivers)
                if (item.Class == "Bayer.BCS.ContractExpressSystem.ArchivedContractsReceiver")
                {
                    deleteAc = item;
                    break;
                }
            
            if (update != null)
                update.Delete();

            if (delete != null)
                delete.Delete();
            if (deleteAc != null)
                deleteAc.Delete();

            ecLst.Update();
            tmplLst.Update();
            acLst.Update();
        }

        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {

        }

        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {

        }
    }

}
