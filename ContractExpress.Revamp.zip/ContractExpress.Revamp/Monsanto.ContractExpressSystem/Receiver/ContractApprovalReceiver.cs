﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Collections.Specialized;
using System.Net.Mail;
using System.Web;
using System.Collections;

namespace Bayer.BCS.ContractExpressSystem
{
    class ApprovalMailFields
    {
        public string FileURL { get; set; }
        public string FileName { get; set; }
        public string SiteURL { get; set; }
        public string Country { get; set; }
        public string SignaturesList { get; set; }
        public string CloneContractSummaryUrl { get; set; }

        const string FILEURL = "##FILEURL##";
        const string FILENAME = "##FILENAME##";
        const string SITEURL = "##SITEURL##";
        const string COUNTRY = "##COUNTRY##";
        const string SIGNATURELIST = "##SIGNATURESLIST##";
        const string CLONECONTRACTSUMMARYURL = "##CLONECONTRACTURL##";

        public ApprovalMailFields()
        {
            FileName = "";
            FileURL = "";
            SiteURL = "";
            Country = "";
            SignaturesList = "";
            CloneContractSummaryUrl = "";
        }

        public string Normalize(string InputString)
        {
            string NormalizedInput = InputString;
            NormalizedInput = NormalizedInput.Replace(FILEURL, FileURL);
            NormalizedInput = NormalizedInput.Replace(FILENAME, FileName);
            NormalizedInput = NormalizedInput.Replace(SITEURL, SiteURL);
            NormalizedInput = NormalizedInput.Replace(COUNTRY, Country);
            NormalizedInput = NormalizedInput.Replace(SIGNATURELIST, SignaturesList);
            NormalizedInput = NormalizedInput.Replace(CLONECONTRACTSUMMARYURL, CloneContractSummaryUrl);
            return NormalizedInput;
        }
    }

    public class ContractApprovalReceiver : SPItemEventReceiver
    {
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            try
            {
                //Comment Venu, Date: 22 March 2016, Added below if condition to ensure the code to run only if the list name is Express contracts
                if (properties.List.Title == "Express contracts")
                {

                    base.ItemUpdated(properties);
                    this.EventFiringEnabled = false;
                    //string ApprovalMessage = "";

                    using (SPSite site = properties.OpenSite())
                    {
                        site.AllowUnsafeUpdates = true;
                        using (SPWeb ieweb = site.OpenWeb())
                        {
                            ieweb.AllowUnsafeUpdates = true;

                            ECContext ctx = new ECContext(SPContext.GetContext(ieweb));
                            bool resetStatus = true;

                            bool isDoaMember = properties.ListItem["Doa Approver"] != null &&
                                (properties.ListItem["Doa Approver"].ToString().Substring(properties.ListItem["Doa Approver"].ToString().LastIndexOf("#") + 1) == ieweb.CurrentUser.Name);

                            SPGroupCollection SPGroups = ieweb.CurrentUser.Groups;

                            foreach (SPGroup g in SPGroups)
                            {
                                if (g.Name.ToLower().IndexOf("legal admin") >= 0 ||
                                    g.Name.ToLower().IndexOf("fcpa approver") >= 0)
                                {
                                    resetStatus = false;
                                    break;
                                }
                            }

                            resetStatus = resetStatus && !isDoaMember;

                            if (resetStatus)
                            {
                                if (properties.ListItem[ctx.Configuration.ECFields.DaoApprover] != null) //Disables changes notification when performed by administrator -> && properties.UserDisplayName != "System Account")
                                {
                                    //SPFieldUserValue daoApprover = new SPFieldUserValue(ieweb, properties.ListItem[ctx.Configuration.ECFields.DaoApprover].ToString());
                                    List<string> bcc = ECContext.CreateLegalHeader(ieweb);
                                    ECContext.SendMail(ieweb, string.Format("Express Contract {0} change made to contract", properties.ListItem.File.Title), CreateChangeMail(properties.ListItem, ctx, site, properties.UserDisplayName), bcc);
                                }
                                //}

                                //Reset contract approval workflow when item updated
                                properties.ListItem[ctx.Configuration.ECFields.LegalApproval] = "Pending Business";
                                properties.ListItem[ctx.Configuration.ECFields.DoaApproval] = "Pending";
                                //Comment : Venu, Change Date 21 March 2016, ContractSubmit logic to avoid multiple mail to Legal department is not working. So I have commented the code
                                //properties.ListItem["ContractSubmitted"] = "No";
                                if (Convert.ToString(properties.ListItem[ctx.Configuration.ECFields.FCPAApproval]) != "N/A")
                                    properties.ListItem[ctx.Configuration.ECFields.FCPAApproval] = "Pending";

                            }

                            if (properties.ListItem[ctx.Configuration.ECFields.Cloneable] != null &&
                                Boolean.Parse(properties.ListItem[ctx.Configuration.ECFields.Cloneable].ToString()) &&
                                (properties.BeforeProperties[ctx.Configuration.ECFields.Cloneable] == null ||
                                (properties.BeforeProperties[ctx.Configuration.ECFields.Cloneable] != null &&
                                !Boolean.Parse(properties.BeforeProperties[ctx.Configuration.ECFields.Cloneable].ToString()))))
                            {
                                properties.ListItem[ctx.Configuration.ECFields.CloningDate] = DateTime.Now.Date;
                                properties.ListItem[ctx.Configuration.ECFields.CloneContractLink] = ctx.CurrentWeb.Url + "/Pages/CloneContract.aspx?ContractID=" + properties.ListItem["ID"] + ", Clone Contract";
                            }

                            properties.ListItem.SystemUpdate(false);

                            //string ApprovalMessage = "";
                            //bool contractApproved = ContractHelper.CheckContractApproved(properties.ListItem, ieweb, ctx, ref ApprovalMessage);
                            //if (contractApproved)
                            //    properties.ListItem.File.Approve(ApprovalMessage);
                            //else if (ContractHelper.CheckContractRejected(properties.ListItem, ieweb, ctx))
                            //    properties.ListItem.File.Deny("Contract rejected");
                        }
                    }
                    this.EventFiringEnabled = true;
                }
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }

        private string CreateChangeMail(SPListItem item, ECContext context, SPSite site, string user)
        {

            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            string selectedEmailTemplate = "";

            string siteUrl = context.CurrentWeb.Site.Url;
            string url = string.Concat(siteUrl, "/Style%20Library/Images/Mail/");

            selectedEmailTemplate = CETemplateMails.ChangeContractEmailTemplate;

            valuesToReplace.Add(CEMailSymbol.changeContract_ContractTItle, item.File.Title);
            valuesToReplace.Add(CEMailSymbol.changeContract_ContractURL, string.Concat(siteUrl, "/", item.File.Url));
            valuesToReplace.Add(CEMailSymbol.changeContract_ModifiedBy, user);
            valuesToReplace.Add(CEMailSymbol.changeContract_SiteURL, siteUrl);
            valuesToReplace.Add(CEMailSymbol.changeContract_Header, "Change made to Express Contract");

            CEEmail email = mailSystem.GetEmailMessageFromTemplate(context.CurrentWeb, selectedEmailTemplate, valuesToReplace);
            email.EmailBody = email.EmailBody.Replace("images/", url);
            return email.EmailBody;
           
        }

        private string CreateSectionHead(string section)
        {
            return string.Format("  <tr> <td valign=\"top\"> <img src=\"images/double-line.gif\" alt=\"\" style=\"display: block;\" /> </td> </tr> <tr><td class=\"article-title\" height=\"30\" valign=\"middle\" style=\"text-transform: uppercase; font-family: Georgia, serif; font-size: 16px; color: #2b2b2b; font-style: italic; border-bottom: 1px solid #c1c1c1;\"> {0} </td> </tr>", section);
        }
    }
}
