﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace Bayer.BCS.ContractExpressSystem
{
    public class TemplateCleanUpReceiver : SPItemEventReceiver
    {
        public override void ItemDeleting(SPItemEventProperties properties)
        {
            base.ItemDeleting(properties);

            ECContext context = new ECContext(SPContext.GetContext(properties.ListItem.ParentList.ParentWeb));
            string qry = string.Format("<Where><Eq><FieldRef Name='Template' /><Value Type='Lookup'>{0}</Value></Eq></Where>", properties.ListItem.Title);
            SPListItemCollection bookmarks = context.Lists.Bookmark.GetItems(new SPQuery() { Query = qry });
            for (int i = bookmarks.Count-1; i >= 0; i--)
			{
                SPFieldLookupValueCollection lookupColumn = bookmarks[i]["Template"] as SPFieldLookupValueCollection;
                if (lookupColumn.Count > 1)
                {
                    lookupColumn.Remove(lookupColumn.Find(delegate(SPFieldLookupValue LV) { return LV.LookupId == properties.ListItemId; }));
                    bookmarks[i]["Template"] = lookupColumn;
                    bookmarks[i].Update();
                }
                else
                {
                    SPListItem item = bookmarks[i];
                    item.Delete();
                }
	        }
        }
    }
}
