﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.IO;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System.Data;
using System.Web;

namespace Bayer.BCS.ContractExpressSystem.Layouts.ContractExpressSystem.Bayer_Pages
{
    public partial class UploadTemplate : LayoutsPageBase
    {

        #region controls & variables
        protected Panel pnlLanguage;
        //protected Panel pnlBilingual;
        protected Panel fldHeaders;
        protected Panel fldHeadersChk;

        protected DropDownList ddlLanguage;
        protected DropDownList ddlSecondLang;
        //protected DropDownList ddlTemplateDocType;
        protected ListBox lbDocType;
        //protected CheckBox chkBilingual;

        protected TextBox TemplateTitle;

        protected Label infoUploadTemplate;
        protected Label infoAnalyseTemplate;
        protected Label infoDetail;
        protected Label lblContractID;
        //protected Label infoDocTypeTemplate;

        protected LinkButton AnalyseBtn;

        protected HtmlAnchor UploadBtn;

        protected HtmlContainerControl stepTitleDiv;
        protected HtmlContainerControl srcContract_wrapper;

        protected PlaceHolder DynaCtrls;

        protected HtmlInputFile FileToUpload;


        protected HiddenField hdnDescriptions;
        protected HiddenField hdnLongDescriptions;
        protected HiddenField hdnDataTypes;
        protected HiddenField hdnMappings;
        protected HiddenField hdnUploadedFileId;
        protected HiddenField hdnExistingTitles;
        protected HiddenField hdnFile;
        protected HiddenField hdnFileName;
        protected HiddenField hdnTemplateName;
        protected HiddenField hdnTemplateTitle;
        protected HiddenField hdnTemplateDocType;
        protected HiddenField hdnAction;
        protected HiddenField hdnContractID;
        protected HiddenField hdnTitle;
        protected HiddenField hdnLink;

        protected HyperLink hlContract;

        protected CheckBox chkAll;

        DropDownList ddlMapping = new DropDownList();
        DropDownList ddlLongDesc = new DropDownList();
        DropDownList ddlDataType = new DropDownList();
        DropDownList ddlDescription = new DropDownList();
        TextBox txtDescription = new TextBox();
        TextBox txtLongDesc = new TextBox();
        HtmlInputCheckBox chkAddDel = new HtmlInputCheckBox();

        protected CheckBox chkMajorChange = new CheckBox();

        protected List<ECContext.Bookmark> bmFromNewTpl;
        protected List<ECContext.Bookmark> bmFromList;
        protected List<ECContext.Bookmark> bmAll;
        protected List<ECContext.Bookmark> duplicated;
        protected bool bUpload;

        protected int i;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            Dictionary<string, ECContext.Bookmark> bmList = null;
            if (Page.IsPostBack)
            {
                try
                {
                    i = Convert.ToInt32(Request.QueryString["tplid"]);
                    chkAll.Visible = (i != 0);
                    if (i != 0)
                    {
                        bUpload = false;
                        if (FileToUpload.PostedFile != null)
                        {
                            UploadFile();
                            bmList = GetNewAndOldBookmarks(i);
                        }
                        else if (!string.IsNullOrEmpty(hdnUploadedFileId.Value))
                            bmList = GetNewAndOldBookmarks(i);
                    }
                    else
                    {
                        bUpload = true;
                        bmList = ExtractBookmarksFromDoc();
                    }
                    if (bmList != null)
                    {
                        if (i != 0 &&
                            this.chkMajorChange.Checked)
                        {
                            SPListItem templateItem = GetOldTemplateListItem(i);
                            int itemsUpdated = RemoveCloneRightsbyTemplateName(templateItem.Title);

                        }
                        RenderBookmarks(bmList);
                    }
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent("Error uploading contract. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    ECContext.AddLogEntry("UploadTemplate.cs - Page_Load - Error uploading contract " + ex.Message, SPContext.Current.Web);
                    if (ex.Message.Contains("already exists"))
                    {
                        CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ex.Message);
                    }
                    else
                        CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.UploadTemplateError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }
            }
            else
            {
                i = Convert.ToInt32(Request.QueryString["tplid"]);
                if (i != 0)
                {
                    bUpload = false;
                    SPListItem itm = ECContext.Current.Lists.ContractTemplate.GetItemById(i);

                    lblContractID.Text = itm.ID.ToString();
                    hlContract.NavigateUrl = itm.File.ServerRelativeUrl;
                    hlContract.Text = itm.Title;
                }
                else
                {
                    bUpload = true;
                    srcContract_wrapper.Visible = false;
                }
            }
        }

        protected void AnalyseDocument_click(object sender, EventArgs e)
        {

            //Dictionary<string, ECContext.Bookmark> bmList = null;
            ////CreateControls();

            //if (Request.QueryString["tplid"] != null)
            //{
            //    bmList = ExtractBookmarksFromList(Int32.Parse(Request.QueryString["tplid"]));
            //}
            //else
            //{
            //    bmList = ExtractBookmarksFromDoc(null);
            //}

            //RenderBookmarks(bmList);
        }

        private void UploadFile()
        {
            string sFileName = hdnFileName.Value;
            string sFile = hdnFile.Value;
            byte[] bytearray = Convert.FromBase64String(sFile);
            MemoryStream ms = new MemoryStream(bytearray, 0, bytearray.Length);

            if (FileToUpload.PostedFile == null || FileToUpload.PostedFile.ContentLength == 0)
            {
                if (ms.Length == 0)
                    throw new Exception("Please, browse for a template to be uploaded.");
            }
            else
            {
                ms = new MemoryStream(ECContext.OpenXml.ReadFully(FileToUpload.PostedFile.InputStream));
                bytearray = ms.ToArray();
                sFile = Convert.ToBase64String(bytearray);
                hdnFile.Value = sFile;

                sFileName = FileToUpload.PostedFile.FileName.Substring(FileToUpload.PostedFile.FileName.LastIndexOf(@"\") + 1);
                hdnFileName.Value = sFileName;
            }

            using (ms)
            {
                ECContext.Current.CurrentWeb.AllowUnsafeUpdates = true;
                DisabledItemEventsScope disEvt = new DisabledItemEventsScope();

                SPListItem itm = ECContext.Current.Lists.ContractTemplate.GetItemById(i);
                string oldTitle = itm.Title;
                string lang = itm["Language"] as string;
                string secondlang = itm["Second Language"] as string;
                SPFieldLookupValueCollection valCol = itm["Document Type"] as SPFieldLookupValueCollection;
                itm.File.SaveBinary(ms);

                bool tryAgain = false;
                do
                {
                    try
                    {
                        disEvt.DisabledItemEvents();

                        itm["Title"] = oldTitle;
                        itm["Document Type"] = valCol;
                        itm["Language"] = lang;
                        itm["Second Language"] = secondlang;
                        itm.Update();
                        tryAgain = false;
                    }
                    catch (Exception ex2)
                    {
                        if (ex2.Message.Contains("has been modified by"))
                        {
                            itm = ECContext.Current.Lists.ContractTemplate.GetItemById(i);
                            System.Threading.Thread.Sleep(1000);
                            tryAgain = true;
                        }
                    }
                } while (tryAgain == true);




                disEvt.Dispose();

                hdnTemplateTitle.Value = oldTitle;
                hdnUploadedFileId.Value = itm.ID.ToString();

                TemplateTitle.Text = hdnTemplateTitle.Value;

                hdnTemplateName.Value = itm.Name;
                TemplateTitle.ReadOnly = true;

                ECContext.Current.CurrentWeb.AllowUnsafeUpdates = false;
            }
        }

        private Dictionary<string, ECContext.Bookmark> ExtractBookmarksFromDoc()
        {
            string sFileName = hdnFileName.Value;
            string sFile = hdnFile.Value;
            byte[] bytearray = Convert.FromBase64String(sFile);
            MemoryStream ms = new MemoryStream(bytearray, 0, bytearray.Length);

            if (FileToUpload.PostedFile == null || FileToUpload.PostedFile.ContentLength == 0)
            {
                if (ms.Length == 0)
                    throw new Exception("Please, browse for a template to be uploaded.");
            }
            else
            {
                ms = new MemoryStream(ECContext.OpenXml.ReadFully(FileToUpload.PostedFile.InputStream));
                bytearray = ms.ToArray();
                sFile = Convert.ToBase64String(bytearray);
                hdnFile.Value = sFile;

                sFileName = FileToUpload.PostedFile.FileName.Substring(FileToUpload.PostedFile.FileName.LastIndexOf(@"\") + 1);
                hdnFileName.Value = sFileName;
            }

            using (ms)
            {
                SPFile template = null;
                try
                {
                    template = ECContext.Current.Lists.ContractTemplate.RootFolder.Files.Add(sFileName, ms);
                    hdnTemplateName.Value = template.Item.Title;
                    hdnUploadedFileId.Value = template.Item.ID.ToString();
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("already exists"))
                    {
                        //Get file
                        foreach (SPFile oFile in ECContext.Current.Lists.ContractTemplate.RootFolder.Files)
                        {
                            if (oFile.Name == sFileName)
                            {
                                template = oFile;
                                hdnTemplateName.Value = template.Item.Title;
                                break;
                            }
                        }
                        if (AnalyseBtn.Visible == true)
                        {
                            throw new Exception("A template titled '" + sFileName + "' already exists, please change template title.");
                        }
                    }
                    else
                    {
                        throw new Exception(ex.Message);
                    }
                }

                hdnTemplateTitle.Value = TemplateTitle.Text;
                if (hdnTemplateTitle.Value == "")
                    TemplateTitle.Text = template.Item.Title;
                else
                    hdnTemplateTitle.Value = TemplateTitle.Text;

                hdnUploadedFileId.Value = template.Item.ID.ToString();
                //hdnTemplateName.Value = template.Item.Title;


                return ECContext.OpenXml.FindBookmarks(ms);
            }
        }

        private Dictionary<string, ECContext.Bookmark> ExtractBookmarksFromList(int tplId)
        {

            var dict = (from SPListItem itm in ECContext.Current.Lists.Bookmark.Items
                        where itm["Template"] != null &&
                        (from SPFieldLookupValue vc in (SPFieldLookupValueCollection)itm["Template"] where vc.LookupId == tplId select vc).FirstOrDefault() != null
                        select new ECContext.Bookmark
                        {
                            Name = itm.Name,
                            ItemID = itm.ID,
                            Mapping = (string)itm["FieldMapping"],
                            DataType = (string)itm["Data_x0020_Type"],
                            Description = (string)itm["Bookmark_x0020_Description"],
                            LongDescription = (string)itm["Long_x0020_Description"]
                        }).ToDictionary(bm => bm.Name);
            return dict;
        }

        private void RenderBookmarks(Dictionary<string, ECContext.Bookmark> bookmarkList)
        {
            try
            {
                SPListItem template = null;
                if (i == 0)
                {
                    if (!string.IsNullOrEmpty(hdnTemplateTitle.Value))
                    {
                        TemplateTitle.Text = hdnTemplateTitle.Value;
                    }
                }
                else
                    template = ECContext.Current.Lists.ContractTemplate.GetItemById(i);

                if (ddlLanguage.SelectedIndex == -1)
                {
                    ddlLanguage.DataSource = ECContext.Current.Lists.Language.GetItems(new SPQuery() { RowLimit = 100 });
                    ddlLanguage.DataValueField = ECContext.Current.Lists.Language.Fields[SPBuiltInFieldId.ID].InternalName;
                    ddlLanguage.DataTextField = ECContext.Current.Lists.Language.Fields[SPBuiltInFieldId.Title].InternalName;
                    ddlLanguage.DataBind();

                    //Set English default language
                    ddlLanguage.Items.FindByText("English").Selected = true;

                    if (template != null && template["Language"] != null)
                    {
                        SPFieldLookupValue lvLang = new SPFieldLookupValue(template["Language"] as String);
                        if (lvLang != null)
                        {
                            ddlLanguage.SelectedItem.Text = Convert.ToString(lvLang.LookupValue);
                        }
                    }
                }

                if (ddlSecondLang.SelectedIndex == -1)
                {
                    ddlSecondLang.DataSource = ECContext.Current.Lists.Language.GetItems(new SPQuery() { RowLimit = 100 });
                    ddlSecondLang.DataValueField = ECContext.Current.Lists.Language.Fields[SPBuiltInFieldId.ID].InternalName;
                    ddlSecondLang.DataTextField = ECContext.Current.Lists.Language.Fields[SPBuiltInFieldId.Title].InternalName;
                    ddlSecondLang.DataBind();

                    ddlSecondLang.Items.Insert(0, "(none)");

                    if (template != null && template["Second Language"] != null)
                    {
                        SPFieldLookupValue lvLang = new SPFieldLookupValue(template["Second Language"] as String);
                        if (lvLang != null)
                        {
                            ddlSecondLang.SelectedItem.Text = Convert.ToString(lvLang.LookupValue);
                        }
                    }
                }

                if (lbDocType.SelectedIndex == -1)
                {
                    lbDocType.DataSource = ECContext.Current.Lists.DocumentType.GetItems(new SPQuery() { RowLimit = 100 });
                    lbDocType.DataValueField = ECContext.Current.Lists.DocumentType.Fields[SPBuiltInFieldId.ID].InternalName;
                    lbDocType.DataTextField = ECContext.Current.Lists.DocumentType.Fields[SPBuiltInFieldId.Title].InternalName;
                    lbDocType.DataBind();

                    lbDocType.Items.Insert(0, "(none)");

                    if (template != null)
                    {
                        foreach (ListItem itm in lbDocType.Items)
                        {
                            foreach (SPFieldLookupValue lVal in template["Document Type"] as SPFieldLookupValueCollection)
                            {
                                if (itm.Text == lVal.LookupValue)
                                    itm.Selected = true;
                            }
                        }
                    }
                }


                DrawBookMarks(bookmarkList, false);
                if (duplicated != null)
                    DrawBookMarks(duplicated.ToDictionary(bm => bm.Name), true);

                UploadBtn.Visible = true;
                stepTitleDiv.Visible = true;
                TemplateTitle.Visible = true;
                //ddlTemplateDocType.Visible = true;
                //infoDocTypeTemplate.Visible = true;
                infoUploadTemplate.Visible = true;
                infoAnalyseTemplate.Visible = true;
                infoDetail.Visible = true;
                pnlLanguage.Visible = true;
                //pnlBilingual.Visible = true;
                AnalyseBtn.Visible = false;
                FileToUpload.Visible = false;
                fldHeaders.Visible = true;
                fldHeadersChk.Visible = true;

                fillHdnExistingTitle();
            }
            catch (Exception exx)
            {
                int logId = ECContext.LogEvent("Error uploading contract. " + exx.Message, exx, ECContext.TraceLevel.Unexpected);
                ECContext.AddLogEntry("UploadTemplate.cs - RenderBookmarks - Error uploading contract " + exx.Message, SPContext.Current.Web);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.UploadTemplateError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void DrawBookMarks(Dictionary<string, ECContext.Bookmark> bookmarkList, bool bAreHidden)
        {
            List<string> LongDescriptionsAvailable = GetListOfLongDescriptions();
            foreach (KeyValuePair<string, ECContext.Bookmark> item in bookmarkList)
            {
                bool bIsInOldTpl = (bmFromList == null ? false : bmFromList.FindAll(x => x.Name == item.Key).Count > 0);
                bool bIsInNewTpl = (bmFromNewTpl == null ? false : bmFromNewTpl.FindAll(x => x.Name == item.Key).Count > 0);
                bool bIsOnlyInOldTpl = bIsInOldTpl && !bIsInNewTpl;
                bool bIsOnlyInNewTpl = !bIsInOldTpl && bIsInNewTpl;
                bool bDuplicatedBM = false;


                if (bAreHidden)
                    bDuplicatedBM = true;
                else if (duplicated != null)
                    bDuplicatedBM = duplicated.FindAll(x => x.Name.ToLower() == item.Key.ToLower()).Count > 0;

                BookmarkDto popularItem = new BookmarkDto();

                List<ECContext.Bookmark> bmOriginalValues = null;
                if (!bUpload)
                    bmOriginalValues = bmFromList.FindAll(x => x.Name.ToLower() == item.Key.ToLower());

                if (!ECContext.Current.Configuration.BookmarkIgnoreList.Exists(s => item.Key.StartsWith(s)))
                {
                    //string dropdown = string.Format("<select id=\"{0}\" class='ddlDatatype ms-ce cmbText' name='Description' onchange=\"changeDDL(this)\" onclick=\"changeDDL(this)\">" + sDescription + "</select><input type=\"text\" id=\"{0}\" name='Description' class=\"ms-inputuserfield txtDDL\" onclick=\"txtClick(this)\" onblur=\"txtFill(this)\" value=\"Type yours...\" />", string.Concat(item.Key, "_Description"));
                    ddlDescription = new DropDownList();
                    ddlDescription.CssClass = "ddlDatatype ms-ce cmbText";
                    ddlDescription.Attributes.Add("ce_name", item.Key + "_Description");
                    ddlDescription.Attributes.Add("group", "Description");
                    //ddlDescription.Attributes.Add("onclick", "changeDDL(this)");
                    ddlDescription.Attributes.Add("onchange", "changeDDL(this)");//if (changeDDL(this)) return true;
                    ddlDescription.AutoPostBack = true;
                    ddlDescription.SelectedIndexChanged += new EventHandler(ddlDescription_SelectedIndexChanged);
                    if (!bUpload)
                        ddlDescription.Enabled = !bIsOnlyInOldTpl;

                    //Get descriptions from Bookmark list for ddl
                    SetBookmarkDescriptionValues(item.Key, ref ddlDescription);
                    ddlDescription.Items.Add("Type yours...");

                    txtDescription = new TextBox();
                    txtDescription.CssClass = "txtDDL";
                    txtDescription.MaxLength = 255;
                    txtDescription.Attributes.Add("ce_name", item.Key + "_DescriptionTXT");
                    txtDescription.Attributes.Add("group", "Description");
                    txtDescription.Attributes.Add("onclick", "txtClick(this)");
                    txtDescription.Attributes.Add("onblur", "txtFill(this)");
                    txtDescription.Text = "Type yours...";
                    if (!bUpload && bIsOnlyInOldTpl)
                        txtDescription.Attributes.Add("readonly", "");

                    //Get most popular bookmark once description is set to prefill mapping, type and long description
                    if (ddlDescription.SelectedValue != "Type yours...")
                    {
                        popularItem = GetMostPopularBookmarkByNameDescription(item.Value.Name, ddlDescription.SelectedValue);
                    }
                    if (!bUpload && bmOriginalValues.Count > 0)
                    {
                        ListItem itm = ddlDescription.Items.FindByText(bmOriginalValues[0].Description);
                        if (itm != null)
                        {
                            ddlDescription.ClearSelection();
                            ddlDescription.Items.FindByText(bmOriginalValues[0].Description).Selected = true;
                        }
                        else
                            txtDescription.Text = bmOriginalValues[0].Description;
                    }

                    //string dropdown2 = string.Format("<select id=\"{0}\" class='ddlDatatype ms-ce ms-ce3' name='DataType'><option selected value=\"Text\" >Text</option><option value=\"Bulleted list\" >Bulleted list</option><option value=\"Date\" >Date</option><option value=\"Numeric\">Numeric (Number to Text)</option></select>", string.Concat(item.Key, "_DataType"));
                    ddlDataType = new DropDownList();
                    ddlDataType.CssClass = "ddlDatatype ms-ce ms-ce3";
                    ddlDataType.Attributes.Add("ce_name", item.Key + "_DataType");
                    ddlDataType.Attributes.Add("group", "DataType");
                    ddlDataType.Items.Add("Text");
                    ddlDataType.Items.Add("Bulleted list");
                    ddlDataType.Items.Add("Date");
                    ddlDataType.Items.Add("Numeric");
                    if (!bUpload)
                        ddlDataType.Enabled = !bIsOnlyInOldTpl;

                    if (String.IsNullOrEmpty(popularItem.mapping) && !String.IsNullOrEmpty(popularItem.datatype))
                        ddlDataType.SelectedValue = popularItem.datatype;
                    if (!bUpload)
                    {
                        if (bmOriginalValues.Count > 0 && bmOriginalValues[0].DataType != null)
                        {
                            ddlDataType.ClearSelection();
                            ddlDataType.Items.FindByText(Convert.ToString(bmOriginalValues[0].DataType)).Selected = true;
                        }
                        else
                        {
                            ddlDataType.SelectedIndex = 0;
                        }
                    }

                    //string dropdown3 = string.Format("<select id=\"{0}\" class='ddlMapping ms-ce ms-ce2' onchange=\"fillLongDesc_click\" name='Mapping'><option ></option><option value=\"Monsanto_x0020_Entity\" >Monsanto Entity</option><option value=\"Country\" >Monsanto Entity Country</option><option value=\"Function\">Function</option><option value=\"Address\" >Monsanto Entity Address</option><option value=\"Jurisdiction\" >Monsanto Entity Jurisdiction</option><option value=\"Counterparty\">Counterparty</option><option value=\"Id_x0020_Number\" >Id Number</option><option value=\"Registration_x0020_#\" >Registration #</option><option value=\"Capital_x0020_Amount\" >Capital Amount</option><option value=\"Entity_x0020_Type\" >Entity Type</option><option value=\"Monsanto_x0020_Entity_x0020_Representative\" >Monsanto Entity Representative</option><option value=\"Monsanto_x0020_Entity_x0020_Representative_x0020_Title\" >Monsanto Entity Representative Title</option></select>", item.Key);
                    ddlMapping = new DropDownList();
                    ddlMapping.CssClass = "ddlMapping ms-ce ms-ce2";
                    ddlMapping.Attributes.Add("ce_name", item.Key + "_Mapping");
                    ddlMapping.Attributes.Add("group", "Mapping");
                    if (!bUpload)
                        ddlMapping.Enabled = !bIsOnlyInOldTpl;
                    CESPUtil.BindDropdownMapping(ddlMapping);

                    if (popularItem.mapping != null)
                        ddlMapping.Items.FindByValue((string)popularItem.mapping).Selected = true;

                    if (!bUpload)
                    {
                        if (bmOriginalValues.Count > 0 && bmOriginalValues[0].Mapping != null)
                        {
                            string sMapping = Convert.ToString(bmOriginalValues[0].Mapping).Replace("_x0020_", " ");
                            ListItem itm = ddlMapping.Items.FindByText(sMapping);
                            if (itm != null)
                            {
                                ddlMapping.ClearSelection();
                                ddlMapping.Items.FindByText(sMapping).Selected = true;
                            }
                        }
                        else
                        {
                            ddlMapping.SelectedIndex = 0;
                        }
                    }

                    //string textbox = string.Format("<select id=\"{0}\" class='ddlDatatype ms-ce cmbText2' name='LongDescription' onchange=\"changeDDL(this)\" onclick=\"changeDDL(this)\">" + sLongDescription + "</select><input type=\"text\" id=\"{0}\" name='LongDescription' class=\"ms-inputuserfield txtDDL2\" onclick=\"txtClick(this)\" onblur=\"txtFill(this)\" value=\"Type yours...\" />", string.Concat(item.Key, "_LongDescription"));

                    ddlLongDesc = new DropDownList();
                    ddlLongDesc.Items.Clear();
                    ddlLongDesc.Items.Add("");
                    foreach (string desc in LongDescriptionsAvailable)
                    {
                        ddlLongDesc.Items.Add(desc);
                    }
                    ddlLongDesc.Items.Add("Type yours...");
                    if (!String.IsNullOrEmpty(popularItem.longdesc))
                        ddlLongDesc.SelectedValue = popularItem.longdesc;
                    //else
                    //    ddlLongDesc.SelectedValue = "Type yours...";
                    ddlLongDesc.CssClass = "ddlDatatype ms-ce cmbText2";
                    ddlLongDesc.Attributes.Add("ce_name", item.Key + "_LongDescription");
                    ddlLongDesc.Attributes.Add("group", "LongDescription");
                    ddlLongDesc.Attributes.Add("onclick", "changeDDL(this)");
                    ddlLongDesc.Attributes.Add("onchange", "changeDDL(this)");

                    if (!bUpload)
                        ddlLongDesc.Enabled = !bIsOnlyInOldTpl;


                    txtLongDesc = new TextBox();
                    txtLongDesc.CssClass = "txtDDL2";
                    txtLongDesc.MaxLength = 255;
                    txtLongDesc.Attributes.Add("ce_name", item.Key + "_LongDescriptionTXT");
                    txtLongDesc.Attributes.Add("group", "LongDescription");
                    txtLongDesc.Attributes.Add("onclick", "txtClick(this)");
                    txtLongDesc.Attributes.Add("onblur", "txtFill(this)");
                    txtLongDesc.Text = "Type yours...";
                    if (!bUpload && bIsOnlyInOldTpl)
                        txtLongDesc.Attributes.Add("readonly", "");
                    if (!bUpload)
                    {
                        if (bmOriginalValues.Count > 0)
                            txtLongDesc.Text = Convert.ToString(bmOriginalValues[0].LongDescription);
                    }

                    //Decide if bookmark is to be deleted or added
                    chkAddDel = new HtmlInputCheckBox();
                    chkAddDel.Attributes.Add("ce_name", item.Key + "_Action");
                    chkAddDel.Attributes.Add("group", "Action");
                    chkAddDel.Attributes.Add("class", "chkAddDel");
                    chkAddDel.Checked = true;
                    Label lblChk = new Label();
                    lblChk.CssClass = "lblAddDel";

                    string sDivClass = "";
                    if (bUpload)
                    {
                        chkAddDel.Attributes.Add("Action", "Update");
                        chkAddDel.Disabled = true;
                        lblChk.Visible = false;
                        chkAddDel.Style.Add("display", "none");
                    }
                    else if (bAreHidden)
                    {
                        chkAddDel.Attributes.Add("Action", "Remove");
                        lblChk.Text = "";
                        chkAddDel.Attributes.Add("style", "display:none");
                        lblChk.Visible = false;
                        sDivClass = "_Duplicate";
                    }
                    else if (bDuplicatedBM)
                    {
                        chkAddDel.Attributes.Add("Action", "Add");
                        lblChk.Text = "Update Bookmark";
                        chkAddDel.Disabled = true;
                        //lblChk.Visible = false;
                    }
                    else if (bIsOnlyInNewTpl)
                    {
                        chkAddDel.Attributes.Add("Action", "Add");
                        lblChk.Text = "Add Bookmark";
                        lblChk.ForeColor = System.Drawing.Color.Green;
                        sDivClass = "_Add";
                    }
                    else if (bIsOnlyInOldTpl)
                    {
                        chkAddDel.Attributes.Add("Action", "Remove");
                        chkAddDel.Disabled = true;
                        lblChk.Text = "Remove Bookmark";
                        lblChk.ForeColor = System.Drawing.Color.Red;
                        sDivClass = "_Remove";
                    }
                    else
                    {
                        chkAddDel.Attributes.Add("Action", "Update");
                        lblChk.Text = "Update Bookmark";
                        chkAddDel.Disabled = true;
                        //lblChk.Visible = false;
                    }

                    DynaCtrls.Controls.Add(new LiteralControl(string.Format("<div class='uploadTemplate" + sDivClass + "'>")));
                    DynaCtrls.Controls.Add(new LiteralControl(string.Format("<span class=\"ms-titlearea fieldname Bookmark\" >{0}:</span>", item.Key)));
                    DynaCtrls.Controls.Add(ddlDescription);
                    DynaCtrls.Controls.Add(txtDescription);
                    DynaCtrls.Controls.Add(ddlMapping);
                    DynaCtrls.Controls.Add(ddlDataType);
                    DynaCtrls.Controls.Add(ddlLongDesc);
                    DynaCtrls.Controls.Add(txtLongDesc);
                    DynaCtrls.Controls.Add(chkAddDel);
                    DynaCtrls.Controls.Add(lblChk);
                    DynaCtrls.Controls.Add(new LiteralControl(string.Format("</div>")));
                    DynaCtrls.Controls.Add(new LiteralControl(string.Format("<div class='spacer'></div>")));
                    //DynaCtrls.Controls.Add(new LiteralControl(string.Format("<span class=\"ms-titlearea fieldname Bookmark\" >{0}:</span>{1}{4}{3}{2}<div class='spacer'></div>", item.Key, dropdown, dropdown2, dropdown3, textbox)));
                }
            }
        }

        //private Dictionary<string, ECContext.Bookmark> DuplicatedBM(Dictionary<string, ECContext.Bookmark> bookmarkList)
        //{
        //    Dictionary<string, ECContext.Bookmark> duplicated = new Dictionary<string,ECContext.Bookmark>();
        //    Dictionary<string, ECContext.Bookmark> tmp = new Dictionary<string, ECContext.Bookmark>();

        //    foreach (KeyValuePair<string, ECContext.Bookmark> item in bookmarkList)
        //    {
        //        if (tmp.ContainsKey(item.Key.ToLower()))
        //            duplicated.Add(item.Key, item.Value);
        //        else
        //            tmp.Add(item.Key.ToLower(), item.Value);
        //    }

        //    return duplicated;
        //}

        struct BookmarkDto
        {
            public string name { get; set; }
            public string mapping { get; set; }
            public string description { get; set; }
            public string datatype { get; set; }
            public string longdesc { get; set; }
            public string template { get; set; }
            public string action { get; set; }
        }

        private void fillHdnExistingTitle()
        {
            SPListItemCollection templateItems = ECContext.Current.Lists.ContractTemplate.Items;
            IEnumerable<SPListItem> foundTitles = (from item in templateItems.Cast<SPListItem>() where item.ID.ToString() != hdnUploadedFileId.Value select item);

            foreach (SPListItem item in foundTitles)
            {
                hdnExistingTitles.Value += item.Title + "//";
            }
        }

        private List<BookmarkDto> ConstructBookmarks()
        {

            List<string> mappings = new List<string>();
            mappings.AddRange(hdnMappings.Value.Split(new string[] { "</mapping>" }, StringSplitOptions.RemoveEmptyEntries));

            List<string> datatypes = new List<string>();
            datatypes.AddRange(hdnDataTypes.Value.Split(new string[] { "</datatype>" }, StringSplitOptions.RemoveEmptyEntries));

            List<string> descriptions = new List<string>();
            descriptions.AddRange(hdnDescriptions.Value.Split(new string[] { "</description>" }, StringSplitOptions.RemoveEmptyEntries));

            List<string> longdescriptions = new List<string>();
            longdescriptions.AddRange(hdnLongDescriptions.Value.Split(new string[] { "</longdescription>" }, StringSplitOptions.RemoveEmptyEntries));

            List<string> action = new List<string>();
            action.AddRange(hdnAction.Value.Split(new string[] { "</action>" }, StringSplitOptions.RemoveEmptyEntries));


            List<BookmarkDto> resultList = new List<BookmarkDto>();
            foreach (string item in mappings)
            {

                BookmarkDto bm = new BookmarkDto() { name = item.Replace("<mapping><id>", string.Empty).Split(new string[] { "</id>" }, StringSplitOptions.RemoveEmptyEntries)[0].Replace("_Mapping", ""), mapping = item.Replace("</value>", string.Empty).Split(new string[] { "<value>" }, StringSplitOptions.None)[1] };

                string datatypeitem = datatypes.First<string>(a => a.StartsWith(string.Format("<datatype><id>{0}_DataType</id><value>", bm.name)));
                bm.datatype = datatypeitem.Replace(string.Format("<datatype><id>{0}_DataType</id><value>", bm.name), string.Empty).Replace("</value>", string.Empty);

                string descriptionitem = descriptions.First<string>(a => a.StartsWith(string.Format("<description><id>{0}_Description</id><value>", bm.name)));
                bm.description = descriptionitem.Replace(string.Format("<description><id>{0}_Description</id><value>", bm.name), string.Empty).Replace("</value>", string.Empty);

                string longdescriptionitem = longdescriptions.First<string>(a => a.StartsWith(string.Format("<longdescription><id>{0}_LongDescription</id><value>", bm.name)));
                bm.longdesc = longdescriptionitem.Replace(string.Format("<longdescription><id>{0}_LongDescription</id><value>", bm.name), string.Empty).Replace("</value>", string.Empty);

                string actionitem = action.First<string>(a => a.StartsWith(string.Format("<action><id>{0}_Action</id><value>", bm.name)));
                bm.action = actionitem.Replace(string.Format("<action><id>{0}_Action</id><value>", bm.name), string.Empty).Replace("</value>", string.Empty);

                resultList.Add(bm);
            }
            resultList = resultList.OrderByDescending(x => x.action).ToList();
            return resultList;
        }

        protected void UploadDocument_click(object sender, EventArgs e)
        {
            try
            {
                List<BookmarkDto> inputBookmarks = ConstructBookmarks();

                if (!inputBookmarks.Any(bm => bm.mapping == "Counterparty"))
                    throw new Exception("A template must contain a bookmark mapped to 'Counterparty' value.");

                if (i == 0)
                {
                    SPListItemCollection templateItems = ECContext.Current.Lists.ContractTemplate.Items;
                    IEnumerable<SPListItem> foundEqualTitles = (from item in templateItems.Cast<SPListItem>() where (string)item["Title"] == TemplateTitle.Text && item.ID.ToString() != hdnUploadedFileId.Value select item);
                    if (foundEqualTitles.Count() > 0)
                        throw new Exception("A template titled '" + TemplateTitle.Text + "' already exists, please change template title.");
                }

                int templateId = Convert.ToInt32(hdnUploadedFileId.Value);
                SPListItem templateItem = ECContext.Current.Lists.ContractTemplate.GetItemById(templateId);
                templateItem[SPBuiltInFieldId.Title] = TemplateTitle.Text;
                //templateItem["Bilingual"] = chkBilingual.Checked;
                templateItem["Language"] = new SPFieldLookupValue(Convert.ToInt32(ddlLanguage.SelectedValue), ddlLanguage.SelectedItem.Text);
                if (ddlSecondLang.SelectedIndex != 0)
                    templateItem["Second Language"] = new SPFieldLookupValue(Convert.ToInt32(ddlSecondLang.SelectedValue), ddlSecondLang.SelectedItem.Text);
                if (lbDocType.SelectedIndex != 0)
                {
                    SPFieldLookupValueCollection lookupCol = new SPFieldLookupValueCollection();
                    foreach (ListItem itm in lbDocType.Items)
                    {
                        if (itm.Selected)
                            lookupCol.Add(new SPFieldLookupValue(Convert.ToInt32(itm.Value.Replace(";", "").Replace("#", "")), itm.Text));
                    }
                    templateItem["Document Type"] = lookupCol;
                }

                templateItem.SystemUpdate();

                SPFieldLookupValue lookupValue = new SPFieldLookupValue(templateId, TemplateTitle.Text);
                SPList bookmarkLst = ECContext.Current.Lists.Bookmark;

                int order = 0;

                foreach (BookmarkDto item in inputBookmarks)
                {
                    #region BuildFilters
                    string sMapping = string.Empty;
                    if (string.IsNullOrEmpty(item.mapping))
                        sMapping = "<IsNull><FieldRef Name='FieldMapping' /></IsNull>";
                    else
                        sMapping = "<Eq><FieldRef Name='FieldMapping' /><Value Type='Text'>" + item.mapping + "</Value></Eq>";

                    string sDataType = string.Empty;
                    if (string.IsNullOrEmpty(item.datatype))
                        sDataType = "<IsNull><FieldRef Name='Data_x0020_Type' /></IsNull>";
                    else
                        sDataType = "<Eq><FieldRef Name='Data_x0020_Type' /><Value Type='Choice'>" + item.datatype + "</Value></Eq>";

                    string sLongDescription = string.Empty;
                    if (string.IsNullOrEmpty(item.longdesc))
                        sLongDescription = "<IsNull><FieldRef Name='Long_x0020_Description' /></IsNull>";
                    else
                        sLongDescription = "<Eq><FieldRef Name='Long_x0020_Description' /><Value Type='Text'>" + item.longdesc + "</Value></Eq>";


                    string sDescription = string.Empty;
                    if (string.IsNullOrEmpty(item.description))
                        sDescription = "<IsNull><FieldRef Name='Bookmark_x0020_Description' /></IsNull>";
                    else
                        sDescription = "<Eq><FieldRef Name='Bookmark_x0020_Description' /><Value Type='Text'>" + item.description + "</Value></Eq>";
                    #endregion
                    //Check if bookmarks already exists
                    SPQuery query = new SPQuery();
                    query.Query = @"<Where><And><Eq><FieldRef Name='Title' /><Value Type='Text'>" + item.name + "</Value></Eq><And>" + sMapping + "<And>" + sDataType + "<And>" + sLongDescription + sDescription + "</And></And></And></And></Where>";

                    SPListItemCollection items = bookmarkLst.GetItems(query);

                    /* DCC update order for bookmarks */
                    SPListItem templateBookmarkOrderItem = ECContext.Current.Lists.TemplateBookmarksOrder.AddItem();
                    templateBookmarkOrderItem["Template"] = lookupValue;
                    templateBookmarkOrderItem["Bookmark"] = item.name;
                    templateBookmarkOrderItem["Order0"] = order;
                    templateBookmarkOrderItem["Title"] = lookupValue.LookupValue + " - " + item.name;
                    templateBookmarkOrderItem.Update();
                    order = order + 1;
                    /* END DCC*/

                    //if (items[0].Title == item.name)
                    if (bUpload)//Upload template not update
                    {
                        if (items != null && items.Count > 0)   //Bookmark already exists --> Add to multi-lookup
                        {
                            SPListItem firstBookmarkMatched = null;
                            foreach (SPListItem itm in items)
                            {
                                //Check case-sensitive (CAML does not)
                                if (item.name == itm.Name)
                                {
                                    firstBookmarkMatched = itm;
                                    break;
                                }
                            }
                            if (firstBookmarkMatched != null)
                            {
                                SPFieldLookupValueCollection lookupCol = firstBookmarkMatched["Template"] as SPFieldLookupValueCollection;

                                if (!lookupCol.Contains(lookupValue))
                                {
                                    lookupCol.Add(lookupValue);
                                    firstBookmarkMatched["Template"] = lookupCol.ToString();


                                }

                                firstBookmarkMatched.Update();
                            }
                            else
                            {
                                SPListItem newitem = bookmarkLst.AddItem();
                                newitem["Title"] = item.name;
                                SPFieldLookupValueCollection valueCol = new SPFieldLookupValueCollection();
                                valueCol.Add(lookupValue);
                                newitem["Template"] = valueCol;
                                newitem["Data_x0020_Type"] = item.datatype;
                                newitem["Bookmark_x0020_Description"] = item.description;
                                newitem["Long_x0020_Description"] = item.longdesc;


                                if (!string.IsNullOrEmpty(item.mapping))
                                    newitem["FieldMapping"] = item.mapping;

                                newitem.Update();
                            }
                        }
                        else
                        {
                            SPListItem newitem = bookmarkLst.AddItem();
                            newitem["Title"] = item.name;
                            SPFieldLookupValueCollection valueCol = new SPFieldLookupValueCollection();
                            valueCol.Add(lookupValue);
                            newitem["Template"] = valueCol;
                            newitem["Data_x0020_Type"] = item.datatype;
                            newitem["Bookmark_x0020_Description"] = item.description;
                            newitem["Long_x0020_Description"] = item.longdesc;


                            if (!string.IsNullOrEmpty(item.mapping))
                                newitem["FieldMapping"] = item.mapping;

                            newitem.Update();
                        }
                    }
                    else if (item.action == "Add")
                    {
                        SPListItem newitem = bookmarkLst.AddItem();
                        newitem["Title"] = item.name;
                        SPFieldLookupValueCollection valueCol = new SPFieldLookupValueCollection();
                        valueCol.Add(lookupValue);
                        newitem["Template"] = valueCol;
                        newitem["Data_x0020_Type"] = item.datatype;
                        newitem["Bookmark_x0020_Description"] = item.description;
                        newitem["Long_x0020_Description"] = item.longdesc;


                        if (!string.IsNullOrEmpty(item.mapping))
                            newitem["FieldMapping"] = item.mapping;

                        newitem.Update();
                    }
                    else if (item.action == "Update")
                    {
                        SPListItem itemToUpdate = null;
                        SPQuery q = new SPQuery();
                        q.Query = @"<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + item.name + "</Value></Eq></Where>";

                        SPListItemCollection itemsToUpdate = bookmarkLst.GetItems(q);
                        foreach (SPListItem itm in itemsToUpdate)
                        {

                            SPFieldLookupValueCollection lookupCollection = (SPFieldLookupValueCollection)itm["Template"];

                            foreach (SPFieldLookupValue lValue in lookupCollection)
                            {
                                if (lValue.LookupId == lookupValue.LookupId && itm.Name == item.name)
                                {
                                    itemToUpdate = itm;
                                }
                            }

                            if (itemToUpdate != null)
                            {
                                itemToUpdate["Title"] = item.name;
                                SPFieldLookupValueCollection valueCol = new SPFieldLookupValueCollection();
                                itemToUpdate["Data_x0020_Type"] = item.datatype;
                                itemToUpdate["Bookmark_x0020_Description"] = item.description;
                                itemToUpdate["Long_x0020_Description"] = item.longdesc;
                                itemToUpdate["FieldMapping"] = item.mapping;


                                itemToUpdate.Update();
                            }
                        }
                    }
                    else if (item.action == "Remove")
                    {
                        if (items != null && items.Count > 0)
                        {
                            SPListItem firstBookmarkMatched = null;
                            SPFieldLookupValueCollection lookupCol = null;

                            foreach (SPListItem itm in items)
                            {
                                if (itm.Name == item.name)
                                {
                                    SPFieldLookupValueCollection lookupCollection = (SPFieldLookupValueCollection)itm["Template"];

                                    foreach (SPFieldLookupValue lValue in lookupCollection)
                                    {
                                        if (lValue.LookupId == lookupValue.LookupId)
                                        {
                                            firstBookmarkMatched = itm;
                                            lookupCol = lookupCollection;
                                        }
                                    }
                                }
                            }

                            if (lookupCol != null)
                            {
                                if (lookupCol.Count == 1)
                                {
                                    firstBookmarkMatched.Delete();
                                    //firstBookmarkMatched.Update();
                                }
                                else
                                {
                                    lookupCol.Remove(lookupCol.Find(delegate (SPFieldLookupValue LV) { return LV.LookupId == templateId; }));
                                    firstBookmarkMatched["Template"] = lookupCol;
                                    firstBookmarkMatched.Update();
                                }
                            }
                        }
                    }
                    else if (item.action == "DoNothing")
                    {
                        //Do nothing
                    }
                }

                SPUtility.Redirect(SPContext.Current.Web.Url + "/Contract Template", SPRedirectFlags.Default, System.Web.HttpContext.Current);
            }
            catch (ThreadAbortException ex)
            {
                //if (ex.InnerException != null)
                //    throw ex;
                // Swallow bogus redirect exception
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                ECContext.AddLogEntry("UploadTemplate.cs - UploadDocument - Error uploading contract " + ex.Message, SPContext.Current.Web);
                CEJSUtil.PopError(Page, "There were validation errors. Please review the problems listed below.", "<ul class=\"ms-dlg-error-list\"><li>" + ex.Message + "</li></ul>");
            }

        }

        protected void ddlDescription_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlDescription = (DropDownList)sender;
            string ddlDescription_ce_name = ddlDescription.Attributes["ce_name"].Replace("_Description", "");
            DropDownList ddlMapping = null;
            DropDownList ddlDataType = null;
            DropDownList ddlLongDesc = null;
            TextBox txtLongDesc = null;
            foreach (Control ctrl in DynaCtrls.Controls)
            {
                if (ctrl is DropDownList)
                {
                    if (((DropDownList)ctrl).Attributes["ce_name"] == ddlDescription_ce_name + "_Mapping")
                    {
                        ddlMapping = (DropDownList)ctrl;
                    }
                    else if (((DropDownList)ctrl).Attributes["ce_name"] == ddlDescription_ce_name + "_DataType")
                    {
                        ddlDataType = (DropDownList)ctrl;
                    }
                    else if (((DropDownList)ctrl).Attributes["ce_name"] == ddlDescription_ce_name + "_LongDescription")
                    {
                        ddlLongDesc = (DropDownList)ctrl;
                    }
                }
                else if (ctrl is TextBox)
                {
                    if (((TextBox)ctrl).Attributes["ce_name"] == ddlDescription_ce_name + "_LongDescriptionTXT")
                    {
                        txtLongDesc = (TextBox)ctrl;
                    }
                    else if (((TextBox)ctrl).Attributes["ce_name"] == ddlDescription_ce_name + "_DescriptionTXT")
                    {
                        txtDescription = (TextBox)ctrl;
                    }
                }
                if (ddlMapping != null && ddlDataType != null && ddlLongDesc != null && txtLongDesc != null)
                    break;
            }
            //DropDoddlLongDescwnList ddlMapping = (DropDownList)DynaCtrls.FindControl(ddlDescription_ce_name + "_Mapping");
            //DropDownList ddlDataType = (DropDownList)DynaCtrls.FindControl(ddlDescription_ce_name + "_DataType");
            //DropDownList ddlLongDesc = (DropDownList)DynaCtrls.FindControl(ddlDescription_ce_name + "_LongDescription");
            //TextBox txtLongDesc =  (TextBox)DynaCtrls.FindControl(ddlDescription.ID + "_LongDescriptionTXT"); 

            //Get Mapping, DataType, LongDescription
            SPList bookmarkLst = ECContext.Current.Lists.Bookmark;
            //SPListItemCollection bookmarksItems = bookmarkLst.Items;

            //IEnumerable<SPListItem> itemsWithCurrentDescription = (from SPListItem listItem in bookmarksItems
            //                                                       where
            //                                                           //(string)listItem["Data Type"] == item.datatype &&
            //                                                       (listItem["Bookmark Description"] == null ? "" : (string)listItem["Bookmark Description"]) == ddlDescription.SelectedItem.Text
            //                                                       //(listItem["FieldMapping"] == null ? "" : (string)listItem["FieldMapping"]) == item.mapping &&
            //                                                       //(listItem["Long Description"] == null ? "" : (string)listItem["Long Description"]) == item.longdesc
            //                                                       select listItem);

            SPQuery query = new SPQuery();
            query.Query = "<Where><Eq><FieldRef Name='Bookmark_x0020_Description'/><Value Type='Text'>" + ddlDescription.SelectedItem.Text + "</Value></Eq></Where>";
            SPListItemCollection itemsWithCurrentDescription = bookmarkLst.GetItems(query);

            if (itemsWithCurrentDescription != null && itemsWithCurrentDescription.Count > 0)   //Bookmark already exists --> Add to multi-lookup
            {
                //Get most popular bookmark
                BookmarkDto popularItem = GetMostPopularBookmark(itemsWithCurrentDescription);

                if (popularItem.mapping != null)
                {
                    //ddlMapping.Items.Add(firstItem["FieldMapping"].ToString());
                    ddlMapping.SelectedValue = popularItem.mapping;
                }

                if (popularItem.datatype != null)
                {
                    //ddlDataType.Items.Add(firstItem["Data Type"].ToString());
                    ddlDataType.SelectedValue = popularItem.datatype;
                }
                if (popularItem.longdesc != null)
                {
                    ddlLongDesc.Items.Clear();
                    ddlLongDesc.Items.Add(popularItem.longdesc);
                    ddlLongDesc.SelectedValue = popularItem.longdesc;
                }

            }


            if (ddlLongDesc != null && ddlDescription != null && ddlDataType != null)
            {
                List<string> bmList = new List<string>();
                try
                {
                    //SPList oList = ECContext.Current.Lists.Bookmark;
                    //SPListItemCollection oListItems = oList.Items;
                    //List<SPListItem> items2 = (from SPListItem listItem in itemsWithCurrentDescription
                    //                           where //(string)listItem.Name == item.name &&
                    //                           (string)listItem["Data Type"] == ddlDataType.SelectedItem.Text &&
                    //                               //(listItem["Bookmark Description"] == null ? "" : (string)listItem["Bookmark Description"]) == ddlDescription.SelectedItem.Text &&
                    //                           (listItem["FieldMapping"] == null ? "" : (string)listItem["FieldMapping"]) == ddlMapping.SelectedItem.Value
                    //                           select listItem).ToList();

                    SPQuery query2 = new SPQuery();
                    query2.Query = "<Where><And><Eq><FieldRef Name='Data_x0020_Type'/><Value Type='Text'>" + ddlDataType.SelectedItem.Text + "</Value></Eq>" +
                                            "<Eq><FieldRef Name='FieldMapping'/><Value Type='Text'>" + ddlMapping.SelectedItem.Value + "</Value></Eq></And></Where>";
                    SPListItemCollection items2 = ECContext.Current.Lists.Bookmark.GetItems(query2);

                    ddlLongDesc.Items.Clear();
                    foreach (SPListItem oItem in items2)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(oItem["Long Description"])))
                            ddlLongDesc.Items.Add(oItem["Long Description"].ToString());
                    }
                    ddlLongDesc.Items.Add("Type yours...");


                }
                catch (Exception ex)
                {
                    ECContext.AddLogEntry("UploadTemplate.cs - ddlDescription_SelectedIndexChanged. " + ex.Message, SPContext.Current.Web);
                    ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                }

            }
            Page.SetFocus(ddlDescription);
        }

        private BookmarkDto GetMostPopularBookmark(SPListItemCollection bookmarks)
        {
            BookmarkDto popularBookmark = new BookmarkDto();
            string blank = "_blank";
            if (bookmarks.Count > 0)
            {
                Dictionary<string, int> mappings = new Dictionary<string, int>();
                Dictionary<string, int> types = new Dictionary<string, int>();
                Dictionary<string, int> longdescs = new Dictionary<string, int>();

                foreach (SPListItem item in bookmarks)
                {
                    //mappings
                    string map = (string)item["FieldMapping"];
                    if (!String.IsNullOrEmpty(map))
                    {
                        if (mappings.ContainsKey(map))
                            mappings[map] += 1;
                        else
                            mappings.Add(map, 1);
                    }
                    else
                    {
                        if (mappings.ContainsKey(blank))
                            mappings[blank] += 1;
                        else
                            mappings.Add(blank, 1);
                    }

                    //type
                    string type = (string)item["Data Type"];
                    if (!String.IsNullOrEmpty(type))
                    {
                        if (types.ContainsKey(type))
                            types[type] += 1;
                        else
                            types.Add(type, 1);
                    }
                    else
                    {
                        if (types.ContainsKey(blank))
                            types[blank] += 1;
                        else
                            types.Add(blank, 1);
                    }

                    //long description
                    string longDesc = (string)item["Long Description"];
                    if (!String.IsNullOrEmpty(longDesc))
                    {
                        if (longdescs.ContainsKey(longDesc))
                            longdescs[longDesc] += 1;
                        else
                            longdescs.Add(longDesc, 1);
                    }
                    else
                    {
                        if (longdescs.ContainsKey(blank))
                            longdescs[blank] += 1;
                        else
                            longdescs.Add(blank, 1);
                    }

                }

                popularBookmark.mapping = mappings.Count > 0 ? mappings.FirstOrDefault(x => x.Value == mappings.Values.Max()).Key : "";
                popularBookmark.datatype = types.Count > 0 ? types.FirstOrDefault(x => x.Value == types.Values.Max()).Key : "";
                popularBookmark.longdesc = longdescs.Count > 0 ? longdescs.FirstOrDefault(x => x.Value == longdescs.Values.Max()).Key : "";
                //popularBookmark.template = bookmarks[0]["Template"].ToString();

                if (popularBookmark.mapping == blank)
                    popularBookmark.mapping = "";

                if (popularBookmark.longdesc == blank)
                    popularBookmark.longdesc = "";

                if (popularBookmark.datatype == blank)
                    popularBookmark.datatype = "Text";

            }

            return popularBookmark;
        }

        private BookmarkDto GetMostPopularBookmarkByNameDescription(string name, string description)
        {
            //SPListItemCollection bookItems = ECContext.Current.Lists.Bookmark.Items;
            //List<SPListItem> items = (from SPListItem listItem in bookItems
            //                          where (string)listItem.Name == name &&
            //                          (listItem["Bookmark Description"] == null ? "" : (string)listItem["Bookmark Description"]) == description
            //                          select listItem).ToList();

            SPQuery query = new SPQuery();
            //Comment Venu, Date 21 March, Commented below query and added new query, added a new condition with template name. Previously only Bookmark name and Bookmark description was there in the query
            //query.Query = "<Where><And><Eq><FieldRef Name='Title'/><Value Type='Text'>" + name + "</Value></Eq>" +
            //                        "<Eq><FieldRef Name='Bookmark_x0020_Description'/><Value Type='Text'>" + description + "</Value></Eq></And></Where>";
            query.Query = "<Where><And><Eq><FieldRef Name='Title' /><Value Type='Text'>" + name + "</Value></Eq><And><Eq><FieldRef Name='Bookmark_x0020_Description' /><Value Type='Text'>" + description + "</Value></Eq><Eq><FieldRef Name='Template' /><Value Type='LookupMulti'>" + hlContract.Text + "</Value></Eq></And></And></Where>";
            query.ViewFields = string.Concat(
                                   "<FieldRef Name='FieldMapping' />",
                                   "<FieldRef Name='Template' />",
                                   "<FieldRef Name='Long_x0020_Description' />",
                                   "<FieldRef Name='Data_x0020_Type' />");
            SPListItemCollection items = ECContext.Current.Lists.Bookmark.GetItems(query);

            return GetMostPopularBookmark(items);
        }

        private List<string> GetListOfLongDescriptions()
        {
            SPQuery query = new SPQuery();
            //query.Query = "<OrderBy><FieldRef Name='Long_x0020_Description' Ascending='FALSE' /></OrderBy>";
            query.ViewFields = string.Concat("<FieldRef Name='Long_x0020_Description' />");
            SPListItemCollection items = ECContext.Current.Lists.Bookmark.GetItems(query);
            List<string> returnValues = new List<string>();
            string longDesc;
            foreach (SPListItem item in items)
            {
                if (item["Long_x0020_Description"] != null)
                {
                    longDesc = (string)item["Long_x0020_Description"];
                    if (!String.IsNullOrEmpty(longDesc))
                    {
                        returnValues.Add(longDesc);
                    }
                }
            }

            return returnValues.Distinct().ToList().OrderBy(s => s).ToList();
        }

        private void SetBookmarkDescriptionValues(string bookmark, ref DropDownList ddlDescription)
        {
            try
            {
                SPList oList = ECContext.Current.Lists.Bookmark;

                if (oList != null)
                {

                    SPQuery query = new SPQuery();
                    query.Query = "<Where><Eq><FieldRef Name='Title'/><Value Type='Text'>" + bookmark + "</Value></Eq></Where>";
                    query.ViewFields = "<FieldRef Name='Bookmark_x0020_Description'/>";
                    SPListItemCollection itemCol = oList.GetItems(query);

                    //var distinctItems = (from SPListItem item in itemCol select item["Bookmark_x0020_Description"]).Take(25).Distinct().ToArray();
                    //for (int i = 0; i < distinctItems.Length; i++)
                    //{
                    //    if (distinctItems[i] != null)
                    //        ddlDescription.Items.Add(distinctItems[i].ToString());
                    //}
                    foreach (SPListItem itm in itemCol)
                    {
                        ListItem bookDesc = new ListItem((string)itm["Bookmark_x0020_Description"]);

                        if (!ddlDescription.Items.Contains(bookDesc) && bookDesc.Value != String.Empty)
                        {
                            ddlDescription.Items.Add(bookDesc);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                ECContext.AddLogEntry("UploadTemplate.cs - SetBookmarkDescriptionValues. " + ex.Message, SPContext.Current.Web);
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }

        private Dictionary<string, ECContext.Bookmark> GetNewAndOldBookmarks(int oldTemplateId)
        {
            if (bmAll == null)
            {
                Dictionary<string, ECContext.Bookmark> oldData;
                //List<ECContext.Bookmark> oldDataSort;
                Dictionary<string, ECContext.Bookmark> newData;
                //List<ECContext.Bookmark> newDataSort;


                // Get bookmark config for existing template
                oldData = GetOldTemplate(oldTemplateId);
                //oldDataSort = oldData.Values.OrderBy(x => x.Name).ToList();


                // Extract bookmarks from new template
                SPListItem itm = ECContext.Current.Lists.ContractTemplate.GetItemById(Convert.ToInt32(hdnUploadedFileId.Value));
                Stream str = itm.File.OpenBinaryStream();
                newData = AnalyseTemplate(str);

                bmFromNewTpl = (from ECContext.Bookmark bm in newData.Values
                                where newData.ContainsKey(bm.Name)
                                select bm).ToList();


                bmFromList = (from ECContext.Bookmark bm in oldData.Values
                              where oldData.ContainsKey(bm.Name)
                              select bm).ToList();

                //DCC bmAll = newData.Values.OrderBy(x => x.Name).ToList();
                bmAll = newData.Values.ToList();

                duplicated = new List<ECContext.Bookmark>();
                foreach (ECContext.Bookmark bm in bmFromList)
                {
                    List<ECContext.Bookmark> tmp = bmAll.FindAll(x => x.Name == bm.Name);
                    if (tmp.Count == 0)
                    {
                        tmp = bmAll.FindAll(x => x.Name.ToLower() == bm.Name.ToLower());
                        if (tmp.Count == 0)
                            bmAll.Add(bm);
                        else
                            duplicated.Add(bm);
                    }
                }
            }
            //dcc return bmAll.OrderBy(x => x.Name).ToDictionary(bm => bm.Name);
            return bmAll.ToDictionary(bm => bm.Name);
        }

        private Dictionary<string, ECContext.Bookmark> AnalyseTemplate(Stream src)
        {
            try
            {
                var buf = ECContext.OpenXml.ReadFully(src);

                using (MemoryStream ms = new MemoryStream(buf))
                {
                    var bookmarkList = ECContext.OpenXml.FindBookmarks(ms);

                    return bookmarkList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private Dictionary<string, ECContext.Bookmark> GetOldTemplate(int tplId)
        {
            var dict = (from SPListItem itm in ECContext.Current.Lists.Bookmark.Items
                        where itm["Template"] != null &&
                        (from SPFieldLookupValue vc in (SPFieldLookupValueCollection)itm["Template"] where vc.LookupId == tplId select vc).FirstOrDefault() != null
                        select new ECContext.Bookmark
                        {
                            Name = itm.Name,
                            ItemID = itm.ID,
                            Mapping = (string)itm["FieldMapping"],
                            DataType = (string)itm["Data_x0020_Type"],
                            Description = (string)itm["Bookmark_x0020_Description"],
                            LongDescription = (string)itm["Long_x0020_Description"]
                        }).ToDictionary(bm => bm.Name);

            return dict;
        }

        private SPListItem GetOldTemplateListItem(int tplID)
        {
            SPListItem item = null;
            try
            {
                string sQuery = string.Format(@"<Where><Eq><FieldRef Name='ID'/><Value Type='Number'>{0}</Value></Eq></Where>", tplID);
                //string sViewFields = @"<FieldRef Name=""ID"" />";
                string sViewAttrs = @"Scope=""Recursive""";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = sQuery;
                //oQuery.ViewFields = sViewFields;
                oQuery.ViewAttributes = sViewAttrs;
                oQuery.RowLimit = iRowLimit;

                SPListItemCollection collListItems = ECContext.Current.Lists.ContractTemplate.GetItems(oQuery);
                if (collListItems.Count == 1)
                {
                    item = collListItems[0];
                }
            }
            catch (Exception ex)
            {
                ECContext.AddLogEntry("UploadTemplate.cs - GetOldTemplateListItem. " + ex.Message, SPContext.Current.Web);
            }
            return item;
        }

        private int RemoveCloneRightsbyTemplateName(String TemplateName)
        {
            int itemsUpdated = 0;

            try
            {
                string sQuery = string.Format(@"<Where><Eq><FieldRef Name='{0}'/><Value Type='Text'>{1}</Value></Eq></Where>", ECContext.Current.Configuration.ECFields.Template, TemplateName);
                //string sViewFields = @"<FieldRef Name=""ID"" />";
                string sViewAttrs = @"Scope=""Recursive""";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = sQuery;
                //oQuery.ViewFields = sViewFields;
                oQuery.ViewAttributes = sViewAttrs;
                oQuery.RowLimit = iRowLimit;

                SPListItemCollection collListItems = ECContext.Current.Lists.ExpressContract.GetItems(oQuery);

                ECContext.Current.CurrentWeb.AllowUnsafeUpdates = true;
                DisabledItemEventsScope disEvnt = new DisabledItemEventsScope();
                disEvnt.DisabledItemEvents();

                foreach (SPListItem item in collListItems)
                {
                    try
                    {
                        if (item[ECContext.Current.Configuration.ECFields.Cloneable] != null &&
                            ((Boolean)item[ECContext.Current.Configuration.ECFields.Cloneable]) == true)
                        {
                            SPSecurity.RunWithElevatedPrivileges(delegate ()
                            {
                                item[ECContext.Current.Configuration.ECFields.Cloneable] = false;
                                item[ECContext.Current.Configuration.ECFields.AutomaticApproval] = false;
                                item[ECContext.Current.Configuration.ECFields.CloneExpirationDate] = null;
                                item[ECContext.Current.Configuration.ECFields.CloningDate] = null;
                                item.SystemUpdate(false);
                            });
                            itemsUpdated = itemsUpdated + 1;
                        }
                    }
                    catch (Exception ecp)
                    {
                        ECContext.LogEvent(ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    }
                }
                //ECContext.Current.Lists.ExpressContract.Update();

                //ECContext.Current.CurrentWeb.Update();
                ECContext.Current.CurrentWeb.AllowUnsafeUpdates = false;
            }
            catch (Exception ex)
            {
                ECContext.AddLogEntry("UploadTemplate.cs - RemoveCloneRightsbyTemplateName. " + ex.Message, SPContext.Current.Web);
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }

            return itemsUpdated;
        }

    }
}
