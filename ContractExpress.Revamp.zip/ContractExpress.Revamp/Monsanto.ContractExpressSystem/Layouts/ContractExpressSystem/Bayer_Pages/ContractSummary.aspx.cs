﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using System.Web.UI;
using System.Data;
using System.Linq;
using System.Data.Linq;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using Microsoft.SharePoint.Utilities;
using System.Web;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Reflection;
using System.Globalization;
using Bayer.BCS.ContractExpressSsytem.HtmlToOpenXml;
using Microsoft.SharePoint.Administration;
using System.Text.RegularExpressions;
using Bayer.BCS.ContractExpressSystem;

using Newtonsoft.Json;
using System.Threading;

namespace Bayer.BCS.ContractExpressSystem.Layouts.ContractExpressSystem.Bayer_Pages
{
    public partial class ContractSummary : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        #region controls
        private int? _clonedContractId;
        private int? _contractId;
        private SPListItem _clonedContract;
        private SPListItem _currentContract;
        protected PlaceHolder DynaCtrls;
        protected Literal customMsg;
        protected HtmlInputHidden hdnUrl;
        #endregion

        protected override void CreateChildControls()
        {
            try
            {
                if (!IsPostBack)
                {
                    int clonedContractId;
                    if (int.TryParse((string)Request.QueryString["clonedContractId"], out clonedContractId))
                    {
                        _clonedContractId = clonedContractId;
                        _clonedContract = ECContext.Current.Lists.ExpressContract.GetItemById(clonedContractId);
                    }
                    int contractId;
                    if (int.TryParse((string)Request.QueryString["itemid"], out contractId))
                    {
                        _contractId = contractId;
                        _currentContract = ECContext.Current.Lists.ExpressContract.GetItemById(contractId);
                    }

                    customMsg.Text = ECContext.Current.Configuration.ContractSummaryPageMessage;

                    if (_currentContract != null)
                    {
                        //BuildContractsComparison();
                    }

                }
                hdnUrl.Value = ECContext.Current.CurrentWeb.Site.Url;

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        protected void RedirectHome(object sender, EventArgs e)
        {
            try
            {
                SPUtility.Redirect(SPContext.Current.Site.RootWeb.Url, SPRedirectFlags.Static, HttpContext.Current);
            }
            catch (ThreadAbortException)
            {
                // Swallow bogus exception caused by redirect
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

        }

        private void BuildContractsComparison()
        {
            try
            {
                BuildBookmarksComparison();
                BuildFCPAComparison();
                //BuildApprovalComparison();
                BuildContractsAttachments();
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error building contracts comparisson. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void BuildBookmarksComparison()
        {

            Dictionary<string, ECContext.Bookmark> clonedContractBookmarks = new Dictionary<string, ECContext.Bookmark>();
            Dictionary<string, ECContext.Bookmark> contractBookmarks = new Dictionary<string, ECContext.Bookmark>();

            Table table = new Table();
            table.CssClass = "contractComparison";
            table.Controls.Add(BuildTableHeader("20%", "40%", "40%"));

            if (_clonedContractId.HasValue)
                clonedContractBookmarks = GetContractBookmarksContent(_clonedContractId.Value);

            if (_contractId.HasValue)
                contractBookmarks = GetContractBookmarksContent(_contractId.Value);

            foreach (KeyValuePair<string, ECContext.Bookmark> bookmark in (clonedContractBookmarks.Count() > contractBookmarks.Count() ? clonedContractBookmarks : contractBookmarks))
            {
                string currentContractBookmarkContent = contractBookmarks.Where(b => b.Value.Name == bookmark.Value.Name).Count() > 0 ? contractBookmarks.Where(b => b.Value.Name == bookmark.Value.Name).FirstOrDefault().Value.Content : "Value not found on contract";
                string clonedContractBookmarkContent = clonedContractBookmarks.Where(b => b.Value.Name == bookmark.Value.Name).Count() > 0 ? clonedContractBookmarks.Where(b => b.Value.Name == bookmark.Value.Name).FirstOrDefault().Value.Content : "Value not found on contract";

                if (clonedContractBookmarkContent != currentContractBookmarkContent || _clonedContract == null)
                {
                    TableRow tr = new TableRow();
                    TableCell tdDescription = new TableCell();
                    TableCell tdCloned = new TableCell();
                    TableCell tdCurrent = new TableCell();

                    tdDescription.Text = bookmark.Value.Name + ":";
                    tdDescription.Attributes.Add("style", "width:20%");
                    tdDescription.CssClass = "fieldname";
                    tr.Controls.Add(tdDescription);

                    if (_clonedContract != null)
                    {
                        tdCloned.Text = clonedContractBookmarkContent;
                        tdCloned.Attributes.Add("style", "width:40%");
                        tr.Controls.Add(tdCloned);
                    }

                    tdCurrent.Text = currentContractBookmarkContent;
                    tdCurrent.Attributes.Add("style", "width:40%");
                    tr.Controls.Add(tdCurrent);

                    table.Controls.Add(tr);
                }
            }

            DynaCtrls.Controls.Add(BuildSectionTitle("Bookmarks"));
            AddTableToHolder(table);
        }

        private void BuildFCPAComparison()
        {
            Table table = new Table();
            table.CssClass = "contractComparison questionForm";
            table.Controls.Add(BuildTableHeader("70%", "15%", "15%"));

            //Add SAPVendorNumber
            TableRow trSAP = new TableRow();
            TableCell tdDescriptionSAP = new TableCell();
            TableCell tdCurrentSAP = new TableCell();
            TableCell tdClonedSAP = new TableCell();
            tdDescriptionSAP.Text = "SAP Vendor Number";
            tdDescriptionSAP.CssClass = "fieldname";
            tdCurrentSAP.Text = (string)_currentContract["Sap Vendor Number"];
            trSAP.Controls.Add(tdDescriptionSAP);
            trSAP.Controls.Add(tdCurrentSAP);
            if (_clonedContract != null)
            {
                tdClonedSAP.Text = (string)_clonedContract["Sap Vendor Number"];
                trSAP.Controls.Add(tdClonedSAP);
            }
            table.Controls.Add(trSAP);

            //Add answers
            Dictionary<string, Dictionary<string, string>> sections = new FCPAQuestionFrom().GetSections();

            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    string clonedAnswerValue = String.Empty;

                    if (_clonedContractId.HasValue)
                        clonedAnswerValue = ECContext.GetQuestionAnswer(_clonedContractId.Value, Convert.ToInt32(question.Key), ECContext.QuestionType.FCPA);
                    if (string.IsNullOrEmpty(clonedAnswerValue))
                        clonedAnswerValue = "false";

                    string contractAnswerValue = ECContext.GetQuestionAnswer(_contractId.Value, Convert.ToInt32(question.Key), ECContext.QuestionType.FCPA);
                    if (string.IsNullOrEmpty(contractAnswerValue))
                        contractAnswerValue = "false";


                    if (clonedAnswerValue != contractAnswerValue || _clonedContract == null)
                    {
                        TableRow tr = new TableRow();
                        TableCell tdDescription = new TableCell();
                        TableCell tdCloned = new TableCell();
                        TableCell tdCurrent = new TableCell();

                        tdDescription.Text = question.Value;
                        tdDescription.Attributes.Add("style", "width:70%");
                        tdDescription.CssClass = "fieldname";
                        tr.Controls.Add(tdDescription);

                        if (_clonedContract != null)
                        {
                            tdCloned.Text = !string.IsNullOrEmpty(clonedAnswerValue) ? clonedAnswerValue : "Value not set";
                            tdCloned.Attributes.Add("style", "width:15%");
                            tr.Controls.Add(tdCloned);
                        }

                        tdCurrent.Text = !string.IsNullOrEmpty(contractAnswerValue) ? contractAnswerValue : "Value not set";
                        tdCurrent.Attributes.Add("style", "width:15%");
                        tr.Controls.Add(tdCurrent);

                        table.Controls.Add(tr);

                    }
                }
            }

            DynaCtrls.Controls.Add(BuildSectionTitle("FCPA Questions"));



            AddTableToHolder(table);
        }

        private void BuildApprovalComparison()
        {
            Dictionary<string, Dictionary<string, string>> sections = new ApprovalForm().GetSections();

            DynaCtrls.Controls.Add(BuildSectionTitle("Approval Questions"));

            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                Literal sectionTitle = new Literal();
                sectionTitle.Text = "<div style='line-height:25px; font-weight:bold;'>" + section.Key + "</div>";
                DynaCtrls.Controls.Add(sectionTitle);
                Table table = new Table();
                table.CssClass = "contractComparison questionForm";
                table.Controls.Add(BuildTableHeader("30%", "35%", "35%"));

                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    string clonedAnswerValue = string.Empty;
                    if (_clonedContractId.HasValue)
                        clonedAnswerValue = ECContext.GetQuestionAnswer(_clonedContractId.Value, Convert.ToInt32(question.Key), ECContext.QuestionType.Approval);

                    string contractAnswerValue = ECContext.GetQuestionAnswer(_contractId.Value, Convert.ToInt32(question.Key), ECContext.QuestionType.Approval);

                    if (clonedAnswerValue != contractAnswerValue || _clonedContract == null)
                    {
                        TableRow tr = new TableRow();
                        TableCell tdDescription = new TableCell();
                        TableCell tdCloned = new TableCell();
                        TableCell tdCurrent = new TableCell();

                        tdDescription.Text = question.Value;
                        tdDescription.Attributes.Add("style", "width:30%");
                        tdDescription.CssClass = "fieldname";
                        tr.Controls.Add(tdDescription);

                        if (_clonedContract != null)
                        {
                            tdCloned.Text = !string.IsNullOrEmpty(clonedAnswerValue) ? clonedAnswerValue : "Value not set";
                            tdCloned.Attributes.Add("style", "width:35%");
                            tr.Controls.Add(tdCloned);
                        }

                        tdCurrent.Text = !string.IsNullOrEmpty(contractAnswerValue) ? contractAnswerValue : "Value not set"; ;
                        tdCurrent.Attributes.Add("style", "width:35%");
                        tr.Controls.Add(tdCurrent);

                        table.Controls.Add(tr);
                    }
                }

                AddTableToHolder(table);
            }
        }

        private void BuildContractsAttachments()
        {
            Table table = new Table();
            table.CssClass = "contractComparison questionForm";
            table.Controls.Add(BuildTableHeader("0%", "10%", "10%"));
            TableRow tr = new TableRow();
            TableCell tdCloned = new TableCell();
            TableCell tdCurrent = new TableCell();
            SPList attachmentsList = ECContext.Current.CurrentWeb.Lists.TryGetList("Express contracts Attachments");

            if (_clonedContract != null)
            {
                SPFieldLookupValueCollection clonedContractAttachs = new SPFieldLookupValueCollection(Convert.ToString(_clonedContract["Documents Attached"]));

                if (clonedContractAttachs.Count > 0)
                {
                    foreach (SPFieldLookupValue attach in clonedContractAttachs)
                    {
                        HyperLink attachLink = new HyperLink();
                        SPListItem attachItem = attachmentsList.GetItemById(attach.LookupId);
                        if (attachItem != null)
                        {
                            attachLink.NavigateUrl = ECContext.Current.CurrentWeb.Url + "/" + attachItem.File.Url;
                            attachLink.Text = attachItem.Title;
                            attachLink.CssClass = "attachLink";
                            tdCloned.Controls.Add(attachLink);
                        }
                    }
                }
                //Set deafult value if empty
                if (tdCloned.Controls.Count == 0)
                    SetAttachDefaultValue(tdCloned);

                //Add controls
                tr.Controls.Add(tdCloned);
            }

            if (_currentContract != null)
            {
                SPFieldLookupValueCollection currentContractAttachs = new SPFieldLookupValueCollection(Convert.ToString(_currentContract["Documents Attached"]));

                if (currentContractAttachs.Count > 0)
                {
                    foreach (SPFieldLookupValue attach in currentContractAttachs)
                    {
                        HyperLink attachLink = new HyperLink();
                        SPListItem attachItem = attachmentsList.GetItemById(attach.LookupId);
                        if (attachItem != null)
                        {
                            attachLink.NavigateUrl = ECContext.Current.CurrentWeb.Url + "/" + attachItem.File.Url;
                            attachLink.Text = attachItem.Title;
                            attachLink.CssClass = "attachLink";
                            tdCurrent.Controls.Add(attachLink);
                        }
                    }
                }

                //Set deafult value if empty
                if (tdCurrent.Controls.Count == 0)
                    SetAttachDefaultValue(tdCurrent);

                //Add controls
                tr.Controls.Add(tdCurrent);
            }

            table.Controls.Add(tr);
            DynaCtrls.Controls.Add(BuildSectionTitle("Attachments"));
            DynaCtrls.Controls.Add(table);
        }

        private Dictionary<string, ECContext.Bookmark> GetContractBookmarksContent(int contractItemId)
        {
            Dictionary<string, ECContext.Bookmark> contractBookmarks = new Dictionary<string, ECContext.Bookmark>();

            //Get bookmarks and content from comtract document
            SPList expresscontractsList = ECContext.Current.Lists.ExpressContract;
            SPListItem contractToClone = expresscontractsList.GetItemById(contractItemId);
            contractBookmarks = ECContext.OpenXml.FindBookmarksAndContent(contractToClone.File.OpenBinaryStream(SPOpenBinaryOptions.SkipVirusScan));

            return contractBookmarks;
        }

        private Panel BuildSectionTitle(string title)
        {
            Panel titlePnl = new Panel();
            Literal titleLt = new Literal();

            titleLt.Text = "<strong>" + title + "</strong>";
            titlePnl.CssClass = "steptitle";
            titlePnl.Controls.Add(titleLt);
            return titlePnl;
        }

        private TableHeaderRow BuildTableHeader(string col1Width, string col2Witdh, string col3Width)
        {
            TableHeaderRow head = new TableHeaderRow();
            TableHeaderCell headCell = new TableHeaderCell();
            TableHeaderCell headCell2 = new TableHeaderCell();
            TableHeaderCell headCell3 = new TableHeaderCell();

            if (col1Width != "0%")
            {
                headCell.Attributes.Add("style", "width:" + col1Width);
                head.Controls.Add(headCell);
            }

            if (_clonedContract != null)
            {
                headCell2.Attributes.Add("style", "width:" + col2Witdh);
                headCell2.Text = "ORIGINAL CONTRACT <br/>[" + _clonedContract.Title + "]";
                head.Controls.Add(headCell2);
            }

            headCell3.Attributes.Add("style", "width:" + col3Width);
            headCell3.Text = "NEW CONTRACT <br/>[" + _currentContract.Title + "]";
            head.Controls.Add(headCell3);

            return head;
        }

        private void AddTableToHolder(Table table)
        {
            if (table.Rows.Count == 1)
            {

                Literal emptyTable = new Literal();
                emptyTable.Text = "<div style='margin-top:10px;'>No differences found between contracts in this section.</div>";
                DynaCtrls.Controls.Add(emptyTable);
            }
            else
            {
                DynaCtrls.Controls.Add(table); 
            }
        }

        private void SetAttachDefaultValue(TableCell cell)
        {
            Literal notFoundAttach = new Literal();
            notFoundAttach.Text = "This contract does not contain any attachment.";
            if (cell.Controls.Count == 0)
                cell.Controls.Add(notFoundAttach);
        }
    }
}
