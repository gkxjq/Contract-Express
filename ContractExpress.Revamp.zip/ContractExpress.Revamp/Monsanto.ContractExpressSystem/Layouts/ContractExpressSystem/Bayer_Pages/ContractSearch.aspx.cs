﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Bayer.BCS.ContractExpressSystem.Layouts.ContractExpressSystem.Bayer_Pages
{
    public partial class ContractSearch : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
