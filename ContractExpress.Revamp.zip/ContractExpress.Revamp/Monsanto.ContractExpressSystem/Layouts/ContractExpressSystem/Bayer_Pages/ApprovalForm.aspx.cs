﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint;
using System.Web.UI.WebControls;
using System.Web.UI;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using System.Collections.Specialized;
using System.Threading;
using System.IO;
using System.Globalization;

namespace Bayer.BCS.ContractExpressSystem.Layouts.ContractExpressSystem.Bayer_Pages
{
    public partial class ApprovalForm : LayoutsPageBase
    {
        #region controls
        protected PlaceHolder DynaCtrls;
        protected RadioButton Approved;
        protected RadioButton Rejected;
        protected RadioButton Pending;
        protected RadioButton PendingBusiness;
        protected CheckBox RejectedQuestions;
        protected CheckBox RejectedBookmarks;
        protected TextBox txtApprove;
        protected TextBox txtRejectQuestion;
        protected TextBox txtRejectDocument;
        protected TextBox txtPending;
        protected LinkButton Submit;
        protected Panel RejectPnl;
        protected Panel pnlApproveReason;
        protected Panel pnlRejectReason;
        protected Panel pnlPendingReason;
        protected Panel pnlStepThree;
        protected Panel pnlError;
        protected Label lblError;
        protected Label lbWarningMessage;
        protected Panel WarningDIV;
        protected Panel pnlWarningMsg;
        protected Panel pnlCloningSection;
        protected CheckBox chkCloneable;
        protected CheckBox chkAutomaticApproval;
        protected DateTimeControl ExpirationDate;

        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    

        #region GlobalVARS
        private string IDs;
        private string approvalOption;
        private string typeApproval;
        #endregion

        protected override void CreateChildControls()
        {
            try
            {
                if (Request.QueryString["ItemId"] != null)
                {
                    IDs = Request.QueryString["ItemId"].ToString();
                }

                if (Request.QueryString["type"] != null)
                {
                    typeApproval = Request.QueryString["type"].ToString();
                }

                if (Request.QueryString["approval"] != null)
                {
                    approvalOption = Request.QueryString["approval"].ToString();
                }

                if (IDs.Split(',').Count() > 1)
                {
                    MassApproval();
                }
                else
                {

                    SPListItemCollection collection = ECContext.Current.Lists.ExpressContract.GetItems(new SPQuery() { Query = string.Format("<Where><Eq><FieldRef Name='ID' /><Value Type='Counter'>{0}</Value></Eq></Where>", Request.QueryString["itemid"]) });
                    if (collection.Count != 1)
                    {
                        CEJSUtil.PopError(this, "Error", "The item selected for approval does not exist, check to see if it has not been deleted.");
                        Submit.Enabled = false;
                    }
                    else
                    {
                        SPListItem item = collection[0];
                        DynaCtrls.Controls.Add(new LiteralControl(string.Format("<span>This is the <strong>{0}</strong> approval form for the contract item <strong>{1}</strong>. Please select one of the options below for this approval.</span>", Request.QueryString["type"], item.File.Title)));
                    }

                    this.ExpirationDate.DatePickerFrameUrl = ResolveUrl(SPContext.Current.Site.Url + "/_layouts/iframe.aspx");

                    if (Request.QueryString["type"] != ECContext.ECLegalType)
                    {
                        Pending.Visible = false;
                        PendingBusiness.Visible = false;
                        pnlPendingReason.Visible = false;
                        pnlApproveReason.Visible = Approved.Checked;
                        pnlCloningSection.Visible = false;
                    }
                    else
                    {
                        pnlCloningSection.Visible = Approved.Checked;
                    }

                    if (collection.Count == 1)
                    {
                        SPListItem item = collection[0];

                        //DCC
                        string type = Request.QueryString["type"];
                        string columnName = (type == ECContext.ECDoaType) ?
                        ECContext.Current.Configuration.ECFields.DoaApproval :
                        (type == ECContext.ECFcpaType) ?
                        ECContext.Current.Configuration.ECFields.FCPAApproval :
                        ECContext.Current.Configuration.ECFields.LegalApproval;

                        if (item[columnName].ToString() == "Approved" ||
                            item[columnName].ToString() == "Rejected")
                        {
                            //throw new Exception("This contract was already validated by " + type + ". The result of this step was: " + item[columnName].ToString());

                            //CEJSUtil.PopInfoWithRedirect(Page,
                            //    "Contract updated successfully",
                            //    "This contract was already validated by " + type + ". The result of this step was: " + item[columnName].ToString(),
                            //    SPContext.Current.Web.Url);
                        }


                        if (type == ECContext.ECDoaType)
                        {
                            //Check user permissions
                            SPWeb site = ECContext.Current.CurrentWeb;
                            bool isDoaMember = (item["Doa Approver"].ToString().Substring(item["Doa Approver"].ToString().LastIndexOf("#") + 1) == site.CurrentUser.Name);
                            if (!isDoaMember && !site.CurrentUser.IsSiteAdmin)
                            {
                                lblError.Text = "Current user has no permissions for DOA Approval.";
                                pnlError.Visible = true;
                                pnlStepThree.Visible = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(this, "Unexpected Error", "Unexpected error ocurred creating the page.");
                Submit.Enabled = false;
            }
        }




        private void MassApproval()
        {
            SPListItem item;
            SPListItem answers;
            SPSite siteColl = SPContext.Current.Site;
            SPWeb site = SPContext.Current.Web;
            Guid listId = ECContext.Current.Lists.ExpressContract.ID;
            Guid answerListId = ECContext.Current.Lists.ApprovalAnswer.ID;

            string[] IDArray = IDs.Split(',');

            foreach (String id in IDArray)
            {
                if (!String.IsNullOrEmpty(id))
                {

                    SPSecurity.RunWithElevatedPrivileges(delegate ()
                    {
                        using (SPSite ElevatedsiteColl = new SPSite(siteColl.ID))
                        using (SPWeb ElevatedSite = ElevatedsiteColl.OpenWeb(site.ID))
                        {
                            item = ElevatedSite.Lists[listId].GetItemById(Convert.ToInt32(id));

                            ElevatedSite.AllowUnsafeUpdates = true;

                            if (typeApproval == ECContext.ECLegalType)
                            {
                                answers = ExtractAnswerItem(item, false);

                                UpdateItem(item, ECContext.ECLegalType, approvalOption);

                                //if (approvalOption == "Approved")
                                //ECContext.SendMail(SPContext.Current.Web, string.Format("Express Contract {0}, request for DOA approval", item.File.Title), CreateMail(item, answers != null ? Convert.ToString(answers["Answers"]) : string.Empty, ECContext.ECDoaType), CreateDOAHeader(item));
                            }

                            if (typeApproval == ECContext.ECDoaType)
                            {
                                answers = ExtractAnswerItem(item, true);

                                UpdateItem(item, ECContext.ECDoaType, approvalOption);

                                //if (approvalOption == "Approved")
                                //{
                                //    if (
                                //        Convert.ToString(item[ECContext.Current.Configuration.ECFields.FCPA])
                                //            .Equals("FCPA APPROVAL REQUIRED"))
                                //    {
                                //        string sAnswers = string.Empty;
                                //        if (answers != null && answers["Answers"] != null)
                                //            sAnswers = Convert.ToString(answers["Answers"]);

                                //        ECContext.SendMail(SPContext.Current.Web,
                                //            string.Format("Express Contract {0}, request for FCPA approval", item.File.Title),
                                //            CreateMail(item, sAnswers, ECContext.ECFcpaType),
                                //            CreateFCPAHeader(item));
                                //    }
                                //}

                            }

                            if (typeApproval == ECContext.ECFcpaType)
                                UpdateItem(item, ECContext.ECFcpaType, approvalOption);

                            ElevatedSite.AllowUnsafeUpdates = false;

                        }
                    });
                }
            }
            SPUtility.Redirect(SPContext.Current.Web.Url + "/Pages/PendingApproval.aspx", SPRedirectFlags.Default, System.Web.HttpContext.Current);
        }

        protected void submitClick(object sender, EventArgs e)
        {

            try
            {

                if (Request.QueryString["type"] != ECContext.ECFcpaType)
                {
                    if (!RejectedBookmarks.Checked && !RejectedQuestions.Checked && Rejected.Checked)
                    {
                        CEJSUtil.PopError(this, "Error", "When you reject a contract, you have to specify what the cause is for your rejection (Questions and/or Document).");
                        //Comment Venu, Date 22 March, Below one line of code will call javascript function to enable Submit button
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptsKey", "<script type=\"text/JavaScript\" language=\"javascript\">ShowSubmit();</script>");
                        return;
                    }
                    else if (!Approved.Checked)
                    {
                        if (RejectedBookmarks.Checked && string.IsNullOrEmpty(txtRejectDocument.Text))
                        {
                            CEJSUtil.PopError(this, "Error", "Please enter document rejection reason.");
                            //Comment Venu, Date 22 March, Below one line of code will call javascript function to enable Submit button
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptsKey", "<script type=\"text/JavaScript\" language=\"javascript\">ShowSubmit();</script>");
                            return;
                        }
                        if (RejectedQuestions.Checked && string.IsNullOrEmpty(txtRejectQuestion.Text))
                        {
                            CEJSUtil.PopError(this, "Error", "Please enter questions rejection reason.");
                            //Comment Venu, Date 22 March, Below one line of code will call javascript function to enable Submit button
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptsKey", "<script type=\"text/JavaScript\" language=\"javascript\">ShowSubmit();</script>");
                            return;
                        }

                    }
                    else if (Approved.Checked)
                    {
                        if (chkCloneable.Checked && this.ExpirationDate.IsDateEmpty)
                        {
                            CEJSUtil.PopError(this, "Error", "Please enter an expiration date for the contract cloning.");
                            //Comment Venu, Date 22 March, Below one line of code will call javascript function to enable Submit button
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptsKey", "<script type=\"text/JavaScript\" language=\"javascript\">ShowSubmit();</script>");
                            return;
                        }
                    }
                }




                SPListItem item;
                SPListItem answers;
                SPSite siteColl = SPContext.Current.Site;
                SPWeb site = SPContext.Current.Web;
                Guid listId = ECContext.Current.Lists.ExpressContract.ID;
                Guid answerListId = ECContext.Current.Lists.ApprovalAnswer.ID;


                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    using (SPSite ElevatedsiteColl = new SPSite(siteColl.ID))
                    using (SPWeb ElevatedSite = ElevatedsiteColl.OpenWeb(site.ID))
                    {
                        item = ElevatedSite.Lists[listId].GetItemById(Convert.ToInt32(Request.QueryString["itemid"]));

                        ElevatedSite.AllowUnsafeUpdates = true;

                        if (Request.QueryString["type"] == ECContext.ECLegalType)
                        {
                            answers = ExtractAnswerItem(item, false);

                            UpdateItem(item, ECContext.ECLegalType);

                            //if (Approved.Checked)
                            //    ECContext.SendMail(SPContext.Current.Web, string.Format("Express Contract {0}, request for DOA approval", item.File.Title), CreateMail(item, answers != null ? Convert.ToString(answers["Answers"]) : string.Empty, ECContext.ECDoaType), CreateDOAHeader(item));
                        }

                        if (Request.QueryString["type"] == ECContext.ECDoaType)
                        {
                            answers = ExtractAnswerItem(item, true);

                            UpdateItem(item, ECContext.ECDoaType);

                            //if (Approved.Checked)
                            //{                                
                            //    if (
                            //        Convert.ToString(item[ECContext.Current.Configuration.ECFields.FCPA])
                            //            .Equals("FCPA APPROVAL REQUIRED"))
                            //    {                                    
                            //        string sAnswers = string.Empty;
                            //        if (answers != null && answers["Answers"] != null)
                            //            sAnswers = Convert.ToString(answers["Answers"]);

                            //        ECContext.SendMail(SPContext.Current.Web,
                            //            string.Format("Express Contract {0}, request for FCPA approval", item.File.Title),
                            //            CreateMail(item, sAnswers, ECContext.ECFcpaType),
                            //            CreateFCPAHeader(item));
                            //    }
                            //}

                        }

                        if (Request.QueryString["type"] == ECContext.ECFcpaType)
                            UpdateItem(item, ECContext.ECFcpaType);

                        ElevatedSite.AllowUnsafeUpdates = false;
                        this.Submit.Visible = false;


                        lbWarningMessage.Text = "Action saved for Express Contract: " + item.File.Title;
                        WarningDIV.Visible = true;
                        pnlWarningMsg.Visible = true;
                        CEJSUtil.TimedRedirect(Page, SPContext.Current.Web.Url + "/Pages/PendingApproval.aspx", 2000);
                    }
                });

            }
            catch (ThreadAbortException)
            {
                // Swallow bogus exception caused by redirect
            }
            catch (Exception ex)
            {
                CEJSUtil.PopError(this, "Error", ex.Message);
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }

        }

        private static SPListItem ExtractAnswerItem(SPListItem item, bool fcpa)
        {
            SPListItem answers = null;
            foreach (SPListItem aitem in ECContext.Current.Lists.ApprovalAnswer.GetItems(new SPQuery() { Query = string.Format("<Where><Eq><FieldRef Name='Contract' /><Value Type='Lookup'>{0}</Value></Eq></Where>", item.Title) }))
            {
                if (new SPFieldLookupValue(Convert.ToString(aitem["Contract"])).LookupId == item.ID)
                {
                    if (fcpa && aitem.DisplayName.StartsWith("FCPA_"))
                    {
                        answers = aitem;
                        break;
                    }
                    if (!fcpa && !aitem.DisplayName.StartsWith("FCPA_"))
                    {
                        answers = aitem;
                        break;
                    }
                }
            }

            return answers;
        }

        private void UpdateItem(SPListItem item, string type, string selectedOption)
        {
            List<string> errorList = new List<string>();
            CEMailer mailSystem = new CEMailer();

            if (selectedOption == "Approved")
            {
                item[(type == ECContext.ECDoaType) ?
                    ECContext.Current.Configuration.ECFields.DoaApproval :
                    (type == ECContext.ECFcpaType) ?
                    ECContext.Current.Configuration.ECFields.FCPAApproval :
                    ECContext.Current.Configuration.ECFields.LegalApproval] = selectedOption;
                if (type == ECContext.ECLegalType)
                {
                    item["LegalApprover"] = new SPFieldUserValue(item.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName);
                    mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approved_by_legalEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                    mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approval_Notification_to_DOA_approved_by_legalEmailTemplate, ECContext.ECDoaType, "", "", TransformListStringtoStringAddresses(CreateDOAHeader(item)));
                }
                else if (type == ECContext.ECDoaType)
                {
                    if (Convert.ToString(item[ECContext.Current.Configuration.ECFields.FCPA]).Equals("FCPA APPROVAL REQUIRED"))
                    {
                        mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approved_by_DOA_FCPA_relevantEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                        ECContext.SendMail(SPContext.Current.Web,
                                            string.Format("Express Contract {0}, request for FCPA approval", item.File.Title),
                                            CreateMail(item, "", ECContext.ECFcpaType),
                                            CreateFCPAHeader(item));
                    }
                    else
                    {
                        mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approved_by_legal_and_DOAEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                        try
                        {
                            CreateCoverPage(item.ID, "No");
                        }
                        catch (Exception ecp)
                        {
                            ECContext.LogEvent("ApprovalForm - CoverPage - Message" + ecp.Message + " InnerException" + ecp.InnerException, ecp, ECContext.TraceLevel.Unexpected);
                        }
                    }
                }
                else if (type == ECContext.ECFcpaType)
                {
                    item["FCPAApprover"] = new SPFieldUserValue(item.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName);
                    mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approved_by_legal_DOA_FCPAEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                    try
                    {
                        CreateCoverPage(item.ID, "Yes");
                    }
                    catch (Exception ecp)
                    {
                        ECContext.LogEvent("ApprovalForm - CoverPage - Message" + ecp.Message + " InnerException" + ecp.InnerException, ecp, ECContext.TraceLevel.Unexpected);
                    }
                }
            }
            else if (selectedOption == "Rejected")
            {
                //Set Status to "Rejected"
                DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                try
                {
                    disEvt.DisabledItemEvents();
                    item.ModerationInformation.Status = SPModerationStatusType.Denied;
                    item.Update();
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    errorList.Add(ex.Message);
                    //CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }
                finally
                {
                    disEvt.Dispose();
                }

                item[(type == ECContext.ECDoaType) ?
                    ECContext.Current.Configuration.ECFields.DoaApproval :
                    (type == ECContext.ECFcpaType) ?
                    ECContext.Current.Configuration.ECFields.FCPAApproval :
                    ECContext.Current.Configuration.ECFields.LegalApproval] = selectedOption;

                if (ECContext.Current.Configuration.ECFields.FCPAApproval == type)
                {
                    SendRejectionMail(item.Web, item, type, false, false);
                }
                else
                {
                }
            }
            else if (selectedOption.IndexOf("Pending") >= 0 && type == ECContext.ECLegalType)
            {
                item[ECContext.Current.Configuration.ECFields.LegalApproval] = selectedOption;
                if (selectedOption.ToLower() == "pending business")
                {
                    //Comment : Venu, Change Date 21 March 2016, ContractSubmit logic to avoid multiple mail to Legal department is not working. So I have commented the code
                    // item["ContractSubmitted"] = "No";
                    mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.BusinessPendingStatusNotificationEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                }

                //String approvalState = selectedOption;

                //SendPendingMail(ECContext.Current.CurrentWeb, item, type, approvalState);
            }


            item[(type == ECContext.ECDoaType) ?
                  ECContext.Current.Configuration.ECFields.DoaApprovalComment :
                  (type == ECContext.ECFcpaType) ?
                  ECContext.Current.Configuration.ECFields.FCPAApprovalComment :
                  ECContext.Current.Configuration.ECFields.LegalApprovalComment] = "";//Approved.Checked? txtApprove.Text : (Pending.Checked || PendingBusiness.Checked? txtPending.Text : string.Empty);

            item[(type == ECContext.ECDoaType) ?
                  ECContext.Current.Configuration.ECFields.DOAActionDate :
                  (type == ECContext.ECFcpaType) ?
                  ECContext.Current.Configuration.ECFields.FCPAActionDate :
                  ECContext.Current.Configuration.ECFields.LegalActionDate] = DateTime.Now.Date;

            DisabledItemEventsScope disEvnt = new DisabledItemEventsScope();
            try
            {
                disEvnt.DisabledItemEvents();
                item.Update();

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                errorList.Add(ex.Message);
            }
            finally
            {
                disEvnt.Dispose();
            }

            ContractHelper.UpdateContractApprovalStatus(item);
        }
        private string TransformListStringtoStringAddresses(List<string> ListofAddresses)
        {
            string returnValue = "";

            foreach (string s in ListofAddresses)
            {
                if (String.IsNullOrEmpty(returnValue))
                    returnValue = s;
                else
                    returnValue = string.Concat(returnValue, ";", s);
            }

            return returnValue;
        }

        private void UpdateItem(SPListItem item, string type)
        {
            CEMailer mailSystem = new CEMailer();

            if (Approved.Checked)
            {
                #region User selects Approve
                item[(type == ECContext.ECDoaType) ?
                    ECContext.Current.Configuration.ECFields.DoaApproval :
                    (type == ECContext.ECFcpaType) ?
                    ECContext.Current.Configuration.ECFields.FCPAApproval :
                    ECContext.Current.Configuration.ECFields.LegalApproval] = "Approved";

                if (type == ECContext.ECLegalType)
                {
                    item["LegalApprover"] = new SPFieldUserValue(item.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName);
                    item[ECContext.Current.Configuration.ECFields.Cloneable] = this.chkCloneable.Checked;
                    item[ECContext.Current.Configuration.ECFields.AutomaticApproval] = this.chkAutomaticApproval.Checked;
                    item[ECContext.Current.Configuration.ECFields.CloneExpirationDate] = this.ExpirationDate.SelectedDate;
                    item[ECContext.Current.Configuration.ECFields.CloningDate] = DateTime.Now.Date;
                    item[ECContext.Current.Configuration.ECFields.CloneContractLink] = ECContext.Current.CurrentWeb.Url + "/Pages/CloneContract.aspx?ContractID=" + item.ID + ", Clone Contract";
                    if (this.chkCloneable.Checked)
                        SendCloneApprovedMail(item.Web, item);

                    mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approved_by_legalEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                    mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approval_Notification_to_DOA_approved_by_legalEmailTemplate, ECContext.ECDoaType, "", "", TransformListStringtoStringAddresses(CreateDOAHeader(item)));
                }
                else if (type == ECContext.ECDoaType)
                {
                    if (Convert.ToString(item[ECContext.Current.Configuration.ECFields.FCPA]).Equals("FCPA APPROVAL REQUIRED"))
                    {
                        mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approved_by_DOA_FCPA_relevantEmailTemplate, ECContext.ECFcpaType, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                        ECContext.SendMail(SPContext.Current.Web,
                                            string.Format("Express Contract {0}, request for FCPA approval", item.File.Title),
                                            CreateMail(item, "", ECContext.ECFcpaType),
                                            CreateFCPAHeader(item));
                    }
                    else
                    {
                        mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approved_by_legal_and_DOAEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);

                        try
                        {
                            CreateCoverPage(item.ID, "No");
                        }
                        catch (Exception ecp)
                        {
                            ECContext.LogEvent("ApprovalForm - CoverPage - Message" + ecp.Message + " InnerException" + ecp.InnerException, ecp, ECContext.TraceLevel.Unexpected);
                        }
                    }
                }
                else if (type == ECContext.ECFcpaType)
                {
                    item["FCPAApprover"] = new SPFieldUserValue(item.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName);
                    mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.Approved_by_legal_DOA_FCPAEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                    try
                    {
                        CreateCoverPage(item.ID, "Yes");
                    }
                    catch (Exception ecp)
                    {
                        ECContext.LogEvent("ApprovalForm - CoverPage - Message" + ecp.Message + " InnerException" + ecp.InnerException, ecp, ECContext.TraceLevel.Unexpected);
                    }
                }
                #endregion
            }
            else if (Rejected.Checked)
            {
                #region User selects Reject
                DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                try
                {
                    disEvt.DisabledItemEvents();
                    item.ModerationInformation.Status = SPModerationStatusType.Denied;
                    item.Update();
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }
                finally
                {
                    disEvt.Dispose();
                }

                item[(type == ECContext.ECDoaType) ?
                    ECContext.Current.Configuration.ECFields.DoaApproval :
                    (type == ECContext.ECFcpaType) ?
                    ECContext.Current.Configuration.ECFields.FCPAApproval :
                    ECContext.Current.Configuration.ECFields.LegalApproval] = "Rejected";



                if (ECContext.Current.Configuration.ECFields.FCPAApproval == type)
                {
                    SendRejectionMail(item.Web, item, type, this.RejectedBookmarks.Checked, this.RejectedQuestions.Checked);
                }
                else
                {
                    if (RejectedBookmarks.Checked)
                        item[ECContext.Current.Configuration.ECFields.DocumentRejection] = txtRejectDocument.Text;

                    if (RejectedQuestions.Checked)
                        item[ECContext.Current.Configuration.ECFields.QuestionRejection] = txtRejectQuestion.Text;
                    SendRejectionMail(item.Web, item, type, this.RejectedBookmarks.Checked, this.RejectedQuestions.Checked);
                }
                #endregion
            }
            else if ((PendingBusiness.Checked || Pending.Checked) && type == ECContext.ECLegalType)
            {
                item[ECContext.Current.Configuration.ECFields.LegalApproval] = PendingBusiness.Checked ? "Pending Business" : "Pending";
                string appStatus = item[ECContext.Current.Configuration.ECFields.LegalApproval].ToString();

                if (PendingBusiness.Checked)
                    //Comment : Venu, Change Date 21 March 2016, ContractSubmit logic to avoid multiple mail to Legal department is not working. So I have commented the code
                    //item["ContractSubmitted"] = "No";
                    mailSystem.SendGenericMail(ECContext.Current, item.Web, item, ECContext.Current.Configuration.BusinessPendingStatusNotificationEmailTemplate, type, "", "", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                //SendPendingMail(ECContext.Current.CurrentWeb, item, type, appStatus);
            }


            item[(type == ECContext.ECDoaType) ?
                  ECContext.Current.Configuration.ECFields.DoaApprovalComment :
                  (type == ECContext.ECFcpaType) ?
                  ECContext.Current.Configuration.ECFields.FCPAApprovalComment :
                  ECContext.Current.Configuration.ECFields.LegalApprovalComment] = Approved.Checked ? txtApprove.Text : (Pending.Checked || PendingBusiness.Checked ? txtPending.Text : string.Empty);

            item[(type == ECContext.ECDoaType) ?
                  ECContext.Current.Configuration.ECFields.DOAActionDate :
                  (type == ECContext.ECFcpaType) ?
                  ECContext.Current.Configuration.ECFields.FCPAActionDate :
                  ECContext.Current.Configuration.ECFields.LegalActionDate] = DateTime.Now.Date;

            DisabledItemEventsScope disEvnt = new DisabledItemEventsScope();
            try
            {
                disEvnt.DisabledItemEvents();
                item.SystemUpdate(true);

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
            finally
            {
                disEvnt.Dispose();
            }

            ContractHelper.UpdateContractApprovalStatus(item);
        }

        protected void changeRejection(object sender, EventArgs e)
        {
            //Clear "Pending" reason when swaping between PendingBusiness and Pending radio buttons 
            if (PendingBusiness.Checked || Pending.Checked)
                txtPending.Text = String.Empty;

            //Show/Hide Comments box
            RejectPnl.Visible = Rejected.Checked;
            pnlApproveReason.Visible = Approved.Checked;

            pnlRejectReason.Visible = Rejected.Checked;


            if (Request.QueryString["type"] != ECContext.ECLegalType)
            {
                pnlPendingReason.Visible = false;
                pnlCloningSection.Visible = false;
            }
            else
            {
                pnlPendingReason.Visible = (PendingBusiness.Checked || Pending.Checked);
                pnlCloningSection.Visible = Approved.Checked;
            }
        }
        protected void changeQuestion(object sender, EventArgs e)
        {
            txtRejectQuestion.Text = string.Empty;
            txtRejectQuestion.Enabled = RejectedQuestions.Checked;

        }
        protected void changeBookmarks(object sender, EventArgs e)
        {
            txtRejectDocument.Text = string.Empty;
            txtRejectDocument.Enabled = RejectedBookmarks.Checked;
        }

        #region reject mail
        private StringDictionary CreateHeader(string mail)
        {
            StringDictionary headers = new StringDictionary();
            headers.Add("bcc", mail);
            headers.Add("from", "ExpressContractSystem@bayer.com");
            headers.Add("subject", "Express Contract approval");
            return headers;
        }


        private void SendRejectionMail(SPWeb web, SPListItem item, string type, bool RejectedBookmarksChecked, bool RejectedQuestionsChecked)
        {
            string url = string.Concat(web.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = web.Site.Url;

            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            string selectedEmailTemplate = "";

            valuesToReplace.Add(CEMailSymbol.Reject_ContractURL, string.Concat(web.Site.Url, "/", item.File.Url));
            valuesToReplace.Add(CEMailSymbol.Reject_ContractTitle, item.File.Title);
            valuesToReplace.Add(CEMailSymbol.Reject_RejectedBy, (type == ECContext.ECLegalType) ? " the Bayer Legal Department." : type);
            valuesToReplace.Add(CEMailSymbol.Reject_ChangeContractURL, string.Concat(web.Site.Url, "/_layouts/15/ContractExpressSystem/ChangeContract.aspx?itemid=", Convert.ToString(item.ID), "&changed=true"));
            valuesToReplace.Add(CEMailSymbol.Reject_DocumentContent, txtRejectDocument.Text);
            valuesToReplace.Add(CEMailSymbol.Reject_Answers, txtRejectQuestion.Text);
            valuesToReplace.Add(CEMailSymbol.Reject_RejectionHeader, "Contract Rejected");

            if (ECContext.ECFcpaType != type)
            {
                if (!RejectedBookmarksChecked && !RejectedQuestionsChecked)
                    selectedEmailTemplate = CETemplateMails.GenericRejectionEmailTemplate;
                else if (RejectedBookmarksChecked && !RejectedQuestionsChecked)
                    selectedEmailTemplate = CETemplateMails.BookmarksErrorRejectionEmailTemplate;
                else if (RejectedQuestionsChecked && !RejectedBookmarksChecked)
                    selectedEmailTemplate = CETemplateMails.QuestionsErrorRejectionEmailTemplate;
                else if (RejectedBookmarksChecked && RejectedQuestionsChecked)
                    selectedEmailTemplate = CETemplateMails.BookmarksnQuestionsErrorRejectionEmailTemplate;

            }
            else
            {
                selectedEmailTemplate = CETemplateMails.FCPARejectionEmailTemplate;
            }

            CEEmail email = mailSystem.GetEmailMessageFromTemplate(ECContext.Current.CurrentWeb, selectedEmailTemplate, valuesToReplace);

            var businessUser = item[ECContext.Current.Configuration.ECFields.BusinessUser];
            email.EmailBody = email.EmailBody.Replace("images/", url);

            if (businessUser != null && email.notifyBU)
            {
                email.TOAddresses.Add(new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
            }
            ECContext.SendMail(SPContext.Current.Web, email.Subject, email.EmailBody, true, "ExpressContractSystem@bayer.com", email.TOAddresses, email.CCAddresses, email.BCCAddresses);
        }




        private void SendCloneApprovedMail(SPWeb web, SPListItem item)
        {
            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            string selectedEmailTemplate = "";

            string url = string.Concat(web.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = web.Site.Url;

            valuesToReplace.Add(CEMailSymbol.mailforClone_ContractURL, string.Concat(web.Site.Url, "/", item.File.Url));
            valuesToReplace.Add(CEMailSymbol.mailforClone_ContractTitle, item.File.Title);
            valuesToReplace.Add(CEMailSymbol.mailforClone_AutomaticApproval, item[ECContext.Current.Configuration.ECFields.AutomaticApproval].ToString());
            valuesToReplace.Add(CEMailSymbol.mailforClone_BU, item[ECContext.Current.Configuration.ECFields.BusinessUser].ToString());
            valuesToReplace.Add(CEMailSymbol.mailforClone_CloneDate, item[ECContext.Current.Configuration.ECFields.CloningDate].ToString());
            valuesToReplace.Add(CEMailSymbol.mailforClone_CloneExpirationDate, item[ECContext.Current.Configuration.ECFields.CloneExpirationDate].ToString());
            valuesToReplace.Add(CEMailSymbol.mailforClone_Country, item[ECContext.Current.Configuration.ECFields.Country].ToString());
            valuesToReplace.Add(CEMailSymbol.mailforClone_Entity, item[ECContext.Current.Configuration.ECFields.MonsantoEntity].ToString());
            valuesToReplace.Add(CEMailSymbol.mailforClone_SiteURL, SPContext.Current.Site.Url);


            selectedEmailTemplate = CETemplateMails.CloningActivatedEmailTemplate;

            CEEmail email = mailSystem.GetEmailMessageFromTemplate(ECContext.Current.CurrentWeb, selectedEmailTemplate, valuesToReplace);


            var businessUser = item[ECContext.Current.Configuration.ECFields.BusinessUser];
            email.EmailBody = email.EmailBody.Replace("images/", url);

            if (businessUser != null && email.notifyBU)
            {
                email.TOAddresses.Add(new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);

            }
            ECContext.SendMail(SPContext.Current.Web, email.Subject, email.EmailBody, true, "ExpressContractSystem@bayer.com", email.TOAddresses, email.CCAddresses, email.BCCAddresses);
        }

        private void SendPendingMail(SPWeb web, SPListItem item, string type, string approvalState)
        {
            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            string selectedEmailTemplate = "";

            string url = string.Concat(web.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = web.Site.Url;

            valuesToReplace.Add(CEMailSymbol.Pending_Contract_URL, string.Concat(web.Site.Url, "/", item.File.Url));
            valuesToReplace.Add(CEMailSymbol.Pending_Contract_Title, item.File.Title);
            valuesToReplace.Add(CEMailSymbol.Pending_Approval_State, approvalState);
            valuesToReplace.Add(CEMailSymbol.Pending_Approval_Team, (type == ECContext.ECLegalType) ? " the Bayer Legal Department." : type);
            valuesToReplace.Add(CEMailSymbol.Pending_Reasons, txtPending.Text);
            valuesToReplace.Add(CEMailSymbol.Pending_Approval_Questions_URL, string.Concat(web.Site.Url, "/_layouts/15/ContractExpressSystem/QuestionForm.aspx?itemid=", Convert.ToString(item.ID)));
            valuesToReplace.Add(CEMailSymbol.Pending_Header, "Contract pending Business");

            selectedEmailTemplate = CETemplateMails.PendingEmailTemplate;

            CEEmail email = mailSystem.GetEmailMessageFromTemplate(ECContext.Current.CurrentWeb, selectedEmailTemplate, valuesToReplace);


            var businessUser = item[ECContext.Current.Configuration.ECFields.BusinessUser];
            email.EmailBody = email.EmailBody.Replace("images/", url);

            if (businessUser != null && email.notifyBU)
            {
                email.TOAddresses.Add(new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
            }
            ECContext.SendMail(SPContext.Current.Web, email.Subject, email.EmailBody, true, "ExpressContractSystem@bayer.com", email.TOAddresses, email.CCAddresses, email.BCCAddresses);
        }

        private string CreateSectionHead(string section)
        {
            return string.Format("  <tr> <td valign=\"top\"> <img src=\"images/double-line.gif\" alt=\"\" style=\"display: block;\" /> </td> </tr> <tr><td class=\"article-title\" height=\"30\" valign=\"middle\" style=\"text-transform: uppercase; font-family: Georgia, serif; font-size: 16px; color: #2b2b2b; font-style: italic; border-bottom: 1px solid #c1c1c1;\"> {0} </td> </tr>", section);
        }

        private string CreateContent(string message)
        {
            return string.Format("<tr><td class=\"copy\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <p>{0}</p></td> </tr>", message);
        }

        #endregion

        #region create approval mail

        private string CreateMail(SPListItem item, string answers, string type)
        {
            StringBuilder sb = new StringBuilder();
            string url = string.Concat(SPContext.Current.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = SPContext.Current.Site.Url;

            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            string selectedEmailTemplate = "";

            selectedEmailTemplate = CETemplateMails.RequestApprovalEmailTemplate;



            try
            {
                string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
                string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
                string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;
                Dictionary<string, Dictionary<string, string>> sections = GetSections(type);
                string sUserName = new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Name;
                string sFileUrl = string.Concat(SPContext.Current.Site.Url, "/", item.File.Url);
                string sApprovalUrl = string.Format("{0}/_layouts/15/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", SPContext.Current.Site.Url, item.ID.ToString(), type);


                valuesToReplace.Add(CEMailSymbol.requestApproval_ContractURL, string.Concat(item.Web.Site.Url, "/", item.File.Url));
                valuesToReplace.Add(CEMailSymbol.requestApproval_ContractTitle, item.File.Title);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Header, "Request for approval");
                valuesToReplace.Add(CEMailSymbol.requestApproval_BU, sUserName);
                valuesToReplace.Add(CEMailSymbol.requestApproval_ApprovalURL, sApprovalUrl);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Entity, Entity);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Country, country);
                valuesToReplace.Add(CEMailSymbol.requestApproval_SiteURL, SPContext.Current.Site.Url);

                List<string> splits = new List<string>();
                splits.AddRange(answers.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));

                if (type == ECContext.ECFcpaType)
                {
                    SPFieldLookupValue lv = new SPFieldLookupValue(Convert.ToString(item[ECContext.Current.Configuration.ECFields.ApprovalAnswer]));
                    if (lv.LookupId != 0)
                    {
                        try
                        {
                            string sUrl = ECContext.Current.Lists.ApprovalAnswer.GetItemById(lv.LookupId).File.Url;
                            valuesToReplace.Add(CEMailSymbol.requestApproval_ApprovalQuestions, string.Format("To review the approval answers please follow <a href ='{0}' >this</a> link. </br>", string.Concat(SPContext.Current.Site.Url, "/", sUrl)));
                        }
                        catch (Exception ex)
                        {
                            ECContext.LogEvent("Contract " + item.ID + " has no approval answers", ex, ECContext.TraceLevel.Information);
                        }
                    }
                }
                foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
                {
                    sb.Append(CreateSectionHead(section.Key));
                    if (type == ECContext.ECFcpaType)
                    {
                        foreach (KeyValuePair<string, string> question in section.Value)
                        {
                            sb.Append(CreateContent(question.Value));
                            string yeskey = string.Format("<answer>{0}yes|true", question.Key);
                            string nokey = string.Format("<answer>{0}no|true", question.Key);

                            if (splits.Exists(a => a.StartsWith(yeskey)))
                                sb.Append(CreateContent("answer was YES"));
                            if (splits.Exists(a => a.StartsWith(nokey)))
                                sb.Append(CreateContent("answer was no"));
                        }
                    }
                    else
                        foreach (KeyValuePair<string, string> question in section.Value)
                        {
                            sb.Append(CreateContent(question.Value));
                            string key = string.Format("<answer>{0}|", question.Key);

                            if (splits.Exists(a => a.StartsWith(key)))
                                sb.Append(CreateContent(splits.First(a => a.StartsWith(key)).Replace(key, string.Empty).Replace("\r\n", "<br />")));
                        }
                }
                valuesToReplace.Add(CEMailSymbol.requestApproval_FCPAQuestions, sb.ToString());
            }
            catch (Exception ex)
            {
                ECContext.LogEvent("Approval Form. Error creating mail for contract " + item.ID, ex, ECContext.TraceLevel.Information);
            }
            CEEmail email = mailSystem.GetEmailMessageFromTemplate(ECContext.Current.CurrentWeb, selectedEmailTemplate, valuesToReplace);
            email.EmailBody = email.EmailBody.Replace("images/", url);
            return email.EmailBody;
        }

        public List<string> CreateDOAHeader(SPListItem item)
        {
            List<string> bcc = new List<string>();

            var doaApprover = item[ECContext.Current.Configuration.ECFields.DaoApprover];
            if (doaApprover != null)
            {
                SPUser user = new SPFieldUserValue(item.Web, Convert.ToString(doaApprover)).User;

                if (user != null && !string.IsNullOrEmpty(user.Email))
                    bcc.Add(user.Email);
            }

            return bcc;
        }
        public List<string> CreateFCPAHeader(SPListItem item)
        {
            SPGroup group = item.Web.Groups["FCPA Approver"];
            List<string> bcc = new List<string>();
            ECContext.LogEvent("Users in group: " + group.Users.Count.ToString(), null, ECContext.TraceLevel.Information);

            foreach (SPUser user in group.Users)
            {

                if (!string.IsNullOrEmpty(user.Email))
                    bcc.Add(user.Email);
            }

            return bcc;
        }

        private void CreateQuestions()
        {

            DynaCtrls.Controls.Clear();

            Dictionary<string, Dictionary<string, string>> sections = GetSections();

            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                DynaCtrls.Controls.Add(new LiteralControl(string.Format("<h2>{0}</h2>", section.Key)));
                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    DynaCtrls.Controls.Add(new LiteralControl(string.Format("<div class=\"DynaQuestions\"><span>{0}</span></div>", question.Value)));
                    DynaCtrls.Controls.Add(new LiteralControl(string.Format("<div class=\"DynaAnswer\"><textarea id='{0}' class=\"DynaTextBox\" cols=\"100\" rows=\"5\"></textarea></div>", question.Key)));
                }
            }
        }
        public Dictionary<string, Dictionary<string, string>> GetSections()
        {
            return GetSections(ECContext.ECDoaType);
        }
        private Dictionary<string, Dictionary<string, string>> GetSections(string type)
        {
            Dictionary<string, Dictionary<string, string>> sections = new Dictionary<string, Dictionary<string, string>>();
            return sections;
        }
        #endregion



        #region CoverPage

        Dictionary<string, ECContext.Bookmark> ContractBookmarks = new Dictionary<string, ECContext.Bookmark>();
        string strCoverPage = string.Empty;
        int contractID = 0;
        private void CreateCoverPage(int ExpressContractID, string fcpaReq)
        {
            contractID = ExpressContractID;
            SPList ecList = ECContext.Current.CurrentWeb.Lists.TryGetList("Configuration");
            SPQuery queryConfiguration = new SPQuery();
            queryConfiguration.Query = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">CoverPage</Value></Eq></Where>";

            SPListItemCollection itemCol = ecList.GetItems(queryConfiguration);
            if (itemCol.Count > 0)
            {
                strCoverPage = Convert.ToString(itemCol[0]["Value"]);

                SPFile contractFile = null;
                Dictionary<string, string> bookmarks;

                SPListItem ContractItem = ECContext.Current.Lists.ExpressContract.GetItemById(contractID);

                ContractBookmarks = ECContext.OpenXml.FindBookmarksAndContent(ContractItem.File.OpenBinaryStream());
                CompileBookmarkData(out bookmarks, strCoverPage, ContractItem, fcpaReq);

                try
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate ()
                    {
                        using (SPSite curSite = new SPSite(SPContext.Current.Site.ID))
                        {
                            using (SPWeb currweb = curSite.OpenWeb(SPContext.Current.Web.ID))
                            {
                                // 3. Generate word document
                                contractFile = SaveContract(bookmarks, currweb, ContractItem.File.Name);
                            }
                        }
                    }
                );
                }
                catch (Exception ecp)
                {
                    if (contractFile != null)
                        contractFile.Delete();
                    ECContext.LogEvent("btGenerateContract_Click Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    throw ecp;
                }
            }
            else
            {
                ECContext.AddLogEntry("CoverPage configuration is missing   " + contractID, SPContext.Current.Web);
            }
        }

        /// <summary>
        /// This method will create a cover page in a ExpressContractCoverPage library and with bookmark values
        /// </summary>
        /// <param name="bookmarks"></param>
        /// <param name="elevatedWeb"></param>
        /// <param name="Contractfilename"></param>
        /// <returns></returns>
        private SPFile SaveContract(Dictionary<string, string> bookmarks, SPWeb elevatedWeb, string Contractfilename)
        {
            try
            {
                string templateName = GetTemplate(strCoverPage)["Title"].ToString();
                Contractfilename = "Cover_" + Contractfilename;

                SPFile destination;

                destination = new ECContext(SPContext.GetContext(elevatedWeb)).CreateNewExpressContractCoverPageFromTemplate(Contractfilename, templateName, elevatedWeb, contractID.ToString());

                try
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        byte[] buffer = destination.OpenBinary();
                        ms.Write(buffer, 0, buffer.Length);
                        ECContext.OpenXml.ProcessTemplate(ms, bookmarks);
                        elevatedWeb.AllowUnsafeUpdates = true;
                        destination.SaveBinary(ms);
                        elevatedWeb.AllowUnsafeUpdates = false;
                    }
                    ECContext.LogEvent("Contract created: " + destination.Url, null, ECContext.TraceLevel.Information, elevatedWeb);
                }
                catch (Exception ecp)
                {
                    if (destination != null)
                    {
                        elevatedWeb.Site.AllowUnsafeUpdates = true;
                        elevatedWeb.AllowUnsafeUpdates = true;
                        destination.Item.Delete();
                        //destination.Delete();
                        elevatedWeb.AllowUnsafeUpdates = false;
                    }
                    ECContext.LogEvent("SaveContract  - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    throw ecp;
                }

                return elevatedWeb.GetFile(destination.Url);
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error saving contract. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                //CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);

            }

            return null;
        }

        private SPListItem GetTemplate(string TemplateName)
        {
            SPListItem returnItem = null;
            try
            {
                string sQuery = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + strCoverPage + "</Value></Eq></Where>";
                //string sViewFields = @"<FieldRef Name=""ID"" />";
                // string sViewAttrs = @"Scope=""Recursive""";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = sQuery;
                oQuery.RowLimit = iRowLimit;

                SPListItemCollection collListItems = ECContext.Current.Lists.ContractTemplate.GetItems(oQuery);
                if (collListItems.Count == 1)
                {
                    returnItem = collListItems[0];
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                // CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
            return returnItem;
        }

        private List<ECContext.ContractDynamicPortion> GetDynamicPortions(string DocumentType, string Language, bool OnlyMandatory)
        {

            List<ECContext.ContractDynamicPortion> portions = new List<ECContext.ContractDynamicPortion>();

            string sQuery = String.Format(@"<Where><And><And><Or><Eq><FieldRef Name=""Document_x0020_Type"" /><Value Type=""Lookup"">{0}</Value></Eq><IsNull><FieldRef Name=""Document_x0020_Type"" /></IsNull></Or><Eq><FieldRef Name=""Language"" /><Value Type=""Lookup"">{1}</Value></Eq></And><Eq><FieldRef Name=""Mandatory"" /><Value Type=""Boolean"">{2}</Value></Eq></And></Where>", DocumentType, Language, OnlyMandatory ? "1" : "0");
            string sViewFields = @"<FieldRef Name=""BookmarkCode"" /><FieldRef Name=""FieldType"" /><FieldRef Name=""Title"" /><FieldRef Name=""Document_x0020_Type"" /><FieldRef Name=""ID"" /><FieldRef Name=""Language"" /><FieldRef Name=""Mandatory"" /><FieldRef Name=""Portion"" />";
            string sViewAttrs = @"Scope=""Recursive""";
            uint iRowLimit = 0;

            var oQuery = new SPQuery();
            oQuery.Query = sQuery;
            oQuery.ViewFields = sViewFields;
            oQuery.ViewAttributes = sViewAttrs;
            oQuery.RowLimit = iRowLimit;

            SPListItemCollection collListItems = ECContext.Current.Lists.ContractPortions.GetItems(oQuery);

            foreach (SPListItem oListItem in collListItems)
            {
                ECContext.ContractDynamicPortion portion = new ECContext.ContractDynamicPortion();
                portion.DocumentType = DocumentType;// oListItem["Document_x0020_Type"] != null ? oListItem["Document_x0020_Type"].ToString() : "";
                portion.BookMarkCode = oListItem["BookmarkCode"] != null ? oListItem["BookmarkCode"].ToString() : "";
                portion.DisplayText = oListItem["Title"] != null ? oListItem["Title"].ToString() : "";
                portion.Mandatory = oListItem["Mandatory"] != null ? bool.Parse(oListItem["Mandatory"].ToString()) : false;
                portion.FieldType = oListItem["FieldType"] != null ? oListItem["FieldType"].ToString() : "Text";
                portion.Language = Language;

                SPFieldMultiLineText multiPortion = oListItem.Fields.GetField("Portion") as SPFieldMultiLineText;

                string portionText = "";
                if (oListItem["FieldType"].ToString() != "Bulleted List")
                {
                    portionText = multiPortion.GetFieldValueAsText(oListItem["Portion"]);
                }
                else
                {
                    portionText = multiPortion.GetFieldValueAsHtml(oListItem["Portion"], oListItem);
                }

                portion.Portion = portionText;// oListItem["Portion"] != null ? oListItem["Portion"].ToString() : "";
                portions.Add(portion);
            }

            return portions;
        }

        private bool CompileBookmarkData(out Dictionary<string, string> bookmarkList, string bookmarkTilte, SPListItem CEtemplate, string fcpaReq)
        {
            try
            {
                StringBuilder emtpyFields = new StringBuilder();

                Dictionary<string, string> replacements = new Dictionary<string, string>();

                SPListItemCollection bookmarks = ECContext.Current.Lists.Bookmark.GetItems(new SPQuery { Query = String.Format("<Where><Eq><FieldRef Name=\"Template\"/><Value Type=\"Text\">{0}</Value></Eq></Where>", bookmarkTilte) });

                string bookmarkValue = string.Empty;
                DateTimeFormatInfo dtfi = new DateTimeFormatInfo { ShortDatePattern = "dd-MM-yyyy", DateSeparator = "-" };
                string entityFieldValue = string.Empty;

                for (int i = 0; i < bookmarks.GetDataTable().Rows.Count; i++)
                {
                    if (string.IsNullOrEmpty(bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()))
                    {
                        bookmarkValue = string.Empty;
                        bookmarkValue = ContractBookmarks.ContainsKey(bookmarks.GetDataTable().Rows[i][0].ToString()) ? ContractBookmarks[bookmarks.GetDataTable().Rows[i][0].ToString()].Content : String.Empty;
                        replacements.Add(bookmarks.GetDataTable().Rows[i][0].ToString(), bookmarkValue);
                    }
                    else
                    {

                        entityFieldValue = string.Empty;
                        if (!string.IsNullOrEmpty(Convert.ToString(CEtemplate[bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()])))
                        {
                            if (CEtemplate.Fields.GetField(bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()).Type == SPFieldType.Lookup)
                            {
                                entityFieldValue = new SPFieldLookupValue(Convert.ToString(CEtemplate[bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()])).LookupValue;
                            }
                            else if (CEtemplate.Fields.GetField(bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()).Type == SPFieldType.DateTime)
                            {
                                //DateTime objDate = Convert.ToDateTime(Convert.ToString(CEtemplate[bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()]), dtfi);
                                //Below culture info is hardcoded because it is agreed that the cover page will be created in English language
                                // entityFieldValue = objDate.ToString("dd MMMM yyyy", new System.Globalization.CultureInfo("en-GB"));
                                entityFieldValue = DateTime.Parse(Convert.ToString(CEtemplate[bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()])).ToString("dd MMMM yyyy", new System.Globalization.CultureInfo("en-GB"));
                            }
                            else if (CEtemplate.Fields.GetField(bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()).Type == SPFieldType.User)
                            {
                                SPFieldUserValueCollection usersFields = new SPFieldUserValueCollection(CEtemplate.Web.Site.RootWeb, Convert.ToString(CEtemplate[bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()]));
                                entityFieldValue = usersFields[0].User.LoginName;
                            }
                            else
                            {
                                entityFieldValue = Convert.ToString(CEtemplate[bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString()]);
                            }
                            replacements.Add(bookmarks.GetDataTable().Rows[i][0].ToString(), entityFieldValue);
                        }
                        else
                        {
                            if (fcpaReq.ToLower().Equals("yes"))
                            {
                                if (bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString() == "FCPA_x0020_action_x0020_date")
                                {
                                    //Below culture info is hardcoded because it is agreed that the cover page will be created in English language
                                    entityFieldValue = DateTime.Parse(DateTime.Now.ToString()).ToString("dd MMMM yyyy", new System.Globalization.CultureInfo("en-GB"));
                                    replacements.Add(bookmarks.GetDataTable().Rows[i][0].ToString(), entityFieldValue);
                                }
                                if (bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString() == "FCPAApprover")
                                {
                                    entityFieldValue = SPContext.Current.Web.CurrentUser.LoginName;
                                    replacements.Add(bookmarks.GetDataTable().Rows[i][0].ToString(), entityFieldValue);
                                }
                            }
                            else
                            {
                                if (bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString() == "DOA_x0020_action_x0020_date")
                                {
                                    //Below culture info is hardcoded because it is agreed that the cover page will be created in English language
                                    entityFieldValue = DateTime.Parse(DateTime.Now.ToString()).ToString("dd MMMM yyyy", new System.Globalization.CultureInfo("en-GB"));
                                    replacements.Add(bookmarks.GetDataTable().Rows[i][0].ToString(), entityFieldValue);
                                }
                            }
                            if (bookmarks.GetDataTable().Rows[i]["FieldMapping"].ToString() == "Legal_x0020_action_x0020_date")
                            {
                                SPList ecList = ECContext.Current.CurrentWeb.Lists.TryGetList("Configuration");
                                SPQuery queryConfiguration = new SPQuery();
                                queryConfiguration.Query = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">LegalActionDateText</Value></Eq></Where>";

                                SPListItemCollection itemCol = ecList.GetItems(queryConfiguration);
                                if (itemCol.Count > 0)
                                {
                                    entityFieldValue = Convert.ToString(itemCol[0]["Value"]);
                                    replacements.Add(bookmarks.GetDataTable().Rows[i][0].ToString(), entityFieldValue);
                                }
                                //Below culture info is hardcoded because it is agreed that the cover page will be created in English language
                            }
                        }
                    }
                    string str = string.Empty;
                }

                Dictionary<string, string> richTextDescriptionReplacements = new Dictionary<string, string>();

                bookmarkList = replacements;
                return true;
            }
            catch (Exception ex)
            {
                bookmarkList = null;
                ECContext.LogEvent("CompileBookmarkData  - " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                throw ex;
            }
        }

        #endregion
    }
}
