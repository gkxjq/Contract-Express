﻿namespace Bayer.BCS.ContractExpressSystem.Layouts.ContractExpressSystem.Bayer_Pages
{
    public partial class ContractSearch
    {
    }
}
