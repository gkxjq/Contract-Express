﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using System.Web.UI;
using System.Data;
using System.Linq;
using System.Data.Linq;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using Microsoft.SharePoint.Utilities;
using System.Web;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Reflection;
using System.Globalization;
using Bayer.BCS.ContractExpressSsytem.HtmlToOpenXml;
using Microsoft.SharePoint.Administration;
using System.Text.RegularExpressions;


using Newtonsoft.Json;
using System.Threading;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.CustomProperties;

namespace Bayer.BCS.ContractExpressSystem.Layouts.ContractExpressSystem.Bayer_Pages
{
    public partial class ChangeContract : LayoutsPageBase
    {
        #region controls and vars
        private SPListItem _contractItem;
        protected HtmlInputFile inputFile;
        protected Button btnUpload;
        private GridView dgdUpload;
        private string fileName = "";
        private HyperLinkField hlnkFileName;
        private CommandField cmdDelete;
        protected PlaceHolder DynaCtrls;
        DataTable dt;//datatable use for multiple file upload
        DataRow dr;//datarow use for multiple file upload
        DataColumn dc;//datacolumn use for multiple file upload
        private SPFieldLookupValueCollection _attachments;
        private SPList _attachmentsList;
        protected Literal docTypeLtl;
        //protected Literal functionLtl;
        //protected Literal positionLtl;
        protected Literal divisionLtl;
        protected Literal languageLtl;
        protected Literal doaApproverLtl;
        protected HyperLink filenameLink;
        protected FileUpload fu;
        protected System.Web.UI.WebControls.Menu Menu1;
        protected MultiView MultiView1;
        protected Label lblMesg;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                ViewState.Remove("AtFiles");

        }

        private void InitAttachmentsDataTable()
        {
            _attachmentsList = SPContext.Current.Site.RootWeb.Lists.TryGetList("Express contracts Attachments");

            foreach (SPFieldLookupValue attach in _attachments)
            {
                SPFile attachFile = _attachmentsList.GetItemById(attach.LookupId).File;
                AddRow(attachFile.Name, attachFile.ServerRelativeUrl, true, false, attach.LookupId);
            }
        }

        protected override void CreateChildControls()
        {
            try
            {
                #region GridView
                string[] url = { "FilePath" };

                this.dgdUpload = new GridView();
                this.hlnkFileName = new HyperLinkField();
                this.hlnkFileName.DataTextField = "FileName";
                this.hlnkFileName.DataNavigateUrlFields = url;
                this.hlnkFileName.HeaderText = "FileName";
                //this.bndFileSize = new BoundField();
                //this.bndFileSize.HeaderText = "FileSize";
                //this.bndFileSize.DataField = "FileSize";
                //this.bndFileSize.ControlStyle.CssClass = "gvCell";
                //this.bndFileKb = new BoundField();
                //this.bndFileKb.HeaderText = "";
                //this.bndFileKb.DataField = "KB";
                this.cmdDelete = new CommandField();
                this.cmdDelete.HeaderText = "";
                this.cmdDelete.ButtonType = ButtonType.Link;
                this.cmdDelete.InsertImageUrl = "delete.gif";
                this.cmdDelete.DeleteText = "Delete";
                this.cmdDelete.ShowDeleteButton = true;
                this.dgdUpload.ID = "_dgdFileUpload";
                this.dgdUpload.Columns.Add(hlnkFileName);
                //this.dgdUpload.Columns.Add(bndFileSize);
                //this.dgdUpload.Columns.Add(bndFileKb);
                this.dgdUpload.Columns.Add(cmdDelete);
                this.dgdUpload.AutoGenerateColumns = false;
                this.dgdUpload.CssClass = "gvNewContract";
                this.dgdUpload.RowDeleting += new GridViewDeleteEventHandler(dgdUpload_RowDeleting);
                _attachmentsList = SPContext.Current.Site.RootWeb.Lists.TryGetList("Express contracts Attachments");

                #endregion

                #region Add Controls
                
                //this.DynaCtrls.Controls.Add(inputFile);
                //this.DynaCtrls.Controls.Add(lblMessage);
                //this.DynaCtrls.Controls.Add(btnUpload);
                this.DynaCtrls.Controls.Add(dgdUpload);
                base.CreateChildControls();

                #endregion

                int contractId;
                if (int.TryParse((string)Request.QueryString["itemId"], out contractId))
                {
                    _contractItem = ECContext.Current.Lists.ExpressContract.GetItemById(contractId);
                    _attachments = _contractItem["Documents Attached"] as SPFieldLookupValueCollection;

                    if (!Page.IsPostBack)
                        InitAttachmentsDataTable();

                    if (_contractItem != null)
                    {
                        docTypeLtl.Text = new SPFieldLookupValue((string)_contractItem[ECContext.Current.Configuration.ECFields.DocumentType]).LookupValue;
                        //functionLtl.Text = new SPFieldLookupValue((string)_contractItem[ECContext.Current.Configuration.ECFields.Function]).LookupValue;
                        //positionLtl.Text = new SPFieldLookupValue((string)_contractItem[ECContext.Current.Configuration.ECFields.NegotiationPosition]).LookupValue;
                        divisionLtl.Text = new SPFieldLookupValue((string)_contractItem[ECContext.Current.Configuration.ECFields.MonsantoDivision]).LookupValue;
                        doaApproverLtl.Text = new SPFieldLookupValue((string)_contractItem[ECContext.Current.Configuration.ECFields.DaoApprover]).LookupValue;
                        filenameLink.Text = _contractItem.File.Name;
                        filenameLink.NavigateUrl = SPContext.Current.Site.Url + "/" + _contractItem.File.Url;
                        SPFieldLookupValue template = new SPFieldLookupValue((string)_contractItem[ECContext.Current.Configuration.ECFields.Template]);
                        try
                        {
                            SPListItem tempalteItem = ECContext.Current.Lists.ContractTemplate.GetItemById(template.LookupId);
                            languageLtl.Text = new SPFieldLookupValue((string)tempalteItem["Language"]).LookupValue;
                        }
                        catch (Exception ex)
                        {
                            //Template from lookup does not exist in Contract Template list
                            int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

        }


        // MAIN CONTRACT CREATION METHOD
        protected void lnkbtnHome_Click(object sender, EventArgs e)
        {

            //Clear Session attachments
            ViewState.Remove("AtFiles");
            try
            {
                SPUtility.Redirect(SPContext.Current.Web.Url, SPRedirectFlags.Static, HttpContext.Current);
            }
            catch (ThreadAbortException)
            {
                // Swallow bogus exception caused by redirect
            }

        }

        #region File Upload

        private void UpdateGridRowsVisibility()
        {
            int index = 0;
            int visibleRowsCount = dt.Rows.Count;
            foreach (DataRow row in dt.Rows)
            {
                if ((Boolean)row["DoDelete"])
                {
                    dgdUpload.Rows[index].Visible = false;
                    visibleRowsCount--;
                }

                index++;
            }

            if (visibleRowsCount == 0)
                dgdUpload.Visible = false;
            else
                dgdUpload.Visible = true;
        }

        private void dgdUpload_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                int recordToDelete = e.RowIndex;
                dt = (DataTable)ViewState["AtFiles"];

                Int32 uploadedItemId = Int32.Parse(dt.Rows[recordToDelete]["UploadedItemId"].ToString());
                SPFile file = _attachmentsList.GetItemById(uploadedItemId).File;

                SPFieldLookupValue value = _attachments.Find(x => x.LookupId == uploadedItemId);
                if (value != null)
                {
                    //Delete attachment from lookup field in Express Contract List
                    _attachments.Remove(value);

                    //Delecte attachment from Express Contracts attachments
                    file.Delete();
                    file.Update();
                }


                if ((Boolean)dt.Rows[recordToDelete]["IsUploaded"])
                    dt.Rows[recordToDelete]["DoDelete"] = true;
                else
                    dt.Rows[recordToDelete].Delete();
                dt.AcceptChanges();
                ViewState["AtFiles"] = dt;
                this.dgdUpload.DataSource = dt;
                this.dgdUpload.DataBind();
                UpdateGridRowsVisibility();

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Unexpected error ocurred deleting attached file. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        protected void btnUploadUploadClick(object sender, EventArgs e)
        {
            try
            {
                fileName = System.IO.Path.GetFileName(inputFile.PostedFile.FileName);

                if (fileName != "")
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate ()
                    {
                        if (inputFile.PostedFile.FileName.EndsWith(".exe"))
                            throw new Exception("File type (.exe) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".msi"))
                            throw new Exception("File type (.msi) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".config"))
                            throw new Exception("File type (.config) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".dll"))
                            throw new Exception("File type (.dll) not supported.");
                        else
                        {
                            using (SPSite curSite = new SPSite(SPContext.Current.Site.ID))
                            {
                                using (SPWeb web = curSite.OpenWeb(SPContext.Current.Web.ID))
                                {
                                    SPFolder attachmentsLibrary = web.Folders["Express contracts attachments"];

                                    web.AllowUnsafeUpdates = true;

                                    //0. Check if file already exists
                                    SPQuery q = new SPQuery();
                                    q.Query = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">" + fileName + "</Value></Eq></Where>";
                                    SPListItemCollection items = _attachmentsList.GetItems(q);
                                    if (items.Count > 0)
                                    {
                                        //If file exists rename
                                        int i = fileName.LastIndexOf(".");
                                        fileName = fileName.Substring(0, i) + "_" + DateTime.Now.ToString("ffff") + fileName.Substring(i, fileName.Length - i);
                                    }

                                    //1. Add file to 'Express contracts attachments' Document Library
                                    Stream fStream = inputFile.PostedFile.InputStream;
                                    MemoryStream ms = new MemoryStream(ECContext.OpenXml.ReadFully(fStream));

                                    SPFile file = attachmentsLibrary.Files.Add(fileName, ms, true);
                                    file.Item["Title"] = fileName;
                                    file.Item.Update();

                                    //2. Add link to file in 'Express contracts' Document Library
                                    SPFieldLookupValue lv = new SPFieldLookupValue(file.Item.ID, file.Item.Title);
                                    _attachments.Add(lv);

                                    _contractItem["Documents Attached"] = _attachments.ToString();

                                    //3. Update Attachments datatable
                                    AddRow(file.Name, file.ServerRelativeUrl, true, false, lv.LookupId);

                                    DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                                    try
                                    {
                                        //Disable event firing --> no mail when updating item
                                        disEvt.DisabledItemEvents();

                                        _contractItem.SystemUpdate(false);
                                        _contractItem.Web.AllowUnsafeUpdates = false;
                                    }
                                    catch (Exception exx)
                                    {
                                        int logId = ECContext.LogEvent("Error saving contract metadata. " + exx.Message, exx, ECContext.TraceLevel.Unexpected);
                                        CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                                    }
                                    finally
                                    {
                                        disEvt.Dispose();
                                    }

                                    web.AllowUnsafeUpdates = false;
                                }
                            }
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.StartsWith("File attached length is") || ex.Message.StartsWith("File type (."))
                {
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ex.Message);
                }
                else
                {
                    int logId = ECContext.LogEvent("Unexpected error ocurred uploading attached file. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }
            }
        }

        private void AddMoreColumns()
        {
            dt = new DataTable("Files");
            dc = new DataColumn("FileName", Type.GetType("System.String"));
            dt.Columns.Add(dc);
            dc = new DataColumn("FilePath", Type.GetType("System.String"));
            dt.Columns.Add(dc);
            dc = new DataColumn("IsUploaded", Type.GetType("System.Boolean"));
            dt.Columns.Add(dc);
            dc = new DataColumn("DoDelete", Type.GetType("System.Boolean"));
            dt.Columns.Add(dc);
            dc = new DataColumn("UploadedItemId", Type.GetType("System.Int32"));
            dt.Columns.Add(dc);
            //dc = new DataColumn("FileSize", Type.GetType("System.String"));
            //dt.Columns.Add(dc);
            //dc = new DataColumn("KB", Type.GetType("System.String"));
            //dt.Columns.Add(dc);
            ViewState["AtFiles"] = dt;
        }

        private void AddRow(string file, string path, bool isUploaded, bool doDelete, int? uploadedItemId)
        {
            dt = (DataTable)ViewState["AtFiles"];
            if (dt == null)
            {
                AddMoreColumns();
            }

            dr = dt.NewRow();
            dr["FileName"] = file;
            dr["FilePath"] = path;
            dr["IsUploaded"] = isUploaded;
            dr["DoDelete"] = doDelete;
            dr["UploadedItemId"] = uploadedItemId.HasValue ? uploadedItemId.Value : 0;
            //dr["FileSize"] = Convert.ToString(length);
            //dr["KB"] = "KB";
            dt.Rows.Add(dr);
            ViewState["AtFiles"] = dt;
            this.dgdUpload.DataSource = dt;
            this.dgdUpload.DataBind();//bind in grid

            UpdateGridRowsVisibility();
        }

        #endregion

        protected void btnReplace_Click(object sender, EventArgs e)
        {
            if (_contractItem != null && fu.HasFile)
            {

                #region 1. Save Original Metadata

                Dictionary<string, string> OriginalValues = new Dictionary<string, string>();

                foreach (SPField field in _contractItem.Fields)
                {
                    if (!field.FromBaseType &&
                        !field.ReadOnlyField &&
                        _contractItem[field.InternalName] != null)
                        OriginalValues.Add(field.InternalName, _contractItem[field.InternalName].ToString());
                }
                #endregion

                ECContext ec = new ECContext(SPContext.Current);
                using (SPSite curSite = new SPSite(SPContext.Current.Site.ID))
                {
                    using (SPWeb currweb = curSite.OpenWeb(SPContext.Current.Web.ID))
                    {
                        try
                        {
                            _contractItem.Web.AllowUnsafeUpdates = true;

                            DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                            SPListItem req = _contractItem;
                            bool tryAgain = false;
                            do
                            {
                                try
                                {
                                    //Disable event firing --> no mail when updating item
                                    disEvt.DisabledItemEvents();


                                    //2. Save file
                                    _contractItem.File.SaveBinary(fu.FileBytes);
                                    tryAgain = false;

                                    bool tryAgain2 = false;
                                    do
                                    {
                                        try
                                        {
                                            int listItemID = _contractItem.ID;

                                            //3. Add original metadata
                                            SPListItem item = ECContext.Current.Lists.ExpressContract.GetItemById(listItemID);
                                            //item["Monsanto Entity"] = "67;#Monsanto Ireland Limited";

                                            #region Copy original metadata

                                            foreach (KeyValuePair<string, string> originalData in OriginalValues)
                                            {
                                                item[originalData.Key] = originalData.Value;
                                            }

                                            #endregion

                                            item.Update();
                                            tryAgain2 = false;
                                        }
                                        catch (Exception ex2)
                                        {
                                            if (ex2.Message.Contains("has been modified by"))
                                            {
                                                int logId = ECContext.LogEvent("Error archiving contract. " + ex2.Message, ex2, ECContext.TraceLevel.Unexpected);
                                                req = _contractItem;
                                                System.Threading.Thread.Sleep(1000);
                                                tryAgain2 = true;
                                            }
                                        }
                                    } while (tryAgain2 == true);

                                }
                                catch (Exception exx)
                                {
                                    if (exx.Message.Contains("has been modified by"))
                                    {
                                        int logId = ECContext.LogEvent("Error archiving contract. " + exx.Message, exx, ECContext.TraceLevel.Unexpected);
                                        req = _contractItem;
                                        System.Threading.Thread.Sleep(1000);
                                        tryAgain = true;
                                    }
                                }
                            } while (tryAgain == true);

                            disEvt.Dispose();

                            _contractItem.Web.AllowUnsafeUpdates = false;
                            lblMesg.Text = "Contract succesfully updated!";

                        }
                        catch (Exception ex)
                        {
                            int logId = ECContext.LogEvent("Error archiving contract. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                            CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                        }
                    }
                }
            }
        }

        protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
        {
            MultiView1.ActiveViewIndex = Int32.Parse(e.Item.Value);
            //for (int i = 0; i == Menu1.Items.Count - 1; i++)
            //{
            //    if (i == Int32.Parse(e.Item.Value))
            //        Menu1.Items[i].ImageUrl = "MenuTab.png";
            //    else
            //        Menu1.Items[i].ImageUrl = "";
            //}
        }
    }
}
