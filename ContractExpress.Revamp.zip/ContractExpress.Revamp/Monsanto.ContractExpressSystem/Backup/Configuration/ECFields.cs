﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.ContractExpressSystem
{
    public class ECFields
    {
        public string BusinessUser { get; set; }
        public string DaoApprover { get; set; }
        public string DocumentType { get; set; }
        public string ApprovalAnswer { get; set; }
        public string FcpaApprovalAnswer { get; set; }
        //public string NegotiationPosition { get; set; }
        public string MonsantoDivision { get; set; }
        public string Function { get; set; }
        public string Country { get; set; }
        public string MonsantoEntity { get; set; }
        public string LegalApprovalComment { get; set; }
        public string LegalApproval { get; set; }
        public string DoaApprovalComment { get; set; }
        public string DoaApproval { get; set; }
        public string FCPA { get; set; }
        public string FCPAApprovalComment { get; set; }
        public string FCPAApproval { get; set; }
        public string DocumentRejection { get; set; }
        public string QuestionRejection { get; set; }
        public string Template { get; set; }
//        public string TemplateChoices { get; set; }
//        public string Draft { get; set; }
        public string LegalActionDate { get; set; }
        public string FCPAActionDate { get; set; }
        public string DOAActionDate { get; set; }
        public string ClonedFromContractId { get; set; }
        public string AccessDelegation { get; set; }
        public string EntitySignatory { get; set; }
        public string Cloneable { get; set; }
        public string AutomaticApproval { get; set; }
        public string CloneExpirationDate { get; set; }
        public string CloningDate { get; set; }
        public string FCPA_XML { get; set; }
        public string CloneContractLink { get; set; }
        public string Region { get; set; }
        public string Division { get; set; }
        public string ChangeControle { get; set; }
    }
     
}
