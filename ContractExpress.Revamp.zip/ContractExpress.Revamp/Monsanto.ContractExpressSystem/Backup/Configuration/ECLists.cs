﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace Monsanto.ContractExpressSystem
{
    public class ECLists
    {
        private ECContext ParentContext;
        public ECLists(ECContext parentContext)
        {
            ParentContext = parentContext;
        }

        private SPList List(string name)
        {
            try
            {

                return ParentContext.SPContext.Web.Lists[name];
            }
            catch (Exception ex)
            {
                ParentContext.HandleException(new ApplicationException(string.Format("Error Loading list '{0}' from context innerexception: {1}", name, ex.Message)));
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                return null;
            }
        }

        public SPList TemplateBookmarksOrder
        {
            get
            {
                return List("TemplateBookmarksOrder");
            }
        }


        public SPList DraftContracts
        {
            get
            {
                return List(ParentContext.Configuration.DraftContractsListName);
            }
        }



        public SPList Negotiation
        {
            get
            {
                return List(ParentContext.Configuration.NegotiationPositionListName);
            }
        }
        public SPList MonsantoDivision
        {
            get
            {
                return List(ParentContext.Configuration.MonsantoDivisionListName);
            }
        }
        public SPList Country
        {
            get
            {
                return List(ParentContext.Configuration.CountryListName);
            }
        }
        public SPList DocumentType
        {
            get
            {
                return List(ParentContext.Configuration.DocumentTypeListName);
            }
        }
        public SPList Function
        {
            get
            {
                return List(ParentContext.Configuration.FunctionListName);
            }
        }
        public SPList MonsantoEntity
        {
            get
            {
                return List(ParentContext.Configuration.MonsantoEntityListName);
            }
        }

        public SPList FieldMappings
        {
            get
            {
                return List(ParentContext.Configuration.FieldMappingsListName);
            }
        }

        //dcc
        public SPList Regions
        {
            get
            {
                return List(ParentContext.Configuration.RegionListName);
            }
        }
        public SPList ExpressContract
        {
            get
            {
                return List(ParentContext.Configuration.ExpressContractLibraryName);
            }
        }
        public SPList Bookmark
        {
            get
            {
                return List(ParentContext.Configuration.BookmarkListName);
            }
        }
        //public SPList Question
        //{
        //    get
        //    {
        //        return List(ParentContext.Configuration.QuestionsListName);
        //    }
        //}
        public SPList ContractTemplate
        {
            get
            {
                return List(ParentContext.Configuration.ContractTemplateLibraryName);
            }
        }

        public SPList ContractPortions
        {
            get
            {
                return List(ParentContext.Configuration.ContractPortionsListName);
            }
        }
        public SPList ApprovalAnswer
        {
            get
            {
                return List(ParentContext.Configuration.ApprovalAnswerlistName);
            }

        }
        public SPList ApprovalQuestion
        {
            get
            {
                return List(ParentContext.Configuration.ApprovalQuestionlistName);
            }
        }
        public SPList Language
        {
            get
            {
                return List(ParentContext.Configuration.LanguageListName);
            }
        }

        public SPList Signatures
        {
            get
            {
                return List(ParentContext.Configuration.SignaturesListName);
            }
        }
        //public SPList Translations
        //{
        //    get
        //    {
        //        return List(ParentContext.Configuration.TranslationsListName);
        //    }
        //}

        public SPList MonsantoBankInformation
        {
            get 
            {
                return List(ParentContext.Configuration.MonsantoEntitiesBankInformationListName);
            } 
        }

        public SPList ArchivedContracts
        {
            get
            {
                return List(ParentContext.Configuration.ArchiveListName);
            }
        }

        //public SPList MonsantoEntitiesRepresentatives
        //{
        //    get
        //    {
        //        return List(ParentContext.Configuration.MonsantoEntitiesRepresentativesListName);
        //    }
        //}

        public SPList MonsantoEntitiesSignatoriesInformation
        {
            get
            {
                return List(ParentContext.Configuration.MonsantoEntitiesSignatoriesInformationListName);
            }
        }
    }
}
