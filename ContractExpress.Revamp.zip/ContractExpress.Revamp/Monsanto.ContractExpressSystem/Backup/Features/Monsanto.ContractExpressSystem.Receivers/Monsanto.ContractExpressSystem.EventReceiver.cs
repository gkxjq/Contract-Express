using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;

namespace Monsanto.ContractExpressSystem.Features.Monsanto.ContractExpressSystem.Receivers
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("4d8c878c-41f9-4350-b173-ade9b6127fd2")]
    public class MonsantoContractExpressSystemEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            try
            {

                //Add new event reciver to ExpressContact List - DLH - 17/11/14
                SPList ecLst = ECContext.Current.Lists.ExpressContract;
                ecLst.EventReceivers.Add(SPEventReceiverType.ItemUpdated, "Monsanto.ContractExpressSystem, Version=1.0.0.0, Culture=neutral, PublicKeyToken=9747fdf77c58e4f0", "Monsanto.ContractExpressSystem.ContractApprovalReceiver");
                ecLst.Update();

                //Add new event reciver to ArchivedContracts List - DLH - 17/11/14
                SPList acLst = ECContext.Current.Lists.ArchivedContracts;
                acLst.EventReceivers.Add(SPEventReceiverType.ItemUpdated, "Monsanto.ContractExpressSystem, Version=1.0.0.0, Culture=neutral, PublicKeyToken=9747fdf77c58e4f0", "Monsanto.ContractExpressSystem.ArchivedContractsReceiver");
                acLst.Update();

            }
            catch (Exception ex)
            {
                //ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }

        /// <summary>
        /// Occurs when a Feature is deactivated.
        /// </summary>
        /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPList ecLst = ECContext.Current.Lists.ExpressContract;
            SPList tmplLst = ECContext.Current.Lists.ContractTemplate;
            SPList acLst = ECContext.Current.Lists.ArchivedContracts;

            SPEventReceiverDefinition update = null;
            SPEventReceiverDefinition deleteAc = null;
            SPEventReceiverDefinition delete = null;

            foreach (SPEventReceiverDefinition item in ecLst.EventReceivers)
                if (item.Class == "Monsanto.ContractExpressSystem.ContractApprovalReceiver")
                {
                    update = item;
                    break;
                }

            foreach (SPEventReceiverDefinition item in tmplLst.EventReceivers)
                if (item.Class == "Monsanto.ContractExpressSystem.TemplateCleanUpReceiver")
                {
                    delete = item;
                    break;
                }

            foreach (SPEventReceiverDefinition item in acLst.EventReceivers)
                if (item.Class == "Monsanto.ContractExpressSystem.ArchivedContractsReceiver")
                {
                    deleteAc = item;
                    break;
                }

            if (update != null)
                update.Delete();

            if (delete != null)
                delete.Delete();
            if (deleteAc != null)
                deleteAc.Delete();

            ecLst.Update();
            tmplLst.Update();
            acLst.Update();
        }

        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
