using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;

namespace Monsanto.ContractExpressSystem.Features.Monsanto.ContractExpressSystem.MasterPage
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("e3f4a037-058c-409f-b7ef-97ad38919d4d")]
    public class MonsantoContractExpressSystemEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite siteCollection = properties.Feature.Parent as SPSite;
            ApplyMasterPageRecursively(siteCollection, "ContractExpressv4.master");
        }

        //Uncomment the method below to handle the event raised before a feature is deactivated.
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSite siteCollection = properties.Feature.Parent as SPSite;
            ApplyMasterPageRecursively(siteCollection, "v4.master");
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}

        private string GetRelativeUrl(string serverRelativeUrl)
        {
            // Calculate relative path to site from Web Application root.
            string webAppRelativePath = serverRelativeUrl;
            if (!webAppRelativePath.EndsWith("/"))
            {
                webAppRelativePath += "/";
            }


           
            return webAppRelativePath;
        }

        private void ApplyMasterPageRecursively(SPSite siteCollection, string masterPageName)
        {
            if (siteCollection != null)
            {
                SPWeb rootWeb = siteCollection.RootWeb;
                string rootWebUrl = GetRelativeUrl(rootWeb.ServerRelativeUrl);
                rootWeb.MasterUrl = rootWebUrl + "_catalogs/masterpage/" + masterPageName;
                rootWeb.CustomMasterUrl = rootWebUrl + "_catalogs/masterpage/" + masterPageName;
                rootWeb.SiteLogoUrl = rootWeb.Url + "/Style%20Library/Images/monsantoLogo.png";
                rootWeb.AlternateCssUrl = rootWeb.Url + "/Style%20Library/Css/ContractExpress.css";
                rootWeb.UIVersion = 4;
                rootWeb.Update();
            }
        }
    }
}
