﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint.WebControls;
using System.Threading;
using System.Globalization;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Monsanto.ContractExpressSsytem.HtmlToOpenXml;
using Microsoft.SharePoint.Utilities;
using System.Web;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using System.Xml;
using System.Collections;

namespace Monsanto.ContractExpressSystem.WebParts.NewContractWebPart
{
    public partial class NewContractWebPartUserControl : UserControl
    {

        //added new line
        public NewContractWebPart WebPartControl { get; set; }

        protected bool IsForCloning
        {
            get
            {
                if (this.WebPartControl != null)
                    return this.WebPartControl.isForCloning;
                else
                    return false;
            }
        }

        public String MainLanguage
        {
            get
            {
                if (ViewState["MainLanguage"] != null)
                    return ViewState["MainLanguage"].ToString();
                else
                    return "";
            }
            set
            {
                ViewState["MainLanguage"] = value;
            }
        }

        public String SecLanguage
        {
            get
            {
                if (ViewState["SecLanguage"] != null)
                    return ViewState["SecLanguage"].ToString();
                else
                    return "";
            }
            set
            {
                ViewState["SecLanguage"] = value;
            }
        }

        public List<ECContext.BookmarkGridItem> MainBookmarks
        {
            get
            {
                if (ViewState["MainBookmarks"] != null)
                    return (List<ECContext.BookmarkGridItem>)ViewState["MainBookmarks"];
                else
                    return new List<ECContext.BookmarkGridItem>();
            }
            set
            {
                ViewState["MainBookmarks"] = value;
            }
        }

        public List<ECContext.BookmarkGridItem> SecondaryLanguageBookmarks
        {
            get
            {
                if (ViewState["SecondaryLanguageBookmarks"] != null)
                    return (List<ECContext.BookmarkGridItem>)ViewState["SecondaryLanguageBookmarks"];
                else
                    return new List<ECContext.BookmarkGridItem>();
            }
            set
            {
                ViewState["SecondaryLanguageBookmarks"] = value;
            }
        }

        protected Dictionary<string, Func<string>> field_mappings;

        Dictionary<string, ECContext.Bookmark> _clonedContractBookmarks = new Dictionary<string, ECContext.Bookmark>();

        SPListItem _clonedContractItem = null;

        private int? _clonedContractId;

        protected string GetEntityField(string FieldName)
        {
            string entityFieldValue = "";
            try
            {
                if (ddlMonsantoEntity.SelectedItem != null &&
                   ddlMonsantoEntity.SelectedIndex > 0)
                {
                    SPListItem item = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));
                    if (item != null && item.Fields.ContainsField(FieldName) && item[FieldName] != null)
                    {
                        //Comment: Date: 31-01-2016, Code commented since this code do not handle lookup column. When return the value (72;#Switzerland)
                        //if (FieldName == "Country_x007c_Incorporation_x002")
                        //{
                        //    entityFieldValue = item[FieldName].ToString();
                        //    entityFieldValue = entityFieldValue.Substring((entityFieldValue.IndexOf("#")) + 1);
                        //}
                        //else
                        //{
                        //    entityFieldValue = item[FieldName].ToString();
                        //}
                        if (item.Fields.GetField(FieldName).Type == SPFieldType.Lookup)
                        {
                            entityFieldValue = new SPFieldLookupValue(Convert.ToString(item[FieldName])).LookupValue;
                        }
                        else
                        {
                            entityFieldValue = item[FieldName].ToString();
                        }

                    }
                }
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent("GetEntityField Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
            }
            return entityFieldValue;
        }

        private void BuildMappingDictionary()
        {
            field_mappings = new Dictionary<string, Func<string>>();

            try
            {
                SPListItemCollection mappings = ECContext.Current.Lists.FieldMappings.GetItems();
                foreach (SPListItem mapping in mappings)
                {
                    field_mappings.Add(mapping["InternalField"].ToString(), () => GetEntityField(mapping["InternalField"].ToString()));
                }
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent("BuildMappingDictionary Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
            }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //BuildMappingDictionary();

            //field_mappings = new Dictionary<string, Func<string>>
            //    {
            //        { ECContext.Current.Configuration.ECFields.MonsantoEntity, () => ddlMonsantoEntity.SelectedItem.Text },
            //        { ECContext.Current.Configuration.ECFields.Country, () => ddlCountry.SelectedItem.Text },
            //        { ECContext.Current.Configuration.ECFields.MonsantoDivision, () => this.ddlDivision.SelectedItem.Text }					
            //    };




            this.templatesDS.TypeName = this.GetType().AssemblyQualifiedName;
            this.ddlRegion.SelectedIndexChanged += new EventHandler(ddlRegion_SelectedIndexChanged);
            this.ddlDivision.SelectedIndexChanged += new EventHandler(ddlDivision_SelectedIndexChanged);
            this.gvTemplates.RowDataBound += new GridViewRowEventHandler(gvTemplates_RowDataBound);
            this.gvTemplates.RowCreated += new GridViewRowEventHandler(gvTemplates_RowCreated);
            this.gvBookmarks.RowDataBound += new GridViewRowEventHandler(gvBookmarks_RowDataBound);
            this.dgdUpload.RowDeleting += new GridViewDeleteEventHandler(dgdUpload_RowDeleting);
            this.gvFCPAQuestions.RowCreated += new GridViewRowEventHandler(gvFCPAQuestions_RowCreated);
            this.gvFCPAQuestions.RowDataBound += new GridViewRowEventHandler(gvFCPAQuestions_RowDataBound);
            this.btGenerateContract.Click += new EventHandler(btGenerateContract_Click);
            this.gvBookmarks.RowCreated += new GridViewRowEventHandler(gvBookmarks_RowCreated);

            if (IsForCloning)
            {
                this.lbPageHeader.Text = "Clone express contract form";
                this.lbWelcomeMessage.Text = "This page will allow you to clone a new express contract. Please follow all of the steps below to clone your contract. After the contract has been clonned you are required to fill in a questionnaire, which will be provided to the DOA and the Legal representatives as additional approval information";
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["ContractID"] != null)
            {
                int oldContractID = Convert.ToInt32(Request.QueryString["ContractID"]);
                ShowCloningControls(oldContractID, Page.IsPostBack);
                if (!String.IsNullOrEmpty(hdnCloneContractParentId.Value))
                {
                    _clonedContractItem = ECContext.Current.Lists.ExpressContract.GetItemById(int.Parse(hdnCloneContractParentId.Value));
                    _clonedContractBookmarks = ECContext.OpenXml.FindBookmarksAndContent(_clonedContractItem.File.OpenBinaryStream());
                }

                if (hdnCloneContractParentId != null)
                {
                    int clID = 0;
                    if (int.TryParse(hdnCloneContractParentId.Value, out clID))
                        _clonedContractId = clID;
                }


                if (_clonedContractId.HasValue)
                {
                    SPList expresscontractList = ECContext.Current.Lists.ExpressContract;

                    if (_clonedContractItem != null)
                    {
                        if (String.IsNullOrEmpty(sapVendorNumberTxt.Text))
                        {
                            sapVendorNumberTxt.Text = (string)_clonedContractItem["Sap Vendor Number"];
                            ScriptManager.RegisterStartupScript(this.pnlMain, this.pnlMain.GetType(), "MakeSAPNumberDIVVisible", "MakeSAPNumberDIVVisible();", true);
                        }
                        if (String.IsNullOrEmpty(this.hdnCounterparty.Value))
                        {
                            this.hdnCounterparty.Value = (string)_clonedContractItem["CounterParty"];

                        }
                        if (String.IsNullOrEmpty(this.counterPartyNameForFile.Value))
                        {

                            this.counterPartyNameForFile.Value = this.hdnCounterparty.Value;
                        }

                        if (_clonedContractItem[ECContext.Current.Configuration.ECFields.DocumentType] != null)
                        {
                            this.hdnDocumentType.Value = _clonedContractItem[ECContext.Current.Configuration.ECFields.DocumentType].ToString();
                        }
                    }
                }
            }
            else
                RefreshGrid();

            this.lbFileName.Text = BuildFileName();
            if (!Page.IsPostBack)
            {
                this.ddlRegion.DataSource = QueryDivisionsbyField("Regions");
                this.ddlDivision.DataSource = QueryDivisionsbyField("Divisions");

                this.ddlRegion.DataBind();
                this.ddlDivision.DataBind();
                this.ddlRegion.Items.Insert(0, " - SELECT - ");
                this.ddlDivision.Items.Insert(0, " - SELECT - ");

                if (_clonedContractItem != null)
                {
                    string lookupValue = new SPFieldLookupValue((string)_clonedContractItem[ECContext.Current.Configuration.ECFields.Region]).LookupValue;

                    System.Web.UI.WebControls.ListItem item = this.ddlRegion.Items.FindByText(lookupValue);

                    if (item != null)
                    {
                        ddlRegion.SelectedValue = item.Value;
                    }

                    lookupValue = new SPFieldLookupValue((string)_clonedContractItem[ECContext.Current.Configuration.ECFields.MonsantoDivision]).LookupValue;

                    item = this.ddlDivision.Items.FindByText(lookupValue);

                    if (item != null)
                    {
                        ddlDivision.SelectedValue = item.Value;
                    }


                    if (_clonedContractItem[ECContext.Current.Configuration.ECFields.DaoApprover] != null)
                    {
                        SPFieldUserValue DOAUser = new SPFieldUserValue(ECContext.Current.CurrentWeb, _clonedContractItem[ECContext.Current.Configuration.ECFields.DaoApprover].ToString());
                        PickerEntity _pickerEntity = new PickerEntity();
                        _pickerEntity.Key = DOAUser.User.LoginName;
                        _pickerEntity.IsResolved = true;
                        ArrayList userList = new ArrayList();
                        userList.Add(_pickerEntity);
                        this.DoaAdmin.UpdateEntities(userList);

                    }
                }


                BindCountryDropDown();
                SetMonsantoEntityValues();
            }
        }

        private void BindCountryDropDown()
        {
            try
            {

                string where = "<Where><Eq><FieldRef Name='UseInCE'/><Value Type='Boolean'>1</Value></Eq></Where>";
                string orderBy = "<OrderBy><FieldRef Name=\"Country_x007c_Incorporation_x002\"></FieldRef></OrderBy>";
                string groupBy = "<GroupBy Collapse=\"TRUE\"><FieldRef Name=\"Country_x007c_Incorporation_x002\" /></GroupBy>";

                string sViewFields = @"<FieldRef Name=""Country_x007c_Incorporation_x002"" />";
                string sViewAttrs = @"Scope=""Recursive""";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = where + orderBy + groupBy;
                oQuery.ViewFields = sViewFields;
                oQuery.ViewAttributes = sViewAttrs;
                oQuery.RowLimit = iRowLimit;

                SPListItemCollection collListItems = ECContext.Current.Lists.MonsantoEntity.GetItems(oQuery);

                if (collListItems.Count > 0)
                {
                    DataTable dt = collListItems.GetDataTable();
                    if (dt != null)
                    {
                        var grouped = (from docs in dt.AsEnumerable()
                                       group docs by new { Country = docs["Country_x007c_Incorporation_x002"] } into newDoc
                                       orderby newDoc.Key.Country
                                       select new
                                       {
                                           Country = newDoc.Key.Country
                                       }).AsEnumerable();

                        this.ddlCountry.DataTextField = "Country";
                        this.ddlCountry.DataValueField = "Country";
                        this.ddlCountry.DataSource = grouped;
                        this.ddlCountry.DataBind();
                        this.ddlCountry.Items.Insert(0, "- SELECT -");
                    }
                }
            }
            catch (Exception ecp)
            {

                ECContext.LogEvent("BindCountryDropDown Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
            }
        }

        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                BindDropDownList(ddlMonsantoEntity, ECContext.Current.Lists.MonsantoEntity.GetItems(new SPQuery() { RowLimit = 1000, Query = string.Format("<Where><And><And><Eq><FieldRef Name='Country_x007c_Incorporation_x002' /><Value Type='Lookup'>{0}</Value></Eq><Eq><FieldRef Name='Language' /><Value Type='Lookup'>{1}</Value></Eq></And><Eq><FieldRef Name='UseInCE'/><Value Type='Boolean'>1</Value></Eq></And></Where>", ddlCountry.SelectedItem.Value, "English") }));
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Unexpected error ocurred selecting new country." + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        protected void ddlMonsantoEntity_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SetMonsantoEntityValues();
                string sapNumber = this.sapVendorNumberTxt.Text;
                this.sapVendorNumberTxt.Text = "";
                this.sapVendorNumberTxt.Text = sapNumber;
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Unexpected error ocurred selecting new entity." + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void SetMonsantoEntityValues()
        {
            try
            {
                this.ddlSigantories.Items.Clear();

                if (ddlMonsantoEntity.SelectedItem != null &&
                    ddlMonsantoEntity.SelectedIndex > 0)
                {

                    //ECContext.ContractDynamicPortion entityInformation = GetEntityDynamicPortion("English");
                    //ReplaceEntityInfoInPortions(entityInformation, "English");

                    //string matchCodeTag = @"\[#(.*?)\#]";
                    //string textToReplace = entityInformation.Portion;
                    //string replaceWith = "";
                    //string output = Regex.Replace(textToReplace, matchCodeTag, replaceWith);
                    //this.litMonsantoEntity.Text = output;
                    SPListItem item = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));
                    SPListItem template = GetTemplate(this.templateName.Value);
                    this.templateNameForFile.Value = template["Title"].ToString();
                    this.entityForFile.Value = item["Abbreviation"] != null ? Convert.ToString(item["Abbreviation"]) : ddlMonsantoEntity.SelectedItem.Text;
                    this.lbFileName.Text = BuildFileName();
                    if (item["Signatories"] != null)
                    {
                        SPFieldLookupValueCollection signatories = new SPFieldLookupValueCollection(Convert.ToString(item["Signatories"]));
                        foreach (SPFieldLookupValue signatory in signatories)
                        {
                            this.ddlSigantories.Items.Add(new System.Web.UI.WebControls.ListItem(signatory.LookupValue, signatory.LookupId.ToString()));
                        }
                        this.ddlSigantories.Items.Insert(0, " - SELECT - ");
                    }
                }
                else
                    this.litMonsantoEntity.Text = "";
                if (_clonedContractItem != null)
                {
                    string ddlMonsantoRepresentedByLookupValue = new SPFieldLookupValue((string)_clonedContractItem["Monsanto_x0020_Entity_x0020_Signatory"]).LookupValue;
                    ddlMonsantoRepresentedByLookupValue = ddlMonsantoRepresentedByLookupValue.Replace(";", "").Trim();

                    foreach (System.Web.UI.WebControls.ListItem signatory in this.ddlSigantories.Items)
                    {
                        if (signatory.Value == new SPFieldLookupValue((string)_clonedContractItem["Monsanto_x0020_Entity_x0020_Signatory"]).LookupId.ToString())
                        {
                            ddlSigantories.SelectedValue = signatory.Value;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error getting the values of the selected Monsanto Entity. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

        }

        void gvTemplates_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }

        private Dictionary<string, ECContext.Bookmark> GetBookmarksFromOriginalContract(SPListItem OriginalContract)
        {
            Dictionary<string, ECContext.Bookmark> bookmarks;
            bookmarks = ECContext.OpenXml.FindBookmarks(OriginalContract.File.OpenBinaryStream());
            return bookmarks;
        }

        private void CheckTemplateSanity(DataTable dt, int templateId)
        {
            StringBuilder validationErrors = new StringBuilder();

            if (dt == null)
            {
                validationErrors.AppendLine("Template contains no bookmarks.<br/>");
                throw new ECValidationException(String.Empty, validationErrors.ToString());
            }

            var bookmarks = from bookmark in dt.AsEnumerable()
                            select new ECContext.Bookmark { Name = bookmark.Field<string>("Title"), DataValue = bookmark.Field<string>("Data_x0020_Value"), DataType = bookmark.Field<string>("Data_x0020_Type"), Description = bookmark.Field<string>("Bookmark_x0020_Description"), Mapping = bookmark.Field<string>("FieldMapping"), LongDescription = bookmark.Field<string>("Long_x0020_Description") };

            //Check counterparty is mapped
            if (!bookmarks.Any(bm => bm.Mapping == "Counterparty"))
                validationErrors.AppendLine("A template must contain a bookmark mapped to 'Counterparty' value.<br/>");

            //Check unique bookmark name
            if (bookmarks.GroupBy(b => b.Name).All(x => x.Count() == 1) == false)
                validationErrors.AppendLine("There is at least one bookmark name repeated.<br/>");

            //Check template is valid (all bookmarks on list for this template are present on document template)
            SPListItem templateItem = ECContext.Current.Lists.ContractTemplate.GetItemById(templateId);
            Dictionary<string, ECContext.Bookmark> templateBookmarks = ECContext.OpenXml.FindBookmarks(templateItem.File.OpenBinaryStream());

            if (bookmarks.Any(b => templateBookmarks.Where(b2 => b2.Value.Name == b.Name).Count() == 0))
            {
                string MissingBookmarks = GetBookmarkDiferences(templateBookmarks, bookmarks);
                validationErrors.AppendLine("The bookmarks within template file don't match the ones defined in 'Bookmark' list for this template. Bookmarks missing: " + MissingBookmarks + "<br/>");
            }

            //Check if contract template has more user defined bookmarks than created on list for this template
            if (validationErrors.Length == 0 && templateBookmarks.Count > bookmarks.Count())
            {
                ECContext.LogEvent("Template '" + templateItem.Title + "' contains bookmarks tha aren't defined on 'Bookmark' list for this template. Following bookmarks are missing on list for this template: " + DistinctBookmarks(templateBookmarks, bookmarks.ToList()), null, ECContext.TraceLevel.Template);
                CEJSUtil.PopInfo(Page, ECContext.Messages.InfoPopupTitle, ECContext.Messages.MissingBookmarksOnListInfo + "<br/><br/>Missing bookmarks: " + DistinctBookmarks(templateBookmarks, bookmarks.ToList()) + "<br/>");
            }

            //Raise exception if errors found
            if (validationErrors.Length > 0)
                throw new ECValidationException(String.Empty, validationErrors.ToString());
        }

        private string GetBookmarkDiferences(Dictionary<string, ECContext.Bookmark> templateBookmarks, EnumerableRowCollection<ECContext.Bookmark> bookmarks)
        {
            string BookmarksFound = string.Empty;
            foreach (ECContext.Bookmark templBookmark in bookmarks)
            {
                if (!templateBookmarks.ContainsKey(templBookmark.Name))
                    BookmarksFound += templBookmark.Name + ", ";
            }
            if (BookmarksFound.Length > 2)
                BookmarksFound = BookmarksFound.Substring(0, BookmarksFound.Length - 2);

            return BookmarksFound;
        }

        private string DistinctBookmarks(Dictionary<string, ECContext.Bookmark> templateBookmarks, List<ECContext.Bookmark> listBookmarks)
        {
            string distinctBookmarks = " ";

            foreach (KeyValuePair<string, ECContext.Bookmark> bookmark in templateBookmarks)
            {
                if (listBookmarks.Where(b => b.Name == bookmark.Value.Name).Count() == 0)
                {
                    distinctBookmarks += " " + bookmark.Value.Name + ",";
                }
            }

            return distinctBookmarks.Substring(0, distinctBookmarks.Length - 1);
        }

        void gvFCPAQuestions_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                try
                {
                    RadioButton rbYes = (RadioButton)e.Row.FindControl("rbFCPAYes");
                    rbYes.Attributes.Add("OnClick", "CheckifSAPNUmberisNeeded();");
                    RadioButton rbNo = (RadioButton)e.Row.FindControl("rbFCPANo");
                    rbNo.Attributes.Add("OnClick", "CheckifSAPNUmberisNeeded();");
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("gvFCPAQuestions_RowCreated Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                }
            }
        }

        void gvFCPAQuestions_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (_clonedContractItem != null)
            {
                try
                {
                    XmlDocument doc = new XmlDocument();
                    if (_clonedContractItem[ECContext.Current.Configuration.ECFields.FCPA_XML] != null &&
                        !String.IsNullOrEmpty(_clonedContractItem[ECContext.Current.Configuration.ECFields.FCPA_XML].ToString()))
                    {
                        doc.LoadXml(_clonedContractItem[ECContext.Current.Configuration.ECFields.FCPA_XML].ToString());

                        if (DataBinder.Eval(e.Row.DataItem, "ID") != null)
                        {
                            string ID = DataBinder.Eval(e.Row.DataItem, "ID").ToString();
                            XmlNode xnquestion = doc.SelectSingleNode(String.Format("/FCPAQuestions/question[@ID='{0}']", ID));
                            if (xnquestion != null)
                            {
                                bool questionResult = Boolean.Parse(xnquestion.InnerText);
                                ((RadioButton)e.Row.FindControl("rbFCPAYes")).Checked = questionResult;
                                ((RadioButton)e.Row.FindControl("rbFCPANo")).Checked = !questionResult;
                            }
                        }

                    }
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("gvFCPAQuestions_RowDataBound Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                }
            }
        }

        private bool SAPNumberNeeded()
        {
            bool FCPAApprovalRequested = false;
            string ID = "";
            foreach (GridViewRow row in this.gvFCPAQuestions.Rows)
            {
                FCPAApprovalRequested = ((RadioButton)row.FindControl("rbFCPAYes")).Checked;
                ID = ((Label)row.FindControl("lbID")).Text;
                if (FCPAApprovalRequested) break;
            }
            return FCPAApprovalRequested;
        }

        private string BuildFCPAXML()
        {
            bool FCPAChecked;
            string ID = "";
            XmlDocument doc = new XmlDocument();
            XmlElement fcpaElement;
            fcpaElement = doc.CreateElement("FCPAQuestions");
            doc.AppendChild(fcpaElement);

            foreach (GridViewRow row in this.gvFCPAQuestions.Rows)
            {
                XmlElement questionXML = doc.CreateElement("question");
                FCPAChecked = ((RadioButton)row.FindControl("rbFCPAYes")).Checked;
                ID = ((Label)row.FindControl("lbID")).Text;
                questionXML.SetAttribute("ID", ID);
                questionXML.InnerText = FCPAChecked.ToString();
                doc.DocumentElement.AppendChild(questionXML);
            }
            return doc.OuterXml;
        }


        void gvTemplates_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                try
                {
                    if (DataBinder.Eval(e.Row.DataItem, "Document_x0020_Type") != null)
                    {
                        string documentType = DataBinder.Eval(e.Row.DataItem, "Document_x0020_Type").ToString();
                        SPListItemCollection items = GetLanguagesbyDocumentType(documentType, ""/*description*/);
                        if (items != null)
                        {

                            string mainLang,
                                secondLang;
                            int HorizontalCellCount = 0;
                            System.Web.UI.WebControls.Table languageTable = new System.Web.UI.WebControls.Table();
                            System.Web.UI.WebControls.TableRow languageRow = new System.Web.UI.WebControls.TableRow();
                            System.Web.UI.WebControls.TableCell languageCell;
                            Panel languagePanel = (Panel)e.Row.FindControl("InnerLanguagesDiv");

                            foreach (SPListItem item in items)
                            {
                                if (HorizontalCellCount == 10)
                                {
                                    languageTable.Rows.Add(languageRow);
                                    languageRow = new System.Web.UI.WebControls.TableRow();
                                    HorizontalCellCount = 0;
                                }



                                mainLang = new SPFieldLookupValue(item["Language"] as String).LookupValue;
                                if (item["Second_x0020_Language"] != null &&
                                    !String.IsNullOrEmpty(item["Second_x0020_Language"].ToString()))
                                {
                                    secondLang = new SPFieldLookupValue(item["Second_x0020_Language"] as String).LookupValue;
                                    mainLang = string.Concat(mainLang, " - ", secondLang);
                                }

                                LinkButton lnkButton = new LinkButton();
                                lnkButton.ID = item["FileLeafRef"].ToString() + "#" + mainLang;
                                lnkButton.Text = mainLang;
                                lnkButton.Click += new EventHandler(lnkButton_Click);
                                lnkButton.ToolTip = item.Title;
                                languageCell = new System.Web.UI.WebControls.TableCell();
                                languageCell.Controls.Add(lnkButton);
                                languageCell.CssClass = "languageCell";
                                languageRow.Cells.Add(languageCell);
                                HorizontalCellCount = HorizontalCellCount + 1;
                            }

                            languageTable.Rows.Add(languageRow);
                            languagePanel.Controls.Add(languageTable);

                        }
                    }
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("gvTemplates_RowCreated Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                }
            }
        }

        void lnkButton_Click(object sender, EventArgs e)
        {

            string[] parameters = ((LinkButton)sender).ID.Split('#');
            this.lbErrorMessage.Visible = false;



            this.templateName.Value = parameters[0];
            this.lbContractLanguages.Text = parameters[1];

            try
            {
                this.pnlStepThree.Style.Add("display", "inline!important");
                this.BookmarkPanel.Style.Add("display", "inline!important");

                SPListItem template = GetTemplate(this.templateName.Value);
                if (template != null)
                {
                    this.templateNameForFile.Value = template["Title"].ToString();

                    this.lbFileName.Text = BuildFileName();
                    this.lbContractTemplate.Text = template["Title"].ToString();
                    this.hdnDocumentType.Value = template["Document_x0020_Type"].ToString();
                    if (!IsForCloning)
                    {
                        BuildBookmarkLists(template);
                        BuildFCPAQuestions();
                    }
                    string script = String.Format("$(\"#{0}\").click();", this.RefreshPageButton.ClientID);
                    if (!IsForCloning) ScriptManager.RegisterStartupScript(this.pnlMain, this.pnlMain.GetType(), "clickRefresh", script, true);
                }
            }
            catch (Exception ecp)
            {
                this.pnlStepThree.Style.Add("display", "none!important");
                this.BookmarkPanel.Style.Add("display", "none!important");
                lbErrorMessage.Text = ecp.Message;
                this.lbErrorMessage.Visible = true;
                ECContext.LogEvent("lnkButton_Click Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
            }
        }

        private string BuildFileName()
        {
            string fileNamePattern = string.Format("{0}_[Template]_[counterparty]_[Monsanto Entity].docx", DateTime.Now.ToString("yyyyMMddHHmm"));
            string template = this.templateNameForFile.Value;
            string counterparty = this.counterPartyNameForFile.Value;
            string entity = this.entityForFile.Value;

            if (!String.IsNullOrEmpty(template))
                fileNamePattern = fileNamePattern.Replace("[Template]", template);

            if (!String.IsNullOrEmpty(counterparty))
            {
                if (counterparty.Length > 20)
                    counterparty = counterparty.Substring(0, 20);
                fileNamePattern = fileNamePattern.Replace("[counterparty]", counterparty);
            }

            if (!String.IsNullOrEmpty(entity))
                fileNamePattern = fileNamePattern.Replace("[Monsanto Entity]", entity);

            return fileNamePattern;
        }

        private void BuildFCPAQuestions()
        {

            this.gvFCPAQuestions.DataSource = ECContext.Current.Lists.ApprovalQuestion.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='LinkTitleNoMenu' Ascending='True' /><FieldRef Name='Order0' Ascending='True' /></OrderBy>" }).GetDataTable();
            this.gvFCPAQuestions.DataBind();
        }

        private void BuildBookmarkLists(SPListItem template)
        {
            List<ECContext.BookmarkGridItem> tempMainBookmarks = new List<ECContext.BookmarkGridItem>();
            List<ECContext.BookmarkGridItem> tempSecondaryLangunageBookmarks = new List<ECContext.BookmarkGridItem>();
            ECContext.BookmarkGridItem bookmarkItem;

            SPListItemCollection langs,
                bookmarks;


            string MainLanguageCode = "",
                SecLanguageCode = "";

            try
            {
                MainLanguage = new SPFieldLookupValue(Convert.ToString(template["Language"])).LookupValue; //template["Language"].ToString();
                if (template["Second_x0020_Language"] != null)
                    SecLanguage = new SPFieldLookupValue(Convert.ToString(template["Second_x0020_Language"])).LookupValue; //template["Second_x0020_Language"] != null ? template["Second_x0020_Language"].ToString() : "";
                else
                    SecLanguage = "";

                langs = ECContext.Current.Lists.Language.GetItems(new SPQuery { Query = String.Format("<Where><Or><Eq><FieldRef Name=\"Title\"/><Value Type=\"Text\">{0}</Value></Eq><Eq><FieldRef Name=\"Title\"/><Value Type=\"Text\">{1}</Value></Eq></Or></Where>", MainLanguage, SecLanguage) });
                foreach (SPListItem lang in langs)
                {
                    if (lang["Title"].ToString() == MainLanguage) MainLanguageCode = lang["BookmarkLangCode"].ToString();
                    else if (lang["Title"].ToString() == SecLanguage) SecLanguageCode = lang["BookmarkLangCode"].ToString();
                }

                bookmarks = ECContext.Current.Lists.Bookmark.GetItems(new SPQuery { Query = String.Format("<Where><Eq><FieldRef Name=\"Template\"/><Value Type=\"Text\">{0}</Value></Eq></Where>", template["Title"]) });

                Dictionary<string, ECContext.Bookmark> OriginalBookmarks = null;
                if (_clonedContractItem != null)
                {
                    OriginalBookmarks = GetBookmarksFromOriginalContract(_clonedContractItem);
                }
                else
                    CheckTemplateSanity(bookmarks.GetDataTable(), int.Parse(template["ID"].ToString()));
                bool isBookmarkValid = true;
                foreach (SPListItem bookmark in bookmarks)
                {
                    if (//(bookmark["FieldMapping"] == null || bookmark["FieldMapping"].ToString() == "Counterparty") &&
                        (bookmark["Bookmark_x0020_Description"] != null && !String.IsNullOrEmpty(bookmark["Bookmark_x0020_Description"].ToString().Trim())))
                    {

                        isBookmarkValid = _clonedContractItem == null ||
                            ((OriginalBookmarks != null) && (OriginalBookmarks.Where(s => s.Key == bookmark.Title).Count() > 0));
                        if (isBookmarkValid)
                        {
                            bookmarkItem = new ECContext.BookmarkGridItem();
                            bookmarkItem.BookmarkDescription = bookmark["Bookmark_x0020_Description"] != null ? bookmark["Bookmark_x0020_Description"].ToString() : "";
                            bookmarkItem.DataType = bookmark["Data_x0020_Type"] != null ? bookmark["Data_x0020_Type"].ToString() : "";
                            bookmarkItem.FieldMapping = bookmark["FieldMapping"] != null ? bookmark["FieldMapping"].ToString() : "";
                            bookmarkItem.Required = bookmark["Required"] != null ? bool.Parse(bookmark["Required"].ToString()) : false;
                            bookmarkItem.InternalName = bookmark["Title"].ToString();
                            bookmarkItem.LongDescription = bookmark["Long_x0020_Description"] != null ? bookmark["Long_x0020_Description"].ToString() : "";
                            bookmarkItem.MainBookmarkDescription = bookmark["Bookmark_x0020_Description"] != null ? bookmark["Bookmark_x0020_Description"].ToString() : "";
                            bookmarkItem.SecBookmarkDescription = !String.IsNullOrEmpty(SecLanguage) && bookmarkItem.BookmarkDescription.EndsWith("_" + MainLanguageCode) ? bookmarkItem.BookmarkDescription.Substring(0, bookmarkItem.BookmarkDescription.Length - MainLanguageCode.Length) + SecLanguageCode : "";

                            bool isCounterparty = (bookmarkItem.FieldMapping == "Counterparty");


                            string sQuery = String.Format(@"<Where><And><Eq><FieldRef Name=""Template""/><Value Type=""Text"">{0}</Value></Eq><Eq><FieldRef Name=""Bookmark""/><Value Type=""Text"">{1}</Value></Eq></And></Where>", template["Title"], bookmark["Title"]);
                            string sViewFields = @"<FieldRef Name=""Bookmark"" /><FieldRef Name=""Template"" /><FieldRef Name=""Order0"" />";
                            string sViewAttrs = @"Scope=""Recursive""";
                            uint iRowLimit = 0;

                            var oQuery = new SPQuery();
                            oQuery.Query = sQuery;
                            oQuery.ViewFields = sViewFields;
                            oQuery.ViewAttributes = sViewAttrs;
                            oQuery.RowLimit = iRowLimit;

                            SPListItemCollection orderbookmark = ECContext.Current.Lists.TemplateBookmarksOrder.GetItems(oQuery);

                            int order = 0;
                            if (orderbookmark != null &&
                                orderbookmark.Count > 0 &&
                                orderbookmark[0]["Order0"] != null &&
                                int.TryParse(orderbookmark[0]["Order0"].ToString(), out order))
                            {
                                bookmarkItem.OrderPosition = order;
                            }
                            else
                                bookmarkItem.OrderPosition = 0;


                            if (!String.IsNullOrEmpty(SecLanguageCode) &&
                                bookmarkItem.BookmarkDescription.EndsWith("_" + SecLanguageCode))
                                tempSecondaryLangunageBookmarks.Add(bookmarkItem);
                            else
                                if (!String.IsNullOrEmpty(bookmarkItem.BookmarkDescription)) tempMainBookmarks.Add(bookmarkItem);
                        }

                    }
                }

                this.SecondaryLanguageBookmarks = tempSecondaryLangunageBookmarks;
                this.MainBookmarks = tempMainBookmarks;



                var mainGrouped = (from mainB in MainBookmarks
                                   where String.IsNullOrEmpty(mainB.FieldMapping) || mainB.FieldMapping == "Counterparty"
                                   orderby mainB.OrderPosition
                                   group mainB by new { Bookmark_x0020_Description = mainB.BookmarkDescription, Required = true } into newDoc
                                   select new
                                   {
                                       Bookmark_x0020_Description = newDoc.Key.Bookmark_x0020_Description.EndsWith("_" + MainLanguageCode) ? newDoc.Key.Bookmark_x0020_Description.Substring(0, newDoc.Key.Bookmark_x0020_Description.Length - (MainLanguageCode.Length + 1)) : newDoc.Key.Bookmark_x0020_Description,
                                       MainBookmark_x0020_Description = newDoc.Key.Bookmark_x0020_Description,
                                       SecBookmark_x0020_Description = !String.IsNullOrEmpty(SecLanguage) && newDoc.Key.Bookmark_x0020_Description.EndsWith("_" + MainLanguageCode) ? newDoc.Key.Bookmark_x0020_Description.Substring(0, newDoc.Key.Bookmark_x0020_Description.Length - MainLanguageCode.Length) + SecLanguageCode : "",
                                       Required = newDoc.Key.Required
                                   });

                this.gvBookmarks.DataSource = mainGrouped;
                this.gvBookmarks.DataBind();
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent("BuildBookmarkLists Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                throw;
            }

        }

        void gvBookmarks_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            bool HideColumn = String.IsNullOrEmpty(SecLanguage);
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[4].Text = MainLanguage;

                e.Row.Cells[5].Text = !String.IsNullOrEmpty(SecLanguage) ? SecLanguage : "N/A";
            }
            else if (e.Row.RowType == DataControlRowType.DataRow)
            {

                try
                {
                    if (DataBinder.Eval(e.Row.DataItem, "Bookmark_x0020_Description") != null)
                    {
                        bool Required = bool.Parse(DataBinder.Eval(e.Row.DataItem, "Required").ToString());

                        string MainBookmarkDescritption = DataBinder.Eval(e.Row.DataItem, "MainBookmark_x0020_Description").ToString();
                        string SecBookmarkDescription = DataBinder.Eval(e.Row.DataItem, "SecBookmark_x0020_Description").ToString();
                        DisplayBookmarkControl(e.Row, MainBookmarkDescritption, SecBookmarkDescription, !String.IsNullOrEmpty(SecBookmarkDescription));

                        ECContext.BookmarkGridItem item = this.MainBookmarks.Where(s => s.MainBookmarkDescription == MainBookmarkDescritption && s.FieldMapping.ToLower() == "counterparty").FirstOrDefault();
                        if ((item != null))
                        {
                            this.hdnCounterparty.Value = e.Row.RowIndex.ToString();
                            //((TextBox)e.Row.FindControl("BookmarkTextValue")).Attributes.Add("onchange", "BuildFileName(" + ((TextBox)e.Row.FindControl("BookmarkTextValue")).ClientID + ")");
                            ((TextBox)e.Row.FindControl("BookmarkTextValue")).Attributes.Add("onblur", "BuildFileName(" + ((TextBox)e.Row.FindControl("BookmarkTextValue")).ClientID + ")");
                        }
                    }
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("gvBookmarks_RowDataBound Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    throw ecp;
                }
            }

            if (HideColumn)
                e.Row.Cells[5].Visible = false;
        }

        void gvBookmarks_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                System.Web.UI.Control ctrl = e.Row.FindControl("BookmarkCalendarValue");
                ((DateTimeControl)ctrl).DatePickerFrameUrl = ResolveUrl(SPContext.Current.Site.Url + "/_layouts/iframe.aspx");
            }
        }

        private string DisplayBookmarkControl(GridViewRow row, string mainDescription, string secDescription, bool DisplaySecondaryLanguageControl)
        {

            System.Web.UI.Control ctrl = null;

            ECContext.BookmarkGridItem itemBookmark = this.MainBookmarks.Where(s => s.MainBookmarkDescription == mainDescription).FirstOrDefault();

            try
            {
                if (itemBookmark != null)
                {
                    string mainDataType = itemBookmark.DataType;

                    switch (mainDataType)
                    {
                        case "Text":
                            ctrl = row.FindControl("BookmarkTextValue");
                            ctrl.Visible = true;
                            ((TextBox)ctrl).ToolTip = this.MainBookmarks.Where(s => s.MainBookmarkDescription == mainDescription).FirstOrDefault().LongDescription;
                            if (this.ValidateForm.Value == "1" &&
                                String.IsNullOrEmpty(((TextBox)ctrl).Text))
                            {
                                ((TextBox)ctrl).CssClass += ((TextBox)ctrl).CssClass + "ms-bookmark-val-error";
                            }

                            ((TextBox)ctrl).Text = _clonedContractBookmarks.ContainsKey(itemBookmark.InternalName) ? _clonedContractBookmarks[itemBookmark.InternalName].Content : String.Empty;

                            break;
                        case "Bulleted list":
                            ctrl = row.FindControl("BookmarkMultiTextValue");
                            ctrl.Visible = true;
                            ((InputFormTextBox)ctrl).ToolTip = this.MainBookmarks.Where(s => s.MainBookmarkDescription == mainDescription).FirstOrDefault().LongDescription;
                            if (this.ValidateForm.Value == "1" &&
                                String.IsNullOrEmpty(((InputFormTextBox)ctrl).Text))
                            {
                                ((InputFormTextBox)ctrl).CssClass += ((InputFormTextBox)ctrl).CssClass + "ms-bookmark-val-error";
                            }

                            string bulletedContent = _clonedContractBookmarks.ContainsKey(itemBookmark.InternalName) ? _clonedContractBookmarks[itemBookmark.InternalName].Content : String.Empty;
                            bulletedContent = bulletedContent.Replace("\r\n", "<br />");
                            bulletedContent = bulletedContent.Replace("<br /><br />", "<br />");
                            while (bulletedContent.StartsWith("<br />"))
                                bulletedContent = bulletedContent.Substring(6);
                            ((InputFormTextBox)ctrl).Text = bulletedContent;

                            break;
                        case "Date":
                            ctrl = row.FindControl("BookmarkCalendarValue");
                            ((DateTimeControl)ctrl).ToolTip = this.MainBookmarks.Where(s => s.MainBookmarkDescription == mainDescription).FirstOrDefault().LongDescription;
                            ctrl.Visible = true;
                            ((DateTimeControl)ctrl).DatePickerFrameUrl = ResolveUrl(SPContext.Current.Site.Url + "/_layouts/iframe.aspx");
                            if (this.ValidateForm.Value == "1" &&
                                ((DateTimeControl)ctrl).IsDateEmpty)
                            {
                                ((DateTimeControl)ctrl).CssClassTextBox += ((DateTimeControl)ctrl).CssClassTextBox + "ms-bookmark-val-error";
                            }
                            if (_clonedContractBookmarks.ContainsKey(itemBookmark.InternalName))
                            {
                                DateTime dt = new DateTime();
                                bool parsed = DateTime.TryParse(_clonedContractBookmarks[itemBookmark.InternalName].Content, out dt);
                                if (parsed)
                                    ((DateTimeControl)ctrl).SelectedDate = dt;
                            }

                            break;
                        case "Numeric":
                            ctrl = row.FindControl("BookmarkNumberValue");
                            ((TextBox)ctrl).ToolTip = this.MainBookmarks.Where(s => s.MainBookmarkDescription == mainDescription).FirstOrDefault().LongDescription;
                            ctrl.Visible = true;
                            //((TextBox)ctrl).AutoPostBack = true;
                            if (this.ValidateForm.Value == "1" &&
                                String.IsNullOrEmpty(((TextBox)ctrl).Text))
                            {
                                ((TextBox)ctrl).CssClass += ((TextBox)ctrl).CssClass + "ms-bookmark-val-error";
                            }
                            ((TextBox)ctrl).Text = _clonedContractBookmarks.ContainsKey(itemBookmark.InternalName) ? _clonedContractBookmarks[itemBookmark.InternalName].Content : String.Empty;
                            break;
                    }
                }
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent("DisplayBookmarkControl mainbookmark Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                throw ecp;
            }

            try
            {
                if (!String.IsNullOrEmpty(secDescription))
                {
                    itemBookmark = this.SecondaryLanguageBookmarks.Where(s => s.MainBookmarkDescription == secDescription).FirstOrDefault();
                    if (itemBookmark != null)
                    {
                        string secDataType = itemBookmark.DataType;
                        switch (secDataType)
                        {
                            case "Text":
                                ctrl = row.FindControl("SecBookmarkTextValue");
                                ((TextBox)ctrl).ToolTip = this.SecondaryLanguageBookmarks.Where(s => s.MainBookmarkDescription == secDescription).FirstOrDefault().LongDescription;
                                row.FindControl("SecBookmarkTextValue").Visible = DisplaySecondaryLanguageControl;
                                if (this.ValidateForm.Value == "1" &&
                                String.IsNullOrEmpty(((TextBox)ctrl).Text))
                                {
                                    ((TextBox)ctrl).CssClass += ((TextBox)ctrl).CssClass + "ms-bookmark-val-error";
                                }
                                ((TextBox)ctrl).Text = _clonedContractBookmarks.ContainsKey(itemBookmark.InternalName) ? _clonedContractBookmarks[itemBookmark.InternalName].Content : String.Empty;
                                break;
                            case "Bulleted list":
                                ctrl = row.FindControl("SecBookmarkMultiTextValue");

                                ((InputFormTextBox)ctrl).ToolTip = this.SecondaryLanguageBookmarks.Where(s => s.MainBookmarkDescription == secDescription).FirstOrDefault().LongDescription;
                                row.FindControl("SecBookmarkMultiTextValue").Visible = DisplaySecondaryLanguageControl;
                                if (this.ValidateForm.Value == "1" &&
                                String.IsNullOrEmpty(((InputFormTextBox)ctrl).Text))
                                {
                                    ((InputFormTextBox)ctrl).CssClass += ((InputFormTextBox)ctrl).CssClass + "ms-bookmark-val-error";
                                }

                                string bulletedContent = _clonedContractBookmarks.ContainsKey(itemBookmark.InternalName) ? _clonedContractBookmarks[itemBookmark.InternalName].Content : String.Empty;
                                bulletedContent = bulletedContent.Replace("\r\n", "<br />");
                                while (bulletedContent.StartsWith("<br />"))
                                    bulletedContent = bulletedContent.Substring(6);

                                ((InputFormTextBox)ctrl).Text = bulletedContent;
                                break;
                        }
                    }
                }
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent("DisplayBookmarkControl secondarybookmark Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                throw ecp;
            }

            return "";
        }

        void gvBookmarksSecondLanguage_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                try
                {
                    if (DataBinder.Eval(e.Row.DataItem, "Data_x0020_Type") != null)
                    {
                        string dataType = DataBinder.Eval(e.Row.DataItem, "Data_x0020_Type").ToString();
                        string SecBookmarkDescription = DataBinder.Eval(e.Row.DataItem, "SecBookmark_x0020_Description").ToString();
                        //DisplayBookmarkControl(e.Row, dataType, !String.IsNullOrEmpty(SecBookmarkDescription));
                    }
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("gvBookmarksSecondLanguage_RowDataBound  Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    throw ecp;
                }
            }
        }

        void gvTemplates_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                try
                {
                    if (DataBinder.Eval(e.Row.DataItem, "Document_x0020_Type") != null)
                    {
                        string documentType = DataBinder.Eval(e.Row.DataItem, "Document_x0020_Type").ToString();
                        //SPListItem dtype = GetDocumentTypeInfo(documentType);
                        string description = "";
                        SPListItem docType = GetDocumentTypeInfo(documentType);

                        if (docType != null)
                        {
                            description = docType["Description"] != null ? Convert.ToString(docType["Description"]) : "";
                            if (docType["Description"] != null)
                            {

                                SPFieldMultiLineText desc = docType.Fields["Description"] as SPFieldMultiLineText;
                                Label helpIcon = (Label)e.Row.FindControl("ldDocumentType");
                                description = desc.GetFieldValueAsHtml(docType["Description"]);
                                description = description.Replace("\r", String.Empty);
                                string[] arr = description.Split('\n').Where(a => a.Trim() != string.Empty).ToArray();
                                var htmlStr = "<p>" + String.Join("</p><p>", arr) + "</p>";

                                Literal tooltip = (Literal)e.Row.FindControl("tooltipLiteral");
                                tooltip.Text = htmlStr;

                                Panel pnltooltip = (Panel)e.Row.FindControl("documentTypeTooltip");

                                helpIcon.Attributes.Add("onmouseover", "showTooltip('" + pnltooltip.ClientID + "','" + htmlStr + "')");
                                helpIcon.Attributes.Add("onmouseout", "hideTooltip('" + pnltooltip.ClientID + "')");
                            }
                        }
                    }
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("gvTemplates_RowDataBound  Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                }
            }
        }

        private void dgdUpload_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                int recordToDelete = e.RowIndex;
                DataTable dt = ViewState["Files"] == null ? new DataTable() : (DataTable)ViewState["Files"];
                int cn = dt.Rows.Count;
                dt.Rows.RemoveAt(recordToDelete);
                dt.AcceptChanges();
                ViewState["Files"] = dt;
                this.dgdUpload.DataSource = dt;
                this.dgdUpload.DataBind();
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent("dgdUpload_RowDeleting  Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                throw ecp;
            }

        }

        protected void btnUploadUploadClick(object sender, EventArgs e)
        {
            try
            {
                String fileName = System.IO.Path.GetFileName(inputFile.PostedFile.FileName);

                if (fileName != "")
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {

                        if (inputFile.PostedFile.FileName.EndsWith(".exe"))
                            throw new Exception("File type (.exe) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".msi"))
                            throw new Exception("File type (.msi) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".config"))
                            throw new Exception("File type (.config) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".dll"))
                            throw new Exception("File type (.dll) not supported.");
                        else
                        {
                            string _fileTime = DateTime.Now.ToFileTime().ToString();
                            string _fileorgPath = System.IO.Path.GetFullPath(inputFile.PostedFile.FileName);
                            string _newfilePath = _fileTime + "~" + fileName;
                            string tempFolder = Environment.GetEnvironmentVariable("TEMP");
                            string _filepath = tempFolder + _newfilePath;
                            inputFile.PostedFile.SaveAs(_filepath);
                            AddRow(fileName, _filepath);
                            DataTable dt = (DataTable)ViewState["Files"];
                            if (dt != null)
                            {
                                this.dgdUpload.DataSource = dt;
                                this.dgdUpload.DataBind();
                            }

                        }
                    });
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.StartsWith("File attached length is") || ex.Message.StartsWith("File type (."))
                {
                    ECContext.LogEvent("Unexpected error ocurred uploading attached file - " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ex.Message);
                }
                else
                {
                    int logId = ECContext.LogEvent("Unexpected error ocurred uploading attached file. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }
            }
        }

        private void AddMoreColumns()
        {
            DataTable dt = new DataTable("Files");
            DataColumn dc = new DataColumn("FileName", Type.GetType("System.String"));
            dt.Columns.Add(dc);
            dc = new DataColumn("FilePath", Type.GetType("System.String"));
            dt.Columns.Add(dc);

            ViewState["Files"] = dt;
        }

        private void AddRow(string file, string path)
        {
            DataTable dt = (DataTable)ViewState["Files"];
            if (dt == null)
            {
                AddMoreColumns();
                dt = (DataTable)ViewState["Files"];
            }

            DataRow dr = dt.NewRow();
            dr["FileName"] = file;
            dr["FilePath"] = path;
            //dr["FileSize"] = Convert.ToString(length);
            //dr["KB"] = "KB";
            dt.Rows.Add(dr);
            ViewState["Files"] = dt;
        }

        void ddlRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddl = (DropDownList)sender;
            if (!_clonedContractId.HasValue &&
                ddlRegion.SelectedIndex > 0)
            {
                RefreshGrid();
                this.templateName.Value = "";
                this.lbContractLanguages.Text = "";

                this.pnlStepThree.Style.Add("display", "none!important");
                this.BookmarkPanel.Style.Add("display", "none!important");
            }
            //else
            //  this.gvTemplates.Visible = false;
        }

        void ddlDivision_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!_clonedContractId.HasValue &&
                ddlDivision.SelectedIndex > 0)
            {
                RefreshGrid();
                this.templateName.Value = "";
                this.lbContractLanguages.Text = "";

                this.pnlStepThree.Style.Add("display", "none!important");
                this.BookmarkPanel.Style.Add("display", "none!important");
            }
            //else
            //  this.gvTemplates.Visible = false;

        }

        private void RefreshGrid()
        {
            if (ddlRegion.SelectedIndex > 0 &&
                ddlDivision.SelectedIndex > 0)
            {
                this.gvTemplates.Visible = true;
                this.gvTemplates.DataSource = QueryData(this.ddlDivision.SelectedValue, this.ddlRegion.SelectedValue);
                this.gvTemplates.DataBind();
            }
        }

        private SPListItem GetDocumentTypeInfo(string DocumentType)
        {
            SPListItem returnItem = null;
            try
            {
                string sQuery = string.Format(@"<Where> <Eq><FieldRef Name='Title'/><Value Type='Text'>{0}</Value></Eq></Where>", DocumentType);
                //string sViewFields = @"<FieldRef Name=""ID"" />";
                string sViewAttrs = @"Scope=""Recursive""";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = sQuery;
                //oQuery.ViewFields = sViewFields;
                oQuery.ViewAttributes = sViewAttrs;
                oQuery.RowLimit = iRowLimit;

                SPListItemCollection collListItems = ECContext.Current.Lists.DocumentType.GetItems(oQuery);
                if (collListItems.Count == 1)
                {
                    returnItem = collListItems[0];
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
            return returnItem;
        }


        private SPListItem GetTemplate(string TemplateName)
        {
            SPListItem returnItem = null;
            try
            {
                string sQuery = string.Format(@"<Where> <Eq><FieldRef Name='FileLeafRef'/><Value Type='Lookup'>{0}</Value></Eq></Where>", TemplateName);
                //string sViewFields = @"<FieldRef Name=""ID"" />";
                string sViewAttrs = @"Scope=""Recursive""";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = sQuery;
                //oQuery.ViewFields = sViewFields;
                oQuery.ViewAttributes = sViewAttrs;
                oQuery.RowLimit = iRowLimit;

                SPListItemCollection collListItems = ECContext.Current.Lists.ContractTemplate.GetItems(oQuery);
                if (collListItems.Count == 1)
                {
                    returnItem = collListItems[0];
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
            return returnItem;
        }

        public SPListItemCollection GetLanguagesbyDocumentType(string DocumentType, string Description)
        {
            SPListItemCollection collListItems = null;
            try
            {
                string queryDivision = String.Format("<Eq><FieldRef Name='Divisions' LookupId='TRUE' /><Value Type='Lookup'>{0}</Value></Eq>", this.ddlDivision.SelectedValue);
                string queryRegions = String.Format("<Eq><FieldRef Name='Regions'  LookupId='TRUE' /><Value Type='Lookup'>{0}</Value></Eq>", this.ddlRegion.SelectedValue);
                string documentQuery = string.Format("<Eq><FieldRef Name='Document_x0020_Type'/><Value Type='Lookup'>{0}</Value></Eq>", DocumentType);

                string docQuery = string.Format("<And>{0}<And>{1}{2}</And></And>", queryDivision, queryRegions, documentQuery);

                string sQuery;
                if (!String.IsNullOrEmpty(Description))
                {
                    sQuery = string.Format("<Where><And>{0}<Eq><FieldRef Name='Description0'/><Value Type='Text'>{1}</Value></Eq></And></Where>", docQuery, Description);
                }
                else
                    sQuery = string.Format("<Where>{0}</Where>", docQuery);

                string sViewFields = @"<FieldRef Name=""Title"" /><FieldRef Name=""Document_x0020_Type"" /><FieldRef Name=""Language"" /><FieldRef Name=""Second_x0020_Language"" /><FieldRef Name=""BaseName"" /><FieldRef Name=""FileLeafRef"" /><FieldRef Name=""Description0"" />";
                string sViewAttrs = @"Scope=""Recursive""";
                string sOrder = @"<OrderBy><FieldRef Name=""Language"" ></FieldRef><FieldRef Name=""Second_x0020_Language"" ></FieldRef></OrderBy>";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = sQuery + sOrder;
                oQuery.ViewFields = sViewFields;
                oQuery.ViewAttributes = sViewAttrs;
                oQuery.RowLimit = iRowLimit;

                collListItems = ECContext.Current.Lists.ContractTemplate.GetItems(oQuery);
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

            return collListItems;
        }

        void btGenerateContract_Click(object sender, EventArgs e)
        {
            SPFile contractFile = null;
            Dictionary<string, string> bookmarks;
            Dictionary<string, string> rtfBookmarks;
            bool bOk = false;

            try
            {
                if (!DoaAdmin.IsValid)
                    throw new ECValidationException("DOA Approver", "Please select a valid DOA approver");

                CompileBookmarkData(BuildBookmarListFromGrid(), out bookmarks, out rtfBookmarks);

                try
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        //everis-052814 Fix 'Access Denied' issue
                        using (SPSite curSite = new SPSite(SPContext.Current.Site.ID))
                        {
                            using (SPWeb currweb = curSite.OpenWeb(SPContext.Current.Web.ID))
                            {
                                // 3. Generate word document
                                contractFile = SaveContract(bookmarks, rtfBookmarks, currweb);

                                // 4. Populate contract metadata columns
                                bOk = SaveContractMeta(contractFile.Item, currweb);
                                if (!bOk)
                                    throw new Exception("There was a problem saving metadata or uploading attachment files");
                            }
                        }
                    }
                );
                }
                catch (Exception ecp)
                {
                    if (contractFile != null)
                        contractFile.Delete();
                    ECContext.LogEvent("btGenerateContract_Click Exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    throw ecp;
                }


                SPSite site = SPContext.Current.Site;
                SPWeb web = SPContext.Current.Web;

                SPListItem item = null;
                try
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        using (SPSite ElevatedSite = new SPSite(site.ID))
                        using (SPWeb ElevatedWeb = ElevatedSite.OpenWeb(web.ID))
                        {


                            item = ElevatedWeb.Lists[ECContext.Current.Configuration.ExpressContractLibraryName].GetItemById(contractFile.Item.ID);
                            if (SAPNumberNeeded())
                            {
                                item[ECContext.Current.Configuration.ECFields.FCPA] = "FCPA APPROVAL REQUIRED";
                                item[ECContext.Current.Configuration.ECFields.FCPAApproval] = "Pending";
                                item[ECContext.Current.Configuration.ECFields.FCPAActionDate] = null;
                                SaveFCPAMailAsWordDocument(item);
                            }
                            else
                            {
                                item[ECContext.Current.Configuration.ECFields.FCPA] = "NOT FCPA RELEVANT";
                                item[ECContext.Current.Configuration.ECFields.FCPAApproval] = "N/A";
                                item[ECContext.Current.Configuration.ECFields.FCPAActionDate] = null;
                            }

                            item[ECContext.Current.Configuration.ECFields.DoaApproval] = "Pending";
                            item[ECContext.Current.Configuration.ECFields.DOAActionDate] = null;
                            item[ECContext.Current.Configuration.ECFields.LegalApproval] = "Pending Business";
                            item[ECContext.Current.Configuration.ECFields.LegalActionDate] = null;


                            item["Sap Vendor Number"] = sapVendorNumberTxt.Text;
                            ElevatedWeb.AllowUnsafeUpdates = true;

                            DisabledItemEventsScope disEvnt = new DisabledItemEventsScope();
                            try
                            {
                                disEvnt.DisabledItemEvents();
                                item.SystemUpdate(false);
                            }
                            catch (Exception ex)
                            {
                                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                            }
                            finally
                            {
                                disEvnt.Dispose();
                            }

                            ElevatedWeb.AllowUnsafeUpdates = false;

                        }
                    });
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("btGenerateContract_click Saving FCPA data exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    throw ecp;
                }


                // 4. Redirect to summary
                if (bOk)
                    SPUtility.Redirect(string.Format("ContractExpressSystem/ContractSummary.aspx?itemid={0}{1}", Convert.ToString(item.ID), String.Empty), SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);

            }
            catch (ECValidationException ex)
            {
                ECContext.LogEvent("btGenerateContract_click  - " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, "Validation error", ex.Message);

            }
            catch (ThreadAbortException the)
            {
                ECContext.LogEvent("btGenerateContract_click  - " + the.Message, the, ECContext.TraceLevel.Unexpected);
            }
            catch (Exception ex)
            {
                //Comment : Venu, Date 07 April 2016, Show proper information about the error when there is duplicate bookmark
                int logId = 0;
                try
                {
                    if (hdnDuplicateBookmark.Value.ToString().StartsWith(";"))
                    {
                        hdnDuplicateBookmark.Value = hdnDuplicateBookmark.Value.Substring(1);
                    }
                    if (hdnDuplicateBookmark.Value.ToString().EndsWith(";"))
                    {
                        hdnDuplicateBookmark.Value = hdnDuplicateBookmark.Value.Substring(0, hdnDuplicateBookmark.Value.Length - 1);
                    }
                }
                catch (Exception)
                {
                    ECContext.AddLogEntry(ex.Message + " hdnDuplicateBookmark.Value concatenation", SPContext.Current.Web);
                }

                if (ex.Message.Contains("An item with the same key has already been added"))
                {
                    ECContext.AddLogEntry(ex.Message + " Duplicate Bookmark " + hdnDuplicateBookmark.Value, SPContext.Current.Web);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, " Error : Same Bookmark is present in Contract Portion and Contract Template which is not allowed, Duplicate Bookmark  : " + hdnDuplicateBookmark.Value + " Please, contact system administrator for support.");
                }
                else
                {
                    logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }
            }

        }

        private SPFile SaveContract(Dictionary<string, string> bookmarks, Dictionary<string, string> rtfBookmarks, SPWeb elevatedWeb)
        {
            try
            {
                SPListItem entityitem = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));
                string templateName = GetTemplate(this.templateName.Value)["Title"].ToString();
                String fileName = this.lbFileName.Text;

                fileName = CESPUtil.NormalizeFilename(fileName);
                SPFile destination;
                if (_clonedContractItem != null)
                    destination = new ECContext(SPContext.GetContext(elevatedWeb)).CreateNewExpressContractFromClone(_clonedContractItem, fileName, elevatedWeb);
                else
                    destination = new ECContext(SPContext.GetContext(elevatedWeb)).CreateNewExpressContractFromTemplate(fileName, templateName, elevatedWeb);

                try
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        byte[] buffer = destination.OpenBinary();
                        ms.Write(buffer, 0, buffer.Length);

                        if (rtfBookmarks.Count == 0)
                            ECContext.OpenXml.ProcessTemplate(ms, bookmarks);
                        else
                            ECContext.OpenXml.ProcessTemplate(ms, bookmarks, rtfBookmarks);

                        //Activate Track Changes                        
                        if (_clonedContractItem != null)
                        {
                            using (WordprocessingDocument docPart = WordprocessingDocument.Open(ms, true))
                            {
                                TrackRevisions newrevision = new TrackRevisions();
                                newrevision.Val = new DocumentFormat.OpenXml.OnOffValue(true);
                                docPart.MainDocumentPart.DocumentSettingsPart.Settings.AppendChild(newrevision);
                                docPart.MainDocumentPart.DocumentSettingsPart.Settings.Save();
                            }
                        }

                        elevatedWeb.AllowUnsafeUpdates = true;
                        destination.SaveBinary(ms);
                        elevatedWeb.AllowUnsafeUpdates = false;
                    }
                    ECContext.LogEvent("Contract created: " + destination.Url, null, ECContext.TraceLevel.Information, elevatedWeb);
                }
                catch (Exception ecp)
                {
                    if (destination != null)
                    {
                        elevatedWeb.Site.AllowUnsafeUpdates = true;
                        elevatedWeb.AllowUnsafeUpdates = true;
                        destination.Item.Delete();
                        //destination.Delete();
                        elevatedWeb.AllowUnsafeUpdates = false;
                    }
                    ECContext.LogEvent("SaveContract  - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    throw ecp;
                }




                return elevatedWeb.GetFile(destination.Url);
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error saving contract. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);

            }

            return null;
        }

        private bool SaveContractMeta(SPListItem itm, SPWeb elevatedWeb)
        {
            bool bOk = false;
            try
            {
                elevatedWeb.AllowUnsafeUpdates = true;


                itm[ECContext.Current.Configuration.ECFields.MonsantoEntity] = new SPFieldLookupValue(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value), ddlMonsantoEntity.SelectedItem.Text);
                itm[ECContext.Current.Configuration.ECFields.DocumentType] = this.hdnDocumentType.Value;
                itm[ECContext.Current.Configuration.ECFields.MonsantoDivision] = new SPFieldLookupValue(Convert.ToInt32(this.ddlDivision.SelectedItem.Value), this.ddlDivision.SelectedItem.Text);
                itm[ECContext.Current.Configuration.ECFields.Region] = new SPFieldLookupValue(Convert.ToInt32(this.ddlRegion.SelectedItem.Value), this.ddlRegion.SelectedItem.Text);
                itm[ECContext.Current.Configuration.ECFields.BusinessUser] = new SPFieldUserValue(itm.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName);
                itm["CounterParty"] = this.counterPartyNameForFile.Value;
                SPListItem entityitem = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));
                itm["Title"] = Path.GetFileNameWithoutExtension(itm.File.Name);
                SPListItem template = GetTemplate(this.templateName.Value);
                itm[ECContext.Current.Configuration.ECFields.Template] = new SPFieldLookupValue(template.ID, template.Title);
                SPListItem country = ECContext.Current.Lists.Country.GetItems(new SPQuery() { Query = string.Format("<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>{0}</Value></Eq></where>", ddlCountry.SelectedItem.Value) })[0];
                itm[ECContext.Current.Configuration.ECFields.Country] = new SPFieldLookupValue(country.ID, country.Title);
                itm[ECContext.Current.Configuration.ECFields.EntitySignatory] = new SPFieldLookupValue(int.Parse(this.ddlSigantories.SelectedItem.Value), this.ddlSigantories.SelectedItem.Text);
                SPUser doaUser = elevatedWeb.EnsureUser(((PickerEntity)DoaAdmin.ResolvedEntities[0]).Key);
                itm[ECContext.Current.Configuration.ECFields.DaoApprover] = new SPFieldUserValue(itm.Web, doaUser.ID, doaUser.LoginName);
                SPUser creatorUser = elevatedWeb.EnsureUser(new SPFieldUserValue(itm.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName).User.LoginName);
                string value1 = creatorUser.ID + ";#" + creatorUser.Name; //Create in same format               
                itm[SPBuiltInFieldId.Created] = DateTime.Now;
                itm[SPBuiltInFieldId.Author] = value1;
                itm[ECContext.Current.Configuration.ECFields.Cloneable] = false;
                itm[ECContext.Current.Configuration.ECFields.AutomaticApproval] = false;
                itm[ECContext.Current.Configuration.ECFields.CloneExpirationDate] = null;
                itm[ECContext.Current.Configuration.ECFields.CloningDate] = null;
                itm[ECContext.Current.Configuration.ECFields.CloneContractLink] = "";
                itm[ECContext.Current.Configuration.ECFields.FCPA_XML] = BuildFCPAXML();
                //Comment : Venu, Change Date 21 March 2016, ContractSubmit logic to avoid multiple mail to Legal department is not working. So I have commented the code
                //itm["ContractSubmitted"] = "No";




                DisabledItemEventsScope disEvnt = new DisabledItemEventsScope();
                disEvnt.DisabledItemEvents();
                bOk = false;
                itm.UpdateOverwriteVersion();
                itm.Update();
                itm.ParentList.Update();
                itm.Web.Update();

                bOk = true;

                if (_clonedContractItem != null)
                {
                    itm[ECContext.Current.Configuration.ECFields.ClonedFromContractId] = _clonedContractItem.ID;

                    //if (_clonedContractItem[ECContext.Current.Configuration.ECFields.AutomaticApproval] != null &&
                    //    (Boolean)_clonedContractItem[ECContext.Current.Configuration.ECFields.AutomaticApproval])
                    //{
                    //    itm[ECContext.Current.Configuration.ECFields.LegalApproval] = "Approved";
                    //    ECContext.SendMail(SPContext.Current.Web, string.Format("Express Contract {0}, request for DOA approval", itm.File.Title), ECContext.CreateMail(itm, string.Empty, ECContext.ECDoaType, CETemplateMails.RequestApprovalEmailTemplate), ECContext.CreateDOAHeader(itm, elevatedWeb));
                    //}
                    bOk = false;
                    itm.UpdateOverwriteVersion();
                    itm.Update();
                    itm.ParentList.Update();
                    itm.Web.Update();

                    bOk = true;
                }

                try
                {
                    DataTable dt = (DataTable)ViewState["Files"];
                    SPFolder attachmentsLibrary = elevatedWeb.Folders["Express contracts attachments"];
                    SPFieldLookupValueCollection valueCol = new SPFieldLookupValueCollection();
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            //1. Add file to 'Express contracts attachments' Document Library
                            string strFilepath = dr["FilePath"].ToString();
                            StreamReader sr = new StreamReader(strFilepath);
                            Stream fStream = sr.BaseStream;

                            MemoryStream ms = new MemoryStream(ECContext.OpenXml.ReadFully(fStream));
                            string sFileName = dr["Filename"].ToString();
                            SPFile file = attachmentsLibrary.Files.Add(sFileName, ms, true);
                            file.Item["Title"] = sFileName;

                            file.Item.Update();
                            attachmentsLibrary.Update();

                            //2. Add link to file in 'Express contracts' Document Library
                            valueCol.Add(new SPFieldLookupValue(file.Item.ID, file.Item.Title.ToString()));
                        }
                        itm["Documents Attached"] = valueCol.ToString();
                    }
                    //Clear Session attachments
                    ViewState.Remove("Files");
                    bOk = false;
                    itm.UpdateOverwriteVersion();
                    itm.Update();
                    itm.ParentList.Update();
                    itm.Web.Update();

                    bOk = true;
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent("Error saving contract attachments. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractAttachmentError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }

                if (bOk)
                {
                    //DisabledItemEventsScope disEvnt = new DisabledItemEventsScope();
                    try
                    {
                        disEvnt.DisabledItemEvents();
                        bOk = false;
                        itm.UpdateOverwriteVersion();
                        itm.Update();
                        itm.ParentList.Update();
                        itm.Web.Update();

                        bOk = true;

                        itm.Web.AllowUnsafeUpdates = false;
                    }
                    catch (Exception ex)
                    {
                        int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                        CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                    }
                    finally
                    {
                        disEvnt.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error saving contract metadata. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
            return bOk;
        }

        private string ConvertBulletedListToHTML(ListItemCollection items)
        {
            string HTMLGenerated = "";
            HTMLGenerated = "<ul>";
            foreach (System.Web.UI.WebControls.ListItem item in items)
            {
                HTMLGenerated = string.Concat(HTMLGenerated, String.Format("<li>{0}</li>", item.Text));
            }
            HTMLGenerated = string.Concat(HTMLGenerated, "</ul>");
            return HTMLGenerated;
        }

        public List<ECContext.BookmarkGridItem> BuildBookmarListFromGrid()
        {
            //Comment : Venu, Date 07 April 2016, Below line added to collect all the Bookmark description
            string allBookmarkDesc = string.Empty;
            hdnDuplicateBookmark.Value = "";

            List<ECContext.BookmarkGridItem> returnList = new List<ECContext.BookmarkGridItem>();
            try
            {
                ECContext.BookmarkGridItem bookmarkItem;
                SPListItem template = GetTemplate(this.templateName.Value);

                string bookmarkType,
                    bookmarkDescription,
                    fieldMapping;



                SPFieldLookupValue documentType = new SPFieldLookupValue(this.hdnDocumentType.Value);

                //List<ECContext.ContractDynamicPortion> portionsEnglish = GetDynamicPortions(documentType.LookupValue, "English", true);

                List<ECContext.ContractDynamicPortion> portionsEnglish = GetDynamicPortions(documentType.LookupValue, MainLanguage, true);
                List<ECContext.ContractDynamicPortion> portionsSecLanguage;
                if (template["Second_x0020_Language"] != null)
                {
                    SPFieldLookupValue languageValue = new SPFieldLookupValue(template["Second_x0020_Language"].ToString());
                    portionsSecLanguage = GetDynamicPortions(documentType.LookupValue, languageValue.LookupValue, true);
                    ReplaceEntityInfoInPortions(portionsSecLanguage, languageValue.LookupValue);
                }
                else
                    portionsSecLanguage = new List<ECContext.ContractDynamicPortion>();

                //ReplaceEntityInfoInPortions(portionsEnglish, "English");
                ReplaceEntityInfoInPortions(portionsEnglish, MainLanguage);

                List<ECContext.ContractDynamicPortion> totalPortions = portionsEnglish.Union(portionsSecLanguage).ToList();

                foreach (ECContext.ContractDynamicPortion portionToAdd in totalPortions)
                {
                    string[] bookmarkCodeList = portionToAdd.BookMarkCode.Split(';');
                    foreach (string bookmarkCode in bookmarkCodeList)
                    {
                        bookmarkItem = new ECContext.BookmarkGridItem();
                        bookmarkItem.BookmarkDescription = portionToAdd.DisplayText;
                        allBookmarkDesc = allBookmarkDesc + portionToAdd.DisplayText + ";";
                        bookmarkItem.DataType = portionToAdd.FieldType;
                        bookmarkItem.InternalName = bookmarkCode.Trim();
                        bookmarkItem.FieldMapping = "";
                        bookmarkItem.Required = true;
                        bookmarkItem.Value = portionToAdd.Portion;
                        if (!String.IsNullOrEmpty(portionToAdd.Portion))
                            returnList.Add(bookmarkItem);
                    }
                }


                //DataTable filteredBookmarks = ECContext.Current.Lists.Bookmark.GetItems(new SPQuery { Query = String.Format("<Where><Eq><FieldRef Name=\"Template\"/><Value Type=\"Text\">{0}</Value></Eq></Where>", template["Title"]) }).GetDataTable();

                foreach (GridViewRow row in this.gvBookmarks.Rows)
                {


                    bookmarkDescription = ((Label)row.FindControl("MainBookmakDescription")).Text;
                    //bookmarkType = ((Label)row.FindControl("DataType")).Text;
                    //Comment : Venu, Date 07 April 2016, Below code added to check any duplicate bookmark description exist in Contract Portion and from template
                    if (!string.IsNullOrEmpty(bookmarkDescription.ToString().Trim()) && allBookmarkDesc.Contains(bookmarkDescription))
                    {
                        hdnDuplicateBookmark.Value = hdnDuplicateBookmark.Value + bookmarkDescription + ";";
                    }
                    allBookmarkDesc = allBookmarkDesc + bookmarkDescription + ";";


                    ECContext.BookmarkGridItem gridItem = this.MainBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription).FirstOrDefault();
                    fieldMapping = this.MainBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription && !string.IsNullOrEmpty(s.FieldMapping)).Select(s => s.FieldMapping).FirstOrDefault();// filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("FieldMapping")).FirstOrDefault();
                    bookmarkType = gridItem.DataType;// this.MainBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription).Select(s => s.DataType).FirstOrDefault(); //filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("Data_x0020_Type")).FirstOrDefault();

                    List<String> internalNames = this.MainBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription).Select(s => s.InternalName).ToList(); //filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("Title")).ToList();

                    foreach (string iname in internalNames)
                    {
                        bookmarkItem = new ECContext.BookmarkGridItem();
                        bookmarkItem.BookmarkDescription = bookmarkDescription;
                        bookmarkItem.DataType = bookmarkType;
                        bookmarkItem.InternalName = iname;
                        bookmarkItem.FieldMapping = fieldMapping;
                        bookmarkItem.Required = true;// ((System.Web.UI.WebControls.Label)row.FindControl("lbMandatory")).Text == "True";

                        switch (bookmarkType)
                        {
                            case "Text":
                                bookmarkItem.Value = ((TextBox)row.FindControl("BookmarkTextValue")).Text;
                                break;
                            case "Bulleted list":
                                bookmarkItem.Value = ((InputFormTextBox)row.FindControl("BookmarkMultiTextValue")).Text;
                                //bookmarkItem.Value = ConvertBulletedListToHTML(((BulletedList)row.FindControl("blMultiValue")).Items);
                                break;
                            case "Date":
                                bookmarkItem.Value = String.Format("{0:dd MMM yyyy}", ((DateTimeControl)row.FindControl("BookmarkCalendarValue")).SelectedDate);
                                break;
                            case "Numeric":
                                bookmarkItem.Value = ((TextBox)row.FindControl("BookmarkNumberValue")).Text;
                                break;
                        }
                        returnList.Add(bookmarkItem);
                    }

                    bookmarkDescription = ((Label)row.FindControl("SecBookmakDescription")).Text;
                    //Comment : Venu, Date 07 April 2016, Below code added to check any duplicate bookmark description exist in Contract Portion and from template
                    if (!string.IsNullOrEmpty(bookmarkDescription.ToString().Trim()) && allBookmarkDesc.Contains(bookmarkDescription))
                    {
                        hdnDuplicateBookmark.Value = hdnDuplicateBookmark.Value + bookmarkDescription + ";";
                    }
                    allBookmarkDesc = allBookmarkDesc + bookmarkDescription + ";";
                    if (!String.IsNullOrEmpty(bookmarkDescription))
                    {
                        internalNames.Clear();

                        fieldMapping = this.SecondaryLanguageBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription).Select(s => s.FieldMapping).FirstOrDefault();// filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("FieldMapping")).FirstOrDefault();
                        bookmarkType = this.SecondaryLanguageBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription).Select(s => s.DataType).FirstOrDefault(); //filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("Data_x0020_Type")).FirstOrDefault();
                        internalNames = this.SecondaryLanguageBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription).Select(s => s.InternalName).ToList(); //filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("Title")).ToList();
                        //internalNames = filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("Title")).ToList();

                        foreach (string iname in internalNames)
                        {
                            bookmarkItem = new ECContext.BookmarkGridItem();
                            bookmarkItem.BookmarkDescription = bookmarkDescription;
                            //bookmarkType = bookmarkType;// filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("Data_x0020_Type")).FirstOrDefault();
                            bookmarkItem.DataType = bookmarkType;
                            bookmarkItem.FieldMapping = fieldMapping;
                            bookmarkItem.InternalName = iname;

                            switch (bookmarkType)
                            {
                                case "Text":
                                    bookmarkItem.Value = ((TextBox)row.FindControl("SecBookmarkTextValue")).Text;
                                    break;
                                case "Bulleted list":
                                    bookmarkItem.Value = ((InputFormTextBox)row.FindControl("SecBookmarkMultiTextValue")).Text;
                                    //bookmarkItem.Value = ConvertBulletedListToHTML(((BulletedList)row.FindControl("secblMultiValue")).Items);
                                    break;
                            }

                            returnList.Add(bookmarkItem);
                        }
                    }
                }

                var mappedBookmarks = (from mainB in MainBookmarks
                                       where !String.IsNullOrEmpty(mainB.FieldMapping) && mainB.FieldMapping != "Counterparty"
                                       select new
                                       {
                                           fieldMapping = mainB.FieldMapping,
                                           internalName = mainB.InternalName,

                                       });

                foreach (var mBookmark in mappedBookmarks)
                {
                    bookmarkItem = new ECContext.BookmarkGridItem();
                    bookmarkItem.BookmarkDescription = "";
                    //bookmarkType = bookmarkType;// filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("Data_x0020_Type")).FirstOrDefault();
                    bookmarkItem.DataType = "";
                    bookmarkItem.FieldMapping = mBookmark.fieldMapping;
                    bookmarkItem.InternalName = mBookmark.internalName;
                    returnList.Add(bookmarkItem);
                }
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent("BuildBookmarkListFromGrid  - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                throw ecp;
            }
            return returnList;
        }

        public void PaintEmptyBookmarks()
        {

            try
            {

                foreach (GridViewRow row in this.gvBookmarks.Rows)
                {


                    string bookmarkDescription = ((Label)row.FindControl("MainBookmakDescription")).Text;

                    ECContext.BookmarkGridItem gridItem = this.MainBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription).FirstOrDefault();
                    string bookmarkType = gridItem.DataType;
                    string Value = "";
                    switch (bookmarkType)
                    {
                        case "Text":
                            Value = ((TextBox)row.FindControl("BookmarkTextValue")).Text;
                            if (String.IsNullOrEmpty(Value))
                            {
                                ((TextBox)row.FindControl("BookmarkTextValue")).CssClass = ((TextBox)row.FindControl("BookmarkTextValue")).CssClass + " ms-bookmark-val-error";
                            }
                            else
                            {
                                ((TextBox)row.FindControl("BookmarkTextValue")).CssClass = ((TextBox)row.FindControl("BookmarkTextValue")).CssClass.Replace(" ms-bookmark-val-error", "");
                            }
                            break;
                        case "Bulleted list":
                            Value = ((InputFormTextBox)row.FindControl("BookmarkMultiTextValue")).Text;
                            if (String.IsNullOrEmpty(Value) ||
                                Value.ToUpper() == "<DIV></DIV>")
                            {
                                ((InputFormTextBox)row.FindControl("BookmarkMultiTextValue")).CssClass = ((InputFormTextBox)row.FindControl("BookmarkMultiTextValue")).CssClass + " ms-bookmark-val-error";
                            }
                            else
                            {
                                ((InputFormTextBox)row.FindControl("BookmarkMultiTextValue")).CssClass = ((InputFormTextBox)row.FindControl("BookmarkMultiTextValue")).CssClass.Replace(" ms-bookmark-val-error", "");
                            }

                            break;
                        case "Date":

                            Value = ((DateTimeControl)row.FindControl("BookmarkCalendarValue")).IsDateEmpty ? "" : String.Format("{0:dd-MM-yyyy}", ((DateTimeControl)row.FindControl("BookmarkCalendarValue")).SelectedDate);
                            if (String.IsNullOrEmpty(Value))
                            {

                                ((DateTimeControl)row.FindControl("BookmarkCalendarValue")).CssClassTextBox = "ms-bookmark-val-error";
                            }
                            else
                            {
                                ((DateTimeControl)row.FindControl("BookmarkCalendarValue")).CssClassTextBox = ((DateTimeControl)row.FindControl("BookmarkCalendarValue")).CssClassTextBox.Replace(" ms-bookmark-val-error", "");
                            }
                            break;
                        case "Numeric":
                            Value = ((TextBox)row.FindControl("BookmarkNumberValue")).Text;
                            if (String.IsNullOrEmpty(Value))
                            {
                                ((TextBox)row.FindControl("BookmarkNumberValue")).CssClass = ((TextBox)row.FindControl("BookmarkNumberValue")).CssClass + " ms-bookmark-val-error";
                            }
                            else
                            {
                                ((TextBox)row.FindControl("BookmarkNumberValue")).CssClass = ((TextBox)row.FindControl("BookmarkNumberValue")).CssClass.Replace(" ms-bookmark-val-error", "");
                            }

                            break;
                    }





                    bookmarkDescription = ((Label)row.FindControl("SecBookmakDescription")).Text;
                    if (!String.IsNullOrEmpty(bookmarkDescription))
                    {

                        bookmarkType = this.SecondaryLanguageBookmarks.Where(s => s.MainBookmarkDescription == bookmarkDescription).Select(s => s.DataType).FirstOrDefault(); //filteredBookmarks.AsEnumerable().Where(s => s.Field<string>("Bookmark_x0020_Description") == bookmarkDescription).Select(s => s.Field<string>("Data_x0020_Type")).FirstOrDefault();

                        switch (bookmarkType)
                        {
                            case "Text":
                                Value = ((TextBox)row.FindControl("SecBookmarkTextValue")).Text;
                                if (String.IsNullOrEmpty(Value))
                                {
                                    ((TextBox)row.FindControl("SecBookmarkTextValue")).CssClass += ((TextBox)row.FindControl("SecBookmarkTextValue")).CssClass + " ms-bookmark-val-error";
                                }
                                else
                                {
                                    ((TextBox)row.FindControl("SecBookmarkTextValue")).CssClass += ((TextBox)row.FindControl("SecBookmarkTextValue")).CssClass.Replace(" ms-bookmark-val-error", "");
                                }
                                break;
                            case "Bulleted list":
                                Value = ((InputFormTextBox)row.FindControl("SecBookmarkMultiTextValue")).Text;
                                if (String.IsNullOrEmpty(Value) ||
                                    Value.ToUpper() == "<DIV></DIV>")
                                {
                                    ((InputFormTextBox)row.FindControl("SecBookmarkMultiTextValue")).CssClass += ((InputFormTextBox)row.FindControl("SecBookmarkMultiTextValue")).CssClass + " ms-bookmark-val-error";
                                }
                                else
                                {
                                    ((InputFormTextBox)row.FindControl("SecBookmarkMultiTextValue")).CssClass += ((InputFormTextBox)row.FindControl("SecBookmarkMultiTextValue")).CssClass.Replace(" ms-bookmark-val-error", "");
                                }
                                break;
                        }
                    }
                }
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent("PaintEmtyBookmarks  - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                throw;
            }
        }

        private bool CompileBookmarkData(List<ECContext.BookmarkGridItem> bookmarkGridList, out Dictionary<string, string> bookmarkList, out Dictionary<string, string> rtfBookmarkList)
        {
            try
            {
                StringBuilder emtpyFields = new StringBuilder();

                if (ddlMonsantoEntity.SelectedItem == null)
                    throw new ECValidationException("Entity", "No Monsanto entity selected.");

                if (ddlSigantories.SelectedIndex == 0)
                    throw new ECValidationException("Entity", "No Monsanto entity signatory selected.");

                Dictionary<string, string> replacements = new Dictionary<string, string>();

                DateTime EffectiveDate = DateTime.Now;
                Dictionary<string, string> descriptionReplacements = new Dictionary<string, string>();
                Dictionary<string, string> richTextDescriptionReplacements = new Dictionary<string, string>();

                DateTimeFormatInfo dtfi = new DateTimeFormatInfo { ShortDatePattern = "dd-MM-yyyy", DateSeparator = "-" };

                // Fetch bookmarks
                var bookmarks = from bookmark in bookmarkGridList
                                select new
                                {
                                    Name = bookmark.InternalName,
                                    DataValue = "",
                                    Description = bookmark.BookmarkDescription,
                                    Required = bookmark.Required,
                                    Mapping = bookmark.FieldMapping
                                };


                foreach (var bm in bookmarkGridList)
                {
                    string pfx;
                    string bmValue;

                    // If field is mapped, assign it
                    if (!String.IsNullOrEmpty(bm.FieldMapping) &&
                        bm.FieldMapping != "Counterparty")
                    {
                        replacements.Add(bm.InternalName, GetEntityField(bm.FieldMapping));
                    }
                    else
                    {
                        if (String.IsNullOrEmpty(bm.Value))
                        {
                            emtpyFields.Append("<br /><b>bm.BookmarkDescription</b>");
                        }
                    }

                    if (!String.IsNullOrEmpty(bm.Value))
                    {
                        bmValue = bm.Value;
                        String cultureInfo = ECContext.Current.Lists.Language.GetItems(new SPQuery() { Query = String.Format("<Where><Eq><FieldRef Name='Title'/><Value Type=\"Text\">{0}</Value></Eq></Where>", MainLanguage), RowLimit = 1000 })[0]["CultureInfo"].ToString();

                        // Field found, unmarshal value
                        switch (bm.DataType.ToLower())
                        {
                            case "date":
                                {
                                    DateTime objDate = Convert.ToDateTime(bmValue, dtfi);

                                    if (bm.InternalName == "EffectiveDate")
                                        EffectiveDate = objDate;

                                    string val = objDate.ToString("dd MMMM yyyy", new System.Globalization.CultureInfo(cultureInfo));

                                    replacements.Add(bm.InternalName, val);

                                    if (!string.IsNullOrEmpty(bm.BookmarkDescription) && !descriptionReplacements.ContainsKey(bm.BookmarkDescription))
                                        descriptionReplacements.Add(bm.BookmarkDescription, val);

                                    break;
                                }
                            case "bulleted list":
                                {
                                    richTextDescriptionReplacements.Add(bm.InternalName, bmValue);
                                    break;
                                }
                            case "text":
                            case "numeric":
                                {
                                    replacements.Add(bm.InternalName, bmValue);

                                    if (!string.IsNullOrEmpty(bm.BookmarkDescription) && !descriptionReplacements.ContainsKey(bm.BookmarkDescription))
                                        descriptionReplacements.Add(bm.BookmarkDescription, bmValue);

                                    break;
                                }
                        }
                    }
                    else
                    {
                        // Field not found & not mapped - generate error
                        if (bm.Required && String.IsNullOrEmpty(bm.FieldMapping))
                        {
                        }
                    }
                }

                if (!string.IsNullOrEmpty(emtpyFields.ToString()))
                {
                    PaintEmptyBookmarks();
                    throw new ECValidationException("Form", string.Concat("Please complete all fields, and enter \"N/A\" for non-applicable fields. ", ""));
                }


                bookmarkList = replacements;
                rtfBookmarkList = richTextDescriptionReplacements;

                return true;
            }
            catch (Exception ex)
            {
                bookmarkList = null;
                rtfBookmarkList = null;
                ECContext.LogEvent("CompileBookmarkData  - " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                throw ex;
            }
        }

        public void SaveFCPAMailAsWordDocument(SPListItem item)
        {
            string url = string.Concat(SPContext.Current.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = SPContext.Current.Site.Url;
            string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
            string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
            //string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;

            string FCPAXML = "";
            string itemXML = "";
            //Dictionary<string, Dictionary<string, string>> sections = GetSections();

            using (MemoryStream generatedDocument = new MemoryStream())
            {
                using (WordprocessingDocument package = WordprocessingDocument.Create(generatedDocument, DocumentFormat.OpenXml.WordprocessingDocumentType.Document))
                {
                    try
                    {
                        MainDocumentPart mainPart = package.MainDocumentPart;
                        if (mainPart == null)
                        {
                            mainPart = package.AddMainDocumentPart();
                            new Document(new Body()).Save(mainPart);
                        }

                        Body body = mainPart.Document.Body;

                        body.Append(CreateWordHeader("Request for approval"));

                        HtmlConverter converter = new HtmlConverter(mainPart);
                        CreateAndConvertWordContent(string.Format("{0} has created a new express contract '{1}' and requests your approval. Please navigate to this <a href=\"{2}\" >approval form</a> to approve it. To navigate to an overview of the contracts you can use this <a href=\"{3}\" >link</a>.<br /><br />The country that was selected for this contract is '{4}' and the entity is '{5}''.", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Name, item.File.Title, string.Format("{0}/_layouts/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", SPContext.Current.Site.Url, item.ID.ToString(), "DOA"), SPContext.Current.Site.Url, country, Entity), body, converter);

                        body.Append(CreateWordHeader("FCPA relevance:"));

                        foreach (GridViewRow row in this.gvFCPAQuestions.Rows)
                        {
                            bool FCPAApprovalRequested = ((RadioButton)row.FindControl("rbFCPAYes")).Checked;
                            string question = ((Label)row.FindControl("QuestionLb")).Text;
                            string ID = ((Label)row.FindControl("lbID")).Text;

                            CreateAndConvertWordContent(question, body, converter);

                            if (FCPAApprovalRequested)
                                body.Append(CreateWordContent("answer was YES"));
                            else
                                body.Append(CreateWordContent("answer was no"));

                            itemXML = String.Format("<answer>{0}{1}</answer>", ID, FCPAApprovalRequested ? "yes|true" : "no|false");
                            FCPAXML = String.Concat(FCPAXML, itemXML);

                        }

                        mainPart.Document.Save();
                    }
                    catch (Exception ecp)
                    {
                        ECContext.LogEvent("SaveFCPAMailAsWordDocument Create Word Document exception - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                    }
                }
                SPWeb ElevatedWeb = item.Web;

                ElevatedWeb.AllowUnsafeUpdates = true;

                SPFile file = ElevatedWeb.Lists[ECContext.Current.Configuration.ApprovalAnswerlistName].RootFolder.Files.Add(string.Concat("FCPA_", item.File.Name), generatedDocument.ToArray(), true);
                SPListItem lstitem = file.Item;
                lstitem[SPBuiltInFieldId.Title] = file.Name;
                lstitem["Answers"] = FCPAXML;
                lstitem["Contract"] = new SPFieldLookupValue(item.ID, item.Title);

                DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                try
                {
                    lstitem.Update();
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                }
                finally
                {
                    disEvt.Dispose();
                }

                SPFieldLookupValue lookUpVal = new SPFieldLookupValue(lstitem.ID, lstitem.Title);
                item[ECContext.Current.Configuration.ECFields.FcpaApprovalAnswer] = lookUpVal;
                item.SystemUpdate();
                ElevatedWeb.AllowUnsafeUpdates = false;
            }

        }

        private void CreateAndConvertWordContent(string html, Body body, HtmlConverter converter)
        {
            html = html.Replace("<br/>", string.Empty);
            var paragraphs = converter.Parse(html);
            for (int i = 0; i < paragraphs.Count; i++)
                body.Append(paragraphs[i]);
        }
        private Paragraph CreateWordContent(string content)
        {
            Paragraph p = new Paragraph();
            Run r = new Run();
            r.Append(new Text(content));
            p.Append(r);
            return p;
        }
        private Paragraph CreateWordHeader(string text)
        {
            Paragraph p = new Paragraph();
            Run r = new Run();
            r.Append(new Text(text));
            p.Append(r);
            return p;
        }

        public object QueryData(string division, string region)
        {
            DataTable dt = new DataTable();
            object results = null;

            try
            {
                string selectedDivision = division;
                string selectedRegion = region;
                string queryDivision = String.Format("<Eq><FieldRef Name='Divisions' LookupId='TRUE' /><Value Type='Lookup'>{0}</Value></Eq>", selectedDivision);
                string queryRegions = String.Format("<Eq><FieldRef Name='Regions'  LookupId='TRUE' /><Value Type='Lookup'>{0}</Value></Eq>", selectedRegion);
                string query = String.Format("<Where><And>{0}{1}</And></Where>", queryDivision, queryRegions);
                string orderBy = "<OrderBy><FieldRef Name=\"Document_x0020_Type\"></FieldRef></OrderBy>";
                string groupBy = "<GroupBy Collapse=\"TRUE\"><FieldRef Name=\"Document_x0020_Type\" /></GroupBy>";

                string sViewFields = @"<FieldRef Name=""Document_x0020_Type"" />";
                string sViewAttrs = @"Scope=""Recursive""";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = orderBy + query + groupBy;
                oQuery.ViewFields = sViewFields;
                oQuery.ViewAttributes = sViewAttrs;
                oQuery.RowLimit = iRowLimit;

                SPListItemCollection collListItems = ECContext.Current.Lists.ContractTemplate.GetItems(oQuery);

                if (collListItems.Count > 0)
                {
                    dt = collListItems.GetDataTable();
                    if (dt != null)
                    {
                        var grouped = (from docs in dt.AsEnumerable()
                                       group docs by new { Document_x0020_Type = docs["Document_x0020_Type"] } into newDoc
                                       orderby newDoc.Key.Document_x0020_Type
                                       select new
                                       {
                                           Document_x0020_Type = newDoc.Key.Document_x0020_Type
                                       }).AsEnumerable();


                        results = grouped;
                    }
                    else
                    {
                        results = null;
                    }
                }


            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

            //}
            return results;
        }

        private Dictionary<int, string> QueryDivisionsbyField(string fieldName)
        {

            DataTable dt = new DataTable();
            Dictionary<int, string> results = new Dictionary<int, string>();

            try
            {
                string orderBy = "<OrderBy>" + String.Format(@"<FieldRef Name=""{0}"" />", fieldName) + "</FieldRef></OrderBy>";
                string groupBy = "<GroupBy Collapse=\"TRUE\">" + String.Format(@"<FieldRef Name=""{0}"" />", fieldName) + "</GroupBy>";

                string sViewFields = String.Format(@"<FieldRef Name=""{0}"" />", fieldName);
                string sViewAttrs = @"Scope=""Recursive""";
                uint iRowLimit = 0;

                var oQuery = new SPQuery();
                oQuery.Query = orderBy + groupBy;
                oQuery.ViewFields = sViewFields;
                oQuery.ViewAttributes = sViewAttrs;
                oQuery.RowLimit = iRowLimit;

                SPListItemCollection collListItems = ECContext.Current.Lists.ContractTemplate.GetItems(oQuery);
                var grouped = (from SPListItem docs in collListItems
                               group docs by new { Document_x0020_Type = docs[fieldName] } into newDoc
                               select new
                               {
                                   Document_x0020_Type = newDoc.Key.Document_x0020_Type
                               });

                foreach (var item in grouped)
                {
                    if (!String.IsNullOrEmpty(item.Document_x0020_Type.ToString()))
                    {
                        SPFieldLookupValueCollection col = new SPFieldLookupValueCollection(item.Document_x0020_Type.ToString());
                        foreach (SPFieldLookupValue value in col)
                        {
                            if (!results.Keys.Contains(value.LookupId))
                            {
                                results.Add(value.LookupId, value.LookupValue);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
            return results;
        }

        private void BindDropDownList(DropDownList ddl, SPList lst)
        {
            try
            {
                BindDropDownList(ddl, lst.GetItems(new SPQuery() { RowLimit = 1000 }));
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void BindDropDownList(DropDownList ddl, SPListItemCollection lst)
        {
            try
            {
                ddl.DataSource = lst;
                ddl.DataValueField = lst.List.Fields[SPBuiltInFieldId.ID].InternalName;
                ddl.DataTextField = lst.List.Fields[SPBuiltInFieldId.Title].InternalName;
                ddl.DataBind();
                ddl.Items.Insert(0, new System.Web.UI.WebControls.ListItem(" - SELECT - ", "0"));
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(String.Format("Error loading values for the list {0}: {1}", lst.List.Title, ex.Message), ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void BindDropDownList(DropDownList ddl, SPListItemCollection lst, string customTextField, string customValueField)
        {
            try
            {
                ddl.DataSource = lst.GetDataTable();
                ddl.DataValueField = lst.List.Fields[customValueField].InternalName;
                ddl.DataTextField = lst.List.Fields[customTextField].InternalName;
                ddl.DataBind();
                ddl.Items.Insert(0, new System.Web.UI.WebControls.ListItem(" - SELECT - ", "0"));
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(String.Format("Error loading values for the list {0}: {1}", lst.List.Title, ex.Message), ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }


        protected void keepMeAliveTimerTick(object sender, EventArgs e)
        {

        }

        private ECContext.ContractDynamicPortion GetEntityDynamicPortion(string Language)
        {
            ECContext.ContractDynamicPortion portions = new ECContext.ContractDynamicPortion();

            string sQuery = String.Format(@"<Where><And><Eq><FieldRef Name=""Language"" /><Value Type=""Lookup"">{0}</Value></Eq><Eq><FieldRef Name=""BookmarkCode"" /><Value Type=""Text"">{1}</Value></Eq></And></Where>", Language, "MonsantoEntityDisplayInformation");
            string sViewFields = @"<FieldRef Name=""BookmarkCode"" /><FieldRef Name=""Title"" /><FieldRef Name=""Document_x0020_Type"" /><FieldRef Name=""ID"" /><FieldRef Name=""Language"" /><FieldRef Name=""Mandatory"" /><FieldRef Name=""Portion"" />";
            string sViewAttrs = @"Scope=""Recursive""";
            uint iRowLimit = 0;

            var oQuery = new SPQuery();
            oQuery.Query = sQuery;
            oQuery.ViewFields = sViewFields;
            oQuery.ViewAttributes = sViewAttrs;
            oQuery.RowLimit = iRowLimit;

            SPListItemCollection collListItems = ECContext.Current.Lists.ContractPortions.GetItems(oQuery);

            foreach (SPListItem oListItem in collListItems)
            {

                portions.DocumentType = "";
                portions.BookMarkCode = oListItem["BookmarkCode"] != null ? oListItem["BookmarkCode"].ToString() : "";
                portions.DisplayText = oListItem["Title"] != null ? oListItem["Title"].ToString() : "";
                portions.Mandatory = oListItem["Mandatory"] != null ? bool.Parse(oListItem["Mandatory"].ToString()) : false;
                portions.Language = Language;
                portions.Portion = oListItem["Portion"] != null ? oListItem["Portion"].ToString() : "";

            }

            return portions;
        }

        private List<ECContext.ContractDynamicPortion> GetDynamicPortions(string DocumentType, string Language, bool OnlyMandatory)
        {

            List<ECContext.ContractDynamicPortion> portions = new List<ECContext.ContractDynamicPortion>();

            string sQuery = String.Format(@"<Where><And><And><Or><Eq><FieldRef Name=""Document_x0020_Type"" /><Value Type=""Lookup"">{0}</Value></Eq><IsNull><FieldRef Name=""Document_x0020_Type"" /></IsNull></Or><Eq><FieldRef Name=""Language"" /><Value Type=""Lookup"">{1}</Value></Eq></And><Eq><FieldRef Name=""Mandatory"" /><Value Type=""Boolean"">{2}</Value></Eq></And></Where>", DocumentType, Language, OnlyMandatory ? "1" : "0");
            string sViewFields = @"<FieldRef Name=""BookmarkCode"" /><FieldRef Name=""FieldType"" /><FieldRef Name=""Title"" /><FieldRef Name=""Document_x0020_Type"" /><FieldRef Name=""ID"" /><FieldRef Name=""Language"" /><FieldRef Name=""Mandatory"" /><FieldRef Name=""Portion"" />";
            string sViewAttrs = @"Scope=""Recursive""";
            uint iRowLimit = 0;

            var oQuery = new SPQuery();
            oQuery.Query = sQuery;
            oQuery.ViewFields = sViewFields;
            oQuery.ViewAttributes = sViewAttrs;
            oQuery.RowLimit = iRowLimit;

            SPListItemCollection collListItems = ECContext.Current.Lists.ContractPortions.GetItems(oQuery);

            foreach (SPListItem oListItem in collListItems)
            {
                ECContext.ContractDynamicPortion portion = new ECContext.ContractDynamicPortion();
                portion.DocumentType = DocumentType;// oListItem["Document_x0020_Type"] != null ? oListItem["Document_x0020_Type"].ToString() : "";
                portion.BookMarkCode = oListItem["BookmarkCode"] != null ? oListItem["BookmarkCode"].ToString() : "";
                portion.DisplayText = oListItem["Title"] != null ? oListItem["Title"].ToString() : "";
                portion.Mandatory = oListItem["Mandatory"] != null ? bool.Parse(oListItem["Mandatory"].ToString()) : false;
                portion.FieldType = oListItem["FieldType"] != null ? oListItem["FieldType"].ToString() : "Text";
                portion.Language = Language;

                SPFieldMultiLineText multiPortion = oListItem.Fields.GetField("Portion") as SPFieldMultiLineText;

                string portionText = "";
                if (oListItem["FieldType"].ToString() != "Bulleted List")
                {
                    portionText = multiPortion.GetFieldValueAsText(oListItem["Portion"]);
                }
                else
                {
                    portionText = multiPortion.GetFieldValueAsHtml(oListItem["Portion"], oListItem);
                }

                portion.Portion = portionText;// oListItem["Portion"] != null ? oListItem["Portion"].ToString() : "";
                portions.Add(portion);
            }

            return portions;
        }

        private void ReplaceEntityInfoInPortions(ECContext.ContractDynamicPortion portion, string Language)
        {
            List<ECContext.ContractDynamicPortion> portions = new List<ECContext.ContractDynamicPortion>();
            portions.Add(portion);
            ReplaceEntityInfoInPortions(portions, Language);
        }

        private void ReplaceEntityInfoInPortions(List<ECContext.ContractDynamicPortion> portions, string Language)
        {
            Dictionary<string, string> replacements = new Dictionary<string, string>();

            if (ddlSigantories.SelectedIndex > 0)
            {
                try
                {
                    string representative = ddlSigantories.SelectedItem.Text;
                    SPListItem item = ECContext.Current.Lists.MonsantoEntitiesSignatoriesInformation.GetItemById(int.Parse(this.ddlSigantories.SelectedValue));
                    if (item["SignatoriesInfo"] != null &&
                            !String.IsNullOrEmpty(item["SignatoriesInfo"].ToString()))
                    {
                        SPFieldCalculated cf = (SPFieldCalculated)item.Fields["SignatoriesInfo"];
                        string value = cf.GetFieldValueAsText(item["SignatoriesInfo"]);
                        replacements.Add(ECContext.EntityTAGStoReplace.SIGNATORY, value);
                    }
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("ReplaceEntityInfoInPortions save signatory information  - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                }
            }
            if (ddlMonsantoEntity.SelectedIndex > 0)
            {
                try
                {
                    string EntityName = ddlMonsantoEntity.SelectedItem.Text;
                    SPListItem Entity = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));

                    SPListItem item = null;
                    if (Entity != null)
                    {
                        if (Language != "English")
                        {
                            string Abbreviation = Entity["Abbreviation"].ToString();
                            SPListItemCollection items = ECContext.Current.Lists.MonsantoEntity.GetItems(new SPQuery() { RowLimit = 1000, Query = string.Format("<Where><And><Eq><FieldRef Name='Abbreviation' /><Value Type='Text'>{0}</Value></Eq><Eq><FieldRef Name='Language' /><Value Type='Lookup'>{1}</Value></Eq></And></Where>", Abbreviation, Language) });


                            if (items != null && items.Count == 1)
                                item = items[0];
                            else
                            {
                                item = Entity;
                                //items = ECContext.Current.Lists.MonsantoEntity.GetItems(new SPQuery() { RowLimit = 1000, Query = string.Format("<Where><And><Eq><FieldRef Name='Abbreviation' /><Value Type='Text'>{0}</Value></Eq><Eq><FieldRef Name='Language' /><Value Type='Lookup'>{1}</Value></Eq></And></Where>", Abbreviation, "English") });
                                //if (items != null && items.Count == 1)
                                //    item = items[0];
                            }
                        }
                        else
                            item = Entity;
                    }

                    if (item != null)
                    {
                        SPListItem bankInfoItem = null;
                        string bankInfoCode = "";
                        if (item["Bank_x0020_Information"] != null &&
                            !String.IsNullOrEmpty(new SPFieldLookupValue(item["Bank_x0020_Information"].ToString()).LookupValue))
                        {
                            bankInfoCode = new SPFieldLookupValue(item["Bank_x0020_Information"].ToString()).LookupValue;
                            SPListItemCollection bankInfoItems = ECContext.Current.Lists.MonsantoBankInformation.GetItems(new SPQuery() { Query = string.Format("<Where><Eq><FieldRef Name=\"BankInfo\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", bankInfoCode) });
                            if (bankInfoItems.Count > 0)
                                bankInfoItem = bankInfoItems[0];
                        }
                        if (item["Abbreviation"] != null &&
                            !String.IsNullOrEmpty(item["Abbreviation"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.ABBREVIATION, item["Abbreviation"].ToString());

                        if (bankInfoItem != null &&
                            bankInfoItem["Account_x0020_No_x002e_"] != null &&
                            !String.IsNullOrEmpty(bankInfoItem["Account_x0020_No_x002e_"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.BANK_AC_NO, bankInfoItem["Account_x0020_No_x002e_"].ToString());

                        if (bankInfoItem != null && bankInfoItem["IBAN"] != null &&
                            !String.IsNullOrEmpty(bankInfoItem["IBAN"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.IBAN, bankInfoItem["IBAN"].ToString());

                        if (bankInfoItem != null && bankInfoItem["Title"] != null &&
                            !String.IsNullOrEmpty(bankInfoItem["Title"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.BANK_NAME_ADDRESS, bankInfoItem["Title"].ToString());

                        if (bankInfoItem != null && bankInfoItem["BIC_x002f_SWIFT"] != null &&
                            !String.IsNullOrEmpty(bankInfoItem["BIC_x002f_SWIFT"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.BIC, bankInfoItem["BIC_x002f_SWIFT"].ToString());

                        if (item["Company_x0020_Registration_x0020"] != null &&
                            !String.IsNullOrEmpty(item["Company_x0020_Registration_x0020"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.COMPANY_REGISTRATION_NO, item["Company_x0020_Registration_x0020"].ToString());

                        if (item["Country_x007c_Incorporation_x002"] != null &&
                            !String.IsNullOrEmpty(item["Country_x007c_Incorporation_x002"].ToString()))
                        {
                            SPFieldLookupValue countryValue = new SPFieldLookupValue(item["Country_x007c_Incorporation_x002"].ToString());
                            replacements.Add(ECContext.EntityTAGStoReplace.COUNTRY, countryValue.LookupValue);
                        }

                        if (item["Title"] != null &&
                            !String.IsNullOrEmpty(item["Title"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.ENTITY_NAME, item["Title"].ToString());

                        if (item["Jurisdiction"] != null &&
                            !String.IsNullOrEmpty(item["Jurisdiction"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.JURISDICTION, item["Jurisdiction"].ToString());

                        if (item["Registred_x0020_Address"] != null &&
                            !String.IsNullOrEmpty(item["Registred_x0020_Address"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.ADDRESS, item["Registred_x0020_Address"].ToString());

                        if (item["VAT_x0020_Number"] != null &&
                            !String.IsNullOrEmpty(item["VAT_x0020_Number"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.VAT, item["VAT_x0020_Number"].ToString());

                        if (item["Annual_x0020_Return_x0020_Filing"] != null &&
                           !String.IsNullOrEmpty(item["Annual_x0020_Return_x0020_Filing"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.ANNUAL_RETURN_FILING_DATE, item["Annual_x0020_Return_x0020_Filing"].ToString());

                        if (item["Ownership"] != null &&
                           !String.IsNullOrEmpty(item["Ownership"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.OWNERSHIP, item["Ownership"].ToString());

                        if (item["Registred_x0020_Address"] != null &&
                            !String.IsNullOrEmpty(item["Registred_x0020_Address"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.REGISTRATION_ADDRESS, item["Registred_x0020_Address"].ToString());

                        if (item["UseInContractExpress_x0020_"] != null &&
                           !String.IsNullOrEmpty(item["UseInContractExpress_x0020_"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.USE_IN_CE, item["UseInContractExpress_x0020_"].ToString());


                        if (item["Bank_x0020_Information"] != null &&
                            !String.IsNullOrEmpty(item["Bank_x0020_Information"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.BANK_DETAILS, item["Bank_x0020_Information"].ToString());

                        if (item["Signatories"] != null &&
                            !String.IsNullOrEmpty(item["Signatories"].ToString()))
                            replacements.Add(ECContext.EntityTAGStoReplace.SIGNATORIES, item["Signatories"].ToString());


                        if (item["DeclinateCountryName"] != null &&
                            !String.IsNullOrEmpty(item["DeclinateCountryName"].ToString()))
                        {
                            replacements.Add(ECContext.EntityTAGStoReplace.DECLINATED_COUNTRY_NAME, item["DeclinateCountryName"].ToString());
                        }

                        if (item["AdditionalInfo"] != null &&
                            !String.IsNullOrEmpty(item["AdditionalInfo"].ToString()))
                        {
                            replacements.Add(ECContext.EntityTAGStoReplace.ADDITIONAL_INFO, item["AdditionalInfo"].ToString());
                        }

                        string matchCodeTag = @"\[#(.*?)\#]";
                        string textToReplace;
                        string replaceWith = "";
                        string output;
                        foreach (ECContext.ContractDynamicPortion portion in portions)
                        {
                            foreach (KeyValuePair<string, string> replacement in replacements)
                            {
                                portion.Portion = portion.Portion.Replace(replacement.Key, String.IsNullOrEmpty(replacement.Value) ? "." : replacement.Value);

                            }
                            textToReplace = portion.Portion;
                            output = Regex.Replace(textToReplace, matchCodeTag, replaceWith);
                            portion.Portion = output;
                        }
                    }
                }
                catch (Exception ecp)
                {
                    ECContext.LogEvent("ReplaceEntityInfoInPortions save entity information  - " + ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                }
            }
        }

        private void ShowCloningControls(int OriginalContractID, bool isPostBack)
        {
            try
            {
                this.pnlStepThree.Style.Add("display", "none!important");
                this.BookmarkPanel.Style.Add("display", "inline!important");
                this.NewContractControls.Style.Add("display", "none!important");



                if (!isPostBack)
                {
                    //Set HdnValue
                    hdnCloneContractParentId.Value = OriginalContractID.ToString();
                    SPListItem template = null;


                    //Get clone info
                    if (!String.IsNullOrEmpty(hdnCloneContractParentId.Value))
                    {
                        _clonedContractItem = ECContext.Current.Lists.ExpressContract.GetItemById(int.Parse(hdnCloneContractParentId.Value));
                        template = ECContext.Current.Lists.ContractTemplate.GetItemById(new SPFieldLookupValue(_clonedContractItem[ECContext.Current.Configuration.ECFields.Template].ToString()).LookupId);
                        this.templateName.Value = template["FileLeafRef"].ToString();
                        this.templateNameForFile.Value = template.Title;
                        _clonedContractBookmarks = ECContext.OpenXml.FindBookmarksAndContent(_clonedContractItem.File.OpenBinaryStream());
                    }

                    //Init controls
                    if (_clonedContractItem != null)
                    {
                        BindCountryDropDown();
                        ddlCountry.SelectedValue = new SPFieldLookupValue((string)_clonedContractItem[ECContext.Current.Configuration.ECFields.Country]).LookupValue;
                        BindDropDownList(ddlMonsantoEntity, ECContext.Current.Lists.MonsantoEntity.GetItems(new SPQuery() { RowLimit = 1000, Query = string.Format("<Where><Eq><FieldRef Name='Country_x007c_Incorporation_x002' /><Value Type='Lookup'>{0}</Value></Eq></Where>", ddlCountry.SelectedItem.Value) }));


                        string ddlMonsantoEntityLookupValue = new SPFieldLookupValue((string)_clonedContractItem[ECContext.Current.Configuration.ECFields.MonsantoEntity]).LookupValue;
                        string ddlMonsantoRepresentedByLookupValue = new SPFieldLookupValue((string)_clonedContractItem["Monsanto_x0020_Entity_x0020_Signatory"]).LookupValue;

                        System.Web.UI.WebControls.ListItem item = ddlMonsantoEntity.Items.FindByText(ddlMonsantoEntityLookupValue);

                        if (item != null)
                        {
                            ddlMonsantoEntity.SelectedValue = item.Value;
                            SetMonsantoEntityValues();
                        }

                        //item = this.ddlSigantories.Items.FindByText(ddlMonsantoRepresentedByLookupValue);
                        ddlMonsantoRepresentedByLookupValue = ddlMonsantoRepresentedByLookupValue.Replace(";", "").Trim();

                        foreach (System.Web.UI.WebControls.ListItem signatory in this.ddlSigantories.Items)
                        {
                            if (signatory.Text.Contains(ddlMonsantoRepresentedByLookupValue))
                            {
                                ddlSigantories.SelectedValue = signatory.Value;
                                break;
                            }
                        }
                    }
                    BuildBookmarkLists(template);
                    //BuildBookmarkLists(_clonedContractItem);
                    BuildFCPAQuestions();


                    //Hide/Show panels
                    this.BookmarkPanel.Style.Add("display", "inline!important");
                    string script = String.Format("$(\"#{0}\").click();", this.RefreshPageButton.ClientID);
                }

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CloneContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        protected void onContractToCloneSelected(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;

            try
            {
                this.pnlStepThree.Style.Add("display", "inline!important");
                this.BookmarkPanel.Style.Add("display", "inline!important");

                //Set HdnValue
                hdnCloneContractParentId.Value = btn.Attributes["data-listitemid"];
                SPListItem template = GetTemplate(this.templateName.Value);


                //Get clone info
                if (!String.IsNullOrEmpty(hdnCloneContractParentId.Value))
                {
                    _clonedContractItem = ECContext.Current.Lists.ExpressContract.GetItemById(int.Parse(hdnCloneContractParentId.Value));
                    _clonedContractBookmarks = ECContext.OpenXml.FindBookmarksAndContent(_clonedContractItem.File.OpenBinaryStream());
                }

                //Init controls
                if (_clonedContractItem != null)
                {
                    ddlCountry.SelectedValue = new SPFieldLookupValue((string)_clonedContractItem[ECContext.Current.Configuration.ECFields.Country]).LookupValue;
                    BindDropDownList(ddlMonsantoEntity, ECContext.Current.Lists.MonsantoEntity.GetItems(new SPQuery() { RowLimit = 1000, Query = string.Format("<Where><Eq><FieldRef Name='Country_x007c_Incorporation_x002' /><Value Type='Lookup'>{0}</Value></Eq></Where>", ddlCountry.SelectedItem.Value) }));


                    string ddlMonsantoEntityLookupValue = new SPFieldLookupValue((string)_clonedContractItem[ECContext.Current.Configuration.ECFields.MonsantoEntity]).LookupValue;
                    string ddlMonsantoRepresentedByLookupValue = new SPFieldLookupValue((string)_clonedContractItem["Monsanto_x0020_Entity_x0020_Signatory"]).LookupValue;

                    System.Web.UI.WebControls.ListItem item = ddlMonsantoEntity.Items.FindByText(ddlMonsantoEntityLookupValue);

                    if (item != null)
                    {
                        ddlMonsantoEntity.SelectedValue = item.Value;
                        SetMonsantoEntityValues();
                    }

                    item = this.ddlSigantories.Items.FindByText(ddlMonsantoRepresentedByLookupValue);
                    ddlMonsantoRepresentedByLookupValue = ddlMonsantoRepresentedByLookupValue.Replace(";", "").Trim();

                    foreach (System.Web.UI.WebControls.ListItem signatory in this.ddlSigantories.Items)
                    {
                        if (signatory.Text.Contains(ddlMonsantoRepresentedByLookupValue))
                        {
                            ddlSigantories.SelectedValue = signatory.Value;
                            break;
                        }
                    }
                }

                BuildBookmarkLists(template);
                BuildFCPAQuestions();


                //Hide/Show panels
                this.BookmarkPanel.Style.Add("display", "inline!important");

                string script = String.Format("$(\"#{0}\").click();", this.RefreshPageButton.ClientID);

                ScriptManager.RegisterStartupScript(this.pnlMain, this.pnlMain.GetType(), "clickRefresh", script, true);

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CloneContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }
    }
}
