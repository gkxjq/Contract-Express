﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.ContractExpressSystem.WebParts.NewContractWebPart
{
    [ToolboxItemAttribute(false)]
    public class NewContractWebPart : WebPart
    {
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/Monsanto.ContractExpressSystem.WebParts/NewContractWebPart/NewContractWebPartUserControl.ascx";

        private bool _isForCloning;

        [WebBrowsable(true),
        Category("Contract Express"),
        WebDescription("Is for clone contracts."),
        WebDisplayName("Clone contracts"),
        Personalizable(PersonalizationScope.Shared)]
        public bool isForCloning
        {
            get
            {
                return _isForCloning;
            } 
            set
            {
                _isForCloning = value;
            }
        }

        protected override void CreateChildControls()
        {
            NewContractWebPartUserControl control = Page.LoadControl(_ascxPath) as NewContractWebPartUserControl;

            if (control != null)
            {
                control.WebPartControl = this;
            }

            //Control control = Page.LoadControl(_ascxPath);
            Controls.Add(control);
        }
    }
}
