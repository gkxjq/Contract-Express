﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.HtmlControls;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.ContractExpressSystem.WebParts.ContractSearch
{
	public partial class ContractSearchUserControl : UserControl
	{
		class SearchTerm
		{
			public string Name { get; set; }
			public string Type { get; set; }
			public string Operator { get; set; }
		}

        protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                CreateControls();

                //Get wait message
                SPList configList = ECContext.Current.CurrentWeb.Lists.TryGetList("Configuration");
                if (configList != null)
                {
                    lblWait.Text = CESPUtil.GetByKey("Search - Wait message", configList);
                }
            }

			if (IsPostBack)
			{
				wpResults.Title = "CHANGED";

                try
                {
                    //Assign view to XSLTListView - DLH - 18/11/2014
                    SPList acLst = ECContext.Current.Lists.ArchivedContracts;
                    SPView acView = acLst.Views["SearchView"];
                    wpResults.ViewGuid = acView.ID.ToString("B").ToUpperInvariant();
                }
                catch (Exception ex)
                {
                    ECContext.LogEvent("Cannot find SearchView in Archived Contracts List. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                }

                SetupSearch();
                
				wpResults.Visible = true;
			}
		}

		private void CreateControls()
		{
            btnSubmit.PostBackUrl = ECContext.Current.CurrentWeb.Url + Page.Request.Url.AbsolutePath;
			hdnMonths.Value = string.Join(" ", new System.Globalization.CultureInfo("en-GB").DateTimeFormat.MonthNames);
			hdnDays.Value = string.Join(" ", new System.Globalization.CultureInfo("en-GB").DateTimeFormat.ShortestDayNames);
            hdnSiteUrl.Value = ECContext.Current.SPContext.Web.Url; 
			
			CESPUtil.BindDropdownList(ddlDocType, ECContext.Current.CurrentWeb.Lists["Archived contract types"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
			CESPUtil.BindDropdownList(ddlMonsantoDivision, ECContext.Current.CurrentWeb.Lists["Monsanto Division"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
			CESPUtil.BindDropdownList(ddlMonsantoEntity, ECContext.Current.CurrentWeb.Lists["Archived Monsanto Entity"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
            CESPUtil.BindDropdownList(ddlBusinessFunction, ECContext.Current.CurrentWeb.Lists["Functions"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));

            ddlDocType.Items.Insert(0, "");
            ddlMonsantoDivision.Items.Insert(0, "");
            ddlBusinessFunction.Items.Insert(0, "");
            ddlMonsantoEntity.Items.Insert(0, "");
			
		}
		
		private void SetupSearch()
		{

            StringBuilder sb = new StringBuilder(
                "<View Name=\"NoFolders\" DefaultView=\"FALSE\" Type=\"HTML\" ShowHeaderUI=\"FALSE\" Scope=\"Recursive\">" + 
					"<Query>${Q}</Query>" +
                      "<ViewFields>" +
                        "<FieldRef Name=\"FileLeafRef\" LinkToItem=\"TRUE\"></FieldRef>" +
                        "<FieldRef Name=\"Monsanto_x0020_Division\"></FieldRef>" +
                        "<FieldRef Name=\"Change_x0020_of_x0020_controle\"></FieldRef>" +
                        "<FieldRef Name=\"Monsanto_x0020_Entity\"></FieldRef>" +
                        "<FieldRef Name=\"Function\"></FieldRef>" +
                        "<FieldRef Name=\"Key_x0020_words\"></FieldRef>" +
                        "<FieldRef Name=\"Effective_x0020_Date\"></FieldRef>" +
                        "<FieldRef Name=\"Counterparty\"></FieldRef>" +
                        "<FieldRef Name=\"Created_x0020_By\"></FieldRef>" +
                        "<FieldRef Name=\"Access_x0020_Delegation\"></FieldRef>" +
                        "<FieldRef Name=\"Change_x0020_of_x0020_controle\"></FieldRef>" +
                        //" <FieldRef Name=\"ID\"></FieldRef>" +
                        //" <FieldRef Name=\"DocIcon\"></FieldRef>" + 
                      "</ViewFields>" +
                      "<RowLimit Paged=\"TRUE\">30</RowLimit>" +
                      "<Aggregations Value=\"Off\"></Aggregations>" +
                      "<ViewStyle ID=\"0\"></ViewStyle>" +
                      "<Toolbar Type=\"None\"></Toolbar>" +
                "</View>");
            
			wpResults.XmlDefinition = sb.Replace("${Q}", BuildQuery()).ToString();
            
		}

        private string BuildQuery()
        {
            Dictionary<string, Control> lstControlsToSearch = new Dictionary<string, Control>();
            lstControlsToSearch = ControlsToSearch();
            string s = "";
            
            if (lstControlsToSearch.Count > 0)
            {
                int i = 0;
                foreach(KeyValuePair<string, Control> ctrl in lstControlsToSearch)
                {
                    bool bIsKeyWords = false;
                    if (ctrl.Key.StartsWith("txt"))
                    {
                        TextBox txt = (TextBox)ctrl.Value;
                        bIsKeyWords = (ctrl.Key == "txtKeyWords");
                    }
                    AddControlToQuery(ref s, ctrl, i != 0, bIsKeyWords);
                    i++;
                }

                s = s.Insert(0, "<Where>");
                s = s.Insert(s.Length, "</Where>");

                s = s.Insert(s.Length, "<OrderBy>");
                s = s.Insert(s.Length, "<FieldRef Name='ID' Ascending='true' />");
                s = s.Insert(s.Length, "</OrderBy>");

            }

            //lblQuery.Text = s.Replace("<", "&lt;").Replace(">", "&gt");

            return s;
        }

        private void AddControlToQuery(ref string s, KeyValuePair<string, Control> ctrl, bool bAddAnd, bool bIsKeyWords)
        {
            if (bAddAnd && !bIsKeyWords)
                s = s.Insert(0, "<And>");

            if (ctrl.Key.StartsWith("txt"))
            {
                string[] keywords = null;
                TextBox txt = (TextBox)ctrl.Value;
                if (ctrl.Key == "txtKeyWords")
                    keywords = txt.Text.Split(',');

                if (keywords != null && keywords.Length > 0)
                {
                    int i = 0;
                    foreach (string sWord in keywords)
                    {
                        if (bAddAnd || i != 0)
                            s = s.Insert(0, "<Or>");
                        
                        s = s.Insert(s.Length, "<Contains>");
                        s = s.Insert(s.Length, "<FieldRef Name='" + txt.Attributes["data-name"] + "'/>");
                        s = s.Insert(s.Length, "<Value Type='Text'>" + sWord.Trim().Replace("&", "&amp;") + "</Value>");
                        s = s.Insert(s.Length, "</Contains>");

                        if (bAddAnd || i != 0)
                            s = s.Insert(s.Length, "</Or>");

                        i++;
                    }
                }
                else
                {
                    if (ctrl.Key == "txtSearch" || ctrl.Key == "txtCounterparty")
                        s = s.Insert(s.Length, "<Contains>");
                    else
                        s = s.Insert(s.Length, "<Eq>");

                    s = s.Insert(s.Length, "<FieldRef Name='" + txt.Attributes["data-name"] + "'/>");
                    s = s.Insert(s.Length, "<Value Type='Text'>" + txt.Text.Trim().Replace("&", "&amp;") + "</Value>");

                    if (ctrl.Key == "txtSearch" || ctrl.Key == "txtCounterparty")
                        s = s.Insert(s.Length, "</Contains>");
                    else
                        s = s.Insert(s.Length, "</Eq>");
                }
            }
            else if (ctrl.Key.StartsWith("dt"))
            {
                HtmlInputText txt = (HtmlInputText)ctrl.Value;
                DateTime d = Convert.ToDateTime(txt.Value);
                s = s.Insert(s.Length, "<Eq>");
                s = s.Insert(s.Length, "<FieldRef Name='" + txt.Attributes["data-name"] + "'/>");
                s = s.Insert(s.Length, "<Value Type='DateTime'>" + d.ToString("yyyy-MM-dd 00:00:00") + "</Value>");
                s = s.Insert(s.Length, "</Eq>");
            }
            else if (ctrl.Key.StartsWith("ddl"))
            {
                DropDownList ddl = (DropDownList)ctrl.Value;
                s = s.Insert(s.Length, "<Eq>");
                s = s.Insert(s.Length, "<FieldRef Name='" + ddl.Attributes["data-name"] + "'/>");
                s = s.Insert(s.Length, "<Value Type='Text'>" + ddl.SelectedItem.Text.Trim().Replace("&", "&amp;") + "</Value>");
                s = s.Insert(s.Length, "</Eq>");
            }
            else if (ctrl.Key.StartsWith("pe"))
            {
                PeopleEditor pe = (PeopleEditor)ctrl.Value;
                PickerEntity entity = (PickerEntity)pe.ResolvedEntities[0];
                SPUser user = ECContext.Current.CurrentWeb.EnsureUser(entity.Key);
                s = s.Insert(s.Length, "<Eq>");
                s = s.Insert(s.Length, "<FieldRef Name='" + pe.Attributes["data-name"] + "' LookupId='TRUE'/>");
                s = s.Insert(s.Length, "<Value Type='Integer'>" + user.ID + "</Value>");
                s = s.Insert(s.Length, "</Eq>");
            }
            else if (ctrl.Key.StartsWith("chn"))
            {
                string Checked="Yes";
                CheckBox chn = (CheckBox)ctrl.Value;
                s = s.Insert(s.Length, "<Eq>");
                s = s.Insert(s.Length, "<FieldRef Name='" + chn.Attributes["data-name"] + "'/>");
                s = s.Insert(s.Length, "<Value Type='Text'>" + chn.Checked + "</Value>");
                s = s.Insert(s.Length, "</Eq>");
            }

            if (bAddAnd && !bIsKeyWords)
                s = s.Insert(s.Length, "</And>");
        }

        private Dictionary<string, Control> ControlsToSearch()
        {
            Dictionary<string, Control> lstSearchValues = new Dictionary<string, Control>();

            if (hdnHiddenDetails.Value == "true" || hdnHiddenDetails.Value == "")
            {
                // IMPORTANT --> KeyWords always first
                if (txtKeyWords.Text.Trim() != "")
                    lstSearchValues.Add("txtKeyWords", txtKeyWords);

                if (dtActionDate.Value.Trim() != "")
                    lstSearchValues.Add("dtActionDate", dtActionDate);

                if (txtContractBarCode.Text.Trim() != "")
                    lstSearchValues.Add("txtContractBarCode", txtContractBarCode);

                if (txtContractReference.Text.Trim() != "")
                    lstSearchValues.Add("txtContractReference", txtContractReference);

                if (txtCounterparty.Text.Trim() != "")
                    lstSearchValues.Add("txtCounterparty", txtCounterparty);

                if (dtEffectiveDate.Value.Trim() != "")
                    lstSearchValues.Add("dtEffectiveDate", dtEffectiveDate);

                if (dtEndContract.Value.Trim() != "")
                    lstSearchValues.Add("dtEndContract", dtEndContract);

                if (dtSignatureDate.Value.Trim() != "")
                    lstSearchValues.Add("dtSignatureDate", dtSignatureDate);

                if (ddlBusinessFunction.SelectedIndex != 0)
                    lstSearchValues.Add("ddlBusinessFunction", ddlBusinessFunction);

                if (ddlDocType.SelectedIndex != 0)
                    lstSearchValues.Add("ddlDocType", ddlDocType);

                if (ddlMonsantoDivision.SelectedIndex != 0)
                    lstSearchValues.Add("ddlMonsantoDivision", ddlMonsantoDivision);

                if (ddlMonsantoEntity.SelectedIndex != 0)
                    lstSearchValues.Add("ddlMonsantoEntity", ddlMonsantoEntity);

                if (peBusinessPerson.ResolvedEntities.Count > 0)
                    lstSearchValues.Add("peBusinessPerson", peBusinessPerson);

                if (peDoaApprover.ResolvedEntities.Count > 0)
                    lstSearchValues.Add("peDoaApprover", peDoaApprover);
                if (chnCtrl.Checked)
                    lstSearchValues.Add("chnCtrl",chnCtrl);
            }

            if (txtSearch.Text.Trim() != "")
                lstSearchValues.Add("txtSearch", txtSearch);


            return lstSearchValues;
        }
	
	}
}

