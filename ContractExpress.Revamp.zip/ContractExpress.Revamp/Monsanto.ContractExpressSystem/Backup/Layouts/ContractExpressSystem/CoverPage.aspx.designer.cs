﻿namespace Monsanto.ContractExpressSystem.Layouts.ContractExpressSystem
{
    public partial class CoverPage
    {
    }
}
