﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint.WebControls;
using System.Threading;
using System.Globalization;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Monsanto.ContractExpressSsytem.HtmlToOpenXml;
using Microsoft.SharePoint.Utilities;
using System.Web;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using System.Xml;
using System.Collections;
using Monsanto.ContractExpressSystem;
using System.Configuration;


namespace Monsanto.ContractExpressSystem.Layouts.ContractExpressSystem
{
    public partial class CoverPage : LayoutsPageBase
    {

        Dictionary<string, ECContext.Bookmark> ContractBookmarks = new Dictionary<string, ECContext.Bookmark>();
        string strCoverPage = string.Empty;
        int contractID = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}