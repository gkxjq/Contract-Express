// global variables //
var TIMER = 5;
var SPEED = 10;


// calculate the current window width //
function pageWidth() {
  return window.innerWidth != null ? window.innerWidth : document.documentElement && document.documentElement.clientWidth ? document.documentElement.clientWidth : document.body != null ? document.body.clientWidth : null;
}

// calculate the current window height //
function pageHeight() {
  return window.innerHeight != null? window.innerHeight : document.documentElement && document.documentElement.clientHeight ? document.documentElement.clientHeight : document.body != null? document.body.clientHeight : null;
}

// calculate the current window vertical offset //
function topPosition() {
  return typeof window.pageYOffset != 'undefined' ? window.pageYOffset : document.documentElement && document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop ? document.body.scrollTop : 0;
}

// calculate the position starting at the left of the window //
function leftPosition() {
  return typeof window.pageXOffset != 'undefined' ? window.pageXOffset : document.documentElement && document.documentElement.scrollLeft ? document.documentElement.scrollLeft : document.body.scrollLeft ? document.body.scrollLeft : 0;
}

// build/show the dialog box, populate the data and call the fadeDialog function //
function showDialog(title,message,type,autohide) {
  if(!type) {
    type = 'error';
  }
  var dialog;
  var dialogheader;
  var dialogclose;
  var dialogtitle;
  var dialogcontent;
  var dialogmask;
  if(!document.getElementById('db_dialog')) {
    dialog = document.createElement('div');
    dialog.id = 'db_dialog';
    dialogheader = document.createElement('div');
    dialogheader.id = 'db_dialog-header';
    dialogtitle = document.createElement('div');
    dialogtitle.id = 'db_dialog-title';
    dialogclose = document.createElement('div');
    dialogclose.id = 'db_dialog-close'
    dialogcontent = document.createElement('div');
    dialogcontent.id = 'db_dialog-content';
    dialogmask = document.createElement('div');
    dialogmask.id = 'db_dialog-mask';
    document.body.appendChild(dialogmask);
    document.body.appendChild(dialog);
    dialog.appendChild(dialogheader);
    dialogheader.appendChild(dialogtitle);
    dialogheader.appendChild(dialogclose);
    dialog.appendChild(dialogcontent);;
    dialogclose.setAttribute('onclick','hideDialog()');
    dialogclose.onclick = hideDialog;
  } else {
    dialog = document.getElementById('db_dialog');
    dialogheader = document.getElementById('db_dialog-header');
    dialogtitle = document.getElementById('db_dialog-title');
    dialogclose = document.getElementById('db_dialog-close');
    dialogcontent = document.getElementById('db_dialog-content');
    dialogmask = document.getElementById('db_dialog-mask');
    dialogmask.style.visibility = "visible";
    dialog.style.visibility = "visible";
  }
  dialog.style.opacity = .00;
  dialog.style.filter = 'alpha(opacity=0)';
  dialog.alpha = 0;
  var width = pageWidth();
  var height = pageHeight();
  var left = leftPosition();
  var top = topPosition();
  var dialogwidth = dialog.offsetWidth;
  var dialogheight = dialog.offsetHeight;
  var topposition = top + (height / 3) - (dialogheight / 2);
  var leftposition = left + (width / 2) - (dialogwidth / 2);
  dialog.style.top = topposition + "px";
  dialog.style.left = leftposition + "px";
  dialogheader.className = type + "header";
  dialogtitle.innerHTML = title;
  dialogcontent.className = type;
  dialogcontent.innerHTML = message;
  dialog.timer = setInterval("fadeDialog(1)", TIMER);
  if(autohide) {
    dialogclose.style.visibility = "hidden";
    window.setTimeout("hideDialog()", (autohide * 1000));
  } else {
    dialogclose.style.visibility = "visible";
  }
}

// hide the dialog box //
function hideDialog() {
  var dialog = document.getElementById('db_dialog');
  clearInterval(dialog.timer);
  dialog.timer = setInterval("fadeDialog(0)", TIMER);
}

// fade-in the dialog box //
function fadeDialog(flag) {
  if(flag == null) {
    flag = 1;
  }
  var dialog = document.getElementById('db_dialog');
  var value;
  if(flag == 1) {
    value = dialog.alpha + SPEED;
  } else {
    value = dialog.alpha - SPEED;
  }
  dialog.alpha = value;
  dialog.style.opacity = (value / 100);
  dialog.style.filter = 'alpha(opacity=' + value + ')';
  if(value >= 99) {
    clearInterval(dialog.timer);
    dialog.timer = null;
  } else if(value <= 1) {
    dialog.style.visibility = "hidden";
    document.getElementById('db_dialog-mask').style.visibility = "hidden";
    clearInterval(dialog.timer);
  }
}

// EVERIS START



function showInformationDialog(message) {
    doShowDialog('info', message, null, null);
}

function showInformationActionDialog(message, actionHandler) {
    doShowDialog('infoWithAction', message, actionHandler, null);
}



function showErrorDialog(message) {
    doShowDialog("S'ha produ�t un error", message, null, null);
}

function showYesNoDialog(message, yesHandler, noHandler) {
    return doShowDialog('yesno', message, yesHandler, noHandler);
}

//this method returns a handle to the dialog object, which can be used to close the dialog.
//Example:
//To open:
//var dlg = showProcessingDialog("please wait...");
//To close:
//dlg.close();
function showProcessingDialog(message) {
    return SP.UI.ModalDialog.showWaitScreenWithNoClose('Processing', message, null, null);
}

function showActionDialog(message, actionHandler, actionBtnText) {
    var dialogTitle;
    var htmlElement = document.createElement('p');
    var actionButton = document.createElement('input');

    var helloWorldNode = document.createTextNode(message);
    htmlElement.appendChild(helloWorldNode);

    dialogTitle = 'Confirmaci�';
    actionButton.type = "button";
    actionButton.value = actionBtnText;
    actionButton.onclick = actionHandler;

    htmlElement.appendChild(actionButton);

    var options = {
        html: htmlElement,
        autoSize: true,
        allowMaximize: false,
        title: dialogTitle,
        showClose: true,
    };

    //gYesNoDialog = SP.UI.ModalDialog.showModalDialog(options);
    return SP.UI.ModalDialog.showModalDialog(options);
}


function doShowDialog(type, message, yesHandler, noHandler) {
    var dialogTitle;
    var htmlElement = document.createElement('p');
    var yesButton = document.createElement('input');
    var noButton = document.createElement('input');
    var helloWorldNode = document.createTextNode(message);
    htmlElement.appendChild(helloWorldNode);


    switch (type) {
        case 'yesno':
            dialogTitle = 'Confirmaci�';
            yesButton.type = "button";
            yesButton.value = 'S�';
            yesButton.onclick = yesHandler;
            noButton.type = "button";
            noButton.value = "No";
            noButton.onclick = noHandler;
            htmlElement.appendChild(yesButton);
            htmlElement.appendChild(noButton);
            break;
        case 'error':
            dialogTitle = 'error';
            break;
        case 'info':
            dialogTitle = 'Informaci�';
        case 'infoWithAction':
            dialogTitle = 'Informaci�';
    }

    var options = {
        html: htmlElement,
        autoSize: true,
        allowMaximize: false,
        title: dialogTitle,
        showClose: true,
    };
    
    //gYesNoDialog = SP.UI.ModalDialog.showModalDialog(options);
    return SP.UI.ModalDialog.showModalDialog(options);
}

// HANDLE ESC KEY FOR CLOSING DIALOGS
document.onkeypress = function (e) {
  e = window.event || e;

  // Check if ESC-Key is pressed
  if (e.keyCode == 27) {
    // Check if a dialog was recently opened
    var dialog = SP.UI.ModalDialog.get_childDialog();
    if (dialog != null) {
    // Try to close the dialog
      SP.UI.ModalDialog.commonModalDialogClose(SP.UI.DialogResult.cancel, "Closed by ESC");
    }
  }
}


function ceErrorDialog(hdr, msg) {

    var content = $("body").append($('<div id="errFillBookmarks"><div class="imgErrorDialog"><b class="txtErrDialog">' + hdr + '</b></div>' + msg + '</div>'));

    var options = {
        html: $("#errFillBookmarks")[0],
        autoSize: true,
        allowMaximize: false,
        title: "Error",
        showClose: true,
    };

    return SP.UI.ModalDialog.showModalDialog(options);
}

function ceInfoDialog(hdr, msg) {

    var  content = $("body").append($('<div id="errFillBookmarks"><div class="imgInfoDialog"><b class="txtErrDialog">' + hdr + '</b></div>' + msg + '</div>'));

    var options = {
        html: $("#errFillBookmarks")[0],
        autoSize: true,
        allowMaximize: false,
        title: "Info",
        showClose: true,
    };

    return SP.UI.ModalDialog.showModalDialog(options);
}

// EVERIS END

//DCC BEGINS
var newURL;
function ceInfoDialogRedirect(hdr, msg, redirectURL) {

    newURL = redirectURL;
    
    var  content = $("body").append($(redirectScript + '<div id="errFillBookmarks"><div class="imgInfoDialog"><b class="txtErrDialog">' + hdr + '</b></div>' + msg + '</div>'));

    var options = {
        html: $("#errFillBookmarks")[0],
        autoSize: true,
        allowMaximize: false,
        title: "Info",
        showClose: true,
        dialogReturnValueCallback: modalDialogClosed
    };

    return SP.UI.ModalDialog.showModalDialog(options);
}

function modalDialogClosed(dialogResult, returnValue) {
    window.location.href = newURL;
}
//DCC ENDS