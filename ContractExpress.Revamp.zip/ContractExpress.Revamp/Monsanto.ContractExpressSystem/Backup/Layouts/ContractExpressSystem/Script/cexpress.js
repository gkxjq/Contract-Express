﻿function CEXPRESS_decorateMyContractsList() {

    $("table[id*='{MYEXPCONTRACTS}'] tbody tr td.ms-vb2:last-child")
            .after("<td class='cexp-actionarea'>FOo</td>");
}