﻿
function toWords(s)
{
    return toWordsEng(s);
}
function toWords(s, l)
{
    if(l == "fr-FR")
        return toWordsFr(s);
    if(l == "nl-NL")
        return toWordsNl(s);

    return toWordsEng(s);

}


function toWordsEng(s)  {

	var a,b,c,j,orlen,result='';
	if (s=='0') {return ('zero');}
		orlen=s.length;
	if ((s.length % 3)>0)
		s=' '+s;
	if ((s.length % 3)>0)
		s=' '+s;
		
		
		
	for (var i = 0; i < s.length; i=i+3) {
		j=s.length-i-1;
		a=s.substring(j, j+1);
		b=s.substring(j-1, j);
		c=s.substring(j-2, j-1);
		if (a!=' '){
			if ((i==3)&(c+b+a!='000') ) {result='thousand '+result;}
			else if ((i==6)&(c+b+a!='000') ) {result='million '+result;}
			else if ((i==9)&(c+b+a!='000') ) {result='billion '+result;}
			else if ((i==12)&(c+b+a!='000') ) {result='trillion '+result;}
			else if ((i==15)&(c+b+a!='000') ) {result='quadrillion '+result;}
			else if ((i==18)&(c+b+a!='000') ) {result='quintillion '+result;}
			else if ((i==21)&(c+b+a!='000') ) {result='sextillion '+result;}
			else if ((i==24)&(c+b+a!='000') ) {result='septillion '+result;}
			else if ((i==27)&(c+b+a!='000') ) {result='octillion '+result;}
			else if ((i==30)&(c+b+a!='000') ) {result='nonillion '+result;}
			else if ((i==33)&(c+b+a!='000') ) {result='decillion '+result;}
			else if ((i==36)&(c+b+a!='000') ) {result='undecillion '+result;}
			else if ((i==39)&(c+b+a!='000') ) {result='duodecillion '+result;}
			else if ((i==42)&(c+b+a!='000') ) {result='tredecillion '+result;}
			else if ((i==45)&(c+b+a!='000') ) {result='quattuordecillion '+result;}
			else if ((i==48)&(c+b+a!='000') ) {result='quindecillion '+result;}
			else if ((i==51)&(c+b+a!='000') ) {result='sexdecillion '+result;}
			else if ((i==54)&(c+b+a!='000') ) {result='septendecillion '+result;}
			else if ((i==57)&(c+b+a!='000') ) {result='octodecillion '+result;}
			else if (i==60) {result='novemdecillion '+result;}
		}
		if ((b!='1') | (b==' ')){
			if (a==1){result='one '+result;}
			else if (a==2){result='two '+result;}
			else if (a==3){result='three '+result;}
			else if (a==4){result='four '+result;}
			else if (a==5){result='five '+result;}
			else if (a==6){result='six '+result;}
			else if (a==7){result='seven '+result;}
			else if (a==8){result='eight '+result;}
			else if (a==9){result='nine '+result;}
		}
		if ((b!=' ')&(b!='0')){
			if (b=='1'){
				if (a==0){result='ten '+result;}
				else if (a==1){result='eleven '+result;}
				else if (a==2){result='twelve '+result;}
				else if (a==3){result='thirteen '+result;}
				else if (a==4){result='fourteen '+result;}
				else if (a==5){result='fifteen '+result;}
				else if (a==6){result='sixteen '+result;}
				else if (a==7){result='seventeen '+result;}
				else if (a==8){result='eighteen '+result;}
				else if (a==9){result='nineteen '+result;}
			}
			else{
				if (b==2){result='twenty '+result;}
				else if (b==3){result='thirty '+result;}
				else if (b==4){result='fourty '+result;}
				else if (b==5){result='fifty '+result;}
				else if (b==6){result='sixty '+result;}
				else if (b==7){result='seventy '+result;}
				else if (b==8){result='eighty '+result;}
				else if (b==9){result='ninety '+result;}
			}
		}
		if ((c!=' ')&(c!='0')){
			if (c==1){result='one hundred '+result;}
			else if (c==2){result='two hundred '+result;}
			else if (c==3){result='three hundred '+result;}
			else if (c==4){result='four hundred '+result;}
			else if (c==5){result='five hundred '+result;}
			else if (c==6){result='six hundred '+result;}
			else if (c==7){result='seven hundred '+result;}
			else if (c==8){result='eight hundred '+result;}
			else if (c==9){result='nine hundred '+result;}
		}
	}
	result=Trim(result);
	result=FixSpaces(result);
	return (result);
}







function toWordsFr(s)  {
	var a,b,c,j,orlen,result='';
	if (s=='0') {return ('zéro');}
		orlen=s.length;
	if ((s.length % 3)>0)
		s=' '+s;
	if ((s.length % 3)>0)
		s=' '+s;
	for (var i = 0; i < s.length; i=i+3) {
		j=s.length-i-1;
		a=s.substring(j, j+1);
		b=s.substring(j-1, j);
		c=s.substring(j-2, j-1);
		if (a!=' '){
			if ((i==3)&(c+b+a!='000') ) {result='mille '+result;}
			else if (((i==6)&(c+b+a!='000') ) &(orlen==7)&(a=='1')) {result='million '+result;}
			else if ((i==6)&(c+b+a!='000') ) {result='millions '+result;}
			else if ((i==9)&(c+b+a!='000') ) {result='mille millions'+result;}
			else if (((i==12)&(c+b+a!='000') ) & (orlen==13)&(a=='1')) {result='billion '+result;}
			else if ((i==12)&(c+b+a!='000') ) {result='billions '+result;}
			else if ((i==15)&(c+b+a!='000') ) {result='mille billions'+result;}
			else if (((i==18)&(c+b+a!='000') )& (orlen==19)&(a=='1'))  {result='trillion '+result;}
			else if ((i==18)&(c+b+a!='000') ) {result='trillions '+result;}
			else if ((i==21)&(c+b+a!='000') ) {result='mille trillions '+result;}
			else if (((i==24)&(c+b+a!='000') )& (orlen==25)&(a=='1')) {result='quadrillion '+result;}
			else if ((i==24)&(c+b+a!='000') ) {result='quadrillions '+result;}
			else if ((i==27)&(c+b+a!='000') ) {result='mille quadrillions '+result;}
			else if (((i==30)&(c+b+a!='000') )& (orlen==31)&(a=='1')) {result='quintillion '+result;}
			else if ((i==30)&(c+b+a!='000') ) {result='quintillions '+result;}
			else if ((i==33)&(c+b+a!='000') ) {result='mille quintillions '+result;}
			else if (((i==36)&(c+b+a!='000') )& (orlen==37)&(a=='1')) {result='sextillion '+result;}
			else if ((i==36)&(c+b+a!='000') ) {result='sextillions '+result;}
			else if ((i==39)&(c+b+a!='000') ) {result='mille sextillions '+result;}
			else if (((i==42)&(c+b+a!='000') )& (orlen==43)&(a=='1')) {result='septillion '+result;}
			else if ((i==42)&(c+b+a!='000') ) {result='septillions '+result;}
			else if ((i==45)&(c+b+a!='000') ) {result='milseptillions '+result;}
			else if (((i==48)&(c+b+a!='000') )& (orlen==49)&(a=='1')) {result='octillion '+result;}
			else if ((i==48)&(c+b+a!='000') ) {result='octillions '+result;}
			else if ((i==51)&(c+b+a!='000') ) {result='mille octillions '+result;}
			else if (((i==54)&(c+b+a!='000') )& (orlen==55)&(a=='1')) {result='nonillion '+result;}
			else if ((i==57)&(c+b+a!='000') ) {result='nonillions '+result;}
			else if (i==60) {result='mille nonillions '+result;}
		}
		if (((b!=1)&(b!=7)&(b!=9)) | (b==' ')){
			if (a==1){result='un '+result;}
			else if (a==2){result='deux '+result;}
			else if (a==3){result='trois '+result;}
			else if (a==4){result='quatre '+result;}
			else if (a==5){result='cinq '+result;}
			else if (a==6){result='six '+result;}
			else if (a==7){result='sept '+result;}
			else if (a==8){result='huit '+result;}
			else if (a==9){result='neuf '+result;}
		}
		if ((b!=' ')&(b!='0')){
			if ((b==1) |(b==7) |(b==9)){
				if (b+a==10){result='dix '+result;}
				else if (b+a==11){result='onze '+result;}
				else if (b+a==12){result='douze '+result;}
				else if (b+a==13){result='treize '+result;}
				else if (b+a==14){result='quatorze '+result;}
				else if (b+a==15){result='quinze '+result;}
				else if (b+a==16){result='seize '+result;}
				else if (b+a==17){result='dix-sept '+result;}
				else if (b+a==18){result='dix-huit '+result;}
				else if (b+a==19){result='dix-neuf '+result;}
				else if (b+a==70){result='soixante-dix '+result;}
				else if (b+a==71){result='soixante-onze '+result;}
				else if (b+a==72){result='soixante-douze '+result;}
				else if (b+a==73){result='soixante-treize '+result;}
				else if (b+a==74){result='soixante-quatorze '+result;}
				else if (b+a==75){result='soixante-quinze '+result;}
				else if (b+a==76){result='soixante-seize '+result;}
				else if (b+a==77){result='soixante-dix-sept '+result;}
				else if (b+a==78){result='soixante-dix-huit '+result;}
				else if (b+a==79){result='soixante-dix-neuf '+result;}
				else if (b+a==90){result='quatre-vingt-dix'+result;}
				else if (b+a==91){result='quatre-vingt-onze'+result;}
				else if (b+a==92){result='quatre-vingt-douze '+result;}
				else if (b+a==93){result='quatre-vingt-treize '+result;}
				else if (b+a==94){result='quatre-vingt-quatorze '+result;}
				else if (b+a==95){result='quatre-vingt-quinze '+result;}
				else if (b+a==96){result='quatre-vingt-seize '+result;}
				else if (b+a==97){result='quatre-vingt-dix-sept '+result;}
				else if (b+a==98){result='quatre-vingt-dix-huit '+result;}
				else if (b+a==99){result='quatre-vingt-dix-neuf '+result;}
				}
			else{
				var temp=''
				if (a==1){temp='et ';}
				if (a>1){temp='-';}
				if (b==2){result='vingt '+temp+result;}
				else if (b==3){result='trente '+temp+result;}
				else if (b==4){result='quarante '+temp+result;}
				else if (b==5){result='cinquante '+temp+result;}
				else if (b==6){result='soixante '+temp+result;}
				else if (b==7){result='soixante-dix '+temp+result;}
				else if (b==8){result='quatre-vingts '+temp+result;}
				else if (b==9){result='quatre-vingt-dix '+temp+result;}
				}
		}
		if ((c!=' ')&(c!='0')){
				if (c==1){result='cent '+result;}
				else if (c==2){result='deux cents '+result;}
				else if (c==3){result='trois cents '+result;}
				else if (c==4){result='quatre cents '+result;}
				else if (c==5){result='cinq cents '+result;}
				else if (c==6){result='six cents '+result;}
				else if (c==7){result='sept cents '+result;}
				else if (c==8){result='huit cents '+result;}
				else if (c==9){result='neuf cents '+result;}
		}
	}
	result=FixSpaces(result);
	result=Trim(result);
	if (result.substring(0, 9)=='un mille ') result=result.substring(3,result.length);
	if (result.substring(result.length-3, result.length)=='et ') 
		result=result.substring(0,result.length-3);
	if (result.substring(result.length-2, result.length)==' -') 
		result=result.substring(0,result.length-2);
if (InStr(result, 'millions')!=RInStr(result, 'millions')) {
    var z = InStr(result, 'millions');
	result=result.substring(0,z-1)+result.substring(z+7,result.length);}
if (InStr(result, 'billions')!=RInStr(result, 'billions')) {
    var z = InStr(result, 'billions');
	result=result.substring(0,z-1)+result.substring(z+7,result.length);}
if (InStr(result, 'trillions')!=RInStr(result, 'trillions')) {
    var z = InStr(result, 'trillions');
	result=result.substring(0,z-1)+result.substring(z+8,result.length);}
if (InStr(result, 'quadrillions')!=RInStr(result, 'quadrillions')) {
    var z = InStr(result, 'quadrillions');
	result=result.substring(0,z-1)+result.substring(z+11,result.length);}
if (InStr(result, 'quintillions')!=RInStr(result, 'quintillions')) {
    var z = InStr(result, 'quintillions');
	result=result.substring(0,z-1)+result.substring(z+11,result.length);}
if (InStr(result, 'sextillions')!=RInStr(result, 'sextillions')) {
    var z = InStr(result, 'sextillions');
	result=result.substring(0,z-1)+result.substring(z+10,result.length);}
if (InStr(result, 'septillions')!=RInStr(result, 'septillions')) {
    var z = InStr(result, 'septillions');
	result=result.substring(0,z-1)+result.substring(z+10,result.length);}
if (InStr(result, 'octillions')!=RInStr(result, 'octillions')) {
    var z = InStr(result, 'octillions');
	result=result.substring(0,z-1)+result.substring(z+9,result.length);}
if (InStr(result, 'nonillions')!=RInStr(result, 'nonillions')) {
    var z = InStr(result, 'nonillions');
	result=result.substring(0,z-1)+result.substring(z+9,result.length);}
	result=FixSpaces(result);
while (InStr(result, ' -')>0){
	var z=InStr(result, ' -');
	result=result.substring(0,z-1)+result.substring(z,result.length);
	}
return (result);
}










function toWordsNl(s)  {

	var a,b,c,j,orlen,result='';
	if (s=='0') {return ('nul');}
		orlen=s.length;
	if ((s.length % 3)>0)
		s=' '+s;
	if ((s.length % 3)>0)
		s=' '+s;
	for (var i = 0; i < s.length; i=i+3) {
		j=s.length-i-1;
		a=s.substring(j, j+1);
		b=s.substring(j-1, j);
		c=s.substring(j-2, j-1);
		if (a!=' '){
			if ((i==3)&(c+b+a!='000') ) {result='duizend ' +result;}
			else if ((i==6)&(c+b+a!='000') ) {result='miljoen'+result;}
			else if ((i==9)&(c+b+a!='000') ) {result='biljoen'+result;}
			else if ((i==12)&(c+b+a!='000') ) {result='triljoen'+result;}
			else if ((i==15)&(c+b+a!='000') ) {result='quadriljoen'+result;}
			else if ((i==18)&(c+b+a!='000') ) {result='quintiljoen'+result;}
			else if ((i==21)&(c+b+a!='000') ) {result='sextiljoen'+result;}
			else if ((i==24)&(c+b+a!='000') ) {result='septiljoen'+result;}
			else if ((i==27)&(c+b+a!='000') ) {result='octiljoen'+result;}
			else if ((i==30)&(c+b+a!='000') ) {result='noniljoen'+result;}
			else if ((i==33)&(c+b+a!='000') ) {result='deciljoen'+result;}
			else if ((i==36)&(c+b+a!='000') ) {result='undeciljoen'+result;}
			else if ((i==39)&(c+b+a!='000') ) {result='duodeciljoen'+result;}
			else if ((i==42)&(c+b+a!='000') ) {result='tredeciljoen'+result;}
			else if ((i==45)&(c+b+a!='000') ) {result='quattuordeciljoen'+result;}
			else if ((i==48)&(c+b+a!='000') ) {result='quindeciljoen'+result;}
			else if ((i==51)&(c+b+a!='000') ) {result='sexdeciljoen'+result;}
			else if ((i==54)&(c+b+a!='000') ) {result='septendeciljoen'+result;}
			else if ((i==57)&(c+b+a!='000') ) {result='octodeciljoen'+result;}
			else if (i==60) {result='novemdeciljoen'+result;}
		}
		if (((b!=1)) | (b==' ')){
			if (a==1){result=result;}
			else if (a==2){result='twee'+result;}
			else if (a==3){result='drie'+result;}
			else if (a==4){result='vier'+result;}
			else if (a==5){result='vijf'+result;}
			else if (a==6){result='zes'+result;}
			else if (a==7){result='zeven'+result;}
			else if (a==8){result='acht'+result;}
			else if (a==9){result='negen'+result;}
		}
		if ((b!=' ')&(b!='0')){
			if ((b==1) ){
				if (b+a==10){result='tien '+result;}
				else if (b+a==11){result='elf '+result;}
				else if (b+a==12){result='twaalf '+result;}
				else if (b+a==13){result='dertien '+result;}
				else if (b+a==14){result='veertien '+result;}
				else if (b+a==15){result='vijftien '+result;}
				else if (b+a==16){result='zestien '+result;}
				else if (b+a==17){result='zeventien '+result;}
				else if (b+a==18){result='achttien '+result;}
				else if (b+a==19){result='negentien '+result;}
				}
			else{
				var temp='';
				if((a==1)|(a==2)|(a==3)|(a==4)|(a==5)|(a==6)|(a==7)|(a==8)|(a==9)){temp='en';}
				if (b==2){result=result + temp+ 'twintig ';}
				else if (b==3){result=result + temp +'dertig ';}
				else if (b==4){result=result + temp +'veertig ';}
				else if (b==5){result=result + temp +'vijftig ';}
				else if (b==6){result=result + temp +'zestig ';}
				else if (b==7){result=result + temp +'zeventig ';}
				else if (b==8){result=result + temp +'tachtig ';}
				else if (b==9){result=result + temp +'negentig ';}
				}
		}
		if ((c!=' ')&(c!='0')){
				if (c==1){result='honderd '+result;}
				else if (c==2){result='tweehonderd '+result;}
				else if (c==3){result='driehonderd '+result;}
				else if (c==4){result='vierhonderd '+result;}
				else if (c==5){result='vijfhonderd '+result;}
				else if (c==6){result='zeshonderd '+result;}
				else if (c==7){result='zevenhonderd '+result;}
				else if (c==8){result='achthonderd '+result;}
				else if (c==9){result='negenhonderd '+result;}
		}
	}
	result=FixSpaces(result);
	result=Trim(result);
	return (result);
}


 
function FixSpaces(s){

	var t='';
	for(var i=0; i<s.length; i++){
		if (i>0){
			if (!((s.substring(i-1,i)==' ')&(s.substring(i,i+1)==' ')))
				t=t+s.substring(i,i+1);
		}else
			t=t+s.substring(i,i+1);
	}
	return t;
}

function InStr(n, s1, s2){
	var numargs=InStr.arguments.length;
	
	if(numargs<3)
		return n.indexOf(s1)+1;
	else
		return s1.indexOf(s2, n)+1;
}
 
function RInStr(n, s1, s2){
	var numargs=RInStr.arguments.length;
	
	if(numargs<3)
		return n.lastIndexOf(s1)+1;
	else
		return s1.lastIndexOf(s2, n)+1;
}

function LTrim(s){
	var i=0;
	var j=0;
	
	for(i=0; i<=s.length-1; i++)
		if(s.substring(i,i+1) != ' '){
			j=i;
			break;
		}
	return s.substring(j, s.length);
}
 
function RTrim(s){
	var j=0;
	
	for(var i=s.length-1; i>-1; i--)
		if(s.substring(i,i+1) != ' '){
			j=i;
			break;
		}
	return s.substring(0, j+1);
}
 
function Trim(s){
	return LTrim(RTrim(s));
}