﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Wordprocessing;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using System.Configuration;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using System.Web;
using Microsoft.SharePoint.Utilities;
using System.Collections.Specialized;
using System.Net.Mail;
using Monsanto.ContractExpressSsytem.HtmlToOpenXml;
using System.Xml.Linq;
using Microsoft.Office.Server.Administration;

namespace Monsanto.ContractExpressSystem
{
    public sealed class ECContext
    {

        public enum TraceLevel { Information, Template, Unexpected };

        public static class Messages
        {
            public const string CloneContractError = "There was a problem cloning the contract. Please, contact system administrator for support.";
            public const string CreateContractError = "There was a problem creating this contract. Please, contact system administrator for support.";
            public const string CreateContractAttachmentError = "There was a problem with attachments in this contract. Please, contact system administrator for support.";
            public const string CreateBookmarksError = "There was a problem setting up current template bookmarks. Please, contact system administrator for support.";
            public const string MissingBookmarksOnListInfo = "We have detected that selected template contains bookmarks that are not present on bookmarks list. You can go ahead creating your contract. <br/> If you want all bookmarks to be filled in, please contact system administrator.";
            public const string UploadTemplateError = "There was a problem uploading this contract. Please, contact system administrator for support.";
            public const string ErrorReferenceMsg = "Error reference ID:";
            public const string ErrorPopupTitle = "Contract Express error";
            public const string InfoPopupTitle = "Contract Express";
            public const string SubmitForApprovalError = "This contract can't be submited due to missing required fields:<br /><br />{0}<br /><br />Please, contact system administrator for support.";
        }

        [Serializable]
        public class BookmarkGridItem
        {
            public string BookmarkDescription { get; set; }
            public string MainBookmarkDescription { get; set; }
            public string SecBookmarkDescription { get; set; }
            public string Language { get; set; }
            public bool Required { get; set; }
            public string DataType { get; set; }
            public string FieldMapping { get; set; }
            public int OrderPosition { get; set; }
            public string InternalName { get; set; }
            public string Value { get; set; }
            public string LongDescription { get; set; }
        }

        [Serializable]
        public class ContractDynamicPortion
        {
            public string BookMarkCode { get; set; }
            public string DisplayText { get; set; }
            public string DocumentType { get; set; }
            public string Language { get; set; }
            public string Portion { get; set; }
            public bool Mandatory { get; set; }
            public string FieldType { get; set; }
        }

        public sealed class EntityTAGStoReplace
        {
            public static readonly string COUNTRY = "[#COUNTRY#]";
            public static readonly string ENTITY_NAME = "[#ENTITY_NAME#]";
            public static readonly string ABBREVIATION = "[#ABBREVIATION#]";
            public static readonly string IBAN = "[#IBAN#]";
            public static readonly string ADDRESS = "[#ADDRESS#]";
            public static readonly string COMPANY_REGISTRATION_NO = "[#COMPANY_REGISTRATION_NO#]";
            public static readonly string VAT = "[#VAT#]";
            public static readonly string JURISDICTION = "[#JURISDICTION#]";
            public static readonly string INCORPORATION = "[#INCORPORATION#]";
            public static readonly string SIGNATORY = "[#SIGNATORY#]";
            public static readonly string BANK_NAME_ADDRESS = "[#BANK_NAME_ADDRESS#]";
            public static readonly string BANK_AC_NO = "[#BANK_AC_NO#]";
            public static readonly string SWIFT = "[#SWIFT#]";
            public static readonly string BIC = "[#BIC#]";
            public static readonly string CORRESPONDENT_BANK_AC_NO = "[#CORRESPONDENT_BANK_AC_NO#]";
            public static readonly string ID_NUMBER = "[#ID_NUMBER#]";
            public static readonly string CAPITAL_AMOUNT = "[#CAPITAL_AMOUNT#]";
            public static readonly string ENTITY_TYPE = "[#ENTITY_TYPE#]";
            public static readonly string REPRESENTATIVE = "[#REPRESENTATIVE#]";
            public static readonly string ANNUAL_RETURN_FILING_DATE = "[#ANNUAL_RETURN_FILING_DATE#]";
            public static readonly string OWNERSHIP = "[#OWNERSHIP#]";
            public static readonly string REGISTRATION_ADDRESS = "[#REGISTRATION_ADDRESS#]";
            public static readonly string USE_IN_CE = "[#USE_IN_CE#]";
            public static readonly string BANK_DETAILS = "[#BANK_DETAILS#]";
            public static readonly string SIGNATORIES = "[#SIGNATORIES#]";
            public static readonly string DECLINATED_COUNTRY_NAME = "[#DECLINATED_COUNTRY_NAME#]";
            public static readonly string ADDITIONAL_INFO = "[#ADDITIONAL_INFO#]";


        }

        public struct Bookmark
        {
            public string Name { get; set; }
            public BookmarkEnd End { get; set; }
            public BookmarkStart Start { get; set; }
            public string Content { get; set; }
            public bool IsBulletedList { get; set; }

            public string DataValue { get; set; }
            public string DataType { get; set; }
            public string Mapping { get; set; }
            public string Description { get; set; }
            public string LongDescription { get; set; }

            public int ItemID { get; set; }
        }

        public ECContext(SPContext sharepointContext)
        {

            context = sharepointContext;
        }

        private SPContext context;
        public SPContext SPContext
        {
            get { return context; }
        }

        public static ECContext Current
        {
            get
            {
                return new ECContext(SPContext.Current);
            }
        }

        public SPWeb CurrentWeb
        {
            get { return context.Web; }
        }
        public ECLists Lists
        {
            get
            {
                return new ECLists(this);

            }
        }

        public ECConfiguration _Configuration;
        public ECConfiguration Configuration
        {
            get
            {
                if (_Configuration == null)
                    _Configuration = new ECConfiguration(context.Web);
                return _Configuration;
            }
        }

        private string _ECMasterpageUrl;
        private string ECMasterpageUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_ECMasterpageUrl))
                    _ECMasterpageUrl = Current.Configuration.MasterpageUrl;
                return _ECMasterpageUrl;
            }
        }

        private static string _ECDoaType;
        public static string ECDoaType
        {
            get
            {
                if (string.IsNullOrEmpty(_ECDoaType))
                    _ECDoaType = Current.Configuration.DOATypeKey;
                return _ECDoaType;
            }
        }

        private static string _ECFcpaType;
        public static string ECFcpaType
        {
            get
            {
                if (string.IsNullOrEmpty(_ECFcpaType))
                    _ECFcpaType = Current.Configuration.FCPATypeKey;
                return _ECFcpaType;
            }
        }

        private static string _ECLegalType;
        public static string ECLegalType
        {
            get
            {
                if (string.IsNullOrEmpty(_ECLegalType))
                    _ECLegalType = Current.Configuration.LegalTypeKey;
                return _ECLegalType;
            }
        }

        public string MasterPageUrl(HttpContext context)
        {
            using (SPWeb web = SPControl.GetContextSite(context).OpenWeb())
                return string.Concat(web.ServerRelativeUrl, Configuration.MasterpageUrl);

        }

        #region Open xml
        public static class OpenXml
        {

            /// <summary>
            /// Process the template stream 
            /// </summary>
            /// <param name="stream"></param>
            /// <param name="newValues"></param>
            public static void ProcessTemplate(Stream stream, Dictionary<string, string> newValues, Dictionary<string, string> richTextNewValues)
            {
                using (WordprocessingDocument document = WordprocessingDocument.Open(stream, true))
                {
                    var bookMarks = FindBookmarks(document.MainDocumentPart.Document);
                    HtmlConverter convert = new HtmlConverter(document.MainDocumentPart);

                    foreach (var bookmark in bookMarks)
                    {
                        if (newValues.ContainsKey(bookmark.Key))
                        {
                            RunProperties properties = null;
                            if (bookmark.Value.Start.Parent.GetType() == typeof(Paragraph))
                                foreach (OpenXmlElement element in bookmark.Value.Start.Parent.ChildElements)
                                    if (element.GetType() == typeof(Run))
                                    {
                                        properties = ((Run)element).RunProperties;
                                        break;
                                    }
                            Text txt = new Text(newValues[bookmark.Key]);
                            Run rn = new Run(txt);
                            if (properties != null)
                                rn.RunProperties = (RunProperties)properties.Clone();

                            OpenXmlElement start = bookmark.Value.Start;

                            while (start != null && start.GetType() != typeof(BookmarkEnd))
                            {
                                OpenXmlElement newcontentElement = start.NextSibling();
                                if (start.GetType() == typeof(Run))
                                    start.Remove();
                                start = newcontentElement;
                            }

                            bookmark.Value.Start.InsertAfterSelf(rn);
                        }
                    }
                    //    return;

                    //else if (richTextNewValues.ContainsKey(bookmark.Key))
                    foreach (KeyValuePair<string, string> pair in richTextNewValues)
                    {
                        if (!bookMarks.Keys.Contains(pair.Key))
                            continue;
                        KeyValuePair<string, Bookmark> bookmark = new KeyValuePair<string, Bookmark>(pair.Key, bookMarks[pair.Key]);
                        RunProperties properties = null;
                        if (bookmark.Value.Start.Parent.GetType() == typeof(Paragraph))
                            foreach (OpenXmlElement element in bookmark.Value.Start.Parent.ChildElements)
                                if (element.GetType() == typeof(Run))
                                {
                                    properties = ((Run)element).RunProperties;
                                    break;
                                }

                        #region remove

                        OpenXmlElement start = bookmark.Value.Start;
                        bool bookmarkEndFound = false;
                        List<OpenXmlElement> elementsToMove = new List<OpenXmlElement>();

                        while (start != null)
                        {
                            if (start.GetType() == typeof(BookmarkEnd))
                                bookmarkEndFound = true;

                            OpenXmlElement newcontentElement = start.NextSibling();

                            if (start.GetType() == typeof(Run))
                            {
                                if (bookmarkEndFound)
                                    elementsToMove.Add(start.CloneNode(true));

                                start.Remove();
                            }
                            start = newcontentElement;
                        }

                        if (!bookmarkEndFound)
                        {
                            OpenXmlElement op = (OpenXmlElement)bookmark.Value.Start.Parent.NextSibling();

                            while (true)
                            {
                                if (op == null)
                                    break;

                                OpenXmlElement worker = op;
                                op = op.NextSibling();

                                if (worker.GetType() == typeof(BookmarkEnd))
                                    bookmarkEndFound = true;
                                else if (worker.GetType() == typeof(Paragraph))
                                    foreach (OpenXmlElement childelement in worker.ChildElements)
                                    {
                                        if (childelement.GetType() == typeof(BookmarkEnd))
                                        {
                                            bookmarkEndFound = true;
                                        }
                                    }

                                worker.Remove();
                                if (bookmarkEndFound == true)
                                    break;

                            }
                        }

                        if (elementsToMove.Count > 0)
                        {
                            OpenXmlElement P = (Paragraph)bookmark.Value.Start.Parent;
                            if (P.Parent == null)
                                P = bookmark.Value.Start;

                            OpenXmlElement P2 = P.InsertAfterSelf(new Paragraph());


                            foreach (OpenXmlElement child in elementsToMove)
                                P2.Append(child);
                        }

                        #endregion


                        OpenXmlElement P1 = bookmark.Value.Start.Parent;
                        if (P1.Parent == null)
                            P1 = bookmark.Value.Start;
                        OpenXmlElement PStartBoorkmark = P1.InsertAfterSelf(new Paragraph());

                        OpenXmlElement openXmlelement = null;
                        foreach (var item in convert.Parse(richTextNewValues[bookmark.Key]))
                        {
                            if (properties != null)
                            {
                                foreach (OpenXmlElement subitem in item.ChildElements)
                                {
                                    if (subitem.GetType() == typeof(Run))
                                        ((Run)subitem).RunProperties = (RunProperties)properties.Clone();
                                }
                            }
                            else
                            {

                                if (document.MainDocumentPart.Document.Descendants<Run>().Count() > 0)
                                {
                                    foreach (OpenXmlElement subitem in item.ChildElements)
                                    {
                                        // EVERIS - fix crash on contract generation when RunFonts is null
                                        // if (subitem.GetType() == typeof(Run))
                                        if (subitem.GetType() == typeof(Run) &&
                                            document.MainDocumentPart.Document.Descendants<Run>().First().RunProperties != null &&
                                            document.MainDocumentPart.Document.Descendants<Run>().First().RunProperties.RunFonts != null)
                                            ((Run)subitem).RunProperties = new RunProperties(document.MainDocumentPart.Document.Descendants<Run>().First().RunProperties.RunFonts.CloneNode(false));
                                    }
                                }

                            }

                            if (openXmlelement == null)
                                openXmlelement = PStartBoorkmark.InsertAfterSelf(item);
                            else
                                openXmlelement = openXmlelement.InsertAfterSelf(item);
                        }

                        openXmlelement.Append(new OpenXmlElement[] { bookmark.Value.End.CloneNode(false) });

                        if (bookmark.Value.End.Parent != null)
                        {
                            bookmark.Value.End.Remove();
                            //CheckEmptyParagraph(bookmark.Value.End.Parent);

                        }
                        if (openXmlelement.NextSibling() != null)
                            CheckEmptyParagraph(openXmlelement.NextSibling());
                    }
                    document.Close();
                }

            }

            /// <summary>
            /// Process the template stream 
            /// </summary>
            /// <param name="stream"></param>
            /// <param name="newValues"></param>
            public static void ProcessTemplate(Stream stream, Dictionary<string, string> newValues)
            {
                using (WordprocessingDocument document = WordprocessingDocument.Open(stream, true))
                {
                    var bookMarks = FindBookmarks(document.MainDocumentPart.Document);

                    foreach (var bookmark in bookMarks)
                    {
                        if (newValues.ContainsKey(bookmark.Key))
                        {
                            RunProperties properties = null;
                            if (bookmark.Value.Start.Parent.GetType() == typeof(Paragraph))
                                foreach (OpenXmlElement element in bookmark.Value.Start.Parent.ChildElements)
                                    if (element.GetType() == typeof(Run))
                                    {
                                        properties = ((Run)element).RunProperties;
                                        break;
                                    }
                            Text txt = new Text(newValues[bookmark.Key]);
                            Run rn = new Run(txt);
                            if (properties != null)
                                rn.RunProperties = (RunProperties)properties.Clone();

                            OpenXmlElement start = bookmark.Value.Start;

                            while (start != null && start.GetType() != typeof(BookmarkEnd))
                            {
                                OpenXmlElement newcontentElement = start.NextSibling();
                                if (start.GetType() == typeof(Run))
                                    start.Remove();
                                start = newcontentElement;
                            }


                            bookmark.Value.Start.InsertAfterSelf(rn);
                        }
                    }
                    document.Close();
                }
            }


            ///<summary>
            /// Load template file into memory
            /// </summary>
            /// <param name="filename"></param>
            /// <returns></returns>
            public static MemoryStream GetTemplateFile(string filename)
            {
                FileStream inStream = File.OpenRead(filename);
                MemoryStream storeStream = new MemoryStream();
                storeStream.SetLength(inStream.Length);
                inStream.Read(storeStream.GetBuffer(), 0, (int)inStream.Length);
                storeStream.Flush();
                inStream.Close();
                return storeStream;
            }

            /// <summary>
            /// Find bookmarks
            /// </summary>
            /// <param name="documentPart"></param>
            /// <returns></returns>
            private static Dictionary<string, Bookmark> FindBookmarks(OpenXmlElement documentPart)
            {
                return FindBookmarks(documentPart, new Dictionary<string, Bookmark>(), new List<BookmarkStart>());
            }

            /// <summary>
            /// Find bookmarks
            /// </summary>
            /// <param name="documentPart"></param>
            /// <returns></returns>
            public static Dictionary<string, Bookmark> FindBookmarks(Stream stream)
            {
                WordprocessingDocument document = WordprocessingDocument.Open(stream, true);
                return FindBookmarks(document.MainDocumentPart.Document);
            }

            /// <summary>
            /// Find bookmarks
            /// </summary>
            /// <param name="documentPart"></param>
            /// <returns></returns>
            public static Dictionary<string, Bookmark> FindBookmarksAndContent(Stream stream)
            {
                WordprocessingDocument document = WordprocessingDocument.Open(stream, true);
                // return FindBookmarksAndContent(document.MainDocumentPart.Document);

                Dictionary<string, Bookmark> lst = FindBookmarksAndContent(document.MainDocumentPart.Document, new Dictionary<string, Bookmark>(), new Dictionary<BookmarkStart, string>());
                List<string> keys = lst.Keys.ToList();




                foreach (string key in keys)
                    if (string.IsNullOrEmpty(lst[key].Content))
                    {
                        string txt = GetBookmarkText(document, lst[key].Name);
                        bool isBulleted = CheckIfBulleted(lst[key]);
                        lst[key] = new Bookmark() { Start = lst[key].Start, End = lst[key].End, Name = lst[key].Name, Content = txt, IsBulletedList = isBulleted };

                    }

                return lst;
            }

            private static bool CheckIfBulleted(Bookmark bookmark)
            {
                OpenXmlElement start = bookmark.Start;
                OpenXmlElement end = bookmark.End;

                /* while (start != null && start.GetType() != typeof(BookmarkEnd))
                 {
                     OpenXmlElement newcontentElement = start.NextSibling();

                     start = newcontentElement;
                 }*/

                while (end != null && end.GetType() != typeof(BookmarkStart))
                {
                    OpenXmlElement newcontentElement = end.PreviousSibling();
                    if (newcontentElement != null && newcontentElement.GetType() == typeof(ParagraphProperties))
                    {
                        if ((newcontentElement).OuterXml.Contains("ListParagraph"))
                            return true;
                    }

                    end = newcontentElement;
                }


                return false;
            }

            /// <summary>
            /// Find bookmarks
            /// </summary>
            /// <param name="documentPart"></param>
            /// <param name="results"></param>
            /// <param name="unmatched"></param>
            /// <returns></returns>
            /// 
            private static Dictionary<string, Bookmark> FindBookmarks(OpenXmlElement documentPart, Dictionary<string, Bookmark> results, List<BookmarkStart> unmatched)
            {
                foreach (var child in documentPart.Elements())
                {
                    if (child is BookmarkStart)
                    {
                        var bStart = child as BookmarkStart;
                        unmatched.Add(bStart);
                    }
                    if (child is BookmarkEnd)
                    {
                        var bEnd = child as BookmarkEnd;
                        foreach (var orphanName in unmatched)
                        {
                            if (bEnd.Id.Value == orphanName.Id.Value && !orphanName.Name.ToString().StartsWith("_"))
                                results.Add(orphanName.Name, new Bookmark() { Start = orphanName, End = bEnd, Name = orphanName.Name });
                        }
                    }
                    FindBookmarks(child, results, unmatched);
                }
                return results;
            }

            /// <summary>
            /// Find bookmarks
            /// </summary>
            /// <param name="documentPart"></param>
            /// <param name="results"></param>
            /// <param name="unmatched"></param>
            /// <returns></returns>
            /// 
            private static Dictionary<string, Bookmark> FindBookmarksAndContent(OpenXmlElement documentPart, Dictionary<string, Bookmark> results, Dictionary<BookmarkStart, string> unmatched)
            {
                foreach (var child in documentPart.Elements())
                {
                    if (child is BookmarkStart)
                    {
                        var bStart = child as BookmarkStart;

                        if (bStart.NextSibling() != null && bStart.NextSibling().GetType() == typeof(Run))
                        {
                            Run run = bStart.NextSibling() as Run;
                            unmatched.Add(bStart, run.InnerText);
                        }
                        else
                            unmatched.Add(bStart, string.Empty);
                    }
                    if (child is BookmarkEnd)
                    {
                        var bEnd = child as BookmarkEnd;
                        foreach (var orphanName in unmatched)
                            if (bEnd.Id.Value == orphanName.Key.Id.Value && !orphanName.Key.ToString().StartsWith("_"))
                                results.Add(orphanName.Key.Name, new Bookmark() { Start = orphanName.Key, End = bEnd, Name = orphanName.Key.Name, Content = orphanName.Value });
                    }

                    FindBookmarksAndContent(child, results, unmatched);
                }
                return results;
            }
            /// <summary>
            /// Bytes from Stream
            /// </summary>
            /// <param name="stream"></param>
            /// <returns></returns>
            public static byte[] ReadFully(Stream stream)
            {
                byte[] buffer = new byte[32768];
                using (MemoryStream ms = new MemoryStream())
                {
                    while (true)
                    {
                        int read = stream.Read(buffer, 0, buffer.Length);
                        if (read <= 0)
                            return ms.ToArray();
                        ms.Write(buffer, 0, read);
                    }
                }
            }


            private static void CheckEmptyParagraph(OpenXmlElement p)
            {
                bool hasRuns;


                if (p.HasChildren)
                {
                    if (!(p is Paragraph)) return;

                    // Has this paragraph some other elements than ParagraphProperties?
                    // This code ensure no default style or attribute on empty div will stay
                    hasRuns = false;
                    for (int j = p.ChildElements.Count - 1; j >= 0; j--)
                    {
                        if (!(p.ChildElements[j] is ParagraphProperties))
                        {
                            hasRuns = true;
                            break;
                        }
                    }

                    if (hasRuns) return;
                }
                p.Remove();
            }

            private static object FlattenParagraphsTransform(XNode node)
            {
                XElement element = node as XElement;
                if (element != null)
                {
                    if (element.Name == W.p)
                    {
                        return element.Elements().Where(e => e.Name != W.pPr).Select(e => FlattenParagraphsTransform(e))
                            .Concat(
                                new[]
                        {
                            new XElement(W.p,
                                element.Attributes(),
                                element.Elements(W.pPr))
                        });
                    }
                    return new XElement(element.Name,
                        element.Attributes(),
                        element.Nodes().Select(n => FlattenParagraphsTransform(n)));
                }
                return node;
            }

            static string GetBookmarkText(WordprocessingDocument doc, string bookmarkName)
            {
                XDocument xDoc = doc.MainDocumentPart.GetXDocument();
                bool containsBookmark = xDoc.Descendants(W.bookmarkStart)
                    .Where(d => (string)d.Attribute(W.name) == bookmarkName)
                    .Any();
                if (!containsBookmark)
                {
                    Console.WriteLine("Document doesn't contain bookmark.");
                    Console.WriteLine("Throw an exception or take appropriate action.");
                    //Comment Venu, Date 21 March, Commented below line and added logging to check the issue with document template and bookmarks
                    //Environment.Exit(0);
                    ECContext.AddLogEntry("Document doesn't contain bookmark - Environment.Exit(0) - Filename " + doc.PackageProperties.Title + "Bookmark  " + bookmarkName, SPContext.Current.Web);
                }
                XElement newRoot = (XElement)FlattenParagraphsTransform(xDoc.Root);

                XElement startBookmarkElement = newRoot.Descendants(W.bookmarkStart)
                    .Where(d => (string)d.Attribute(W.name) == bookmarkName)
                    .FirstOrDefault();
                int bookmarkId = (int)startBookmarkElement.Attribute(W.id);
                XElement endBookmarkElement = newRoot.Descendants(W.bookmarkEnd)
                    .Where(d => (int)d.Attribute(W.id) == bookmarkId)
                    .FirstOrDefault();
                if (startBookmarkElement.Parent != endBookmarkElement.Parent)
                {
                    Console.WriteLine("Bookmark start and end not at same levels.  Can't retrieve text");
                    //Comment Venu, Date 21 March, Commented below line and added logging to check the issue with document template and bookmarks
                    // Environment.Exit(0);
                    ECContext.AddLogEntry("Bookmark start and end not at same levels.  Can't retrieve text - Environment.Exit(0) - Filename " + doc.PackageProperties.Title + "Bookmark  " + bookmarkName, SPContext.Current.Web);
                }

                XElement parentElement = startBookmarkElement.Parent;
                var elementsBetweenBookmarks = startBookmarkElement
                    .ElementsAfterSelf()
                    .TakeWhile(e => e != endBookmarkElement);
                var text = elementsBetweenBookmarks
                    .Select(e =>
                    {
                        string runText = "";

                        if (e.Name == W.r)
                        {
                            runText += e.Descendants(W.t).Select(t => (string)t).StringConcatenate();
                            return runText;
                        }
                        if (e.Name == W.p)
                        {
                            //return Environment.NewLine;
                        }
                        return "";
                    })
                    .StringConcatenate();

                return text;
            }



        }
        #endregion

        public SPFile CreateNewExpressContractFromClone(SPListItem originalContract, string newContractName, SPWeb elevated)
        {
            string newUrl = string.Empty;


            SPFile sourcefile;
            try
            {

                sourcefile = originalContract.File;
            }
            catch (Exception)
            {
                throw new ApplicationException("Contract template not found, please verify that you have selected the template related question.");
                //ECContext.LogEvent(ex.Message, "Contract template not found, please verify that you have selected the template related question.");
            }

            newUrl = string.Format("{0}/{1}{2}", Lists.ExpressContract.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            //DCC New contracts are created in draft mode list newUrl = string.Format("{0}/{1}{2}", Lists.DraftContracts.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            if (sourcefile.CheckOutType != SPFile.SPCheckOutType.None)
                throw new ApplicationException(string.Concat("Template is not checked in. Please check this template ", sourcefile.Name));
            elevated.AllowUnsafeUpdates = true;

            SPFolder CEFolder = elevated.GetFolder(Lists.ExpressContract.RootFolder.Url);
            CEFolder.Files.Add(newUrl, sourcefile.OpenBinary(), SPContext.Current.Web.CurrentUser, SPContext.Current.Web.CurrentUser, DateTime.Now, DateTime.Now);

            //sourcefile.CopyTo(newUrl, true);
            elevated.AllowUnsafeUpdates = false;

            return elevated.GetFile(newUrl);
        }

        public SPFile CreateNewExpressContractCoverPageFromTemplate(string newContractName, string templateName, SPWeb elevated, string ContractID)
        {

            string newUrl = string.Empty;
            SPList eccpList = elevated.Lists.TryGetList("ExpressContractCoverPage");

            SPFile sourcefile;
            try
            {

                sourcefile = elevated.Lists[Configuration.ContractTemplateLibraryName].GetItems(new SPQuery() { RowLimit = 1, Query = string.Format("<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) })[0].File;
                //sourcefile = ECContext.Current.Lists.ContractTemplate.GetItems(new SPQuery() { RowLimit = 1, Query = string.Format("<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) })[0].File;
            }
            catch (Exception)
            {
                throw new ApplicationException("Contract template not found, please verify that you have selected the template related question.");
                //ECContext.LogEvent(ex.Message, "Contract template not found, please verify that you have selected the template related question.");
            }

            newUrl = string.Format("{0}/{1}{2}", eccpList.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            //DCC New contracts are created in draft mode list newUrl = string.Format("{0}/{1}{2}", Lists.DraftContracts.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            if (sourcefile.CheckOutType != SPFile.SPCheckOutType.None)
                throw new ApplicationException(string.Concat("Template is not checked in. Please check this template ", sourcefile.Name));
            elevated.AllowUnsafeUpdates = true;

            SPFolder CEFolder = elevated.GetFolder(eccpList.RootFolder.Url);
            CEFolder.Files.Add(newUrl, sourcefile.OpenBinary(), true);
            SPListItem itemCP = elevated.GetFile(newUrl).Item;
            itemCP["ContractID"] = ContractID;
            itemCP.Update();
            //sourcefile.CopyTo(newUrl, true);
            elevated.AllowUnsafeUpdates = false;

            return elevated.GetFile(newUrl);
        }

        public SPFile CreateNewExpressContractFromTemplate(string newContractName, string templateName, SPWeb elevated)
        {

            string newUrl = string.Empty;


            SPFile sourcefile;
            try
            {

                sourcefile = elevated.Lists[Configuration.ContractTemplateLibraryName].GetItems(new SPQuery() { RowLimit = 1, Query = string.Format("<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) })[0].File;
                //sourcefile = ECContext.Current.Lists.ContractTemplate.GetItems(new SPQuery() { RowLimit = 1, Query = string.Format("<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) })[0].File;
            }
            catch (Exception)
            {
                throw new ApplicationException("Contract template not found, please verify that you have selected the template related question.");
                //ECContext.LogEvent(ex.Message, "Contract template not found, please verify that you have selected the template related question.");
            }

            newUrl = string.Format("{0}/{1}{2}", Lists.ExpressContract.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            //DCC New contracts are created in draft mode list newUrl = string.Format("{0}/{1}{2}", Lists.DraftContracts.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            if (sourcefile.CheckOutType != SPFile.SPCheckOutType.None)
                throw new ApplicationException(string.Concat("Template is not checked in. Please check this template ", sourcefile.Name));
            elevated.AllowUnsafeUpdates = true;

            SPFolder CEFolder = elevated.GetFolder(Lists.ExpressContract.RootFolder.Url);
            CEFolder.Files.Add(newUrl, sourcefile.OpenBinary(), SPContext.Current.Web.CurrentUser, SPContext.Current.Web.CurrentUser, DateTime.Now, DateTime.Now);

            //sourcefile.CopyTo(newUrl, true);
            elevated.AllowUnsafeUpdates = false;

            return elevated.GetFile(newUrl);
        }

        public void HandleException(Exception ex)
        {
            SPUtility.SendEmail(Current.context.Web, false, false, Current.Configuration.SupportMail, "Express contract Exception", ex.Message);
        }

        public static int LogEvent(string message, Exception ex, TraceLevel traceLevel)
        {
            return LogEvent(message, ex, traceLevel, SPContext.Current.Web);
        }

        public static int LogEvent(string message, Exception ex, TraceLevel traceLevel, SPWeb web)
        {
            string logMessage = ex == null ? message : ex.Message;
            string logTrace = ex == null ? string.Empty : ex.ToString();

            //Log into Logging List
            int logId = AddLogListEntry(logMessage, logTrace, traceLevel, web);

            //Log into SP
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ContactExpress", TraceSeverity.High, EventSeverity.Error), TraceSeverity.High, logMessage + " " + logTrace, null);

            // Return logId for referencing in error messages
            return logId;
        }

        private static int AddLogListEntry(string logMessage, string logTrace, TraceLevel traceLevel, SPWeb web)
        {
            try
            {
                SPList logList = web.Lists["Logging"];

                web.AllowUnsafeUpdates = true;

                if (logList != null)
                {
                    web.AllowUnsafeUpdates = true;

                    SPListItem logEntry = logList.Items.Add();

                    logEntry["Level"] = traceLevel;
                    logEntry["Message"] = logMessage;
                    logEntry["StackTrace"] = logTrace;
                    logEntry["TimeStamp"] = DateTime.Now;


                    logEntry.Update();

                    return logEntry.ID;
                }

                return 0;
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ContractExpress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message + ex.StackTrace, null);
                return 0;
            }
            finally
            {
                web.AllowUnsafeUpdates = false;
            }
        }

        public static int AddLogEntry(string logMessage, SPWeb web)
        {
            try
            {
                SPList logList = web.Lists["Logging"];

                web.AllowUnsafeUpdates = true;

                if (logList != null)
                {
                    web.AllowUnsafeUpdates = true;

                    SPListItem logEntry = logList.Items.Add();

                    logEntry["Message"] = logMessage;
                    logEntry["TimeStamp"] = DateTime.Now;


                    logEntry.Update();

                    return logEntry.ID;
                }

                return 0;
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ContractExpress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message + ex.StackTrace, null);
                return 0;
            }
            finally
            {
                web.AllowUnsafeUpdates = false;
            }
        }

        #region mail

        public static string CreateMailForApproval(SPListItem item, string type, string answers, bool isAmended)
        {
            string siteUrl = SPContext.Current.Site.Url;
            return CreateMailForApproval(siteUrl, item, type, answers, isAmended);
        }

        public static string CreateMailForApproval(string sUrl, SPListItem item, string type, string answers, bool isAmended)
        {
            string url = string.Concat(sUrl, "/Style%20Library/Images/Mail/");
            string siteUrl = sUrl;
            string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
            string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
            //string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;
            Dictionary<string, Dictionary<string, string>> sections = GetSections(siteUrl);

            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            string selectedEmailTemplate = "";

            selectedEmailTemplate = CETemplateMails.MailForApprovalEmailTemplate;

            valuesToReplace.Add(CEMailSymbol.mailforApproval_Action, !isAmended ? "created a new express" : "has amended an express");
            valuesToReplace.Add(CEMailSymbol.mailforApproval_ApprovalURL, string.Format("{0}/_layouts/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", sUrl, item.ID.ToString(), type));
            valuesToReplace.Add(CEMailSymbol.mailforApproval_BU, new SPFieldUserValue(item.Web, Convert.ToString(item["Business user"])).User.Name);
            valuesToReplace.Add(CEMailSymbol.mailforApproval_ContractTitle, item.File.Title);
            valuesToReplace.Add(CEMailSymbol.mailforApproval_ContractURL, string.Concat(sUrl, "/", item.ParentList.RootFolder.Url, "/", item.File.Name));
            valuesToReplace.Add(CEMailSymbol.mailforApproval_Country, country);
            valuesToReplace.Add(CEMailSymbol.mailforApproval_Entity, Entity);
            valuesToReplace.Add(CEMailSymbol.mailforApproval_Header, "Request for approval");
            valuesToReplace.Add(CEMailSymbol.mailforApproval_SiteURL, sUrl);

            StringBuilder sb = new StringBuilder();


            List<string> splits = new List<string>();
            splits.AddRange(answers.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));

            //Comment this section to hide questions in Approval email.


            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                valuesToReplace.Add(CEMailSymbol.mailforApproval_FCPAQuestionsTitle, section.Key);
                //sb.Append(CreateSectionHead(section.Key));
                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    sb.Append(CreateContent(question.Value));
                    string key = string.Format("<answer>{0}|", question.Key);

                    if (splits.Exists(a => a.StartsWith(key)))
                        sb.Append(CreateContent(splits.First(a => a.StartsWith(key)).Replace(key, string.Empty).Replace("\r\n", "<br />")));
                }
            }
            valuesToReplace.Add(CEMailSymbol.mailforApproval_FCPAQuestions, sb.ToString());

            //sb.AppendLine(" </table> </td> </tr> <tr>");
            //sb.AppendLine("<td valign=\"top\"> <table cellspacing=\"0\" border=\"0\" cellpadding=\"0\" width=\"675\"> <tr> <td valign=\"top\"> </td> </tr> <tr> <td align=\"center\" class=\"footer\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <img src=\"images/double-line.gif\" alt=\"\" width=\"675\" style=\"display: block;\" /> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> </td> </tr> </table> </td> </tr>  </table> </td> </tr> </table> </body> </html>");

            CEEmail email = mailSystem.GetEmailMessageFromTemplate(item.Web, selectedEmailTemplate, valuesToReplace);
            email.EmailBody = email.EmailBody.Replace("images/", url);

            //return sb.ToString().Replace("images/", url);
            return email.EmailBody;
        }

        public static List<string> CreateLegalHeader(SPWeb web)
        {
            List<string> bcc = new List<string>();

            SPSecurity.RunWithElevatedPrivileges(delegate()
               {
                   using (SPSite newSite = new SPSite(web.Site.ID))
                   {
                       using (SPWeb webElevated = newSite.OpenWeb(web.ID))
                       {
                           SPGroup group = webElevated.Groups["Legal admin"];

                           foreach (SPUser user in group.Users)
                               if (!string.IsNullOrEmpty(user.Email))
                                   bcc.Add(user.Email);

                       }
                   }
               });

            return bcc;
        }

        public static List<string> CreateDOAHeader(SPListItem item, SPWeb web)
        {
            List<string> bcc = new List<string>();

            SPSecurity.RunWithElevatedPrivileges(delegate()
               {
                   using (SPSite newSite = new SPSite(web.Site.ID))
                   {
                       using (SPWeb webElevated = newSite.OpenWeb(web.ID))
                       {
                           SPUser user = new SPFieldUserValue(webElevated, Convert.ToString(item[ECContext.Current.Configuration.ECFields.DaoApprover])).User;
                           if (!string.IsNullOrEmpty(user.Email))
                               bcc.Add(user.Email);
                       }
                   }
               });

            return bcc;
        }




        public static List<string> CreateFCPAHeader(SPWeb web)
        {
            List<string> bcc = new List<string>();

            SPSecurity.RunWithElevatedPrivileges(delegate()
             {
                 using (SPSite newSite = new SPSite(web.Site.ID))
                 {
                     using (SPWeb webElevated = newSite.OpenWeb(web.ID))
                     {
                         StringDictionary headers = new StringDictionary();
                         SPGroup group = webElevated.Groups["FCPA Approver"];

                         foreach (SPUser user in group.Users)
                             if (!string.IsNullOrEmpty(user.Email))
                                 bcc.Add(user.Email);

                     }
                 }
             });

            return bcc;
        }

        private static string CreateSectionHead(string section)
        {
            return string.Format("  <tr> <td valign=\"top\"> <img src=\"images/double-line.gif\" alt=\"\" style=\"display: block;\" /> </td> </tr> <tr><td class=\"article-title\" height=\"30\" valign=\"middle\" style=\"text-transform: uppercase; font-family: Georgia, serif; font-size: 16px; color: #2b2b2b; font-style: italic; border-bottom: 1px solid #c1c1c1;\"> {0} </td> </tr>", section);
        }

        private static string CreateContent(string message)
        {
            return string.Format("<tr><td class=\"copy\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <p>{0}</p> <br /> </td> </tr>", message);
        }


        public static string CreateMail(SPListItem item, string answers, string type, string selectedEmailTemplate)
        {
            StringBuilder sb = new StringBuilder();
            string url = string.Concat(SPContext.Current.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = SPContext.Current.Site.Url;

            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            //string selectedEmailTemplate = "";

            //selectedEmailTemplate = CETemplateMails.RequestApprovalEmailTemplate;



            try
            {
                string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
                string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
                //string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;
                Dictionary<string, Dictionary<string, string>> sections = GetSections();
                string sUserName = new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Name;
                string sFileUrl = string.Concat(SPContext.Current.Site.Url, "/", item.File.Url);
                string sApprovalUrl = string.Format("{0}/_layouts/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", SPContext.Current.Site.Url, item.ID.ToString(), type);


                valuesToReplace.Add(CEMailSymbol.requestApproval_ContractURL, string.Concat(item.Web.Site.Url, "/", item.File.Url));
                valuesToReplace.Add(CEMailSymbol.requestApproval_ContractTitle, item.File.Title);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Header, "Request for approval");
                valuesToReplace.Add(CEMailSymbol.requestApproval_BU, sUserName);
                valuesToReplace.Add(CEMailSymbol.requestApproval_ApprovalURL, sApprovalUrl);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Entity, Entity);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Country, country);
                valuesToReplace.Add(CEMailSymbol.requestApproval_SiteURL, SPContext.Current.Site.Url);


                List<string> splits = new List<string>();
                splits.AddRange(answers.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));

                if (type == ECContext.ECFcpaType)
                {
                    SPFieldLookupValue lv = new SPFieldLookupValue(Convert.ToString(item[ECContext.Current.Configuration.ECFields.ApprovalAnswer]));
                    if (lv.LookupId != 0)
                    {
                        try
                        {
                            string sUrl = ECContext.Current.Lists.ApprovalAnswer.GetItemById(lv.LookupId).File.Url;
                            //sb.Append(CreateContent(string.Format("To review the approval answers please follow <a href ='{0}' >this</a> link. </br>", string.Concat(SPContext.Current.Site.Url, "/", sUrl))));
                            valuesToReplace.Add(CEMailSymbol.requestApproval_ApprovalQuestions, string.Format("To review the approval answers please follow <a href ='{0}' >this</a> link. </br>", string.Concat(SPContext.Current.Site.Url, "/", sUrl)));
                        }
                        catch (Exception ex)
                        {
                            ECContext.LogEvent("Contract " + item.ID + " has no approval answers", ex, ECContext.TraceLevel.Information);
                        }
                    }
                }
                foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
                {
                    sb.Append(CreateSectionHead(section.Key));
                    if (type == ECContext.ECFcpaType)
                    {
                        foreach (KeyValuePair<string, string> question in section.Value)
                        {
                            sb.Append(CreateContent(question.Value));
                            string yeskey = string.Format("<answer>{0}yes|true", question.Key);
                            string nokey = string.Format("<answer>{0}no|true", question.Key);

                            if (splits.Exists(a => a.StartsWith(yeskey)))
                                sb.Append(CreateContent("answer was YES"));
                            if (splits.Exists(a => a.StartsWith(nokey)))
                                sb.Append(CreateContent("answer was no"));
                        }
                    }
                    else
                        foreach (KeyValuePair<string, string> question in section.Value)
                        {
                            sb.Append(CreateContent(question.Value));
                            string key = string.Format("<answer>{0}|", question.Key);

                            if (splits.Exists(a => a.StartsWith(key)))
                                sb.Append(CreateContent(splits.First(a => a.StartsWith(key)).Replace(key, string.Empty).Replace("\r\n", "<br />")));
                        }
                }
                valuesToReplace.Add(CEMailSymbol.requestApproval_FCPAQuestions, sb.ToString());

                //sb.AppendLine(" </table> </td> </tr> <tr>");
                //sb.AppendLine("<td valign=\"top\"> <table cellspacing=\"0\" border=\"0\" cellpadding=\"0\" width=\"675\"> <tr> <td valign=\"top\"> </td> </tr> <tr> <td align=\"center\" class=\"footer\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <img src=\"images/double-line.gif\" alt=\"\" width=\"675\" style=\"display: block;\" /> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> </td> </tr> </table> </td> </tr>  </table> </td> </tr> </table> </body> </html>");
            }
            catch (Exception ex)
            {
                ECContext.LogEvent("Approval Form. Error creating mail for contract " + item.ID, ex, ECContext.TraceLevel.Information);
            }
            CEEmail email = mailSystem.GetEmailMessageFromTemplate(ECContext.Current.CurrentWeb, selectedEmailTemplate, valuesToReplace);
            email.EmailBody = email.EmailBody.Replace("images/", url);
            //return sb.ToString().Replace("images/", url);
            return email.EmailBody;
        }


        public static bool SendMail(SPWeb web, string Subject, string Body, bool IsBodyHtml, string From, List<string> To, List<string> Cc, List<string> Bcc)
        {
            bool mailSent = false;
            try
            {
                SmtpClient smtpClient = new SmtpClient();

                //Comment Venu, Date 22 March, Added below try catch finally block to change the SMPTHost as per the configuration list. 
                string strGUID = string.Empty;
                try
                {
                    strGUID = Guid.NewGuid().ToString();
                    Body = Body + "<span style='font-size:1px;display:none;'>" + strGUID + "</span>";
                    SPList ecList = ECContext.Current.CurrentWeb.Lists.TryGetList("Configuration");
                    SPQuery queryConfiguration = new SPQuery();
                    queryConfiguration.Query = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">SMTPHost</Value></Eq></Where>";

                    SPListItemCollection itemCol = ecList.GetItems(queryConfiguration);
                    if (itemCol.Count > 0)
                    {
                        smtpClient.Host = Convert.ToString(itemCol[0]["Value"]);
                    }
                    else
                    {
                        smtpClient.Host = web.Site.WebApplication.OutboundMailServiceInstance.Server.Address;
                    }
                }
                catch (Exception ex)
                {
                    smtpClient.Host = web.Site.WebApplication.OutboundMailServiceInstance.Server.Address;
                    LogEvent("smtpClient.Host - " + smtpClient.Host + "Mail Sent - Subject - " + Subject + " - strGUID - " + strGUID, ex, ECContext.TraceLevel.Unexpected, web);
                }
                finally
                {
                }

                MailMessage mailMessage = null;

                String contactList = string.Empty;

                //DCC
                mailMessage = new MailMessage();
                mailMessage.Subject = Subject;
                mailMessage.Body = Body;
                mailMessage.From = new MailAddress(From);


                foreach (string toAddress in To)
                {
                    contactList += toAddress + ";";
                    MailAddress TOAddress = new MailAddress(toAddress);
                    mailMessage.To.Add(TOAddress);
                }

                contactList = string.Empty;
                foreach (string ccAddress in Cc)
                {
                    contactList += ccAddress + ";";
                    MailAddress CCAddress = new MailAddress(ccAddress);
                    mailMessage.CC.Add(CCAddress);
                }

                contactList = string.Empty;
                foreach (string bccAddress in Bcc)
                {
                    contactList += bccAddress + ";";
                    MailAddress BcCAddress = new MailAddress(bccAddress);
                    mailMessage.Bcc.Add(BcCAddress);
                }

                mailMessage.IsBodyHtml = IsBodyHtml;
                smtpClient.Send(mailMessage);
                mailSent = true;

                //Comment Venu, Date 21 March, Added try catch to check multiple mails are triggered or not
                try
                {
                    ECContext.AddLogEntry("SendMail - Mail Sent - Subject - " + Subject + " - strGUID - " + strGUID + " - smtpClient.Host " + smtpClient.Host, SPContext.Current.Web);
                }
                catch (Exception ex)
                {
                    LogEvent("Mail Sent - Subject - " + Subject + " - strGUID - " + strGUID, ex, ECContext.TraceLevel.Unexpected, web);
                }

                //LogEvent(String.Format("Mail {0} sent to:{1}", Subject, mailMessage.Bcc.ToString()), null, ECContext.TraceLevel.Information);
            }
            catch (Exception ecp)
            {
                LogEvent(String.Format("Mail error: {0}", ecp.Message), ecp, ECContext.TraceLevel.Unexpected, web);
                return mailSent;
            }
            return mailSent;
        }

        public static bool SendMail(SPWeb web, string Subject, string Body, List<string> Bcc)
        {
            return SendMail(web, Subject, Body, true, "ExpressContractSystem@monsanto.com", new List<string>(), new List<string>(), Bcc);
        }

        public static bool SendMail(SPWeb web, string Subject, string Body, string To)
        {
            List<string> toList = new List<string>();
            toList.Add(To);
            return SendMail(web, Subject, Body, true, "ExpressContractSystem@monsanto.com", toList, new List<string>(), new List<string>());
        }

        private static string GetSharePointMailService(string mysite)
        {
            string address;
            using (SPSite site = new SPSite(mysite))
            {
                address = site.WebApplication.OutboundMailServiceInstance.Server.Address;
            }
            return address;
        }

        #endregion

        #region ApprovalQuestions

        public enum QuestionType { FCPA, Approval };

        public static Dictionary<string, Dictionary<string, string>> GetSections()
        {
            string siteUrl = SPContext.Current.Site.Url;
            return GetSections(siteUrl);
        }

        public static Dictionary<string, Dictionary<string, string>> GetSections(string siteUrl)
        {
            Dictionary<string, Dictionary<string, string>> sections = new Dictionary<string, Dictionary<string, string>>();
            string section = "";
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    if (web.Lists.TryGetList("Approval Questions") != null)
                    {
                        foreach (SPListItem item in web.Lists["Approval Questions"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='LinkTitleNoMenu' Ascending='True' /><FieldRef Name='Order0' Ascending='True' /></OrderBy>" }))
                        {
                            section = Convert.ToString(item[SPBuiltInFieldId.Title]);
                            if (section != "FCPA relevance:")
                            {
                                if (sections.ContainsKey(section))
                                    sections[section].Add(Convert.ToString(item[SPBuiltInFieldId.ID]), Convert.ToString(item["Question"]));
                                else
                                {
                                    Dictionary<string, string> lst = new Dictionary<string, string>();
                                    lst.Add(Convert.ToString(item[SPBuiltInFieldId.ID]), Convert.ToString(item["Question"]));
                                    sections.Add(section, lst);
                                }
                            }
                        }
                    }
                }
            }
            return sections;
        }

        public static string GetQuestionAnswer(int contractItemId, int questionItemId, QuestionType questionType)
        {
            string answer = string.Empty;

            try
            {
                ECFields fields = new ECFields();
                string answerField = string.Empty;
                string answerValue = string.Empty;
                SPList contractExpress = ECContext.Current.Lists.ExpressContract;
                SPList approvalAnswers = ECContext.Current.Lists.ApprovalAnswer;
                SPListItem contractItem = contractExpress.GetItemById(contractItemId);

                switch (questionType)
                {
                    case QuestionType.Approval:
                        answerField = "Approval Answers";
                        break;
                    case QuestionType.FCPA:
                        answerField = "FCPA Approval Answers"; //_x0020_
                        break;
                }

                if (!string.IsNullOrEmpty(answerField))
                {
                    SPFieldLookupValue lookupApprovalAnswer = new SPFieldLookupValue((string)contractItem[answerField]);
                    SPListItem questionAnswerItem = approvalAnswers.GetItemById(lookupApprovalAnswer.LookupId);
                    answerValue = (string)questionAnswerItem["Answers"];

                    List<string> answersTagContent = answerValue.Split(new string[] { "<answer>" }, StringSplitOptions.RemoveEmptyEntries).ToList();

                    foreach (string content in answersTagContent)
                    {
                        List<string> answerTagContentSplitted = content.Split('|').ToList();

                        string key = answerTagContentSplitted[0];
                        string val = answerTagContentSplitted[1].Replace("</answer>", "");

                        //FCPA question format treatment
                        switch (questionType)
                        {
                            case QuestionType.FCPA:
                                if (key.Contains("yes") && val == "true")
                                {
                                    key = key.Replace("yes", "");
                                    val = "true";

                                }
                                else if (key.Contains("no") && val == "true")
                                {   //FCPA question format
                                    key = key.Replace("no", "");
                                    val = "false";

                                }
                                break;
                        }

                        if (key == questionItemId.ToString())
                        {
                            answer = val;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }

            return answer;

        }

        #endregion
    }
}