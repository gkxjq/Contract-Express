﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.ContractExpressSystem
{
	public class ECValidationException : Exception
	{
		public ECValidationException(string field, string fmt, params object[] args) : base (String.Format("{0} {1}", String.IsNullOrEmpty(field) ? "" : "Field '" + field + "':", String.Format(fmt, args)))
		{
		}


	}
}
