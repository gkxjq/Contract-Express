﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.ContractExpressSystem
{
    public class ECFormBase : Microsoft.SharePoint.WebControls.LayoutsPageBase
    {

        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            this.MasterPageFile = ECContext.Current.MasterPageUrl(Context);
        }
    }
}
