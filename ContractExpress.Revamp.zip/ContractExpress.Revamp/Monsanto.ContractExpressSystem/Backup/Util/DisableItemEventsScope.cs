﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace Monsanto.ContractExpressSystem
{
    /// <summary>
    /// Disabled item events scope
    /// </summary>
    /// <see cref="http://adrianhenke.wordpress.com/2010/01/29/disable-item-events-firing-during-item-update/"/>
    class DisabledItemEventsScope : SPItemEventReceiver, IDisposable
    {
        bool oldValue;
        public void DisabledItemEvents()
        {
            this.oldValue = base.EventFiringEnabled;
            base.EventFiringEnabled = false;
        }

        public void EnableItemEvents()
        {
            this.oldValue = base.EventFiringEnabled;
            base.EventFiringEnabled = true;
        }

        #region IDisposable Members

        public void Dispose()
        {
            base.EventFiringEnabled = oldValue;
        }

        #endregion
    }
}
