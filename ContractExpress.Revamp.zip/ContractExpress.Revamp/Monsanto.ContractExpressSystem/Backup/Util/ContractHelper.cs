﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Web.UI;
using Microsoft.SharePoint;
using System.Collections.Specialized;

namespace Monsanto.ContractExpressSystem
{
	
	public static class ContractHelper
	{
        public static void UpdateContractApprovalStatus(SPListItem item)
        {
            string ApprovalMessage = "";

            SPWeb ieweb = item.Web;
            ECContext ctx = new ECContext(SPContext.GetContext(ieweb));

            bool contractApproved = ContractHelper.CheckContractApproved(item, ieweb, ctx, ref ApprovalMessage);

            using (SPSite site = item.Web.Site)
            {
                if (contractApproved)
                {
                    ApproveAndSendMail(item, ApprovalMessage, site, ieweb, ctx);
                }
                else
                { }
            }

        }

        public static void ApproveAndSendMail(SPListItem item, string ApprovalMessage,SPSite site, SPWeb ieweb,ECContext ctx)
        {
            //if (item.ModerationInformation.Status == SPModerationStatusType.Pending)
            //{
                string EmailText = "";
                //DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                //try
                //{
                //    disEvt.DisabledItemEvents();
                //    item.File.Approve(ApprovalMessage);
                //}
                //catch (Exception ex)
                //{
                //    int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                //}
                //finally
                //{
                //    disEvt.Dispose();
                //}

                try
                {
                    EmailText = CreateMail(item, ctx, site, "ApprovalNotificationTemplate");
                    //ECContext.SendMail(ieweb, string.Format("Express Contract {0} {1}", item.File.Title, ApprovalMessage), EmailText, new SPFieldUserValue(ieweb, Convert.ToString(item[ctx.Configuration.ECFields.BusinessUser])).User.Email);
                    //SPListItem division = ctx.Lists.MonsantoDivision.GetItemById(new SPFieldLookupValue(Convert.ToString(item[ctx.Configuration.ECFields.MonsantoDivision])).LookupId);
                    //ECContext.SendMail(ieweb, string.Format("Express Contract {0} {1}", item.File.Title, ApprovalMessage), EmailText, new SPFieldUserValue(ieweb, Convert.ToString(division["Notification"])).User.Email);
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);              
                    
                }
                
            //}
        }
        public static bool CheckContractApproved(SPListItem item, SPWeb ieweb,ECContext ctx, ref string ApprovalMessage)
        {
            bool FCPAApproved, DOAApproved, legalApproved, contractApproved;

            FCPAApproved = (Convert.ToString(item[ctx.Configuration.ECFields.FCPAApproval]) == "Approved");
            DOAApproved = (Convert.ToString(item[ctx.Configuration.ECFields.DoaApproval]) == "Approved");
            legalApproved = (Convert.ToString(item[ctx.Configuration.ECFields.LegalApproval]) == "Approved");

            contractApproved = (DOAApproved && legalApproved) &&
                (FCPAApproved || Convert.ToString(item[ctx.Configuration.ECFields.FCPA]) == "NOT FCPA RELEVANT");

            if (FCPAApproved && DOAApproved && legalApproved)
                ApprovalMessage = "Approved by DOA, Legal and by FCPA.";
            else if (!FCPAApproved && DOAApproved && legalApproved)
                ApprovalMessage = "Approved by DOA and Legal";


            return contractApproved;


        }

        public static bool CheckContractRejected(SPListItem item, SPWeb ieweb, ECContext ctx)
        {
            bool FCPARejected, DOARejected, legalRejected, contractRejected;

            FCPARejected = (Convert.ToString(item[ctx.Configuration.ECFields.FCPAApproval]) == "Rejected");
            DOARejected = (Convert.ToString(item[ctx.Configuration.ECFields.DoaApproval]) == "Rejected");
            legalRejected = (Convert.ToString(item[ctx.Configuration.ECFields.LegalApproval]) == "Rejected");

            contractRejected = FCPARejected || DOARejected || legalRejected;

            return contractRejected;
        }



        private static StringDictionary CreateHeader(string mail)
        {
            StringDictionary headers = new StringDictionary();
            headers.Add("bcc", mail);
            headers.Add("from", "ExpressContractSystem@monsanto.com");
            headers.Add("subject", "Express Contract approval");

            return headers;
        }
        private static StringDictionary CreateHeader(SPListItem item, string doa)
        {
            StringDictionary headers = new StringDictionary();
            SPGroup group = item.Web.Groups["Legal admin"];
            string bcc = doa;

            foreach (SPUser user in group.Users)
                if (!string.IsNullOrEmpty(user.Email))
                {
                    if (string.IsNullOrEmpty(bcc))
                        bcc = user.Email;
                    else
                        bcc += string.Concat(";", user.Email);
                }

            headers.Add("bcc", bcc);
            headers.Add("from", "ExpressContractSystem@monsanto.com");
            headers.Add("subject", "Express Contract approval");

            return headers;
        }
        public static string CreateChangeMail(SPListItem item, ECContext context, SPSite site, string user)
        {
            string siteUrl = context.CurrentWeb.Site.Url;
            string url = string.Concat(siteUrl, "/Style%20Library/Images/Mail/");

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\"><html><head><title>Monsanto Contract Express System</title><meta content=\"text/html; charset=utf-8\" http-equiv=\"Content-Type\" /></head><body marginheight=\"0\" topmargin=\"0\" marginwidth=\"0\" bgcolor=\"#c5c5c5\" leftmargin=\"0\"><table cellspacing=\"0\" border=\"0\" height=\"100%\" style=\"min-height:900px;background-image: url('images/bg.gif'); background-color: #fafafa;\" cellpadding=\"0\" width=\"100%\"><tr><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> </td></tr> <tr><td valign=\"top\"><table cellspacing=\"0\" border=\"0\" align=\"center\" cellpadding=\"0\" width=\"675\"><tr> <td valign=\"top\"> <table cellspacing=\"0\" border=\"0\" align=\"center\" cellpadding=\"0\" width=\"675\">  <tr> <td height=\"9\" valign=\"top\"> <img src=\"images/header-top.gif\" alt=\"\" style=\"display: block;\" /> </td> </tr> <tr> <td valign=\"top\"> <table cellspacing=\"0\" border=\"0\" cellpadding=\"0\" width=\"675\"> <tr> <td valign=\"top\" width=\"5\"> <img src=\"images/header-side.gif\" alt=\"\" style=\"display: block;\" /> </td> <td height=\"90\" valign=\"top\"> <table cellspacing=\"0\" border=\"0\" height=\"90\" cellpadding=\"0\" width=\"665\"> <tr> <td class=\"header-content\" height=\"90\" valign=\"top\" style=\"background-color: #bbcedd; background-image: url('images/header-content.gif');\"> <table cellspacing=\"0\" border=\"0\" height=\"90\" cellpadding=\"0\" width=\"665\"> <tr> ");
            sb.AppendLine("<td class=\"main-title\" align=\"right\" valign=\"middle\" width=\"545\" style=\"color: #4c545b; font-family: Georgia, serif; font-size: 41px; font-weight: bold; font-style: italic;\"> Contract Express System </td> <td valign=\"top\"> <img src=\"images/spacer.gif\" height=\"1\" alt=\"\" style=\"display: block;\" width=\"20\" /> </td> </tr> </table> </td> </tr> </table> </td> <td valign=\"top\" width=\"5\"> <img src=\"images/header-side.gif\" alt=\"\" style=\"display: block;\" /> </td> </tr> </table> </td> </tr>  <tr> <td height=\"35\" valign=\"top\"> <img src=\"images/header-bottom.png\" alt=\"\" style=\"display: block;\" /> </td> </tr>  </table> </td> </tr>  <tr> <td valign=\"top\"> <table cellspacing=\"0\" border=\"0\" align=\"center\" cellpadding=\"0\" width=\"670\">");

            sb.AppendFormat(" {0}{1} ", CreateSectionHead("Change made to Express Contract "), string.Format("<br />A change has been made to <a href='{0}' >{1}</a>, by {2}.</br></br> To navigate to the express system please follow <a href='{3}'> this</a> link. </br></br> ", string.Concat(siteUrl, "/", item.File.Url), item.File.Title, user, siteUrl));

            sb.AppendLine(" </table> </td> </tr> <tr>");
            sb.AppendLine("<td valign=\"top\"> <table cellspacing=\"0\" border=\"0\" cellpadding=\"0\" width=\"675\"> <tr> <td valign=\"top\"> </td> </tr> <tr> <td align=\"center\" class=\"footer\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <img src=\"images/double-line.gif\" alt=\"\" width=\"675\" style=\"display: block;\" /> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> </td> </tr> </table> </td> </tr>  </table> </td> </tr> </table> </body> </html>");
            return sb.ToString().Replace("images/", url);
        }
        private static string CreateMail(SPListItem item, ECContext context, SPSite site, string templateName)
        {
            string HTMLMail = string.Empty;

            ApprovalMailFields mailFields = new ApprovalMailFields();
            SPQuery Query;

            try
            {
                #region Create Signatures
                Dictionary<string, string> singatures = new Dictionary<string, string>();
                Query = new SPQuery() { Query = string.Format("<Where><Eq><FieldRef Name=\"Monsanto_x0020_entity\" /><Value Type=\"Lookup\">{0}</Value></Eq></Where>", new SPFieldLookupValue(Convert.ToString(item[context.Configuration.ECFields.MonsantoEntity])).LookupValue) };
                foreach (SPListItem listitem in context.Lists.Signatures.GetItems(Query))
                {
                    if (listitem["Contact"] != null)
                        singatures.Add(listitem.Title, new SPFieldUserValue(context.CurrentWeb, Convert.ToString(listitem["Contact"])).User.Email);
                }

                foreach (KeyValuePair<string, string> sign in singatures)
                    mailFields.SignaturesList = String.Concat(mailFields.SignaturesList, string.Format("<li><a href=\"mailto:{0}\">{1}</a></li>", sign.Value, sign.Key));
                #endregion

                mailFields.SiteURL = context.CurrentWeb.Site.Url;
                mailFields.Country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
                mailFields.FileURL = string.Concat(mailFields.SiteURL, "/", item.File.Url);
                mailFields.FileName = item.File.Title;


                string clonedFromId = Convert.ToString(item["Cloned from contract ID"]);

                if (!string.IsNullOrEmpty(clonedFromId))
                    mailFields.CloneContractSummaryUrl = string.Format("This contract was cloned from an existing one, <a href='" + site.RootWeb.Url + "/_layouts/ContractExpressSystem/ContractSummary.aspx?itemid={0}&clonedContractId={1}'>navigate to the summary page</a> to compare from base contract.", item.ID, clonedFromId);
                else
                    mailFields.CloneContractSummaryUrl = string.Format("The contract summary can be found in <a href='" + site.RootWeb.Url + "/_layouts/ContractExpressSystem/ContractSummary.aspx?itemid={0}'>here</a>.", item.ID);

                #region Get Template content from ContentLibrary
                using (SPWeb oweb = site.OpenWeb())
                {
                    SPList list = oweb.Lists["EmailTemplates"];
                    SPFile template = oweb.GetFile(string.Format("{0}/{1}.htm", list.RootFolder.Url, templateName));
                    if (template.Exists)
                    {
                        using (System.IO.StreamReader reader = new System.IO.StreamReader(template.OpenBinaryStream()))
                        {
                            HTMLMail = reader.ReadToEnd();
                        }
                    }
                    else
                    {
                        HTMLMail = "Contract approved";
                    }
                }
                #endregion
            }
            catch (Exception ecp)
            {
                HTMLMail = "ERROR: " + ecp.Message + "\n" + ecp.StackTrace;
            }
            HTMLMail = mailFields.Normalize(HTMLMail);

            return HTMLMail;
        }
        private static string CreateSectionHead(string section)
        {
            return string.Format("  <tr> <td valign=\"top\"> <img src=\"images/double-line.gif\" alt=\"\" style=\"display: block;\" /> </td> </tr> <tr><td class=\"article-title\" height=\"30\" valign=\"middle\" style=\"text-transform: uppercase; font-family: Georgia, serif; font-size: 16px; color: #2b2b2b; font-style: italic; border-bottom: 1px solid #c1c1c1;\"> {0} </td> </tr>", section);
        }
        private static string CreateContent(string message, Dictionary<string, string> signatures, string footermessage)
        {
            StringBuilder sb = new StringBuilder();
            foreach (KeyValuePair<string, string> item in signatures)
                sb.AppendFormat("<li><a href=\"mailto:{0}\">{1}</a></li>", item.Value, item.Key);

            return string.Format("<tr><td class=\"copy\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <p>{0}</p> <br /><ul>{1}</ul> <p>{2}</p></td> </tr>", message, sb.ToString(), footermessage);
        }

	}
}
