﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.IO;
using Microsoft.SharePoint.Utilities;
using System.Threading;

namespace Monsanto.ContractExpressSystem.CustomMenuItem
{
    public class CustomItemAction : SPLinkButton
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.Page.Request["__EVENTTARGET"] == "Monsanto.ContractExpressSystem.CustomMenuItem.ButtonClicked")
            {
                try
                {
                    int itemId = Convert.ToInt32(this.Page.Request["__EVENTARGUMENT"]);

                    if (Convert.ToInt32(itemId) != 0)
                        SPUtility.Redirect("ContractExpressSystem/UploadTemplate.aspx?tplid=" + itemId.ToString(), SPRedirectFlags.RelativeToLayoutsPage, System.Web.HttpContext.Current);
                }
                catch (ThreadAbortException)
                {
                    // Swallow bogus exception caused by redirect
                }
                
            }
        }
    }
}
