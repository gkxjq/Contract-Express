﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.SharePoint;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using Microsoft.SharePoint.Utilities;
using System.Data;
namespace Bayer.BCS.ContractExpressSystem
{
    class CESPUtil
    {
        /// <summary>
        /// Populate dropdown with results from SP list Query
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="list"></param>
        public static void BindDropdownList(DropDownList ddl, SPListItemCollection list)
        {
            try
            {
                DataTableReader dt = list.GetDataTable().CreateDataReader();
                ddl.DataSource = dt;
                ddl.DataValueField = list.List.Fields[SPBuiltInFieldId.ID].InternalName;
                ddl.DataTextField = list.List.Fields[SPBuiltInFieldId.Title].InternalName;
                ddl.DataBind();
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(String.Format("Error loading values for the list {0}: {1}", list.List.Title, ex.Message), ex, ECContext.TraceLevel.Unexpected);
                throw ex;
            }
        }

        /// <summary>
        /// Fill dropdown mapping with vlaues
        /// </summary>
        /// <param name="ddl"></param>
        public static void BindDropdownMapping(DropDownList ddl)
        {
            try
            {
                ddl.Items.Add(new ListItem("", ""));
                SPListItemCollection mappings = ECContext.Current.Lists.FieldMappings.GetItems();
                foreach (SPListItem mapping in mappings)
                {
                    ddl.Items.Add(new ListItem(mapping["MappingDescription"].ToString(), mapping["InternalField"].ToString()));
                    //field_mappings.Add(mapping["MappingDescription"].ToString(), () => GetEntityField(mapping["InternalField"].ToString()));
                }

                ddl.Items.Insert(1, new ListItem("Counterparty", "Counterparty"));


                //ddl.Items.Add(new ListItem("", ""));
                //ddl.Items.Add(new ListItem("Address", "Address"));
                //ddl.Items.Add(new ListItem("Capital Amount", "Capital_x0020_Amount"));
                //ddl.Items.Add(new ListItem("Counterparty", "Counterparty"));
                //ddl.Items.Add(new ListItem("Country", "Country"));
                //ddl.Items.Add(new ListItem("Entity Type", "Entity_x0020_Type"));
                //ddl.Items.Add(new ListItem("Function", "Function"));
                //ddl.Items.Add(new ListItem("Id Number", "Id_x0020_Number"));
                //ddl.Items.Add(new ListItem("Jurisdiction", "Jurisdiction"));
                //ddl.Items.Add(new ListItem("Monsanto Entity", "Monsanto_x0020_Entity"));
                //ddl.Items.Add(new ListItem("Monsanto Entity Country", "Country"));
                //ddl.Items.Add(new ListItem("Monsanto Entity Representative", "Monsanto_x0020_Entity_x0020_Representative"));
                //ddl.Items.Add(new ListItem("Monsanto Entity Representative Title", "Monsanto_x0020_Entity_x0020_Representative_x0020_Title"));
                //ddl.Items.Add(new ListItem("Registration #", "Registration_x0020_#"));
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error adding mapping values: " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                throw ex;
            }
        }

        public static string NormalizeFilename(string fileName)
        {
            StringBuilder sb = new StringBuilder();

            string name = Regex.Replace(fileName, "\\.\\.", ".")
                .TrimEnd('.');

            foreach (char c in name)
            {
                if (SPEncode.IsLegalCharInUrl(c))
                    sb.Append(c);
                else
                    sb.Append('_');
            }

            string sRet = sb.ToString().Replace("'", "_").Replace("“", "_").Replace("”", "_").Replace("“", "_");

            sb.Length = 0;
            SPList configList = ECContext.Current.CurrentWeb.Lists.TryGetList("Configuration");
            if (configList != null)
            {
                string sInvalidChars = GetByKey("InvalidChars", configList);
                string[] sChars = sInvalidChars.Split(',');
                foreach (string sChar in sChars)
                {
                    if (!string.IsNullOrEmpty(sChar))
                        sRet = sRet.Replace(sChar.Trim(), "_");
                }
            }

            return sRet;
        }

        /// <summary>
        /// Get list item value by key
        /// </summary>
        /// <param name="sKey">item key</param>
        /// <param name="list">SP list</param>
        /// <returns></returns>
        public static string GetByKey(string sKey, SPList list)
        {
            string sRet = "";
            SPQuery q = new SPQuery();
            q.Query = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">" + sKey + "</Value></Eq></Where>";
            SPListItemCollection itemCol = list.GetItems(q);
            if (itemCol.Count > 0)
            {
                sRet = Convert.ToString(itemCol[0]["Value"]);
            }
            return sRet;
        }

    }
}
