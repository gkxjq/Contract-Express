﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Web.UI;

namespace Bayer.BCS.ContractExpressSystem
{
	// Javascript-related utilities
	public static class CEJSUtil
	{
		public static string ToJsString(this string s)
		{
			return EncodeJsString(s, false);
		}

		public static string EncodeJsString(string s)
		{
			return EncodeJsString(s, false);
		}

		public static string EncodeJsString(string s, bool quoted)
		{
			StringBuilder sb = new StringBuilder();
			if (quoted)
				sb.Append("\"");
			foreach (char c in s)
			{
				switch (c)
				{
					case '\'':
						sb.Append("\\\'");
						break;
					case '\"':
						sb.Append("\\\"");
						break;
					case '\\':
						sb.Append("\\\\");
						break;
					case '\b':
						sb.Append("\\b");
						break;
					case '\f':
						sb.Append("\\f");
						break;
					case '\n':
						sb.Append("\\n");
						break;
					case '\r':
						sb.Append("\\r");
						break;
					case '\t':
						sb.Append("\\t");
						break;
					default:
						int i = (int)c;
						if (i < 32 || i > 127)
						{
							sb.AppendFormat("\\u{0:X04}", i);
						}
						else
						{
							sb.Append(c);
						}
						break;
				}
			}
			if (quoted)
				sb.Append("\"");

			return sb.ToString();
		}

		public static void PopError(Page p, string title, string msg)
		{
			string js_chunk = String.Format("function fncFoo() {{ ceErrorDialog('{0}', '<div style=\"padding:5px\">{1}</div>'); }} SP.SOD.executeFunc('sp.js', 'SP.ClientContext', fncFoo);", EncodeJsString(title), EncodeJsString(msg));

			p.ClientScript.RegisterClientScriptBlock(p.GetType(), Guid.NewGuid().ToString(), js_chunk, true);
		}

        public static void PopInfo(Page p, string title, string msg)
        {
            string js_chunk = String.Format("function fncFoo() {{ ceInfoDialog('{0}', '<div style=\"padding:5px\">{1}</div>'); }} SP.SOD.executeFunc('sp.js', 'SP.ClientContext', fncFoo);", EncodeJsString(title), EncodeJsString(msg));

            p.ClientScript.RegisterClientScriptBlock(p.GetType(), Guid.NewGuid().ToString(), js_chunk, true);
        }

        public static void PopInfoWithRedirect(Page p, string title, string msg, string href)
        {
            string js_chunk = String.Format("function fncFoo() {{ ceInfoDialogRedirect('{0}', '<div style=\"padding:5px\">{1}</div>', '{2}'); }} SP.SOD.executeFunc('sp.js', 'SP.ClientContext', fncFoo);", EncodeJsString(title), EncodeJsString(msg), EncodeJsString(href));

            p.ClientScript.RegisterClientScriptBlock(p.GetType(), Guid.NewGuid().ToString(), js_chunk, true);
        }

		public static void AddJSBlock(Page p, string chunk)
		{
			p.ClientScript.RegisterClientScriptBlock(p.GetType(), Guid.NewGuid().ToString(), EncodeJsString(chunk), true);            
		}

        public static void AddJSBlockAsync(Page p, string chunk)
        {
            ScriptManager.RegisterStartupScript (p, p.GetType(), Guid.NewGuid().ToString(), chunk, true);
        }

        public static void TimedRedirect(Page p, string href, int milliseconds)
        {
			//string js_chunk = String.Format("function fncFoo() {{ setInterval(function(){{location.href='{0}';}},{1}); }} ExecuteOrDelayUntilScriptLoaded(fncFoo, 'sp.js');", EncodeJsString(href), milliseconds.ToString());
			string js_chunk = String.Format("function fncFoo() {{ setInterval(function(){{location.href='{0}';}},{1}); }} SP.SOD.executeFunc('sp.js', 'SP.ClientContext', fncFoo);", EncodeJsString(href), milliseconds.ToString()); 

			p.ClientScript.RegisterClientScriptBlock(p.GetType(), Guid.NewGuid().ToString(), js_chunk, true);
        }

        
	}
}
