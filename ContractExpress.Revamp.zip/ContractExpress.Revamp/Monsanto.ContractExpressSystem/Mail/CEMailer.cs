﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.SharePoint;

namespace Bayer.BCS.ContractExpressSystem
{
    public class CEMailSymbol
    {
        public static readonly string User = "USER";
        public static readonly string RootUrl = "CE_ROOT_URL";
        public static readonly string ContractTitle = "CONTRACT_TITLE";
        public static readonly string ContractUrl = "CONTRACT_URL";
        public static readonly string ApprovalFormUrl = "APPROVAL_FORM_URL";
        public static readonly string Country = "COUNTRY";
        public static readonly string Entity = "ENTITY";
        public static readonly string Function = "FUNCTION";
        public static readonly string MailTitle = "MAIL_TITLE";
        public static readonly string TemplateQuestions = "TEMPLATE_QUESTIONS";
        public static readonly string ApprovalAnswers = "APPROVAL_ANSWERS";

        //REJECTION MAIL SYMBOLS
        public static readonly string Reject_ContractURL = "[#CONTRACTURL#]";
        public static readonly string Reject_ContractTitle = "[#CONTRACTTITLE#]";
        public static readonly string Reject_RejectedBy = "[#REJECTEDBY#]";
        public static readonly string Reject_ChangeContractURL = "[#CHANGECONTRACTURL#]";
        public static readonly string Reject_DocumentContent = "[#DOCUMENTCONTENT#]";
        public static readonly string Reject_Answers = "[#ANSWERS#]";
        public static readonly string Reject_RejectionsReasons = "[#REJECTIONREASON#]";
        public static readonly string Reject_RejectionHeader = "[#HEADER#]";

        //PENDING MAIL SYMBOLS
        public static readonly string Pending_Header = "[#HEADER#]";
        public static readonly string Pending_Contract_URL = "[#CONTRACTURL#]";
        public static readonly string Pending_Contract_Title = "[#CONTRACTTITLE#]";
        public static readonly string Pending_Approval_State = "[#APPROVALSTATE#]";
        public static readonly string Pending_Approval_Team = "[#APPROVALTEAM#]";
        public static readonly string Pending_Reasons = "[#PENDINGREASONS#]";
        public static readonly string Pending_Approval_Questions_URL = "[#APPROVALQUESTIONSURL#]";

        //REQUEST APPROVAL SYMBOLS
        public static readonly string requestApproval_Header = "[#HEADER#]";
        public static readonly string requestApproval_BU = "[#BUSINESSUSER#]";
        public static readonly string requestApproval_ContractURL = "[#CONTRACTURL#]";
        public static readonly string requestApproval_ContractTitle = "[#CONTRACTTITLE#]";
        public static readonly string requestApproval_ApprovalURL = "[#APPROVALURL#]";
        public static readonly string requestApproval_SiteURL = "[#SITEURL#]";
        public static readonly string requestApproval_Country = "[#COUNTRY#]";
        public static readonly string requestApproval_Entity = "[#ENTITY#]";
        public static readonly string requestApproval_ApprovalQuestions = "[#APPROVALQUESTIONS#]";
        public static readonly string requestApproval_FCPAQuestions = "[#FCPAQUESTIONS#]";

        //CHANGE CONTRACT SYMBOLS
        public static readonly string changeContract_ContractURL = "[#CONTRACTURL#]";
        public static readonly string changeContract_ContractTItle = "[#CONTRACTTITLE#]";
        public static readonly string changeContract_ModifiedBy = "[#MODIFIEDBY#]";
        public static readonly string changeContract_SiteURL = "[#SITEURL#]";
        public static readonly string changeContract_Header = "[#HEADER#]";

        //MAIL FOR APPROVAL SYMBOLS
        public static readonly string mailforApproval_Header = "[#HEADER#]";
        public static readonly string mailforApproval_BU = "[#BUSINESSUSER#]";
        public static readonly string mailforApproval_Action = "[#ACTION#]";
        public static readonly string mailforApproval_ContractURL = "[#CONTRACTURL#]";
        public static readonly string mailforApproval_ContractTitle = "[#CONTRACTTITLE#]";
        public static readonly string mailforApproval_ApprovalURL = "[#APPROVALURL#]";
        public static readonly string mailforApproval_SiteURL = "[#SITEURL#]";
        public static readonly string mailforApproval_Country = "[#COUNTRY#]";
        public static readonly string mailforApproval_Entity = "[#ENTITY#]";
        public static readonly string mailforApproval_FCPAQuestionsTitle = "[#FCPAQUESTIONSTITLE#]";
        public static readonly string mailforApproval_FCPAQuestions = "[#FCPAQUESTIONS#]";

        //MAIL FOR CLONE SYMBOLS
        public static readonly string mailforClone_BU = "[#BUSINESSUSER#]";
        public static readonly string mailforClone_ContractURL = "[#CONTRACTURL#]";
        public static readonly string mailforClone_ContractTitle = "[#CONTRACTTITLE#]";
        public static readonly string mailforClone_ApprovalURL = "[#APPROVALURL#]";
        public static readonly string mailforClone_SiteURL = "[#SITEURL#]";
        public static readonly string mailforClone_Country = "[#COUNTRY#]";
        public static readonly string mailforClone_Entity = "[#ENTITY#]";
        public static readonly string mailforClone_AutomaticApproval = "[#AUTOMATICAPPROVAL#]";
        public static readonly string mailforClone_CloneDate = "[#CLONEDATE#]";
        public static readonly string mailforClone_CloneExpirationDate = "[#CLONEEXPIRATIONDATE#]";

        //NEW SYMBOLS FOR EMAILS
        public static readonly string genericFileName = "##FILENAME##";
        public static readonly string genericFileURL = "##FILEURL##";
        public static readonly string genericBU = "##BUSINESSUSER##";
        public static readonly string genericApprovalFormLink = "##APPROVALFORMLINK##";
        public static readonly string siteURL = "##SITEURL##";

    }

    public class CETemplateMails
    {
        public static readonly string BasicEmailTemplate = "BasicEmailTemplate";
        public static readonly string BookmarksErrorRejectionEmailTemplate = "BookmarksErrorRejectionEmailTemplate";
        public static readonly string BookmarksnQuestionsErrorRejectionEmailTemplate = "BookmarksnQuestionsErrorRejectionEmailTemplate";
        public static readonly string FCPARejectionEmailTemplate = "FCPARejectionEmailTemplate";
        public static readonly string GenericRejectionEmailTemplate = "GenericRejectionEmailTemplate";
        public static readonly string QuestionsErrorRejectionEmailTemplate = "QuestionsErrorRejectionEmailTemplate";
        public static readonly string PendingEmailTemplate = "PendingEmailTemplate";
        public static readonly string RequestApprovalEmailTemplate = "RequestApprovalEmailTemplate";
        public static readonly string ChangeContractEmailTemplate = "ChangeContractEmailTemplate";
        public static readonly string MailForApprovalEmailTemplate = "MailForApprovalEmailTemplate";
        public static readonly string CloningActivatedEmailTemplate = "CloningActivatedEmailTemplate";
    }

    public class CEEmail
    {
        public List<string> TOAddresses { get; set; }
        public List<string> CCAddresses { get; set; }
        public List<string> BCCAddresses { get; set; }
        public String Subject { get; set; }
        public String EmailBody { get; set; }
        public bool notifyBU { get; set; }
    }

    public class CEMailer
    {

        private static Regex rx_variable = new Regex(@"\$\((?<SYMBOL>[a-zA-Z0-9\-_\.]*)\)", RegexOptions.Compiled);

        public Dictionary<string, string> Replacements { get; set; }


        public static Dictionary<string, string>
        NewContext()
        {
            var dict = new Dictionary<string, string>();

            dict.Add(CEMailSymbol.RootUrl.ToString(), SPContext.Current.Web.Url);

            return dict;
        }


        public bool Send(SPWeb web, List<string> to, List<string> cc, string template, Dictionary<string, string> values)
        {
            try
            {
                string tpl = LoadTemplate(web, template);
                string body = ReplaceSymbols(tpl, values);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string ReplaceSymbols(string tplText, Dictionary<string, string> values)
        {
            var matches = rx_variable.Matches(tplText);

            foreach (Match match in matches)
            {
                string repl;
                var sym = match.Groups["SYMBOL"].Value;

                if (values.TryGetValue(sym, out repl))
                    tplText = tplText.Replace(match.Value, repl);
            }

            return tplText;
        }

        public CEEmail GetEmailMessageFromTemplate(SPWeb web, string TemplateName, Dictionary<string, string> ValuesToReplace)
        {
            CEEmail BodyMessage = new CEEmail();
            try
            {
                BodyMessage.EmailBody = LoadTemplate(web, TemplateName);
                SPList list = web.Lists["EmailTemplates"];
                SPFile tplFile = web.GetFile(string.Format("{0}/{1}.htm", list.RootFolder.Url, TemplateName));

                if (tplFile.Item != null)
                {
                    BodyMessage.TOAddresses = GetListEmailsFromLookUP(web, tplFile.Item["To"] != null ? tplFile.Item["To"].ToString() : "");
                    BodyMessage.CCAddresses = GetListEmailsFromLookUP(web, tplFile.Item["CC"] != null ? tplFile.Item["CC"].ToString() : "");
                    BodyMessage.BCCAddresses = GetListEmailsFromLookUP(web, tplFile.Item["BCC"] != null ? tplFile.Item["BCC"].ToString() : "");
                    BodyMessage.Subject = tplFile.Item["Subject"] != null ? tplFile.Item["Subject"].ToString() : "";
                    BodyMessage.notifyBU = tplFile.Item["NotifyBU"] != null ? Boolean.Parse(tplFile.Item["NotifyBU"].ToString()) : false;

                    BodyMessage.EmailBody = ReplaceTAGS(BodyMessage.EmailBody, ValuesToReplace);
                    BodyMessage.Subject = ReplaceTAGS(BodyMessage.Subject, ValuesToReplace);
                
                }

                //string sQuery = String.Format(@"<Where><Contains><FieldRef Name=""FileLeafRef""/><Value Type=""Text"">{0}</Value></Contains></Where>", TemplateName);
                //string sViewFields = @"<FieldRef Name=""FileLeafRef"" /><FieldRef Name=""To"" /><FieldRef Name=""CC"" /><FieldRef Name=""BCC"" /><FieldRef Name=""Subject"" />";
                //string sViewAttrs = @"Scope=""Recursive""";
                //uint iRowLimit = 0;

                //SPQuery oQuery = new SPQuery();
                //oQuery.Query = sQuery;
                //oQuery.ViewFields = sViewFields;
                //oQuery.ViewAttributes = sViewAttrs;
                //oQuery.RowLimit = iRowLimit;

                //SPList list = web.Lists["EmailTemplates"];
                //SPListItemCollection emails = list.GetItems(oQuery);

                //if (emails != null &&
                //    emails.Count == 1)
                //{
                //    BodyMessage.TOAddresses = GetListEmailsFromLookUP(web, emails[0]["To"] != null ? emails[0]["To"].ToString() : "");
                //    BodyMessage.CCAddresses = GetListEmailsFromLookUP(web, emails[0]["CC"] != null ? emails[0]["CC"].ToString() : "");
                //    BodyMessage.BCCAddresses = GetListEmailsFromLookUP(web, emails[0]["BCC"] != null ? emails[0]["BCC"].ToString() : "");
                //    BodyMessage.Subject = emails[0]["Subject"] != null ? emails[0]["Subject"].ToString() : "";

                //    BodyMessage.EmailBody = ReplaceTAGS(BodyMessage.EmailBody, ValuesToReplace);
                //    BodyMessage.Subject = ReplaceTAGS(BodyMessage.Subject, ValuesToReplace);
                //}
            }
            catch (Exception ecp)
            {

                throw ecp;
            }
            return BodyMessage;

        }

        private string ReplaceTAGS(string originalText, Dictionary<string, string> ValuesToReplace)
        {

            foreach (KeyValuePair<string, string> replaceString in ValuesToReplace)
            {
                originalText = originalText.Replace(replaceString.Key, replaceString.Value);
            }
            return originalText;
        }

        private List<string> GetListEmailsFromLookUP(SPWeb oweb, string EmailLookupValue)
        {
            List<string> emailList = new List<string>();
            if (!String.IsNullOrEmpty(EmailLookupValue))
            {
                SPFieldUserValueCollection emailsAddresses = new SPFieldUserValueCollection(oweb, EmailLookupValue);
                foreach (SPFieldUserValue lookupValue in emailsAddresses)
                {
                    emailList.Add(lookupValue.User.Email);
                }
            }
            return emailList;
        }

        private string LoadTemplate(SPWeb web, string tplName)
        {
            try
            {
                SPList list = web.Lists["EmailTemplates"];
                SPFile tplFile = web.GetFile(string.Format("{0}/{1}.htm", list.RootFolder.Url, tplName));


                if (!tplFile.Exists)
                    throw new ArgumentException(String.Format("Template {0} not found", tplName));

                using (StreamReader sr = new StreamReader(tplFile.OpenBinaryStream()))
                {
                    return sr.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool SendGenericMail(ECContext ctx, SPWeb web, SPListItem item, string TemplateName, string type, string TO, string CC, string BCC)
        {
            bool returnValue = false;
            try
            {
                CETemplateMails mailTemplates = new CETemplateMails();
                CEMailer mailSystem = new CEMailer();
                Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
                string selectedEmailTemplate = "";

                string url = string.Concat(web.Site.Url, "/Style%20Library/Images/Mail/");
                string siteUrl = web.Site.Url;
                string sApprovalUrl = string.Format("{0}/_layouts/15/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", SPContext.Current.Site.Url, item.ID.ToString(), type);

                valuesToReplace.Add(CEMailSymbol.siteURL, web.Site.Url);
                valuesToReplace.Add(CEMailSymbol.genericFileURL, string.Concat(web.Site.Url, "/", item.File.Url));
                valuesToReplace.Add(CEMailSymbol.genericFileName, item.File.Title);
                valuesToReplace.Add(CEMailSymbol.genericApprovalFormLink, sApprovalUrl);
                valuesToReplace.Add(CEMailSymbol.genericBU, new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Name);

                selectedEmailTemplate = TemplateName;

                CEEmail email = mailSystem.GetEmailMessageFromTemplate(ECContext.Current.CurrentWeb, selectedEmailTemplate, valuesToReplace);

                var businessUser = item[ECContext.Current.Configuration.ECFields.BusinessUser];
                email.EmailBody = email.EmailBody.Replace("images/", url);

                if (email.TOAddresses == null) email.TOAddresses = new List<string>();
                if (email.CCAddresses == null) email.CCAddresses = new List<string>();
                if (email.BCCAddresses == null) email.BCCAddresses = new List<string>();

                if (!String.IsNullOrEmpty(TO)) email.TOAddresses.Add(TO);
                if (!String.IsNullOrEmpty(CC)) email.CCAddresses.Add(CC);
                if (!String.IsNullOrEmpty(BCC)) email.BCCAddresses.Add(BCC);

                if (businessUser != null && email.notifyBU)
                {
                    email.TOAddresses.Add(new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Email);
                    
                }
                ECContext.SendMail(SPContext.Current.Web, email.Subject, email.EmailBody, true, "ExpressContractSystem@bayer.com", email.TOAddresses, email.CCAddresses, email.BCCAddresses);
                
            }
            catch (Exception ecp)
            {
                ECContext.LogEvent(ecp.Message, ecp, ECContext.TraceLevel.Unexpected);
                throw ecp;
            }
            return returnValue;
        }

        private void
        SmtpSend()
        {
        }
    }
}
