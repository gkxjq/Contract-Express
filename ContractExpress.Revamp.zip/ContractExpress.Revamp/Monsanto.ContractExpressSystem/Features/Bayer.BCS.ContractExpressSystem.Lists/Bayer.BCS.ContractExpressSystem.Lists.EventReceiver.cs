using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Bayer.BCS.ContractExpressSsytem.HtmlToOpenXml;
using Microsoft.SharePoint.Administration;

namespace Bayer.BCS.ContractExpressSystem.Features.Bayer.BCS.ContractExpressSystem.Lists
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("0e3e5330-9174-4841-b84f-4918a1091ec6")]
    public class MonsantoContractExpressSystemEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        //public override void FeatureActivated(SPFeatureReceiverProperties properties)
        //{
        //    SPWeb oWeb = properties.Feature.Parent as SPWeb;
        //    SetContractTemplateList(oWeb);
        //    NewContractExpressAttachments(oWeb);
        //    SetBookmarkList(oWeb);
        //    SetupContractArchiveList(oWeb);
        //    SetQuestionListNewForm(oWeb);
        //    SetupConfigList(oWeb);
        //    SetContractExpressList(oWeb);
        //}

        
        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}

        private string GetRelativeUrl(string serverRelativeUrl)
        {
            // Calculate relative path to site from Web Application root.
            string webAppRelativePath = serverRelativeUrl;
            if (!webAppRelativePath.EndsWith("/"))
            {
                webAppRelativePath += "/";
            }

            return webAppRelativePath;
        }

        private void SetBookmarkList(SPWeb oWeb)
        {
            try
            {
                //0.Get Bookmark list
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    SPList oList = oWeb.Lists["Bookmark"];

                    //1.Allow Template field to allow multiple values
                    SPFieldLookup field = (SPFieldLookup)oList.Fields.GetField("Template");

                    if (field.AllowMultipleValues == false)
                    {
                        field.AllowMultipleValues = true;
                        field.Update();
                    }

                    //2. Delete Template grouping from Bookmark list views
                    SPViewCollection colViews = oList.Views;

                    for (int i = 0; i < colViews.Count; i++)
                    {
                        SPView view = colViews[i];
                        if (view.Query.Contains("<GroupBy "))
                        {
                            int iStart = view.Query.IndexOf("<GroupBy");
                            int iEnd = view.Query.IndexOf("</GroupBy>");
                            string sGroupBy = view.Query.Substring(iStart, (iEnd + 10 - iStart));
                            if (view.Query.Contains("<FieldRef Name=\"Template\" />"))
                            {
                                view.Query = view.Query.Replace(sGroupBy, "");
                                view.Update();
                            }
                        }
                    }
                    
                    //foreach (SPView view in colViews)
                    //{
                    //    if (view.Query.Contains("<GroupBy "))
                    //    {
                    //        int iStart = view.Query.IndexOf("<GroupBy");
                    //        int iEnd = view.Query.IndexOf("</GroupBy>");
                    //        string sGroupBy = view.Query.Substring(iStart, (iEnd + 10 - iStart));
                    //        if (view.Query.Contains("<FieldRef Name=\"Template\" />"))
                    //        {
                    //            view.Query = view.Query.Replace(sGroupBy, "");
                    //            view.Update();
                    //        }
                    //    }
                    //}

                    //3. Add new field 'Long description'
                    if (!oList.Fields.ContainsField("Long Description"))
                    {
                        SPFieldText oField = (SPFieldText)oList.Fields.CreateNewField(SPFieldType.Text.ToString(), "Long Description");
                        oField.MaxLength = 255;
                        oList.Fields.Add(oField);
                        oList.Update();
                    }
                });

            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }


        }

        private void SetContractExpressList(SPWeb oWeb)
        {
            try
            {
                if (oWeb != null)
                {
                    SPList contractExpress = oWeb.Lists["Express Contracts"]; //"Express Contracts" list

                    if (!contractExpress.Fields.ContainsField("Sap Vendor Number"))
                        contractExpress.Fields.Add("Sap Vendor Number", SPFieldType.Text, false);

                    if (!contractExpress.Fields.ContainsField("Cloned from contract ID"))
                        contractExpress.Fields.Add("Cloned from contract ID", SPFieldType.Number, false);

                    SPFieldChoice legalApprover = (SPFieldChoice)contractExpress.Fields["Legal Approval"];
                    if (!legalApprover.Choices.Contains("Pending Business"))
                    {
                        legalApprover.Choices.Add("Pending Business");
                        legalApprover.DefaultValue = "Pending Business";
                        legalApprover.Update();
                    }

                    if (!contractExpress.Fields.ContainsField("Documents Attached"))
                    {
                        contractExpress.Fields.AddLookup("Documents Attached", oWeb.Lists.TryGetList("Express contracts Attachments").ID, false);
                        SPFieldLookup attachments = (SPFieldLookup)contractExpress.Fields.GetField("Documents Attached");
                        attachments.AllowMultipleValues = true;
                        attachments.LookupField = "Title";
                        attachments.Update(); 
                    }

                    if (!contractExpress.Fields.ContainsField("CounterParty"))
                    {
                        contractExpress.Fields.Add("CounterParty", SPFieldType.Text, true);
                        contractExpress.Update();
                    }

                    //Delete Negotiation Position fields
                    if (contractExpress.Fields.ContainsField("Negotiation Position"))
                    {
                        contractExpress.Fields.Delete("Negotiation Position");
                    }

                    //Create view for My Contracts webpart
                    bool bExists = false;
                    foreach (SPView view in contractExpress.Views)
                    {
                        if (view.Title.ToLowerInvariant() == "my contracts wp")
                            bExists = true;
                    }
                    if (!bExists)
                    {
                        StringCollection strCol = new StringCollection();
                        strCol.Add("ID");
                        strCol.Add("Type");
                        strCol.Add("Name");
                        strCol.Add("Monsanto Entity");
                        strCol.Add("Legal Approval");
                        strCol.Add("Doa Approval");
                        strCol.Add("FCPA Approval");
                        strCol.Add("Documents Attached");
                        strCol.Add("Cloned from contract ID");
                        strCol.Add("Function");
                        strCol.Add("Approval Status");

                        string sQuery = "<Where><Eq><FieldRef Name=\"Author\"/><Value Type=\"Integer\"><UserID/></Value></Eq></Where>";
                        contractExpress.Views.Add("My Contracts WP", strCol, sQuery , 30, true, true);
                    }

                    contractExpress.Update();
                }
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }


        }

        private void NewContractExpressAttachments(SPWeb oWeb)
        {
            try
            {
                if (oWeb != null)
                {
                    SPList attachments = oWeb.Lists.TryGetList("Express contracts Attachments");
                    if (attachments == null)
                    {
                        oWeb.Lists.Add("Express contracts Attachments", "Attachments for Express contracts", SPListTemplateType.DocumentLibrary);
                        attachments = oWeb.Lists.TryGetList("Express contracts Attachments");
                        SPField title = attachments.Fields.GetField("Title");
                        title.Required = true;
                        title.ShowInEditForm = true;
                        title.Update();
                        attachments.Update();
                    }
                }
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }

        private void SetQuestionListNewForm(SPWeb oWeb)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    try
                    {
                        oWeb.AllowUnsafeUpdates = true;
                        SPList oList = oWeb.Lists["Questions"];

                        SPContentType ct = oList.ContentTypes["Item"];

                        ct.EditFormUrl = "_layouts/15/ContractExpressSystem/NewQuestionForm.aspx";
                        
                        ct.NewFormUrl = "_layouts/15/ContractExpressSystem/NewQuestionForm.aspx";
                        //oList.DefaultNewFormUrl = "_layouts/15/ContractExpressSystem/NewQuestionForm.aspx";

                        //ct.DisplayFormUrl = "Lists/Questions/DispForm.aspx";
                        
                        ct.Update();
                        oList.Update();
                        oWeb.Update();

                        oWeb.AllowUnsafeUpdates = false;
                        
                    }
                    catch (Exception ex)
                    {
                        ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    }
                });
        }

        private void SetContractTemplateList(SPWeb web)
        {
            try
            {
                if (web != null)
                {
                    SPList contractTemplate = web.Lists["Contract Template"]; //"Contract template" library
                    SPView lngView = contractTemplate.DefaultView;

                    if (contractTemplate != null)
                    {
                        if (!contractTemplate.Fields.ContainsField("Second Language"))
                        {
                            contractTemplate.Fields.AddLookup("Second Language", web.Lists.TryGetList("Language").ID, false);
                            var spfld = (SPFieldLookup)contractTemplate.Fields.GetField("Second Language");
                            spfld.LookupField = web.Lists.TryGetList("Language").Fields["Title"].InternalName;
                            spfld.Required = false;
                            lngView.ViewFields.Add("Second Language");
                            spfld.Update();
                        }

                        if (!contractTemplate.Fields.ContainsField("Document Type"))
                        {
                            contractTemplate.Fields.AddLookup("Document Type", web.Lists.TryGetList("Document Type").ID, true);
                            var spfld = (SPFieldLookup)contractTemplate.Fields.GetField("Document Type");
                            spfld.LookupField = web.Lists.TryGetList("Document Type").Fields["Title"].InternalName;
                            spfld.AllowMultipleValues = true;
                            spfld.Required = true;
                            lngView.ViewFields.Add("Document Type");
                            spfld.Update();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }


        //DLH - 19/11/2014
        /// <summary>
        /// Check if exist a SPView in a SPList
        /// </summary>
        /// <param name="list">List of the view</param>
        /// <param name="viewName">View name to check if exist</param>
        /// <returns>boolean true if exist, false if not exist</returns>
        private static bool ViewExists(SPList list, string viewName)
        {
            try
            {
                SPView view = list.Views[viewName];
            }
            catch
            {
                return false;
            }
            return true;
        }

        private void SetupContractArchiveList(SPWeb web)
        {
            web.AllowUnsafeUpdates = true;
            SPList ecList = web.Lists.TryGetList("Express contracts");

            SPList archList = EnsureList(web, "Archived Contracts", "Archived Express Contracts", SPListTemplateType.DocumentLibrary);
            SPView archView = archList.DefaultView;

            //Check if exist search view - DLH - 19/11/2014
            if (!ViewExists(archList,"SearchView"))
            {
                //If not exist, clone the default view of Archived Contracts to use in ContractSearch Webpart  - DLH - 19/11/2014
                SPView searchView = archView.Clone("SearchView", archView.RowLimit, true, false);
                searchView.Scope = SPViewScope.Recursive;
                searchView.Update();
            }

            if (web.Lists.TryGetList("Archived contract types") == null)
            {
                web.Lists.Add("Archived contract types", "Archived contract types", SPListTemplateType.GenericList);
                AddItemsContractTypes(web.Lists.TryGetList("Archived contract types"));
            }            

            //if (web.Lists.TryGetList("Product Types") == null)
            //{
            //    web.Lists.Add("Product Types", "Product Types", SPListTemplateType.GenericList);
            //}

            if (web.Lists.TryGetList("Archived Monsanto Entity") == null)
            {
                web.Lists.Add("Archived Monsanto Entity", "Archived Monsanto Entity", SPListTemplateType.GenericList);
                AddItemsMonsantoEntity(web.Lists.TryGetList("Archived Monsanto Entity"));
            }
            
            // Reference Number
            if (!archList.Fields.ContainsField("Reference Number"))
            {
                archList.Fields.Add("Reference Number", SPFieldType.Number, true);
                var spfld = archList.Fields.GetField("Reference Number");
                spfld.Required = false;
                spfld.Update();
                archView.ViewFields.Add("Reference Number");
            }

            if (!archList.Fields.ContainsField("Agreement Name"))
            {
                archList.Fields.Add("Agreement Name", SPFieldType.Text, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Agreement Name");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("Agreement Name");
            }

            if (!archList.Fields.ContainsField("Document Type"))
            {
                archList.Fields.AddLookup("Document Type", web.Lists.TryGetList("Archived contract types").ID, true);
                var spfld = (SPFieldLookup)archList.Fields.GetField("Document Type");
                spfld.Required = true;
                spfld.LookupField = web.Lists.TryGetList("Archived contract types").Fields["Title"].InternalName;
                spfld.Update();
                archView.ViewFields.Add("Document Type");
            }

            if (!archList.Fields.ContainsField("Monsanto Division"))
            {
                archList.Fields.AddLookup("Monsanto Division", web.Lists.TryGetList("Monsanto Division").ID, true);
                var spfld = (SPFieldLookup)archList.Fields.GetField("Monsanto Division");
                spfld.Required = true;
                spfld.LookupField = web.Lists.TryGetList("Monsanto Division").Fields["Title"].InternalName;
                spfld.Update();
                archView.ViewFields.Add("Monsanto Division");
            }

            if (!archList.Fields.ContainsField("Key words"))
            {
                archList.Fields.Add("Key words", SPFieldType.Text, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Key words");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("Key words");
            }

            if (!archList.Fields.ContainsField("Effective Date"))
            {
                archList.Fields.Add("Effective Date", SPFieldType.DateTime, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Effective Date");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("Effective Date");
            }

            if (!archList.Fields.ContainsField("End of contract"))
            {
                archList.Fields.Add("End of contract", SPFieldType.DateTime, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("End of contract");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("End of contract");
            }

            if (!archList.Fields.ContainsField("Signature Date"))
            {
                archList.Fields.Add("Signature Date", SPFieldType.DateTime, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Signature Date");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("Signature Date");
            }

            if (!archList.Fields.ContainsField("FCPA"))
            {
                archList.Fields.Add("FCPA", SPFieldType.Boolean, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("FCPA");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("FCPA");
            }

            if (!archList.Fields.ContainsField("FCPA Action Date"))
            {
                archList.Fields.Add("FCPA Action Date", SPFieldType.DateTime, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("FCPA Action Date");
                spfld.Required = false;
                spfld.Update();
                archView.ViewFields.Add("FCPA Action Date");
            }

            if (!archList.Fields.ContainsField("Comments"))
            {
                archList.Fields.Add("Comments", SPFieldType.Note, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Comments");
                spfld.Required = false;
                spfld.Update();
                archView.ViewFields.Add("Comments");
            }

            if (!archList.Fields.ContainsField("Monsanto Entity"))
            {
                archList.Fields.AddLookup("Monsanto Entity", web.Lists.TryGetList("Archived Monsanto Entity").ID, true);
                var spfld = (SPFieldLookup)archList.Fields.GetField("Monsanto Entity");
                spfld.Required = true;
                spfld.LookupField = web.Lists.TryGetList("Archived Monsanto Entity").Fields["Title"].InternalName;
                spfld.Update();
                archView.ViewFields.Add("Monsanto Entity");
            }

            if (!archList.Fields.ContainsField("Counterparty"))
            {
                archList.Fields.Add("Counterparty", SPFieldType.Text, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Counterparty");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("Counterparty");
            }

            if (!archList.Fields.ContainsField("Function"))
            {
                archList.Fields.AddLookup("Function", web.Lists.TryGetList("Functions").ID, true);
                var spfld = (SPFieldLookup)archList.Fields.GetField("Function");
                spfld.Required = true;
                spfld.LookupField = web.Lists.TryGetList("Functions").Fields["Title"].InternalName;
                spfld.Update();
                archView.ViewFields.Add("Function");
            }

            if (!archList.Fields.ContainsField("Business user"))
            {
                archList.Fields.Add("Business user", SPFieldType.User, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Business user");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("Business user");
            }

            if (!archList.Fields.ContainsField("DOA Approver"))
            {
                archList.Fields.Add("DOA Approver", SPFieldType.User, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("DOA Approver");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("DOA Approver");
            }

            if (!archList.Fields.ContainsField("Contract Vault Reference"))
            {
                archList.Fields.Add("Contract Vault Reference", SPFieldType.Text, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Contract Vault Reference");
                spfld.Required = false;
                spfld.Update();
                //archView.ViewFields.Add("Contract Vault Reference");
            }

            if (!archList.Fields.ContainsField("Contract Vault Reference Bar Code"))
            {
                archList.Fields.Add("Contract Vault Reference Bar Code", SPFieldType.Text, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Contract Vault Reference Bar Code");
                spfld.Required = false;
                spfld.Update();
                //archView.ViewFields.Add("Contract Vault Reference Bar Code");
            }

            if (!archList.Fields.ContainsField("Data Privacy"))
            {
                archList.Fields.Add("Data Privacy", SPFieldType.Boolean, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Data Privacy");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("Data Privacy");
            }

            if (!archList.Fields.ContainsField("Change of controle"))
            {
                archList.Fields.Add("Change of controle", SPFieldType.Boolean, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Change of controle");
                spfld.Required = true;
                spfld.Update();
                archView.ViewFields.Add("Change of controle");
            }
            if (!archList.Fields.ContainsField("Access Delegation"))
            {
                archList.Fields.Add("Access Delegation", SPFieldType.User, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Access Delegation");
                spfld.Required = false;
                spfld.Update();
                archView.ViewFields.Add("Access Delegation");
            }

            if (!archList.Fields.ContainsField("Lawyer's confidential"))
            {
                archList.Fields.Add("Lawyer's confidential", SPFieldType.Boolean, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("Lawyer's confidential");
                spfld.DefaultValue = "false";
                spfld.Update();
                archView.ViewFields.Add("Lawyer's confidential");
            }

            if (!archList.Fields.ContainsField("External contract"))
            {
                archList.Fields.Add("External contract", SPFieldType.Boolean, true);
                archList.Update();
                var spfld = (SPField)archList.Fields.GetField("External contract");
                spfld.DefaultValue = "false";
                spfld.Update();
                archView.ViewFields.Add("External contract");
            }

            archView.Update();

        }

        private void AddItemsMonsantoEntity(SPList list)
        {
            AddItem("AB SEED LTD", list);
            AddItem("ADVANTA SEEDS B.V.", list);
            AddItem("ALTIN TOHUMCULUK, TURKEY", list);
            AddItem("AMICA-SCIENCE-EEIG", list);
            AddItem("ANOVA INTERNATIONAL LIMITED", list);
            AddItem("ANT TOHUM, Turkey", list);
            AddItem("AQUALLOY B.V. NETHERLANDS", list);
            AddItem("ASGROW FRANCE S.A.", list);
            AddItem("ASGROW GmbH, Bruchsal", list);
            AddItem("ASGROW SEED CO.", list);
            AddItem("ASGROW SEED COMPANY , Kalamazoo/USA", list);
            AddItem("ASPARAGUS B.V., THE NETHERLANDS", list);
            AddItem("BRUINSMA SEED B.V.", list);
            AddItem("BRUINSMA SEEDS BV, NETHERLANDS", list);
            AddItem("BRUINSMA SELECTIEBEDRUJVEN B.V.", list);
            AddItem("BURGAN AGRI-FOOD INDUSTRY EST.", list);
            AddItem("BVBA AvS NO 1928 BVBA, GENT/ BELGIUM", list);
            AddItem("CARDELAGRO S.P.R.L./B.V.B.A., Brussels/Belgium", list);
            AddItem("CARGILL France S.A., Seed Division", list);
            AddItem("CARGILL Genetique Europe , Croix De Pardies-France", list);
            AddItem("CARGILL Semences, Peyrehorade - FR", list);
            AddItem("CARGILL, Wayzata,MN/USA", list);
            AddItem("CASPER JONSEN", list);
            AddItem("CHEETAH ZAMBIA LIMITED", list);
            AddItem("CHRISTOBAL BV", list);
            AddItem("COMPLEJO ASGROW SEMILLAS S.L. \"C.A.S.\" - Madrid/Spain", list);
            AddItem("CONNECTICUT U.S.A.", list);
            AddItem("CORN STATES HYBRID SERVICE LLC", list);
            AddItem("CORN STATES HYBRID SERVICE LLC, HOLDEN'S FOUNDATION SEEDS LLC, MONSANTO SAS, MONSANTO INTERNATIONAL, MONSANTO COMPANY", list);
            AddItem("CORN STATES INTERNATIONAL", list);
            AddItem("CORN STATES INTERNATIONAL S.A.", list);
            AddItem("CORN STATES INTERNATIONAL S.A.S.", list);
            AddItem("CORN STATES INTERNATIONAL SARL", list);
            AddItem("CRITES-MOSCOW GROWERS, INC.", list);
            AddItem("D&PL TECHNOLOGY HOLDINGS COMPANY LLC", list);
            AddItem("DANTUMA BV, THE NETHERLANDS", list);
            AddItem("DE RUITER BEHEER", list);
            AddItem("DE RUITER DIRECTIE V, Netherlands", list);
            AddItem("DE RUITER GRAINES SARL, France", list);
            AddItem("DE RUITER Graines sise, ST Andiol/France", list);
            AddItem("DE RUITER IBERIA HOLDING SA, Spain", list);
            AddItem("DE RUITER PRODUCTIE CV", list);
            AddItem("DE RUITER RESEARCH SA, Spain", list);
            AddItem("DE RUITER SEEDS BV, Netherlands", list);
            AddItem("DE RUITER SEEDS EUROCONSULTAS AGRICOLAS S. de R.L. de C.V., Mexico", list);
            AddItem("DE RUITER SEEDS GROUP BV", list);
            AddItem("DE RUITER SEEDS GROUP BV,Netherlands", list);
            AddItem("DE RUITER SEEDS HOLDING BV, Netherlands", list);
            AddItem("DE RUITER SEEDS HOLDING CO, USA", list);
            AddItem("DE RUITER SEEDS INC., USA", list);
            AddItem("DE RUITER SEEDS LATINA S. DE. R.L. DE C.V., Sinaloa/Mexico", list);
            AddItem("DE RUITER SEEDS LIMITED", list);
            AddItem("DE RUITER SEEDS MAROC, Agadir/Maroc", list);
            AddItem("DE RUITER SEEDS NL BV -  reffered as \"DRS\" (Bergschenhoek- Netherland)", list);
            AddItem("DE RUITER SEEDS NL BV, Netherlands", list);
            AddItem("DE RUITER SEEDS Polska SP Z.o.o., Poland", list);
            AddItem("DE RUITER SEEDS PRODUCITON BV, Netherlands", list);
            AddItem("DE RUITER SEEDS PRODUCTION NL BV,Netherlands", list);
            AddItem("DE RUITER SEEDS R&D BV, Netherlands", list);
            AddItem("DE RUITER SEEDS R&D NL BV, Netherlands", list);
            AddItem("DE RUITER SEEDS SALES LIMITED LIABILITY COMPANY", list);
            AddItem("DE RUITER SEEDS SAN PEDRO SA, Guatemala", list);
            AddItem("DE RUITER SEEDS SEMENTI SRL, Italy", list);
            AddItem("DE RUITER SEEDS SP Z.O.O., Warszawa/Poland", list);
            AddItem("DE RUITER SEEDS VETOMAG KERESKEDO KFT, Hungary", list);
            AddItem("DE RUITER SEEDS Vet�mag Kereskedo KFT, Kecskem�t/Hungary", list);
            AddItem("DE RUITER SEMENTI RICERCA SOCIETA AGRICOLA SRL, Italy", list);
            AddItem("DE RUITER SEMILLAS SA, Spain", list);
            AddItem("DE RUITER ZONEN SELECTION SCEA, Netherlands", list);
            AddItem("DE RUITERSEEDS C.V. , Bergschenhoek/Netherlands", list);
            AddItem("DE RUITERZONEN BV", list);
            AddItem("DE RUITERZONEN C.V., Bergschenhoek, Netherlands", list);
            AddItem("DE STICHTING BEDRIJFSGEZONDHEIDSDIENST NOORD-HOLLAND, THE NETHERLANDS", list);
            AddItem("DE STICHTING BODEMSANERING IN GEBRUIK ZIJNDE BEDRIJFSTERREINEN NOORD-HOLLAND", list);
            AddItem("DEKALB Genetics Corporation USA", list);
            AddItem("DERUITERSEEDS C.V. , Bleiswijk,Netherlands", list);
            AddItem("DOM SAMAN GmbH", list);
            AddItem("EL GOUSSI SEEDS SUDAN", list);
            AddItem("ENRA ASSURANTI�N BV, NETHERLANDS", list);
            AddItem("ENZA ZADEN BV", list);
            AddItem("ENZA ZADEN DE ENKHUIZER ZAADHANDEL B.V. NETHERLANDS", list);
            AddItem("EUROSEED B.V., NAALDWIJK THE NETHERLANDS", list);
            AddItem("FAELLESFORENINGEN FOR DENMARKS BRUGS FORENINGER, DENMARK", list);
            AddItem("FRESHVALLEY B.V. I.O., THE NETHERLANDS", list);
            AddItem("G.D. SEARLE & CO", list);
            AddItem("G.D. SEARLE & CO., Belgique", list);
            AddItem("GARTENLAND GMBH ASCHERSLEBEN, NL", list);
            AddItem("HOLDEN'FOUNDATION SEEDS LLC", list);
            AddItem("HORRIGAN AND COMPANY LIMITED, UK", list);
            AddItem("HORRIGAN AND COMPANY LIMITED, UK", list);
            AddItem("HUNGAROSEED, HUNGARY", list);
            AddItem("HYBRITECH EUROPE SNC, France", list);
            AddItem("HYBRITECH SNC, Bron/France", list);
            AddItem("INCOTEC B.V., THE NETHERLANDS", list);
            AddItem("INNOVEG BV, ENKHUIZEN, NETHERLANDS", list);
            AddItem("INNOVEG BV, NETHERLANDS", list);
            AddItem("Ir. R.A.H. LEGRO, NETHERLANDS", list);
            AddItem("J.A.  LEKKERKERK", list);
            AddItem("J.H.A. TAMBOER, THE NETHERLANDS", list);
            AddItem("JAN TEUNIS VAN BEELEN, GERMANY", list);
            AddItem("KEYGEN NV", list);
            AddItem("KONINKLIJK  KWEEKBEDRIJF EN ZAADHANDEL D.J. VAN DER HAVE B.V. , THE NETHERLANDS", list);
            AddItem("KONINKLIJKE ZAAIZAADBEDRIJVEN GEBROEDERS SLUIS BV", list);
            AddItem("LA S.A.R.L. MARSEM", list);
            AddItem("LATIFA GULIYEVA MS., Baku, Azerbaijan", list);
            AddItem("LOIRET SEMENCE SARL, France", list);
            AddItem("M & B V.O.F., THE NETHERLANDS", list);
            AddItem("MONSANTO  do BRASIL Ltda, S�o Jos� dos Campos/S�o Paulo-BRASIL", list);
            AddItem("MONSANTO (SUISSE) S.A.", list);
            AddItem("MONSANTO Agrar Deutschland GmbH, Dusseldorf/Germany", list);
            AddItem("MONSANTO AGRICOLTURA ITALIA S.P.A.", list);
            AddItem("MONSANTO AGRICULTURA ESPANA SL", list);
            AddItem("MONSANTO AGRICULTURAL COMPANY, St-Louis/USA", list);
            AddItem("MONSANTO Agriculture France SAS", list);
            AddItem("MONSANTO ARGENTINA S.A.I.C.", list);
            AddItem("MONSANTO BULGARIA", list);
            AddItem("MONSANTO BURKINA FASSO SARL", list);
            AddItem("MONSANTO Canada Inc", list);
            AddItem("MONSANTO COMPANY", list);
            AddItem("MONSANTO COMPANY, 2711 Centerville Road, Suite 400, Wilmington, DE", list);
            AddItem("MONSANTO COMPANY, USA", list);
            AddItem("MONSANTO COMPANY, Vegetable Seeds Division, Oxnard/USA", list);
            AddItem("MONSANTO CR S.R.O.", list);
            AddItem("MONSANTO CROATIA", list);
            AddItem("MONSANTO CROP SCIENCES SWEDEN AB - Bromma", list);
            AddItem("MONSANTO DEUTSCHLAND GMBH", list);
            AddItem("MONSANTO Division Seminis (LE ROUZEL) N�mes/France", list);
            AddItem("MONSANTO DO BRASIL LTDA.", list);
            AddItem("MONSANTO EUROPE BVBA, Antweroen/Belgium", list);
            AddItem("MONSANTO EUROPE N.V., Brussels/Belgium", list);
            AddItem("MONSANTO EUROPE S.A.", list);
            AddItem("Monsanto Europe SA/NV", list);
            AddItem("MONSANTO FRANCE S.A.", list);
            AddItem("MONSANTO GIDA VE TARIM TICARET LIMITED SIRKETI, Istanbul/Turkey", list);
            AddItem("MONSANTO HELLAS", list);
            AddItem("MONSANTO HOLDING C.V.", list);
            AddItem("MONSANTO HOLDINGS PRIVATE LIMITED", list);
            AddItem("MONSANTO HOLLAND B.V.", list);
            AddItem("MONSANTO HOLLAND B.V., ANTHONY LIONWEG, BERGSCHENHOEK", list);
            AddItem("MONSANTO HUNGARIA KFT", list);
            AddItem("Monsanto International Sarl", list);
            AddItem("MONSANTO INVEST B.V.", list);
            AddItem("MONSANTO Invest N.V.", list);
            AddItem("MONSANTO KENYA Limited", list);
            AddItem("MONSANTO Kereskedelmi KFT", list);
            AddItem("Monsanto Malawi Limited", list);
            AddItem("MONSANTO NL B.V.", list);
            AddItem("MONSANTO p.l.c.", list);
            AddItem("MONSANTO POLSKA SP Z.O.O.", list);
            AddItem("MONSANTO Romania S.R.L..", list);
            AddItem("Monsanto Russia LLC", list);
            AddItem("MONSANTO Saaten GmbH", list);
            AddItem("MONSANTO SAS", list);
            AddItem("MONSANTO SAS, Bron/France", list);
            AddItem("MONSANTO SERBIA DOO BEOGRAD", list);
            AddItem("MONSANTO SERBIA DOO, Belgrade/Serbia", list);
            AddItem("MONSANTO SERVICES INTERNATIONAL S.A, Belgium", list);
            AddItem("MONSANTO SLOVAKIA, s.r.o.", list);
            AddItem("MONSANTO SOUTH AFRICA (PTY) Ltd", list);
            AddItem("MONSANTO SOUTH AFRICA LIMITED-MOSAF, Transvaal/SouthAfrica", list);
            AddItem("MONSANTO TANZANIA, Ltd.", list);
            AddItem("MONSANTO TECHNOLOGY LLC", list);
            AddItem("MONSANTO THAILAND Limited", list);
            AddItem("MONSANTO TREASURY SERVICES S�rl", list);
            AddItem("MONSANTO UK Ltd., Cambourne, Cambridge/UK", list);
            AddItem("MONSANTO UKRAINE LTD", list);
            AddItem("MONSANTO VEGETABLE HOLDING LLC, USA", list);
            AddItem("MONSANTO VEGETABLE IP MANAGEMENT B.V.", list);
            AddItem("MONSANTO VEGETABLE SEED HOLDING LLC, USA", list);
            AddItem("MONSANTO VEGETABLE SEEDS B.V., THE NETHERLANDS", list);
            AddItem("MONSANTO VEGETABLES BV, WAGENINGEN, THE NETHERLANDS", list);
            AddItem("MONSANTO ZAAD B.V.", list);
            AddItem("MONSANTO ZAO, Moscow/Russia", list);
            AddItem("MONSANTO/DE RUITER, Bron/France", list);
            AddItem("MONSANTO/SEMINIS Bron/France", list);
            AddItem("NULL", list);
            AddItem("OIL SEED PROCESSING DIVISION OF CARGILL, USA", list);
            AddItem("ORANGE", list);
            AddItem("PAN AMERICAN SEEDS INC., USA", list);
            AddItem("PAU-EURALIS, France", list);
            AddItem("PEOTEC SEEDS, Parma/Italy", list);
            AddItem("PETO ITALIANA SRL", list);
            AddItem("PETOSEED CO. INC.", list);
            AddItem("PETOSEED CO. INC., Saticoy-California/USA", list);
            AddItem("PETOSEED FRANCE SARL", list);
            AddItem("PETOSEED TOHUMCULUK AS TURKEY", list);
            AddItem("PIANOSA NV, Curacao", list);
            AddItem("PINETREE DE RUITER SEEDS Ltd", list);
            AddItem("PINETREE Ltd, UK", list);
            AddItem("PIZARRO BV", list);
            AddItem("PLANT BREEDING International Cambridge LTD, Cambridge/UK", list);
            AddItem("PROFESSOR DR. R.A.H. LEGRO", list);
            AddItem("PVSEEDS, BERGSCHENHOEK, THE NETHERLANDS", list);
            AddItem("RAMIRO ARNEDO S.A. SPAIN", list);
            AddItem("RHONE-POULENC AGRO S.A.", list);
            AddItem("ROSSEN SEEDS BV", list);
            AddItem("ROYAL SLUIS", list);
            AddItem("ROYAL SLUIS BENELUX", list);
            AddItem("ROYAL SLUIS BV ", list);
            AddItem("ROYAL SLUIS BV NETHERLANDS", list);
            AddItem("ROYAL SLUIS C.S.", list);
            AddItem("ROYAL SLUIS FAR EAST LIMITED", list);
            AddItem("ROYAL SLUIS INC. CALIFORNIA", list);
            AddItem("ROYAL SLUIS INC. SALINAS", list);
            AddItem("ROYAL SLUIS KONINKLIJKE ZAAIZAADBEDRIJVEN GEBROEDERS SLUIS BV, NETHERLANDS", list);
            AddItem("ROYAL SLUIS VEGETABLES NETHERLANDS", list);
            AddItem("SAKATA SEED EUROPE BV, THE NETHERLANDS", list);
            AddItem("SARL AGRICOOP FRANCE", list);
            AddItem("SEED DIVISION OF CARGILL", list);
            AddItem("SEEDTEC INTERNATIONAL INC.", list);
            AddItem("SEMINIS PRODUCE BUSINESS BV", list);
            AddItem("SEMINIS VEGETABLE SEEDS HOLLAND BV", list);
            AddItem("SEMINIS VEGETABLE SEEDS IBERICA S.A.,  SPAIN", list);
            AddItem("SEMINIS VEGETABLE SEEDS INC., SATICOY, USA", list);
            AddItem("SEMINIS VEGETABLE SEEDS UK LTD", list);
            AddItem("SEMINIS VEGETABLE SEEDS, INC, USA", list);
            AddItem("SEMINIS VEGETABLE SEEDS, Nimes/France", list);
            AddItem("SEMINIS VEGETABLE SEEDS, SOUTH AFRICA (PTY) Ltd", list);
            AddItem("SESI BV, Netherlands", list);
            AddItem("SLUIS GARDEN BV, NL", list);
            AddItem("SLUIS ORNAMENTALS B.V.", list);
            AddItem("SLUIS VEGETABLES B.V., THE NETHERLANDS ", list);
            AddItem("SNOWY RIVER SEED CO-OPERATIVE LTD. AUSTRALIA", list);
            AddItem("SOCIETE MONSANTO FRANCE SA, France", list);
            AddItem("SOCIETE MONSANTO SEMENCES DEKALB", list);
            AddItem("SOLARIS", list);
            AddItem("SOUTHERN  CROSS SEEDS PTY.LTD. AUSTRALIA", list);
            AddItem("STAGROS AMSTERDAM BV", list);
            AddItem("SVALOF AB, Sweeden", list);
            AddItem("SVS HOLLAND B.V., Enkhuizen/Holland", list);
            AddItem("TEZIER S.A. FRANCE", list);
            AddItem("THE GREENERY INTERNATIONAL BV, NL", list);
            AddItem("TIANJIN DR SEEDS Ltd., China", list);
            AddItem("TOMATECH LTD. HUNGARY", list);
            AddItem("UNIVERSAL S.R.L. ROMANIA", list);
            AddItem("UNIVERSITY OF WARWICK", list);
            AddItem("VAN VOORST HOLDING B.V. , THE NETHERLANDS", list);
            AddItem("Vergo Kwekerijen", list);
            AddItem("VET�MAG HANDELSZENTRALE HUNGARY", list);
            AddItem("VW Tuinderijen", list);
            AddItem("WELLS FARGO BANK N.A.", list);
            AddItem("Western Seed 2000 S.L. Murcia, Spain", list);
            AddItem("WESTERN SEED 2000 S.L.,  Murcia, Spain", list);
            AddItem("WESTERN SEED AMERICAS, INC", list);
            AddItem("WESTERN SEED INTERNATIONAL B.V., Naaldwijk/Netherlands", list);
            AddItem("WESTERN SEED S.A., Gran Canaria/Spain", list);
            AddItem("WING SEED BV, THE NETHERLANDS", list);

        }

        private void AddItemsContractTypes(SPList list)
        {
            AddItem("Agreement", list);
            AddItem("Amendment (for a Signed Agreement)", list);
            AddItem("Assignment Agreement", list);
            AddItem("Bank Transfer Agreement", list);
            AddItem("Business Transfer Agreement (BTA)", list);
            AddItem("Code of Conduct", list);
            AddItem("Commission Agreement", list);
            AddItem("Confidentiality Agreement (Company)", list);
            AddItem("Consent to Assignment", list);
            AddItem("Consulting Agreement", list);
            AddItem("Contribution Agreement", list);
            AddItem("Cooperation Agreement", list);
            AddItem("Demonstration Trial Agreement", list);
            AddItem("Distribution Agreement", list);
            AddItem("Engagement Letter", list);
            AddItem("Exclusivity Agreement", list);
            AddItem("Extension", list);
            AddItem("Extension Service Agreement", list);
            AddItem("Facilities agreement", list);
            AddItem("General Terms", list);
            AddItem("Guarantee", list);
            AddItem("Intercompany Agreement", list);
            AddItem("Joint Research Agreement", list);
            AddItem("Land Lease Agreement", list);
            AddItem("Lease Agreement", list);
            AddItem("Letter", list);
            AddItem("License Agreement", list);
            AddItem("Loan Agreement", list);
            AddItem("Market �Financing Agreement", list);
            AddItem("Market Funding Agreement", list);
            AddItem("Material Transfer Agreement", list);
            AddItem("Non Disclosure Agreement (NDA)", list);
            AddItem("Non-Exclusive Distribution Agreement", list);
            AddItem("Payment Agreement", list);
            AddItem("Production and Sales Agreement", list);
            AddItem("Production of Acreage Agreement", list);
            AddItem("Promotion Agreement", list);
            AddItem("Sale Purchase Agreement", list);
            AddItem("Release Agreement", list);
            AddItem("Rental Agreement", list);
            AddItem("Research & Development Agreement", list);
            AddItem("Research Services Agreement", list);
            AddItem("Sales Contract", list);
            AddItem("Seed Distribution Agreement", list);
            AddItem("Seed Processing Agreement", list);
            AddItem("Seed Production Agreement", list);
            AddItem("Services Agreement", list);
            AddItem("Service providers", list);
            AddItem("Settlement Agreement", list);
            AddItem("Shared Services", list);
            AddItem("Supplementary Agreement", list);
            AddItem("Sale Purchase Agreement", list);
            AddItem("Termination Agreement", list);
            AddItem("Termination Letter", list);
            AddItem("Testing Agreement", list);
            AddItem("Tolling Agreement", list);
            AddItem("Trade associations", list);
            AddItem("Transportation Agreement", list);
            AddItem("Trial Agreement", list);
            AddItem("Trust Agreement", list);
            AddItem("Universities or schools", list);
            AddItem("Warehousing Agreement", list);

        }

        private void SetupConfigList(SPWeb web)
        {
            web.AllowUnsafeUpdates = true;
            SPList ecList = web.Lists.TryGetList("Configuration");

            if (ecList != null)
            {
                AddItem("Archiving - Agreement Name", ecList);
                AddItem("Archiving - Key words", ecList);
                AddItem("Archiving - Effective Date", ecList);
                AddItem("Archiving - End of contract", ecList);
                AddItem("Archiving - Signature date", ecList);
                AddItem("Archiving - FCPA Action date", ecList);
                AddItem("Archiving - Counterparty", ecList);
                AddItem("Archiving - Business user", ecList);
                AddItem("Archiving - DOA Approver", ecList);
                AddItem("Archiving - Contract vault reference", ecList);
                AddItem("Archiving - Bar code", ecList);
                AddItem("Archiving - Data privacy", ecList);
                AddItem("Archiving - Change of controle", ecList);
                AddItem("Archiving - Access delegation", ecList);
                AddItem("Archiving - Lawyers confidential", ecList);

                AddItem("Effective Date Archiving Tooltip", ecList);
                AddItem("InvalidChars", ecList);
                AddItem("Search - Wait message", ecList);
            }

        }

		private static SPList EnsureList(SPWeb web, string name, string description, SPListTemplateType template)
		{
			var list = web.Lists.TryGetList(name);
			
			if (list != null)
			{
				if (list.BaseTemplate != template)
					throw new SPException(string.Format("List {0} has type '{1}'; but should have type '{2}'.", name, list.BaseTemplate, template));
				return list;
			}

			var id = web.Lists.Add(name, description, template);
			return web.Lists[id];
		}

        private void AddItem(string sKey, SPList list)
        {
            SPQuery q = new SPQuery();
            q.Query = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">" + sKey + "</Value></Eq></Where>";
            SPListItemCollection itemCol = list.GetItems(q);
            if (itemCol.Count <= 0)
            {
                SPListItem item = list.AddItem();
                item["Title"] = sKey;
                //item["Value"] = "";

                item.Update();
            }
        }
    }
}

