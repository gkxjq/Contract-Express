using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;

namespace Bayer.BCS.ContractExpressSystem.Features.Bayer.BCS.ContractExpressSystem.Receivers
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("4d8c878c-41f9-4350-b173-ade9b6127fd2")]
    public class MonsantoContractExpressSystemEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            try
            {

                //Add new event reciver to ExpressContact List - DLH - 17/11/14
                SPList ecLst = ECContext.Current.Lists.ExpressContract;
                //ecLst.EventReceivers.Add(SPEventReceiverType.ItemUpdated, "Bayer.BCS.ContractExpressSystem", "Bayer.BCS.ContractExpressSystem.ContractApprovalReceiver");
                //ecLst.Update();

                ////Add new event reciver to ArchivedContracts List - DLH - 17/11/14
                SPList acLst = ECContext.Current.Lists.ArchivedContracts;
                //acLst.EventReceivers.Add(SPEventReceiverType.ItemUpdated, "Bayer.BCS.ContractExpressSystem", "Bayer.BCS.ContractExpressSystem.ArchivedContractsReceiver");
                //acLst.Update();


                ECContext.LogErrorEvent("Bayer.BCS.ContractExpressSystem.EventReceivers test - Feature activating custom updated");
                SPWeb web = properties.Feature.Parent as SPWeb;
                ECContext.LogErrorEvent("Bayer.BCS.ContractExpressSystem.EventReceivers - "+ web + "");
                //// Add Event for Transmittal list
                AttachReceiver(web, ecLst, SPEventReceiverType.ItemUpdated, "Bayer.BCS.ContractExpressSystem", "ContractApprovalReceiver", 1000);
                ECContext.LogErrorEvent("Bayer.BCS.ContractExpressSystem.EventReceivers - " + ecLst + "attached");
                //ECContext.LogErrorEvent("Bayer.BCS.ContractExpressSystem.EventReceivers - Feature ContractApprovalReceiver activated custom");
                AttachReceiver(web, acLst, SPEventReceiverType.ItemUpdated, "Bayer.BCS.ContractExpressSystem", "ArchivedContractsReceiver", 1000);

                //ECContext.LogErrorEvent("Bayer.BCS.RecordsManagement.EventReceivers - Added Event recevier for Transmittal list");
            }
            catch (Exception ex)
            {
                //ECContext.LogErrorEvent("Bayer.BCS.ContractExpressSystem.EventReceivers - " + ex.Message + "");
                //ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }

        private void AttachReceiver(SPWeb web, SPList ListName, SPEventReceiverType eventtype, string namespaceName, string classname, int sequence)
        {
            // SPList list = web.Lists.TryGetList(ListName);
            string fullclassname = namespaceName + "." + classname;
            //first detach from list. In case it was already attached.
            DetachReceiver(web, ListName, eventtype, namespaceName, classname);

            //now attach to list.
            SPEventReceiverDefinition def = ListName.EventReceivers.Add();

            def.Name = string.Format("{0}_{1}", classname, eventtype.ToString());
            def.Class = fullclassname;
            def.Assembly = this.GetType().Assembly.FullName;
            def.SequenceNumber = sequence;
            def.Type = eventtype;
            def.Update();
        }
        private void DetachReceiver(SPWeb web, SPList ListName, SPEventReceiverType eventtype, string namespaceName, string classname)
        {
            //  SPList list = web.Lists.TryGetList(ListName);
            string fullclassname = namespaceName + "." + classname;
            if (ListName != null)
            {
                for (int i = ListName.EventReceivers.Count - 1; i >= 0; i--)
                {
                    SPEventReceiverDefinition def = ListName.EventReceivers[i];
                    if (def.Class == fullclassname && def.Type == eventtype)
                    {
                        ListName.EventReceivers[i].Delete();
                    }
                }
            }
        }
        /// <summary>
        /// Occurs when a Feature is deactivated.
        /// </summary>
        /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //    SPList ecLst = ECContext.Current.Lists.ExpressContract;
        //    SPList tmplLst = ECContext.Current.Lists.ContractTemplate;
        //    SPList acLst = ECContext.Current.Lists.ArchivedContracts;

        //    SPEventReceiverDefinition update = null;
        //    SPEventReceiverDefinition deleteAc = null;
        //    SPEventReceiverDefinition delete = null;

        //    foreach (SPEventReceiverDefinition item in ecLst.EventReceivers)
        //        if (item.Class == "Bayer.BCS.ContractExpressSystem.ContractApprovalReceiver")
        //        {
        //            update = item;
        //            break;
        //        }

        //    //foreach (SPEventReceiverDefinition item in tmplLst.EventReceivers)
        //    //    if (item.Class == "Bayer.BCS.ContractExpressSystem.TemplateCleanUpReceiver")
        //    //    {
        //    //        delete = item;
        //    //        break;
        //    //    }

        //    foreach (SPEventReceiverDefinition item in acLst.EventReceivers)
        //        if (item.Class == "Bayer.BCS.ContractExpressSystem.ArchivedContractsReceiver")
        //        {
        //            deleteAc = item;
        //            break;
        //        }

        //    if (update != null)
        //        update.Delete();

        //    //if (delete != null)
        //    //    delete.Delete();
        //    if (deleteAc != null)
        //        deleteAc.Delete();

        //    ecLst.Update();
        //   // tmplLst.Update();
        //    acLst.Update();
        //}

        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
