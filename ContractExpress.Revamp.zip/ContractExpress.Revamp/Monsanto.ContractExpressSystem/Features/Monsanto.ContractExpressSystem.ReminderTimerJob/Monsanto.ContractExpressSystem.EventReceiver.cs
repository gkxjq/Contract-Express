using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Administration;
using Monsanto.ContractExpressSystem.Jobs;

namespace Monsanto.ContractExpressSystem.Features.Monsanto.ContractExpressSystem.ReminderTimerJob
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>
    
  

    [Guid("eb192006-b915-488b-ac16-07804b9f7c48")]
    public class MonsantoContractExpressSystemEventReceiver : SPFeatureReceiver
    {

        private string jobName = "ContractExpressSystemJob";

        //Uncomment the method below to handle the event raised after a feature has been activated.
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPWebApplication webApp = properties.Feature.Parent as SPWebApplication;

            if (webApp != null)
            {
                // Make sure the job isn't already registered.
                foreach (SPJobDefinition job in webApp.JobDefinitions)
                {
                    if (job.Name == jobName)
                        job.Delete();
                }


                // Install the job.
                ContractExpressSystemJob contractReminderJob = new ContractExpressSystemJob(jobName, webApp, "http://win-aaf6htv2rsi/sites/monsanto/", new Guid("78074c02-15e0-4ad2-9793-44e0417a4715"), "1", "test@test.com");
                //SharePointWarmupJob SharePointWarmupJob = new SharePointWarmupJob(site.WebApplication);

                SPMinuteSchedule schedule = new SPMinuteSchedule();
                schedule.BeginSecond = 0;
                schedule.EndSecond = 59;
                schedule.Interval = 2;

                contractReminderJob.Schedule = schedule;
                contractReminderJob.Update();
            }
        }


        ////Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPWebApplication webApp = properties.Feature.Parent as SPWebApplication;

            if (webApp != null)
            {
                // Delete the job.
                foreach (SPJobDefinition job in webApp.JobDefinitions)
                {
                    if (job.Name == jobName)
                        job.Delete();
                }
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
