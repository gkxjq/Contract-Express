﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Server.Diagnostics;
using Microsoft.SharePoint;


namespace Bayer.BCS.ContractExpressSystem
{
    public static class Logger
    {
        #region Private Fields
        /// <summary>
        /// Enumeration specifying the types of logging events used by the EventLogging class.
        /// </summary>
        private enum LogType
        {
            Information,
            Error
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Method used to log an information event to the SharePoint trace logs.
        /// </summary>
        /// <param name="source">String containing the source of the information event.</param>
        /// <param name="message">String containing the information message.</param>
        public static void LogInformation(string message)
        {
            // Call the LogEvent method with the log type of Information.
            LogEvent(message, LogType.Information);
        }
        public static void LogErrorEvent(string message)
        {
            // Call the LogEvent method with the log type of Information.
            LogEvent(message, LogType.Information);
        }

        /// <summary>
        /// Method used to log an error event to the SharePoint trace logs.
        /// </summary>
        /// <param name="source">String containing the source of the error event.</param>
        /// <param name="message">String containing the error message.</param>
        public static void LogError(Exception source, string message)
        {
            // Call the LogEvent method with the log type of Error.
            LogEventError(source, message, LogType.Error);
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Method that calls the PortalLog.LogString method to log a message to the SharePoint 
        /// trace logs. The method accepts a source and message string as well as the type of
        /// log message that will be written to the trace logs.
        /// </summary>
        /// <param name="source">String containing the source of the message.</param>
        /// <param name="message">String containing the message.</param>
        /// <param name="type">Type of message to be written.</param>
        private static void LogEvent(string message, LogType type)
        {
            try
            {
                // Run the portal logging with elevated priveleges, so that the error can be sucessfully logged.
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    // Call the PortalLog LogString method. Use the format string to format the log type, source and message.
                    PortalLog.LogString("Bayer.BCS.RecordManagment {0} Message - Source: {1}", type.ToString(), message);
                });
            }
            catch (Exception)
            {
                // Not sure where to log if we can't log here
            }
        }
        private static void LogEventError(Exception source, string message, LogType type)
        {
            try
            {
                // Run the portal logging with elevated priveleges, so that the error can be sucessfully logged.
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    // Call the PortalLog LogString method. Use the format string to format the log type, source and message.
                    PortalLog.LogString("Bayer.BCS.RecordManagment {0} Message - Source: {1} - Message: {2}", type.ToString(), source, message);
                });
            }
            catch (Exception)
            {
                // Not sure where to log if we can't log here
            }
        }
        #endregion
    }
}