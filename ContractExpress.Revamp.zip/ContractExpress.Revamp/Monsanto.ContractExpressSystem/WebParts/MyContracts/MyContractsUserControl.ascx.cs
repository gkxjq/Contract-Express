﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System.Threading;
using System.Web;

namespace Bayer.BCS.ContractExpressSystem.WebParts.MyContracts
{
	public partial class MyContractsUserControl : UserControl
	{
		protected HtmlInputHidden pdfListPath;


		private void AddHiddenData()
		{
			this.pdfListPath.Value = SPUtility.ConcatUrls(SPContext.Current.Web.Url, ECContext.Current.Lists.ArchivedContracts.RootFolder.Url);
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			AddHiddenData();
			
			if (Page.IsPostBack)
            {
                string target = Page.Request.Form["__EVENTTARGET"];
                string arg = Page.Request.Form["__EVENTARGUMENT"];

                if (target.Equals("Archive") && !string.IsNullOrEmpty(arg) && arg.ToLower() != "aspnetform")
                {
                    string contractId = (string)arg;
                    if (!String.IsNullOrEmpty(contractId))
                    {
                        try
                        {
                            SPUtility.Redirect(string.Format("ContractExpressSystem/ArchiveContractForm.aspx?cid={0}", contractId), SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);
                        }
                        catch (ThreadAbortException)
                        {
                            // Swallow bogus exception caused by redirect
                        }
                    }
                }
            }
		}
	}
}
