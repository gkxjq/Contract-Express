﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.Collections.Generic;
using Microsoft.SharePoint.Administration;
using System.Linq;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using System.Threading;
using System.Web;

namespace Bayer.BCS.ContractExpressSystem.WebParts.MyContractsToSubmit
{
    public partial class MyContractsToSubmitUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {
                string target = Page.Request.Form["__EVENTTARGET"];
                string arg = Page.Request.Form["__EVENTARGUMENT"];

                try
                {
                    if (target.Equals("submitApproval") && !string.IsNullOrEmpty(arg) && arg.ToLower() != "aspnetform")
                    {
                        string contractId = (string)arg;
                        int cId = 0;
                        if (!String.IsNullOrEmpty(contractId))
                        {
                            if (Int32.TryParse(contractId, out cId))
                            {
                                SubmitContractForApproval(contractId);
                            }
                            else
                            {
                                throw new Exception("Error submitting contract for approval. Contract ID: " + contractId);
                            }
                        }
                    }
                    else if (target.Equals("viewDetails") && !string.IsNullOrEmpty(arg) && arg.ToLower() != "aspnetform")
                    {
                        string contractId = (string)arg;
                        if (!String.IsNullOrEmpty(contractId))
                        {
                            SPUtility.Redirect(string.Format("ContractExpressSystem/ChangeContract.aspx?itemid={0}", contractId), SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);
                        }
                    }
                }
                catch (ThreadAbortException)
                {
                    // Swallow bogus exception caused by redirect
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }
            }
        }

        private void SubmitContractForApproval(string contractId)
        {
            string NullFields = "";
            List<string> RequiredFields = new List<string>();
            RequiredFields.Add(ECContext.Current.Configuration.ECFields.Country);
            //RequiredFields.Add(ECContext.Current.Configuration.ECFields.Function);
            RequiredFields.Add(ECContext.Current.Configuration.ECFields.MonsantoEntity);
            RequiredFields.Add(ECContext.Current.Configuration.ECFields.DocumentType);
            RequiredFields.Add(ECContext.Current.Configuration.ECFields.MonsantoDivision);
            //RequiredFields.Add(ECContext.Current.Configuration.ECFields.NegotiationPosition);
            RequiredFields.Add(ECContext.Current.Configuration.ECFields.BusinessUser);
            //RequiredFields.Add(ECContext.Current.Configuration.ECFields.TemplateChoices);

            try
            {
                SPListItem item = null;
                item = ECContext.Current.Lists.ExpressContract.GetItemById(Convert.ToInt32(contractId));
                if (item.File.CheckOutStatus == SPFile.SPCheckOutStatus.None)
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        using (SPSite site = new SPSite(SPContext.Current.Site.ID))
                        {
                            using (SPWeb web = site.OpenWeb())
                            {
                                string sAnswers = "";
                                string sTitle = "";
                                string sUrl = web.Url;

                                //Get doc title from 'Express contracts'
                                //Date: 24 Jan 2016 Added below condition to check if file is already opened, if the file is open it will give error while submitting the contract

                                bool isMarkedForAutomaticApproval = false;

                                //Check contract integrity
                                foreach (string s in RequiredFields)
                                {
                                    if (string.IsNullOrEmpty((string)item[s]))
                                        NullFields += s.Replace("_x0020_", " ") + "<br />";
                                }

                                if (!string.IsNullOrEmpty(NullFields))
                                {
                                    //int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, string.Format(ECContext.Messages.SubmitForApprovalError, NullFields));
                                }
                                else
                                {
                                    //Modify state
                                    DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                                    try
                                    {
                                        disEvt.DisabledItemEvents();
                                        int originalContract = 0;

                                        if (int.TryParse(item[ECContext.Current.Configuration.ECFields.ClonedFromContractId] != null ? item[ECContext.Current.Configuration.ECFields.ClonedFromContractId].ToString() : "0", out originalContract))
                                        {
                                            isMarkedForAutomaticApproval = CheckifAutomaticApproval(originalContract);
                                        }

                                        if (isMarkedForAutomaticApproval)
                                            item[ECContext.Current.Configuration.ECFields.LegalApproval] = "Approved";
                                        else
                                            item[ECContext.Current.Configuration.ECFields.LegalApproval] = "Pending";

                                        item.Update();
                                        //CEJSUtil.PopInfo(Page, "Submit for approval", "Contract successfully submitted for approval");
                                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "SetMessage" + DateTime.Now, "SetMessage('','Red');alert('Contract successfully submitted for approval');location.href='" + SPContext.Current.Site.RootWeb.Url + "';", true);
                                        Response.Write("<script>alert('Contract successfully submitted for approval')</script>");
                                        Response.Write("<script>window.location.href='"+SPContext.Current.Site.RootWeb.Url+"';</script>");
                                    }
                                    catch (Exception ex)
                                    {
                                        int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                                        CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                                    }
                                    finally
                                    {
                                        disEvt.Dispose();
                                    }

                                    //Get Answers from 'Approval Answers'
                                    sTitle = item["LinkFilename"].ToString();
                                    SPListItemCollection approvalItems = ECContext.Current.Lists.ApprovalAnswer.Items;
                                    List<SPListItem> items = (from SPListItem listItem in approvalItems
                                                              where listItem.Title == sTitle
                                                              select listItem).ToList();
                                    if (items.Count > 0)
                                        sAnswers = Convert.ToString(items[0]["Answers"]);

                                    List<string> header = new List<string>();
                                    string mail = "";
                                    string subject = "";
                                    if (isMarkedForAutomaticApproval)
                                    {
                                        subject = string.Format("Express Contract {0}, request for DOA approval", item.File.Title);
                                        mail = ECContext.CreateMail(item, string.Empty, ECContext.ECDoaType, CETemplateMails.RequestApprovalEmailTemplate);
                                        header = ECContext.CreateDOAHeader(item, web);

                                    }
                                    else
                                    {
                                        subject = string.Format("Express Contract {0}, request for Legal approval", sTitle);
                                        mail = ECContext.CreateMailForApproval(sUrl, item, ECContext.ECLegalType, sAnswers, false);
                                        header = ECContext.CreateLegalHeader(web);
                                    }

                                    bool bReturn = ECContext.SendMail(web, subject, mail, header);
                                }
                            }
                        }
                    });
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "showSaveMessage", "<script language='javascript'>alert('Please close the contract and resubmit');</script>");
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private bool CheckifAutomaticApproval(int OriginalContract)
        {
            bool isMarkedForAutomaticApproval = false;
            try
            {
                SPListItem originalContract = ECContext.Current.Lists.ExpressContract.GetItemById(OriginalContract);
                isMarkedForAutomaticApproval = Boolean.Parse(originalContract[ECContext.Current.Configuration.ECFields.AutomaticApproval].ToString());
            }
            catch (Exception ex)
            {
                isMarkedForAutomaticApproval = false;
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }

            return isMarkedForAutomaticApproval;
        }
    }
}
