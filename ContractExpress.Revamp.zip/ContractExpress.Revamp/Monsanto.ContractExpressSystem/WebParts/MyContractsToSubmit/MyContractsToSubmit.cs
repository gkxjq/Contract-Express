﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Xml;

namespace Bayer.BCS.ContractExpressSystem.WebParts.MyContractsToSubmit
{
    [ToolboxItemAttribute(false)]
    public class MyContractsToSubmit : WebPart
    {
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/15/Bayer.BCS.ContractExpressSystem.WebParts/MyContractsToSubmit/MyContractsToSubmitUserControl.ascx";

        protected override void CreateChildControls()
        {
            bool isWebPartInBrowseMode = this.WebPartManager.DisplayMode == WebPartManager.BrowseDisplayMode;

            if (isWebPartInBrowseMode)
            {
                Control control = Page.LoadControl(_ascxPath);
                Controls.Add(control);
            }
            else
            {
                Literal editModeLtl = new Literal();
                editModeLtl.Text = "The contents of this webpart aren't displayed while editing.";
                Controls.Add(editModeLtl);
            }
        }

        protected override void OnInit(EventArgs e)
        {
            this.CssClass = "MyContractsToSubmit";
            base.OnInit(e);
        }

    }
}
