﻿using System;
using System.Collections.Generic;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.Packaging;
using System.Globalization;

namespace Bayer.BCS.ContractExpressSsytem.HtmlToOpenXml
{
    sealed class NumberingListStyleCollection
    {
        private MainDocumentPart mainPart;
        private int currentNumId = 40, absNumId, numberLevelRef;
        private bool firstItem;
        private string levelText;
        private NumberFormatValues format;
        //private Dictionary<NumberFormatValues, int> decimals;
        //private Dictionary<string, int> bullets;

        public NumberingListStyleCollection(MainDocumentPart mainPart)
        {
            this.mainPart = mainPart;
            InitNumberingIds();
        }


        #region InitNumberingIds

        private void InitNumberingIds()
        {
            // Ensure the numbering.xml file exists or any numbering or bullets list will results
            // in simple numbering list (1.   2.   3...)
            //if (mainPart.NumberingDefinitionsPart == null || mainPart.NumberingDefinitionsPart.Numbering == null)
            //{
            GenerateNumberingDefinitionsPart1Content(mainPart.NumberingDefinitionsPart);

            // }
        }



        // Generates content of numberingDefinitionsPart1.
        private void GenerateNumberingDefinitionsPart1Content(NumberingDefinitionsPart numberingDefinitionsPart1)
        {
            if(numberingDefinitionsPart1 != null)
            {
                GenerateNumberingDefinitionsIfTemplate(numberingDefinitionsPart1);
                return;
            }
            Numbering numbering1 = new Numbering();
            numbering1.AddNamespaceDeclaration("ve", "http://schemas.openxmlformats.org/markup-compatibility/2006");
            numbering1.AddNamespaceDeclaration("o", "urn:schemas-microsoft-com:office:office");
            numbering1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
            numbering1.AddNamespaceDeclaration("m", "http://schemas.openxmlformats.org/officeDocument/2006/math");
            numbering1.AddNamespaceDeclaration("v", "urn:schemas-microsoft-com:vml");
            numbering1.AddNamespaceDeclaration("wp", "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing");
            numbering1.AddNamespaceDeclaration("w10", "urn:schemas-microsoft-com:office:word");
            numbering1.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
            numbering1.AddNamespaceDeclaration("wne", "http://schemas.microsoft.com/office/word/2006/wordml");

            AbstractNum abstractNum1 = new AbstractNum() { AbstractNumberId = 0 };
            Nsid nsid1 = new Nsid() { Val = "47170366" };
            MultiLevelType multiLevelType1 = new MultiLevelType() { Val = MultiLevelValues.HybridMultilevel };
            TemplateCode templateCode1 = new TemplateCode() { Val = "F11094B2" };

            Level level1 = new Level() { LevelIndex = 0, TemplateCode = "711CB100" };
            StartNumberingValue startNumberingValue1 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat1 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText1 = new LevelText() { Val = "·" };
            LevelJustification levelJustification1 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties1 = new PreviousParagraphProperties();
            Indentation indentation2 = new Indentation() { Left = "720", Hanging = "360" };

            previousParagraphProperties1.Append(indentation2);

            NumberingSymbolRunProperties numberingSymbolRunProperties1 = new NumberingSymbolRunProperties();
            RunFonts runFonts2 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Symbol", HighAnsi = "Symbol", EastAsiaTheme = ThemeFontValues.MinorEastAsia, ComplexScriptTheme = ThemeFontValues.MinorBidi };

            numberingSymbolRunProperties1.Append(runFonts2);

            level1.Append(startNumberingValue1);
            level1.Append(numberingFormat1);
            level1.Append(levelText1);
            level1.Append(levelJustification1);
            level1.Append(previousParagraphProperties1);
            level1.Append(numberingSymbolRunProperties1);

            Level level2 = new Level() { LevelIndex = 1, TemplateCode = "04090003", Tentative = true };
            StartNumberingValue startNumberingValue2 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat2 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText2 = new LevelText() { Val = "o" };
            LevelJustification levelJustification2 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties2 = new PreviousParagraphProperties();
            Indentation indentation3 = new Indentation() { Left = "1440", Hanging = "360" };

            previousParagraphProperties2.Append(indentation3);

            NumberingSymbolRunProperties numberingSymbolRunProperties2 = new NumberingSymbolRunProperties();
            RunFonts runFonts3 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Courier New", HighAnsi = "Courier New", ComplexScript = "Courier New" };

            numberingSymbolRunProperties2.Append(runFonts3);

            level2.Append(startNumberingValue2);
            level2.Append(numberingFormat2);
            level2.Append(levelText2);
            level2.Append(levelJustification2);
            level2.Append(previousParagraphProperties2);
            level2.Append(numberingSymbolRunProperties2);

            Level level3 = new Level() { LevelIndex = 2, TemplateCode = "04090005", Tentative = true };
            StartNumberingValue startNumberingValue3 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat3 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText3 = new LevelText() { Val = "§" };
            LevelJustification levelJustification3 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties3 = new PreviousParagraphProperties();
            Indentation indentation4 = new Indentation() { Left = "2160", Hanging = "360" };

            previousParagraphProperties3.Append(indentation4);

            NumberingSymbolRunProperties numberingSymbolRunProperties3 = new NumberingSymbolRunProperties();
            RunFonts runFonts4 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Wingdings", HighAnsi = "Wingdings" };

            numberingSymbolRunProperties3.Append(runFonts4);

            level3.Append(startNumberingValue3);
            level3.Append(numberingFormat3);
            level3.Append(levelText3);
            level3.Append(levelJustification3);
            level3.Append(previousParagraphProperties3);
            level3.Append(numberingSymbolRunProperties3);

            Level level4 = new Level() { LevelIndex = 3, TemplateCode = "04090001", Tentative = true };
            StartNumberingValue startNumberingValue4 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat4 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText4 = new LevelText() { Val = "·" };
            LevelJustification levelJustification4 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties4 = new PreviousParagraphProperties();
            Indentation indentation5 = new Indentation() { Left = "2880", Hanging = "360" };

            previousParagraphProperties4.Append(indentation5);

            NumberingSymbolRunProperties numberingSymbolRunProperties4 = new NumberingSymbolRunProperties();
            RunFonts runFonts5 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Symbol", HighAnsi = "Symbol" };

            numberingSymbolRunProperties4.Append(runFonts5);

            level4.Append(startNumberingValue4);
            level4.Append(numberingFormat4);
            level4.Append(levelText4);
            level4.Append(levelJustification4);
            level4.Append(previousParagraphProperties4);
            level4.Append(numberingSymbolRunProperties4);

            Level level5 = new Level() { LevelIndex = 4, TemplateCode = "04090003", Tentative = true };
            StartNumberingValue startNumberingValue5 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat5 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText5 = new LevelText() { Val = "o" };
            LevelJustification levelJustification5 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties5 = new PreviousParagraphProperties();
            Indentation indentation6 = new Indentation() { Left = "3600", Hanging = "360" };

            previousParagraphProperties5.Append(indentation6);

            NumberingSymbolRunProperties numberingSymbolRunProperties5 = new NumberingSymbolRunProperties();
            RunFonts runFonts6 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Courier New", HighAnsi = "Courier New", ComplexScript = "Courier New" };

            numberingSymbolRunProperties5.Append(runFonts6);

            level5.Append(startNumberingValue5);
            level5.Append(numberingFormat5);
            level5.Append(levelText5);
            level5.Append(levelJustification5);
            level5.Append(previousParagraphProperties5);
            level5.Append(numberingSymbolRunProperties5);

            Level level6 = new Level() { LevelIndex = 5, TemplateCode = "04090005", Tentative = true };
            StartNumberingValue startNumberingValue6 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat6 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText6 = new LevelText() { Val = "§" };
            LevelJustification levelJustification6 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties6 = new PreviousParagraphProperties();
            Indentation indentation7 = new Indentation() { Left = "4320", Hanging = "360" };

            previousParagraphProperties6.Append(indentation7);

            NumberingSymbolRunProperties numberingSymbolRunProperties6 = new NumberingSymbolRunProperties();
            RunFonts runFonts7 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Wingdings", HighAnsi = "Wingdings" };

            numberingSymbolRunProperties6.Append(runFonts7);

            level6.Append(startNumberingValue6);
            level6.Append(numberingFormat6);
            level6.Append(levelText6);
            level6.Append(levelJustification6);
            level6.Append(previousParagraphProperties6);
            level6.Append(numberingSymbolRunProperties6);

            Level level7 = new Level() { LevelIndex = 6, TemplateCode = "04090001", Tentative = true };
            StartNumberingValue startNumberingValue7 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat7 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText7 = new LevelText() { Val = "·" };
            LevelJustification levelJustification7 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties7 = new PreviousParagraphProperties();
            Indentation indentation8 = new Indentation() { Left = "5040", Hanging = "360" };

            previousParagraphProperties7.Append(indentation8);

            NumberingSymbolRunProperties numberingSymbolRunProperties7 = new NumberingSymbolRunProperties();
            RunFonts runFonts8 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Symbol", HighAnsi = "Symbol" };

            numberingSymbolRunProperties7.Append(runFonts8);

            level7.Append(startNumberingValue7);
            level7.Append(numberingFormat7);
            level7.Append(levelText7);
            level7.Append(levelJustification7);
            level7.Append(previousParagraphProperties7);
            level7.Append(numberingSymbolRunProperties7);

            Level level8 = new Level() { LevelIndex = 7, TemplateCode = "04090003", Tentative = true };
            StartNumberingValue startNumberingValue8 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat8 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText8 = new LevelText() { Val = "o" };
            LevelJustification levelJustification8 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties8 = new PreviousParagraphProperties();
            Indentation indentation9 = new Indentation() { Left = "5760", Hanging = "360" };

            previousParagraphProperties8.Append(indentation9);

            NumberingSymbolRunProperties numberingSymbolRunProperties8 = new NumberingSymbolRunProperties();
            RunFonts runFonts9 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Courier New", HighAnsi = "Courier New", ComplexScript = "Courier New" };

            numberingSymbolRunProperties8.Append(runFonts9);

            level8.Append(startNumberingValue8);
            level8.Append(numberingFormat8);
            level8.Append(levelText8);
            level8.Append(levelJustification8);
            level8.Append(previousParagraphProperties8);
            level8.Append(numberingSymbolRunProperties8);

            Level level9 = new Level() { LevelIndex = 8, TemplateCode = "04090005", Tentative = true };
            StartNumberingValue startNumberingValue9 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat9 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText9 = new LevelText() { Val = "§" };
            LevelJustification levelJustification9 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties9 = new PreviousParagraphProperties();
            Indentation indentation10 = new Indentation() { Left = "6480", Hanging = "360" };

            previousParagraphProperties9.Append(indentation10);

            NumberingSymbolRunProperties numberingSymbolRunProperties9 = new NumberingSymbolRunProperties();
            RunFonts runFonts10 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Wingdings", HighAnsi = "Wingdings" };

            numberingSymbolRunProperties9.Append(runFonts10);

            level9.Append(startNumberingValue9);
            level9.Append(numberingFormat9);
            level9.Append(levelText9);
            level9.Append(levelJustification9);
            level9.Append(previousParagraphProperties9);
            level9.Append(numberingSymbolRunProperties9);

            abstractNum1.Append(nsid1);
            abstractNum1.Append(multiLevelType1);
            abstractNum1.Append(templateCode1);
            abstractNum1.Append(level1);
            abstractNum1.Append(level2);
            abstractNum1.Append(level3);
            abstractNum1.Append(level4);
            abstractNum1.Append(level5);
            abstractNum1.Append(level6);
            abstractNum1.Append(level7);
            abstractNum1.Append(level8);
            abstractNum1.Append(level9);

            NumberingInstance numberingInstance1 = new NumberingInstance() { NumberID = 1 };
            AbstractNumId abstractNumId1 = new AbstractNumId() { Val = 0 };

            numberingInstance1.Append(abstractNumId1);

            numbering1.Append(abstractNum1);
            numbering1.Append(numberingInstance1);
            if (numberingDefinitionsPart1 == null)
                numberingDefinitionsPart1 = mainPart.AddNewPart<NumberingDefinitionsPart>();

            numberingDefinitionsPart1.Numbering = numbering1;
            if (numberingDefinitionsPart1 == null)
                numberingDefinitionsPart1.Numbering.Save(numberingDefinitionsPart1);

        }

        private void GenerateNumberingDefinitionsIfTemplate(NumberingDefinitionsPart numberingDefinitionsPart1)
        {
            AbstractNum abstractNum1 = null;
            foreach (var subElement in numberingDefinitionsPart1.Numbering.ChildElements)
            {
                if (subElement.GetType() == typeof(AbstractNum) && ((AbstractNum)subElement).AbstractNumberId == 0)
                {
                    abstractNum1 = (AbstractNum)subElement;
                    break;
                }

            }
            if (abstractNum1 == null)
            {
                abstractNum1 = new AbstractNum() { AbstractNumberId = 0 };
                numberingDefinitionsPart1.Numbering.Append(abstractNum1);
            }

            Nsid nsid1 = new Nsid() { Val = "47170366" };
            MultiLevelType multiLevelType1 = new MultiLevelType() { Val = MultiLevelValues.HybridMultilevel };
            TemplateCode templateCode1 = new TemplateCode() { Val = "F11094B2" };

            Level level1 = new Level() { LevelIndex = 0, TemplateCode = "711CB100" };
            StartNumberingValue startNumberingValue1 = new StartNumberingValue() { Val = 1 };
            NumberingFormat numberingFormat1 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
            LevelText levelText1 = new LevelText() { Val = "·" };
            LevelJustification levelJustification1 = new LevelJustification() { Val = LevelJustificationValues.Left };

            PreviousParagraphProperties previousParagraphProperties1 = new PreviousParagraphProperties();
            Indentation indentation2 = new Indentation() { Left = "720", Hanging = "360" };

            previousParagraphProperties1.Append(indentation2);

            NumberingSymbolRunProperties numberingSymbolRunProperties1 = new NumberingSymbolRunProperties();
            RunFonts runFonts2 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Symbol", HighAnsi = "Symbol", EastAsiaTheme = ThemeFontValues.MinorEastAsia, ComplexScriptTheme = ThemeFontValues.MinorBidi };

            numberingSymbolRunProperties1.Append(runFonts2);

            level1.Append(startNumberingValue1);
            level1.Append(numberingFormat1);
            level1.Append(levelText1);
            level1.Append(levelJustification1);
            level1.Append(previousParagraphProperties1);
            level1.Append(numberingSymbolRunProperties1);


            abstractNum1.Append(nsid1);
            abstractNum1.Append(multiLevelType1);
            abstractNum1.Append(templateCode1);
            abstractNum1.Append(level1);

            NumberingInstance numberingInstance1 = new NumberingInstance() { NumberID = 1 };
            AbstractNumId abstractNumId1 = new AbstractNumId() { Val = 0 };

            numberingInstance1.Append(abstractNumId1);

            if (numberingDefinitionsPart1 == null)
                numberingDefinitionsPart1 = mainPart.AddNewPart<NumberingDefinitionsPart>();

            if (numberingDefinitionsPart1 == null)
                numberingDefinitionsPart1.Numbering.Save(numberingDefinitionsPart1);

        }






        private static void addAbstract(int index, Numbering numbering, NumberFormatValues fm, string leveltxt)
        {
            numbering.Append(
         new AbstractNum(
                        new MultiLevelType() { Val = MultiLevelValues.SingleLevel },
                        new Level(
                            new StartNumberingValue() { Val = 1 },
                            new NumberingFormat() { Val = fm },
                            new LevelText() { Val = leveltxt },
                            new PreviousParagraphProperties(
                                new Indentation() { Left = "420", Hanging = "360" })
                        ) { LevelIndex = 0 }
                    ) { AbstractNumberId = index }
                    );
            numbering.Save();
        }


        #endregion

        #region BeginList

        public void BeginList(HtmlEnumerator en)
        {

            if (en.CurrentTag.Equals("<ul>", StringComparison.InvariantCultureIgnoreCase))
            {
                switch ((en.StyleAttributes["list-style-type"] ?? "disc").ToLowerInvariant())
                {
                    case "none":
                    case "circle":
                        format = NumberFormatValues.Bullet;
                        levelText = "o";
                        absNumId = 0;
                        break;
                    case "square":
                        format = NumberFormatValues.Bullet;
                        levelText = "■";
                        absNumId = 0;
                        break;
                    case "disc":
                    default:
                        format = NumberFormatValues.Bullet;
                        levelText = "•";
                        absNumId = 0;
                        break;
                }
            }
            else
            {
                switch ((en.StyleAttributes["list-style-type"] ?? "decimal").ToLowerInvariant())
                {
                    case "upper-alpha":
                        format = NumberFormatValues.UpperLetter;
                        levelText = "%1.";
                        absNumId = 0;
                        break;
                    case "lower-alpha":
                        format = NumberFormatValues.LowerLetter;
                        levelText = "%1.";
                        absNumId = 0;
                        break;
                    case "upper-roman":
                        format = NumberFormatValues.UpperRoman;
                        levelText = "%1.";
                        absNumId = 0;
                        break;
                    case "lower-roman":
                        format = NumberFormatValues.LowerRoman;
                        levelText = "%1.";
                        absNumId = 0;
                        break;
                    case "decimal-leading-zero":
                    default:
                        format = NumberFormatValues.Decimal;
                        levelText = "%1.";
                        absNumId = 0;
                        break;
                }
            }

            firstItem = true;
            numberLevelRef++;
            currentNumId++;

            Numbering numbering = mainPart.NumberingDefinitionsPart.Numbering;
            numbering.Append(
                new NumberingInstance(
                    new AbstractNumId() { Val = absNumId }
                ) { NumberID = currentNumId });
            numbering.Save(mainPart.NumberingDefinitionsPart);
            numbering.Reload();
        }

        #endregion

        #region EndList

        public void EndList()
        {
            numberLevelRef--;
            firstItem = true;
        }

        #endregion

        #region ProcessItem

        public int ProcessItem(HtmlEnumerator en)
        {
            if (!firstItem) return currentNumId;

            firstItem = false;
            Double leftMarginSize = 0;
            if (en.StyleAttributes["margin-left"] != null)
            {
                Unit margin = en.StyleAttributes.GetAsUnit("margin-left");
                if (margin.IsValid)
                {
                    if (margin.Value > 0 && margin.Type == "px")
                        leftMarginSize = margin.Value;
                }
            }
            else if (en.StyleAttributes["margin"] != null)
            {
                Margin margin = en.StyleAttributes.GetAsMargin("margin");
                if (margin.IsValid && margin.Left.Value > 0 && margin.Left.Type == "px")
                {
                    leftMarginSize = margin.Left.Value;
                }
            }

            if (leftMarginSize > 0)
            {
                Margin margin = en.StyleAttributes.GetAsMargin("margin");
                leftMarginSize = margin.Left.Value;

                mainPart.NumberingDefinitionsPart.Numbering.Append(
                    new AbstractNum(
                            new MultiLevelType() { Val = MultiLevelValues.SingleLevel },
                            new Level(
                                new StartNumberingValue() { Val = 1 },
                                new NumberingFormat() { Val = format },
                                new LevelText() { Val = levelText },
                                new PreviousParagraphProperties(
                                    new Indentation() { Left = leftMarginSize.ToString(CultureInfo.InvariantCulture), Hanging = "360" })
                            ) { LevelIndex = 0 }
                        ) { AbstractNumberId = currentNumId + 8 });
                mainPart.NumberingDefinitionsPart.Numbering.Save(mainPart.NumberingDefinitionsPart);
                mainPart.NumberingDefinitionsPart.Numbering.Append(
                    new NumberingInstance(
                            new AbstractNumId() { Val = currentNumId + 8 }
                        ) { NumberID = currentNumId });
                mainPart.NumberingDefinitionsPart.Numbering.Save(mainPart.NumberingDefinitionsPart);
                mainPart.NumberingDefinitionsPart.Numbering.Reload();
            }

            return currentNumId;
        }

        #endregion

        //____________________________________________________________________
        //
        // Properties Implementation

        public Int32 LevelRef
        {
            get { return numberLevelRef; }
        }
    }
}