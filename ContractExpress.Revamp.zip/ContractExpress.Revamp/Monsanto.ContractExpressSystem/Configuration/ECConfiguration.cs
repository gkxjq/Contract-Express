﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Configuration;
using System.Web;

namespace Bayer.BCS.ContractExpressSystem
{
    public class ECConfiguration
    {
        private ECFields _ECFields;
        public ECFields ECFields { get { return _ECFields; } }

        private string _TurnAroundTime;
        public string TurnAroundTime { get { return _TurnAroundTime; } }
        private string _SupportMail;
        public string SupportMail { get { return _SupportMail; } }
        private string _LegalTypeKey;
        public string LegalTypeKey { get { return _LegalTypeKey; } }
        private string _DOATypeKey;
        public string DOATypeKey { get { return _DOATypeKey; } }
        private string _MasterpageUrl;
        public string MasterpageUrl { get { return _MasterpageUrl; } }
        private string _ApprovalQuestionlistName;
        public string ApprovalQuestionlistName { get { return _ApprovalQuestionlistName; } }
        private string _ApprovalAnswerlistName;
        public string ApprovalAnswerlistName { get { return _ApprovalAnswerlistName; } }
        private string _NegotiationPositionListName;
        public string NegotiationPositionListName { get { return _NegotiationPositionListName; } }
        private string _MonsantoDivisionListName;
        public string MonsantoDivisionListName { get { return _MonsantoDivisionListName; } }
        private string _CountryListName;
        public string CountryListName { get { return _CountryListName; } }
        private string _DocumentTypeListName;
        public string DocumentTypeListName { get { return _DocumentTypeListName; } }
        private string _FunctionListName;
        public string FunctionListName { get { return _FunctionListName; } }
        private string _MonsantoEntityListName;
        public string MonsantoEntityListName { get { return _MonsantoEntityListName; } }
        private string _ContractTemplateLibraryName;
        public string ContractTemplateLibraryName { get { return _ContractTemplateLibraryName; } }
        //private string _QuestionsListName;
        //public string QuestionsListName { get { return _QuestionsListName; } }
        private string _ExpressContractLibraryName;
        public string ExpressContractLibraryName { get { return _ExpressContractLibraryName; } }
        private string _BookmarkListName;
        public string BookmarkListName { get { return _BookmarkListName; } }
        private string _SignaturesListName;
        public string SignaturesListName { get { return _SignaturesListName; } }
        private List<string> _BookmarkIgnoreList;
        public List<string> BookmarkIgnoreList { get { return _BookmarkIgnoreList; } }
        private string _LanguageListName;
        public string LanguageListName { get { return _LanguageListName; } }
        //private string _TranslationsListName;
        //public string TranslationsListName { get { return _TranslationsListName; } }

        //dcc
        private string _FieldMappingsListName;
        public string FieldMappingsListName { get { return _FieldMappingsListName; } }
        public string RegionListName { get; set; }
        private string _FCPASectionTitle;
        public string FCPASectionTitle { get { return _FCPASectionTitle; } }
        private string _FCPATypeKey;
        public string FCPATypeKey { get { return _FCPATypeKey; } }
        private string _ApprovalNotificationMail;
        public string ApprovalNotificationMail { get { return _ApprovalNotificationMail; } }
        private string _ApprovalNotificationAddress;
        public string ApprovalNotificationAddress { get { return _ApprovalNotificationAddress; } }
        private string _DraftContractsListName;
        public string DraftContractsListName { get { return _DraftContractsListName; } }
        private string _ContractSummaryPageMessage;
        public string ContractSummaryPageMessage { get { return _ContractSummaryPageMessage; } }
        private string _AccessDelegation;
        public string AccessDelegation { get { return _AccessDelegation; } }
        private string _MonsantoEntitiesRepresentativesListName;
        public string MonsantoEntitiesRepresentativesListName { get { return _MonsantoEntitiesRepresentativesListName; } }
        private string _MonsantoEntitiesSignatoriesInformationListName;
        public string MonsantoEntitiesSignatoriesInformationListName { get { return _MonsantoEntitiesSignatoriesInformationListName; } }
        private string _MonsantoEntitiesBankInformationListName;
        public string MonsantoEntitiesBankInformationListName { get { return _MonsantoEntitiesBankInformationListName; } }


        #region EmailTemplates
        private string _Approval_Notification_to_DOA_approved_by_legalEmailTemplate;
        public string Approval_Notification_to_DOA_approved_by_legalEmailTemplate { get { return _Approval_Notification_to_DOA_approved_by_legalEmailTemplate; } }

        private string _Approved_by_DOA_FCPA_relevantEmailTemplate;
        public string Approved_by_DOA_FCPA_relevantEmailTemplate { get { return _Approved_by_DOA_FCPA_relevantEmailTemplate; } }

        private string _Approved_by_legalEmailTemplate;
        public string Approved_by_legalEmailTemplate { get { return _Approved_by_legalEmailTemplate; } }

        private string _Approved_by_legal_DOA_FCPAEmailTemplate;
        public string Approved_by_legal_DOA_FCPAEmailTemplate { get { return _Approved_by_legal_DOA_FCPAEmailTemplate; } }

        private string _Approved_by_legal_and_DOAEmailTemplate;
        public string Approved_by_legal_and_DOAEmailTemplate { get { return _Approved_by_legal_and_DOAEmailTemplate; } }

        private string _BusinessPendingStatusNotificationEmailTemplate;
        public string BusinessPendingStatusNotificationEmailTemplate { get { return _BusinessPendingStatusNotificationEmailTemplate; } }
        #endregion

        public string ContractPortionsListName { get; set; }


		private string _ArchiveListName = "Archived Contracts";
		public string ArchiveListName { get { return _ArchiveListName; } }


        public ECConfiguration(SPWeb web)
        {
            //SPList cfg = web.Lists[ConfigurationManager.AppSettings["Configuration list name"]];
            SPList cfg = web.Lists["Configuration"];
            SPListItemCollection items = cfg.Items;
            _ECFields = new ECFields();

            foreach (SPListItem item in items)
            {
                if (item.Title.ToLower().Equals("monsanto entities bank information list name"))
                    _MonsantoEntitiesBankInformationListName = Convert.ToString(item["Value"]);

                if (item.Title.ToLower().Equals("monsanto entities signatories information list name"))
                    _MonsantoEntitiesSignatoriesInformationListName = Convert.ToString(item["Value"]);

                //if (item.Title.ToLower().Equals("monsanto entities representatives"))
                //    _MonsantoEntitiesRepresentativesListName = Convert.ToString(item["Value"]);

                if (item.Title.ToLower().Equals("contract portions list name"))
                    ContractPortionsListName = Convert.ToString(item["Value"]);

                if (item.Title.ToLower().Equals("region list name"))
                    RegionListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Draft Contracts List Name"))
                    _DraftContractsListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Turnaround Time (days)"))
                    _TurnAroundTime = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Support Contact Mail address"))
                    _SupportMail = Convert.ToString(item["Value"]);

//                if (item.Title.Equals("Express Contract Draft FieldName"))
//                    _ECFields.Draft = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Business User Fieldname"))
                    _ECFields.BusinessUser = Convert.ToString(item["Value"]);

                //if(item.Title.Equals("Template Choices Field"))
                //    _ECFields.TemplateChoices = Convert.ToString(item["Value"]);

                 if (item.Title.Equals("Express Contract Doa Approver Fieldname"))
                    _ECFields.DaoApprover = Convert.ToString(item["Value"]);
                
                if (item.Title.Equals("Express Contract Legal Approval Fieldname"))
                    _ECFields.LegalApproval = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Document Type Fieldname"))
                    _ECFields.DocumentType = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Doa Approval Fieldname"))
                    _ECFields.DoaApproval = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Doa Approval Comment Fieldname"))
                    _ECFields.DoaApprovalComment = Convert.ToString(item["Value"]);
                
                //if (item.Title.Equals("Express Contract Negotiation Position Fieldname"))
                //    _ECFields.NegotiationPosition = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Monsanto Division Fieldname"))
                    _ECFields.MonsantoDivision = Convert.ToString(item["Value"]);
                if (item.Title.Equals("Express Contract Monsanto Change Controle Fieldname"))
                    _ECFields.ChangeControle = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Function Fieldname"))
                    _ECFields.Function = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Country Fieldname"))
                    _ECFields.Country = Convert.ToString(item["Value"]);
                              

                if (item.Title.Equals("Express Contract Monsanto entity Fieldname"))
                    _ECFields.MonsantoEntity = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Legal Approval Comment Fieldname"))
                    _ECFields.LegalApprovalComment = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Legal Approval Fieldname"))
                    _ECFields.LegalApproval = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Doa Approval Comment Fieldname"))
                    _ECFields.FCPAApprovalComment = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract FCBA Approval Fieldname"))
                    _ECFields.FCPAApproval = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract FCBA Fieldname"))
                    _ECFields.FCPA = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Template Fieldname"))
                    _ECFields.Template = Convert.ToString(item["Value"]);
                
                if (item.Title.Equals("Express Contract Approval Answer Fieldname"))
                    _ECFields.ApprovalAnswer = Convert.ToString(item["Value"]);
                
                if (item.Title.Equals("Express Contract FCPA Approval Answer Fieldname"))
                    _ECFields.FcpaApprovalAnswer = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Legal action date Fieldname"))
                    _ECFields.LegalActionDate = Convert.ToString(item["Value"]);

                if (item.Title.Equals("DOA action date Fieldname"))
                    _ECFields.DOAActionDate = Convert.ToString(item["Value"]);

                if (item.Title.Equals("FCPA action date Fieldname"))
                    _ECFields.FCPAActionDate = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Legal Type Key"))
                    _LegalTypeKey = Convert.ToString(item["Value"]);

                if (item.Title.Equals("DOA Type Key"))
                    _DOATypeKey = Convert.ToString(item["Value"]);

                if (item.Title.Equals("FCPA Type Key"))
                    _FCPATypeKey = Convert.ToString(item["Value"]);

                //Ignores configuration list value
                if (item.Title.Equals("Masterpage url"))
                    _MasterpageUrl = "/_catalogs/masterpage/ContractExpressMaster.master";

                if (item.Title.Equals("Approval Question list name"))
                    _ApprovalQuestionlistName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Approval Answer list name"))
                    _ApprovalAnswerlistName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Negotiation position list name"))
                    _NegotiationPositionListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Monsanto Division list name"))
                    _MonsantoDivisionListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Country list name"))
                    _CountryListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Document Type list name"))
                    _DocumentTypeListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Function List name"))
                    _FunctionListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Monsanto Entity List name"))
                    _MonsantoEntityListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Monsanto Entity List name"))
                    _MonsantoEntityListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Contract Template Library Name"))
                    _ContractTemplateLibraryName = Convert.ToString(item["Value"]);

                //if (item.Title.Equals("Questions list Name"))
                //    _QuestionsListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Bookmark list Name"))
                    _BookmarkListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Express Contract Library Name"))
                    _ExpressContractLibraryName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Language List name"))
                    _LanguageListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Signatures list name"))
                    _SignaturesListName = Convert.ToString(item["Value"]);


                if (item.Title.Equals("FieldMappings List Name"))
                    _FieldMappingsListName = Convert.ToString(item["Value"]);

                //if (item.Title.Equals("Translation list  name"))
                //    _TranslationsListName = Convert.ToString(item["Value"]);

                if (item.Title.Equals("FCPA Approval Questions Section Title"))
                    _FCPASectionTitle = Convert.ToString(item["Value"]);

                #region Set Email Template Variables
                if (item.Title.Equals("Approval_Notification_to_DOA_approved_by_legal Email Template"))
                {
                    _Approval_Notification_to_DOA_approved_by_legalEmailTemplate = Convert.ToString(item["Value"]);
                }

                if (item.Title.Equals("Approved_by_DOA_FCPA_relevant Email Template"))
                {
                    _Approved_by_DOA_FCPA_relevantEmailTemplate = Convert.ToString(item["Value"]);
                }

                if (item.Title.Equals("Approved_by_legal Email Template"))
                {
                    _Approved_by_legalEmailTemplate = Convert.ToString(item["Value"]);
                }

                if (item.Title.Equals("Approved_by_legal_and_DOA Email Template"))
                {
                    _Approved_by_legal_and_DOAEmailTemplate = Convert.ToString(item["Value"]);
                }

                if (item.Title.Equals("Approved_by_legal_DOA_FCPA Email Template"))
                {
                    _Approved_by_legal_DOA_FCPAEmailTemplate = Convert.ToString(item["Value"]);
                }

                if (item.Title.Equals("BusinessPendingStatusNotification Email Template"))
                {
                    _BusinessPendingStatusNotificationEmailTemplate = Convert.ToString(item["Value"]);
                }
                #endregion

                if (item.Title.Equals("Document Rejection Comment Field"))
                    _ECFields.DocumentRejection = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Question Rejection Comment Field"))
                    _ECFields.QuestionRejection = Convert.ToString(item["Value"]);

                if(item.Title.Equals("Approval Notification Mail"))
                    _ApprovalNotificationMail =  Convert.ToString(item["Value"]);

                if (item.Title.Equals("Approval Notification Address"))
                    _ApprovalNotificationAddress = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Entity Signatory Field Name"))
                    _ECFields.EntitySignatory = Convert.ToString(item["Value"]);

                if (item.Title.Equals("CloneExpirationDate Field Name"))
                    _ECFields.CloneExpirationDate = Convert.ToString(item["Value"]);

                if (item.Title.Equals("Cloneable Field Name"))
                    _ECFields.Cloneable = Convert.ToString(item["Value"]);

                if (item.Title.Equals("AutomaticApproval Field Name"))
                    _ECFields.AutomaticApproval = Convert.ToString(item["Value"]);

                if (item.Title.Equals("CloningDate Field Name"))
                    _ECFields.CloningDate = Convert.ToString(item["Value"]);


                if (item.Title.Equals("Contract Summary Page Message"))
                {
                    if (Convert.ToString(item["Value"]) != "")
                        _ContractSummaryPageMessage = Convert.ToString(item["Value"]);
                    else
                        _ContractSummaryPageMessage = "[Add a new record with key 'Contract Summary Page Message' within 'Configuration' list to display custom message.]";
                }
                if (item.Title.Equals("Ignore bookmark starting with"))
                {
                    if (_BookmarkIgnoreList == null)
                        _BookmarkIgnoreList = new List<string>();
                    _BookmarkIgnoreList.Add(Convert.ToString(item["Value"]));
                }

                if (item.Title.Equals("FCPA_XML Field Name"))
                {
                    _ECFields.FCPA_XML = Convert.ToString(item["Value"]);
                }

                if (item.Title.Equals("CloneContractLink Field Name"))
                {
                    _ECFields.CloneContractLink = Convert.ToString(item["Value"]);
                }

                if (item.Title.Equals("Region Field Name"))
                {
                    _ECFields.Region = Convert.ToString(item["Value"]);
                }

                if (item.Title.Equals("Division Field Name"))
                {
                    _ECFields.Division = Convert.ToString(item["Value"]);
                }

                
            }

            //Column names not defined on Configuration list
            _ECFields.ClonedFromContractId = "Cloned from contract ID";
            _ECFields.AccessDelegation = "Access Delegation";

        }
    }
}
