﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.WebControls;
using System.Data;


namespace Monsanto.ContractExpressSystem
{
    public class NewQuestionForm : WebPartPage
    {
        #region controls

        protected TextBox txtAnswer;
        protected TextBox txtQuestion;
        protected DropDownList ddlDocType;
        protected DropDownList ddlTemplate;
        protected ListBox lstCandidate;
        protected ListBox lstCandidateOriginal;
        protected ListBox lstResult;
        protected Button btnSaveItem;
        protected HiddenField hdnResult;

        #endregion

        string sID = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            sID = Request.QueryString["ID"];

            if (!Page.IsPostBack)
            {
                FillDDLDocumentType();
                FillDDLContractTemplate();
                FillLSTCandidate();

                if (!string.IsNullOrEmpty(sID))
                {
                    string sTemplate = string.Empty;
                    string sQ_and_A = string.Empty;
                    string sDocType = string.Empty;
                    string sAnswer = string.Empty;
                    string sQuestion = string.Empty;

                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        try
                        {
                            SPListItem itemCol = ECContext.Current.Lists.Question.GetItemById(Convert.ToInt32(sID));
                            if (itemCol != null)
                            {
                                sAnswer = string.Empty;
                                if (itemCol["Answer"] != null)
                                    sAnswer = itemCol["Answer"].ToString();

                                sDocType = string.Empty;
                                if (itemCol["Document Type"] != null)
                                    sDocType = itemCol["Document Type"].ToString().Substring(0, itemCol["Document Type"].ToString().IndexOf(";#"));

                                sQuestion = string.Empty;
                                if (itemCol["Question"] != null)
                                    sQuestion = itemCol["Question"].ToString();

                                sTemplate = string.Empty;
                                if (itemCol["Template"] != null)
                                    sTemplate = itemCol["Template"].ToString().Substring(0, itemCol["Template"].ToString().IndexOf(";#"));
                                
                                txtAnswer.Text = sAnswer;
                                ddlDocType.SelectedValue = sDocType;
                                txtQuestion.Text = sQuestion;
                                ddlTemplate.SelectedValue = sTemplate;

                                if (itemCol["Redirect Question"] != null)
                                {
                                    
                                    SPFieldLookupValueCollection valueCol = itemCol["Redirect Question"] as SPFieldLookupValueCollection;
                                    foreach (SPFieldLookupValue question in valueCol)
                                    {
                                        ListItem item = new ListItem();
                                        item.Value = question.LookupId.ToString();

                                        SPListItem itmQuestion = ECContext.Current.Lists.Question.GetItemById(question.LookupId);

                                        sQ_and_A = string.Empty;
                                        if (itmQuestion["Q_and_A"] != null)
                                            sQ_and_A = itmQuestion["Q_and_A"].ToString().Substring(itmQuestion["Q_and_A"].ToString().IndexOf(";#") + 2);


                                        string info = sQ_and_A + " - " + item.Value +" - " + sTemplate;

                                        item.Text = sQ_and_A + " - " + item.Value;
                                        item.Attributes.Add("title", info);
                                        lstResult.Items.Add(item);
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                        }
                    });
                }
            }
        }

        private void FillDDLDocumentType()
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    try
                    {
                        SPQuery query = new SPQuery();
                        query.Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>";
                        ddlDocType.DataSource = ECContext.Current.Lists.DocumentType.GetItems(query);
                        ddlDocType.DataTextField = "Title";
                        ddlDocType.DataValueField = "ID";
                        ddlDocType.DataBind();

                        ddlDocType.Items.Insert(0, "(None)");
                    }
                    catch (Exception ex)
                    {
                        ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    }
                });
        }

        private void FillDDLContractTemplate()
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                try
                {
                    SPQuery query = new SPQuery();
                    query.Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>";
                    ddlTemplate.DataSource = ECContext.Current.Lists.ContractTemplate.GetItems(query);
                    ddlTemplate.DataTextField = "Title";
                    ddlTemplate.DataValueField = "ID";
                    ddlTemplate.DataBind();

                    ddlTemplate.Items.Insert(0, "(None)");
                }
                catch (Exception ex)
                {
                    ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                }
            });
        }

        private void FillLSTCandidate()
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                try
                {
                    string sItemText = string.Empty;
                    string info = string.Empty;
                    string DocType = string.Empty;
                    string sTemplate = string.Empty;
                    string sQ_and_A = string.Empty;
                    string sDocType = string.Empty;

                    foreach (SPListItem itm in ECContext.Current.Lists.Question.GetItems(new SPQuery()))
                    {
                        sTemplate = string.Empty;
                        if (itm["Template"] != null)
                            sTemplate = itm["Template"].ToString().Substring(itm["Template"].ToString().IndexOf(";#") + 2);

                        sQ_and_A = string.Empty;
                        if (itm["Q_and_A"] != null)
                            sQ_and_A = itm["Q_and_A"].ToString().Substring(itm["Q_and_A"].ToString().IndexOf(";#") + 2);

                        sDocType = string.Empty;
                        if (itm["Document Type"] != null)
                            sDocType = itm["Document Type"].ToString().Substring(0, itm["Document Type"].ToString().IndexOf(";#"));

                        sItemText = sQ_and_A + " - " + itm["ID"].ToString();
                        info = sQ_and_A + " - " + itm["ID"].ToString() + " - " + sTemplate;
                        DocType = sDocType;


                        ListItem tmp = new ListItem(sItemText, itm.ID.ToString());
                        tmp.Attributes.Add("title", info);
                        tmp.Attributes.Add("DocType", DocType);

                        lstCandidate.Items.Add(tmp);
                        lstCandidateOriginal.Items.Add(tmp);
                    }
                }
                catch (Exception ex)
                {
                    ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                }
            });
        }

        protected void btnSaveItem_Click(object sender, EventArgs e)
        {
            if (txtQuestion.Text != "")
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    try
                    {
                        string Answer = txtAnswer.Text;
                        ListItem DocType = ddlDocType.SelectedItem;
                        string Question = txtQuestion.Text;
                        ListItem Template = ddlTemplate.SelectedItem;

                        SPList QuestionList = ECContext.Current.Lists.Question;

                        SPListItem item = null;
                        if (sID != null && sID != string.Empty)
                            item = QuestionList.GetItemById(Convert.ToInt32(sID));
                        else
                            item = QuestionList.Items.Add();

                        item["Answer"] = Answer;

                        if (DocType.Value != "(None)")
                            item["Document Type"] = DocType.Value + ";#" + DocType.Text;
                        else
                            item["Document Type"] = "";
                        item["Question"] = Question;

                        if (Template.Value != "(None)")
                            item["Template"] = Template.Value + ";#" + Template.Text;
                        else
                            item["Template"] = "";

                        SPFieldLookupValueCollection lookupCol = new SPFieldLookupValueCollection();

                        char[] splitchar = { '|' };
                        string[] res = hdnResult.Value.Split(splitchar);

                        foreach (string itm in res)
                        {
                            if (itm != "")
                            {
                                string val = itm.Substring(0, itm.IndexOf(";#"));
                                SPFieldLookupValue lookupValue = new SPFieldLookupValue();
                                lookupValue.LookupId = Convert.ToInt32(val);
                                lookupCol.Add(lookupValue);
                            }
                        }
                        item["Redirect Question"] = lookupCol;

                        item.Update();
                        QuestionList.Update();

                        this.Page.ClientScript.RegisterStartupScript(this.GetType(), "PopupScript", "SP.UI.ModalDialog.commonModalDialogClose(1, 1);", true);
                    }
                    catch (Exception ex)
                    {
                        ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    }
                });
            }
        }
    }
}
