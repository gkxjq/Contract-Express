﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using System.Web.UI;
using System.Data;
using System.Linq;
using System.Data.Linq;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using Microsoft.SharePoint.Utilities;
using System.Web;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Reflection;
using System.Globalization;
using Monsanto.ContractExpressSsytem.HtmlToOpenXml;
using Microsoft.SharePoint.Administration;
using System.Text.RegularExpressions;


using Newtonsoft.Json;
using System.Threading;
using DocumentFormat.OpenXml.Wordprocessing;


namespace Monsanto.ContractExpressSystem
{
    public class ContractExpressSystem : ECFormBase
    {

        #region controls
        // Type prefixes for controls
        private static readonly string pfx_empty = String.Empty;
        private static readonly string pfx_date = "Dyna_date_";
        private static readonly string pfx_rtf = "Dyna_RichText_";
        protected Dictionary<string, Func<string>> field_mappings;
        protected Panel pnl;
        protected Panel pnlStepThree;
        protected Panel pnlStepFour;
        protected Label lblMonsantoAddress;
        protected Label lblMonsantoJurisdiction;
        protected Label lblMonsantoIdNr;
        //protected Label lblMonsantoReprese;
        protected Label lblMonsantoRegistration;
        protected Label lblMonsantoCapitalAmount;
        //protected Label lblMonsantoRepreseTitle;
        protected Label lblMonsantoEntityType;
        protected DropDownList ddlDocType;
        protected DropDownList ddlFunction;
        protected DropDownList ddlMonsantoEntity;
        protected DropDownList ddlCountry;
        protected DropDownList ddlMonsantoDivision;
        //protected DropDownList ddlNegotiation;
        protected DropDownList ddlLanguage;
        protected RadioButtonList lstQuestions;
        protected PlaceHolder DynaCtrlsLeft;
        protected PlaceHolder DynaCtrlsRight;
        protected PlaceHolder DynaCtrlsMiddle;
        protected TextBox txtFilename;
        protected HiddenField hdnQuestions;
        protected HiddenField hdnCounterparty;
        protected HiddenField hdnLanguage;
        protected HiddenField hdnDays;
        protected HiddenField hdnMonths;
        protected HiddenField hdnTemplateChoices;
        protected HiddenField hdnBookmarksShown;
        protected HiddenField hdnCloneContractParentId;
        protected Panel pnlStepCloneContract;
        protected LinkButton showCloned;
        protected LinkButton showRegular;
        protected System.Web.UI.WebControls.ListView listViewContractSelection;
        protected Panel pnlCloneContractSelection;
        protected PlaceHolder Dyna_FCPA_Ctrls;
        protected TextBox sapVendorNumberTxt;
        protected System.Web.UI.Timer keepMeAliveTimer;



        // JSON-encoded list values
        protected HiddenField hdnBookmarkValues;
        protected PeopleEditor DoaAdmin;
        private static DataTable Bookmarks;
        //private static DataTable QuestionData;
        Dictionary<string, ECContext.Bookmark> _clonedContractBookmarks = new Dictionary<string, ECContext.Bookmark>();
        SPListItem _clonedContractItem = null;
        //private static List<string> Templates;
        #endregion

        #region Variables

        protected HtmlInputFile inputFile;
        protected Button btnUpload;
        private GridView dgdUpload;
        private string fileName = "";
        private HyperLinkField hlnkFileName;
        private CommandField cmdDelete;
        protected PlaceHolder DynaCtrls;
        DataTable dt;//datatable use for multiple file upload
        DataRow dr;//datarow use for multiple file upload
        DataColumn dc;//datacolumn use for multiple file upload
        private int? _clonedContractId;
        protected HiddenField hdnAnswers;
        protected HiddenField hdn_FCPA_Answers;


        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(hdnCloneContractParentId.Value))
            {
                _clonedContractItem = ECContext.Current.Lists.ExpressContract.GetItemById(int.Parse(hdnCloneContractParentId.Value));
                _clonedContractBookmarks = ECContext.OpenXml.FindBookmarksAndContent(_clonedContractItem.File.OpenBinaryStream());
            }
        }

        protected override void CreateChildControls()
        {
            try
            {
                hdnBookmarksShown.Value = "";
                if (!IsPostBack)
                {
                    CreateQuestions();
                }

                #region GridView

                this.dgdUpload = new GridView();
                this.hlnkFileName = new HyperLinkField();
                this.hlnkFileName.DataTextField = "FileName";
                this.hlnkFileName.DataNavigateUrlFormatString = "FilePath";
                this.hlnkFileName.HeaderText = "FileName";
                //this.bndFileSize = new BoundField();
                //this.bndFileSize.HeaderText = "FileSize";
                //this.bndFileSize.DataField = "FileSize";
                //this.bndFileSize.ControlStyle.CssClass = "gvCell";
                //this.bndFileKb = new BoundField();
                //this.bndFileKb.HeaderText = "";
                //this.bndFileKb.DataField = "KB";
                this.cmdDelete = new CommandField();
                this.cmdDelete.HeaderText = "";
                this.cmdDelete.ButtonType = ButtonType.Link;
                this.cmdDelete.InsertImageUrl = "delete.gif";
                this.cmdDelete.DeleteText = "Delete";
                this.cmdDelete.ShowDeleteButton = true;
                this.dgdUpload.ID = "_dgdFileUpload";
                this.dgdUpload.Columns.Add(hlnkFileName);
                //this.dgdUpload.Columns.Add(bndFileSize);
                //this.dgdUpload.Columns.Add(bndFileKb);
                this.dgdUpload.Columns.Add(cmdDelete);
                this.dgdUpload.AutoGenerateColumns = false;
                this.dgdUpload.CssClass = "gvNewContract";
                this.dgdUpload.RowDeleting += new GridViewDeleteEventHandler(dgdUpload_RowDeleting);

                #endregion

                #region Add Controls

                //this.DynaCtrls.Controls.Add(inputFile);
                //this.DynaCtrls.Controls.Add(lblMessage);
                //this.DynaCtrls.Controls.Add(btnUpload);
                this.DynaCtrls.Controls.Add(dgdUpload);
                base.CreateChildControls();

                CreateFCPAQuestions();

                //Init Sap Vendor
                if (_clonedContractId.HasValue)
                {
                    SPList expresscontractList = ECContext.Current.Lists.ExpressContract;
                    SPListItem contractItem = expresscontractList.GetItemById(_clonedContractId.Value);
                    if (contractItem != null)
                        sapVendorNumberTxt.Text = (string)contractItem["Sap Vendor Number"];
                }

                #endregion

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

        }

        protected void keepMeAliveTimerTick(object sender, EventArgs e)
        {

        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            try
            {
                field_mappings = new Dictionary<string, Func<string>>
				{
					{ ECContext.Current.Configuration.ECFields.MonsantoEntity, () => ddlMonsantoEntity.SelectedItem.Text },
					{ ECContext.Current.Configuration.ECFields.Country, () => ddlCountry.SelectedItem.Text },
					{ ECContext.Current.Configuration.ECFields.Function, () => ddlFunction.SelectedItem.Text },
					{ ECContext.Current.Configuration.ECFields.MonsantoDivision, () => ddlMonsantoDivision.SelectedItem.Text },
					//{ ECContext.Current.Configuration.ECFields.NegotiationPosition, () => ddlNegotiation.SelectedItem.Text },
					{ "Address", () =>  lblMonsantoAddress.Text },
					{ "Jurisdiction", () =>  lblMonsantoJurisdiction.Text },
					{ "Id_x0020_Number", () =>  lblMonsantoIdNr.Text },
					{ "Registration_x0020_#", () =>  lblMonsantoRegistration.Text },
					{ "Capital_x0020_Amount", () => lblMonsantoCapitalAmount.Text },
					{ "Entity_x0020_Type", () =>  lblMonsantoEntityType.Text }
				};

                if (!IsPostBack)
                {
                    try
                    {
                        BindDropDownList(ddlDocType, ECContext.Current.Lists.DocumentType.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
                        BindDropDownList(ddlFunction, ECContext.Current.Lists.Function.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
                        BindDropDownList(ddlLanguage, ECContext.Current.Lists.Language.GetItems(new SPQuery() { Query = "<Where><IsNotNull><FieldRef Name='CultureInfo'/></IsNotNull></Where><OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }), "Title", "CultureInfo");
                        //BindDropDownList(ddlNegotiation, ECContext.Current.Lists.Negotiation.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
                        BindDropDownList(ddlMonsantoDivision, ECContext.Current.Lists.MonsantoDivision.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));

                        // Force English to be default language
                        ddlLanguage.SelectedValue = "en-GB";
                    }
                    catch
                    {
                        throw new Exception("There was an error binding the internal data to the main drop down lists");
                    }

                    if (ddlMonsantoEntity.SelectedItem != null)
                    {
                        try
                        {
                            SPListItem item = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));
                            lblMonsantoAddress.Text = Convert.ToString(item["Address"]);
                            lblMonsantoJurisdiction.Text = Convert.ToString(item["Jurisdiction"]);
                            lblMonsantoCapitalAmount.Text = Convert.ToString(item["Capital_x0020_Amount"]);
                            lblMonsantoIdNr.Text = Convert.ToString(item["Id_x0020_Number"]);
                            lblMonsantoRegistration.Text = Convert.ToString(item["Registration_x0020__x0023_"]);
                            lblMonsantoEntityType.Text = new SPFieldLookupValue(Convert.ToString(item["Entity_x0020_Type"])).LookupValue;

                            txtFilename.Text = string.Format("{0}_{1}_{2}_{3}", DateTime.Now.ToString("yyMMddHHmm"), ddlDocType.SelectedItem.Text, string.IsNullOrEmpty(hdnCounterparty.Value) ? "[counterparty]" : hdnCounterparty.Value, Convert.ToString(item["Abbreviation"]));
                        }
                        catch
                        {
                            throw new Exception("There was an error binding the data of the Monsanto Entity");
                        }
                    }
                    else
                    {
                        lblMonsantoAddress.Text = string.Empty;
                        lblMonsantoJurisdiction.Text = string.Empty;
                        lblMonsantoCapitalAmount.Text = string.Empty;
                        lblMonsantoIdNr.Text = string.Empty;
                        lblMonsantoRegistration.Text = string.Empty;
                        lblMonsantoEntityType.Text = string.Empty;
                        txtFilename.Text = string.Format("{0}_{1}_{2}_[Monsanto entity]", DateTime.Now.ToString("yyMMddHHmm"), ddlDocType.SelectedItem.Text, string.IsNullOrEmpty(hdnCounterparty.Value) ? "[counterparty]" : hdnCounterparty.Value);
                    }

                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void BindDropDownList(DropDownList ddl, SPList lst)
        {
            try
            {
                BindDropDownList(ddl, lst.GetItems(new SPQuery() { RowLimit = 1000 }));
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void BindDropDownList(DropDownList ddl, SPListItemCollection lst)
        {
            try
            {
                ddl.DataSource = lst;
                ddl.DataValueField = lst.List.Fields[SPBuiltInFieldId.ID].InternalName;
                ddl.DataTextField = lst.List.Fields[SPBuiltInFieldId.Title].InternalName;
                ddl.DataBind();
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(String.Format("Error loading values for the list {0}: {1}", lst.List.Title, ex.Message), ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void BindDropDownList(DropDownList ddl, SPListItemCollection lst, string customTextField, string customValueField)
        {
            try
            {
                ddl.DataSource = lst.GetDataTable();
                ddl.DataValueField = lst.List.Fields[customValueField].InternalName;
                ddl.DataTextField = lst.List.Fields[customTextField].InternalName;
                ddl.DataBind();
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(String.Format("Error loading values for the list {0}: {1}", lst.List.Title, ex.Message), ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private struct QuestionControl
        {
            public int Id { get; set; }
            public string Question { get; set; }
            public string Answer { get; set; }
            public SPFieldLookupValue Template { get; set; }
            public SPFieldLookupValueCollection Redirect { get; set; }
            public bool HasParent { get; set; }
            public string ParentId { get; set; }
        }

        private bool CreateQuestions()
        {
            string templateName = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(hdnQuestions.Value))
                {
                    string qxml = string.Concat("<question>", hdnQuestions.Value, "</question>");
                    if (!hdnTemplateChoices.Value.EndsWith(qxml))
                        hdnTemplateChoices.Value += qxml;
                }

                pnl.Controls.Clear();
                SPListItemCollection templates;
                // Load all templates  for a specific language
                try
                {
                    templates = ECContext.Current.Lists.ContractTemplate.GetItems(new SPQuery() { Query = string.Format("<Where><Eq><FieldRef Name=\"Language\" /><Value Type=\"Lookup\">{0}</Value></Eq></Where>", ddlLanguage.SelectedItem.Text) });

                }
                catch
                {
                    throw new Exception("There was en error creating the questions. The application cannot get the templates for your language");
                }
                SPListItemCollection questions;
                Dictionary<string, StringBuilder> toCreate;
                // Load all questions related to the chosen document type
                try
                {
                    questions = ECContext.Current.Lists.Question.GetItems(new SPQuery() { Query = string.Format("<Where><Eq><FieldRef Name='Document_x0020_Type' /><Value Type='Lookup'>{0}</Value></Eq></Where><OrderBy><FieldRef Name='Title' Ascending='False' /></OrderBy>", ddlDocType.SelectedItem.Text) });
                    toCreate = new Dictionary<string, StringBuilder>();
                    if (questions.Count == 0)
                    {

                        return false;
                    }
                }
                catch
                {
                    throw new Exception("There was en error creating the questions. The application cannot get the questions of the seletected template");
                }


                List<QuestionControl> possibilities = new List<QuestionControl>();

                foreach (SPListItem question in questions)
                {
                    try
                    {
                        QuestionControl qcontrol = new QuestionControl()
                        {
                            Id = question.ID,
                            Question = string.Format("<div class=\"DynaLabel\" ><span>{0}</span></div>", Convert.ToString(question["Question"]).Trim()),
                            Answer = string.Format("<a class=Answers onclick=\"javascript:setQuestion('{0}')\">{1}</a><br />", question.ID, Convert.ToString(question["Answer"]).Trim())
                        };

                        if (question["Template"] != null && Convert.ToString(question["Template"]) != "0;#")
                        {
                            // if this question leads directly to a template just add it
                            SPFieldLookupValue template = new SPFieldLookupValue(Convert.ToString(question["Template"]));
                            if (templates.GetDataTable().AsEnumerable().Where(listitem => Convert.ToInt32(listitem["ID"]) == template.LookupId).Count() > 0)
                            {
                                qcontrol.Template = template;
                                possibilities.Add(qcontrol);
                            }
                        }
                        else if (question["Redirect_x0020_Question"] != null)
                        {
                            // if this question leads to another qestion find redirect an add it
                            SPFieldLookupValueCollection redirects = new SPFieldLookupValueCollection(Convert.ToString(question["Redirect_x0020_Question"]));
                            qcontrol.Redirect = redirects;
                            possibilities.Add(qcontrol);
                        }
                    }
                    catch
                    {
                        throw new Exception("There was an error creating one of the questions.");
                    }
                }


                // filter out all the questions that do not lead to a valid template
                try
                {
                    for (int i = possibilities.Count - 1; i >= 0; i--)
                    {
                        QuestionControl question = possibilities[i];
                        if (!FindTemplate(question, possibilities))
                        {
                            possibilities.RemoveAt(i);
                            continue;
                        }
                        int parentId;
                        if (FindParents(question, possibilities, out parentId))
                        {
                            question.HasParent = true;
                            question.ParentId = parentId.ToString();
                        }

                        possibilities[i] = question;
                    }
                }
                catch
                {
                    throw new Exception("There was en error filtering the questions.");
                }

                bool templateFound = false;

                if (possibilities.Count > 0)
                {
                    try
                    {
                        foreach (QuestionControl question in possibilities)
                        {
                            if ((string.IsNullOrEmpty(hdnQuestions.Value) && !question.HasParent)
                                || (hdnQuestions.Value == question.ParentId)
                                || (hdnQuestions.Value == question.Id.ToString() && question.Template != null))
                            {
                                if (toCreate.ContainsKey(question.Question))
                                    toCreate[question.Question].AppendLine(question.Answer);
                                else
                                    toCreate.Add(question.Question, new StringBuilder(question.Answer));

                                templateFound = (hdnQuestions.Value == question.Id.ToString() && question.Template != null);
                            }
                        }
                    }
                    catch
                    {
                        throw new Exception("There was en error determining the hierarchy of the questions.");
                    }

                    try
                    {
                        foreach (KeyValuePair<string, StringBuilder> control in toCreate)
                        {
                            pnl.Controls.Add(new LiteralControl(control.Key));
                            pnl.Controls.Add(new LiteralControl(control.Value.ToString()));
                        }
                    }
                    catch
                    {
                        throw new Exception("There was en error rendering questions.");
                    }
                }
                else
                    pnl.Controls.Add(new LiteralControl(string.Format("<div class=\"DynaLabel\" ><span>{0}</span></div>", "There are no available templates for this selection. Please, select a different language or document type.")));

                if (templateFound)
                {
                    if (pnlStepCloneContract.Visible == false)
                    {
                        SPFieldLookupValue template = new SPFieldLookupValue(Convert.ToString(ECContext.Current.Lists.Question.GetItemById(Convert.ToInt32(hdnQuestions.Value))["Template"]));
                        templateName = template.LookupValue;
                        DataTable filteredBookmarks = ECContext.Current.Lists.Bookmark.GetItems(new SPQuery { Query = String.Format("<Where><Eq><FieldRef Name=\"Template\"/><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) }).GetDataTable();
                        CheckTemplateSanity(filteredBookmarks, template.LookupId);
                    }
                    pnlStepCloneContract.Visible = true;

                    FindContractsToClone();
                }

                return templateFound;
            }
            catch (ECValidationException ex)
            {

                ECContext.LogEvent("INVALID TEMPLATE: " + ex.Message, ex, ECContext.TraceLevel.Information);

                Panel errPnl = new Panel();
                errPnl.CssClass = "errPnl";

                Image errImg = new Image();
                errImg.ImageUrl = "../../Style%20Library/Images/error-24.png";
                errImg.CssClass = "errImg";
                errPnl.Controls.Add(errImg);

                Literal errMsg = new Literal();
                errMsg.Text = @"<strong>Bookmarks configuration for this contract template is incorrect. Please correct the following errors before using this template:</strong><br/><br/>"
                                + ex.Message +
                                "<br/><br/> Contact the system administrator for support <br/>(Template name: " + templateName + ")";

                pnlStepThree.Controls.Clear();
                pnlStepFour.Controls.Clear();
                errPnl.Controls.Add(errMsg);
                pnlStepThree.Controls.Add(errPnl);

                pnlStepThree.Visible = true;
                pnlStepCloneContract.Visible = false;
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

            return false;
        }

        private bool FindParents(QuestionControl question, List<QuestionControl> list, out int id)
        {
            id = -1;
            foreach (QuestionControl redirectControl in list)
                if (redirectControl.Redirect != null)
                    foreach (SPFieldLookupValue nestedItem in redirectControl.Redirect)
                        if (nestedItem.LookupId == question.Id)
                        {
                            id = redirectControl.Id;
                            return true;
                        }
            return false;

        }

        private bool FindTemplate(QuestionControl control, List<QuestionControl> list)
        {
            if (control.Template != null)
                return true;

            foreach (SPFieldLookupValue nestedItem in control.Redirect)
            {
                foreach (QuestionControl redirectControl in list)
                    if (redirectControl.Id == nestedItem.LookupId)
                    {
                        if (redirectControl.Template != null)
                            return true;
                        else
                            return FindTemplate(redirectControl, list);
                    }
            }
            return false;
        }

        private void CheckTemplateSanity(DataTable dt, int templateId)
        {
            StringBuilder validationErrors = new StringBuilder();

            if (dt == null)
            {
                validationErrors.AppendLine("Template contains no bookmarks.<br/>");
                throw new ECValidationException(String.Empty, validationErrors.ToString());
            }

            var bookmarks = from bookmark in dt.AsEnumerable()
                            select new ECContext.Bookmark { Name = bookmark.Field<string>("Title"), DataValue = bookmark.Field<string>("Data_x0020_Value"), DataType = bookmark.Field<string>("Data_x0020_Type"), Description = bookmark.Field<string>("Bookmark_x0020_Description"), Mapping = bookmark.Field<string>("FieldMapping"), LongDescription = bookmark.Field<string>("Long_x0020_Description") };

            //Check counterparty is mapped
            if (!bookmarks.Any(bm => bm.Mapping == "Counterparty"))
                validationErrors.AppendLine("A template must contain a bookmark mapped to 'Counterparty' value.<br/>");

            //Check unique bookmark name
            if (bookmarks.GroupBy(b => b.Name).All(x => x.Count() == 1) == false)
                validationErrors.AppendLine("There is at least one bookmark name repeated.<br/>");

            //Check template is valid (all bookmarks on list for this template are present on document template)
            SPListItem templateItem = ECContext.Current.Lists.ContractTemplate.GetItemById(templateId);
            Dictionary<string, ECContext.Bookmark> templateBookmarks = ECContext.OpenXml.FindBookmarks(templateItem.File.OpenBinaryStream());

            if (bookmarks.Any(b => templateBookmarks.Where(b2 => b2.Value.Name == b.Name).Count() == 0))
            {
                string MissingBookmarks = GetBookmarkDiferences(templateBookmarks, bookmarks);
                validationErrors.AppendLine("The bookmarks within template file don't match the ones defined in 'Bookmark' list for this template. Bookmarks missing: " + MissingBookmarks + "<br/>");
            }

            //Check if contract template has more user defined bookmarks than created on list for this template
            if (validationErrors.Length == 0 && templateBookmarks.Count > bookmarks.Count())
            {
                ECContext.LogEvent("Template '" + templateItem.Title + "' contains bookmarks tha aren't defined on 'Bookmark' list for this template. Following bookmarks are missing on list for this template: " + DistinctBookmarks(templateBookmarks, bookmarks.ToList()), null, ECContext.TraceLevel.Template);
                CEJSUtil.PopInfo(Page, ECContext.Messages.InfoPopupTitle, ECContext.Messages.MissingBookmarksOnListInfo + "<br/><br/>Missing bookmarks: " + DistinctBookmarks(templateBookmarks, bookmarks.ToList()) + "<br/>");
            }

            //Raise exception if errors found
            if (validationErrors.Length > 0)
                throw new ECValidationException(String.Empty, validationErrors.ToString());
        }

        //Return the names of the bookmarks not present on the template, but present on the list.
        private string GetBookmarkDiferences(Dictionary<string, ECContext.Bookmark> templateBookmarks, EnumerableRowCollection<ECContext.Bookmark> bookmarks)
        {
            string BookmarksFound = string.Empty;
            foreach (ECContext.Bookmark templBookmark in bookmarks)
            {
                if (!templateBookmarks.ContainsKey(templBookmark.Name))
                    BookmarksFound += templBookmark.Name + ", ";
            }
            if (BookmarksFound.Length > 2)
                BookmarksFound = BookmarksFound.Substring(0, BookmarksFound.Length - 2);

            return BookmarksFound;
        }

        //Return the names of the bookmarks not present on the list, but present on template.
        private string DistinctBookmarks(Dictionary<string, ECContext.Bookmark> templateBookmarks, List<ECContext.Bookmark> listBookmarks)
        {
            string distinctBookmarks = " ";

            foreach (KeyValuePair<string, ECContext.Bookmark> bookmark in templateBookmarks)
            {
                if (listBookmarks.Where(b => b.Name == bookmark.Value.Name).Count() == 0)
                {
                    distinctBookmarks += " " + bookmark.Value.Name + ",";
                }
            }

            return distinctBookmarks.Substring(0, distinctBookmarks.Length - 1);
        }


        private void CreateBookmark()
        {
            DynaCtrlsLeft.Controls.Clear();
            DynaCtrlsMiddle.Controls.Clear();   //Not used?
            DynaCtrlsRight.Controls.Clear();    //Not used?

            Hashtable descriptions = new Hashtable();

            string templateName = String.Empty;

            try
            {
                SPFieldLookupValue template = new SPFieldLookupValue(Convert.ToString(ECContext.Current.Lists.Question.GetItemById(Convert.ToInt32(hdnQuestions.Value))["Template"]));
                templateName = template.LookupValue;
                DataTable filteredBookmarks = ECContext.Current.Lists.Bookmark.GetItems(new SPQuery { Query = String.Format("<Where><Eq><FieldRef Name=\"Template\"/><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) }).GetDataTable();

                //CheckTemplateSanity(filteredBookmarks, template.LookupId);

                var bookmarks = from bookmark in filteredBookmarks.AsEnumerable()
                                where (string.IsNullOrEmpty(bookmark.Field<string>("FieldMapping")) || bookmark.Field<string>("FieldMapping") == "Counterparty")
                                select new { Name = bookmark.Field<string>("Title"), DataValue = bookmark.Field<string>("Data_x0020_Value"), DataType = bookmark.Field<string>("Data_x0020_Type"), Description = bookmark.Field<string>("Bookmark_x0020_Description"), Mapping = bookmark.Field<string>("FieldMapping"), LongDescription = bookmark.Field<string>("Long_x0020_Description") };

                #region Process bookmarks
                foreach (var bookmark in bookmarks)
                {
                    PlaceHolder DynaCtrls;
                    DynaCtrls = DynaCtrlsLeft;
                    bool isCounterparty = (bookmark.Mapping == "Counterparty");
                    Label lbl = new Label();
                    lbl.CssClass = "DynaLabel ";

                    string description = (string.IsNullOrEmpty(bookmark.Description) ? "" : bookmark.Description.TrimEnd());
                    if (!string.IsNullOrEmpty(description) && descriptions.ContainsKey(description))
                    {
                        if (bookmark.DataType == "Date")
                        {
                            HtmlInputText txt = ((HtmlInputText)descriptions[description]);
                            txt.Attributes["onchange"] = txt.Attributes["onchange"] + string.Format("fillValue('{0}',{1}); ", bookmark.Name, txt.ClientID);
                            txt.Attributes["data-ce-aliases"] = (" " + txt.Attributes["data-ce-aliases"] + " " + bookmark.Name).Trim();

                        }
                        else
                        {
                            WebControl ctrl = ((WebControl)descriptions[description]);
                            if (bookmark.DataType == "Text" && isCounterparty)
                                ctrl.Attributes.Add("onblur", string.Format("setNameAndFillValue('{0}',{1}); ", bookmark.Name, ctrl.ClientID));
                            else
                                ctrl.Attributes["onchange"] = ctrl.Attributes["onchange"] + string.Format("fillValue('{0}',{1}); ", bookmark.Name, ctrl.ClientID);

                        }
                        continue;  //If description is empty or already exists we don't show it on the screen
                    }

                    bool bookMarkIsPresent = _clonedContractItem == null || (_clonedContractItem != null && _clonedContractBookmarks.ContainsKey(bookmark.Name));

                    var fieldLabel = new LiteralControl(String.Format("<div class='ms-field-label'>{0}{1}</div>", string.IsNullOrEmpty(description) ? bookmark.Name : description, bookMarkIsPresent ? string.Empty : "<strong>  (This bookmark was removed from cloned contract)</strong>"));
                    DynaCtrls.Controls.Add(fieldLabel);

                    //lbl.Text = string.IsNullOrEmpty(description) ? bookmark.Name : description;
                    //DynaCtrls.Controls.Add(lbl);

                    Panel pnl = new Panel();
                    DynaCtrls.Controls.Add(pnl);

                    //Hide control if bookmark is not present in cloned contract 
                    if (bookMarkIsPresent)
                    {
                        if (bookmark.DataType == "Numeric")
                        {
                            TextBox numCtrl = new TextBox();
                            numCtrl.ID = string.Format("Dyna{0}", bookmark.Name);
                            numCtrl.CssClass = "ms-inputuserfield DynText ce-bookmark ";
                            numCtrl.Attributes.Add("data-ce-bookmark-name", bookmark.Name);

                            pnl.Controls.Add(numCtrl);
                            numCtrl.Attributes.Add("onchange", string.Format("convertAndFillValue('{0}',{1}); ", bookmark.Name, numCtrl.ClientID));
                            if (!string.IsNullOrEmpty(description))
                                descriptions.Add(description, numCtrl);

                            //Set value if cloned
                            numCtrl.Text = _clonedContractBookmarks.ContainsKey(bookmark.Name) ? _clonedContractBookmarks[bookmark.Name].Content : String.Empty;

                            //Add tooltip
                            if (!String.IsNullOrEmpty(bookmark.LongDescription))
                                numCtrl.Attributes.Add("title", bookmark.LongDescription);
                        }

                        if (bookmark.DataType == "Text")
                        {
                            TextBox newCtrl = new TextBox();
                            newCtrl.ID = string.Format("Dyna{0}", bookmark.Name);
                            newCtrl.CssClass = "ms-inputuserfield DynText ce-bookmark " + (isCounterparty ? "ce-bookmark-counterparty" : "");
                            newCtrl.Attributes.Add("data-ce-bookmark-name", bookmark.Name);
                            newCtrl.MaxLength = 100;
                            pnl.Controls.Add(newCtrl);
                            if (!isCounterparty)
                            {
                                newCtrl.Attributes.Add("onchange", string.Format("fillValue('{0}',{1}); ", bookmark.Name, newCtrl.ClientID));
                            }
                            else
                            {
                                newCtrl.Attributes.Add("onblur", string.Format("setNameAndFillValue('{0}',{1}); ", bookmark.Name, newCtrl.ClientID));
                            }
                            if (!string.IsNullOrEmpty(description))
                                descriptions.Add(description, newCtrl);

                            //Set value if cloned
                            newCtrl.Text = _clonedContractBookmarks.ContainsKey(bookmark.Name) ? _clonedContractBookmarks[bookmark.Name].Content : String.Empty;

                            //Add tooltip
                            if (!String.IsNullOrEmpty(bookmark.LongDescription))
                                newCtrl.Attributes.Add("title", bookmark.LongDescription);

                        }

                        if (bookmark.DataType == "Date")
                        {
                            HtmlInputText newCalCtrl = new HtmlInputText();
                            newCalCtrl.ID = string.Format("Dyna_date_{0}", bookmark.Name);
                            newCalCtrl.Attributes.Add("class", "ms-inputuserfield datepicker ce-bookmark ");
                            newCalCtrl.Attributes.Add("data-ce-bookmark-name", bookmark.Name);
                            newCalCtrl.Attributes.Add("readonly", "readonly");

                            newCalCtrl.Value = "Click to select a date";
                            pnl.Controls.Add(newCalCtrl);
                            newCalCtrl.Attributes.Add("onchange", string.Format("fillValue('{0}',{1}); ", bookmark.Name, newCalCtrl.ClientID));



                            if (!string.IsNullOrEmpty(description))
                                descriptions.Add(description, newCalCtrl);

                            if (string.IsNullOrEmpty(hdnLanguage.Value))
                            {
                                hdnLanguage.Value = ddlLanguage.SelectedItem.Value;
                                hdnMonths.Value = string.Join(" ", new System.Globalization.CultureInfo(ddlLanguage.SelectedItem.Value).DateTimeFormat.MonthNames);
                                hdnDays.Value = string.Join(" ", new System.Globalization.CultureInfo(ddlLanguage.SelectedItem.Value).DateTimeFormat.ShortestDayNames);
                            }

                            //Set value if cloned
                            newCalCtrl.Value = _clonedContractBookmarks.ContainsKey(bookmark.Name) ? _clonedContractBookmarks[bookmark.Name].Content : String.Empty;

                            //Add tooltip
                            if (!String.IsNullOrEmpty(bookmark.LongDescription))
                                newCalCtrl.Attributes.Add("title", bookmark.LongDescription);

                        }
                        if (bookmark.DataType == "Bulleted list")
                        {
                            var txtbox = new InputFormTextBox { RichTextMode = SPRichTextMode.Compatible, RichText = true };
                            txtbox.TextMode = TextBoxMode.MultiLine;
                            txtbox.Rows = 4;
                            txtbox.ID = String.Format("Dyna_RichText_{0}", bookmark.Name);
                            txtbox.Attributes.Add("data-ce-bookmark-name", bookmark.Name);
                            txtbox.CssClass += "ms-ce-richtext";
                            txtbox.Attributes.Add("onchange", string.Format("fillValue('{0}',{1}); ", bookmark.Name, txtbox.ClientID));

                            //Set value if cloned
                            txtbox.Text = _clonedContractBookmarks.ContainsKey(bookmark.Name) ? _clonedContractBookmarks[bookmark.Name].Content : String.Empty;

                            //Add tooltip
                            if (!String.IsNullOrEmpty(bookmark.LongDescription))
                                txtbox.Attributes.Add("title", bookmark.LongDescription);

                            pnl.Controls.Add(txtbox);
                        }
                    }

                    if (isCounterparty && _clonedContractBookmarks.ContainsKey(bookmark.Name))
                        hdnCounterparty.Value = _clonedContractBookmarks[bookmark.Name].Content;
                }

                //CEJSUtil.AddJSBlock(Page, "initDatePicker();");

                #endregion

            }
            catch (ECValidationException ex)
            {
                ECContext.LogEvent("INVALID TEMPLATE: " + ex.Message, ex, ECContext.TraceLevel.Information);

                Panel errPnl = new Panel();
                errPnl.CssClass = "errPnl";

                Image errImg = new Image();
                errImg.ImageUrl = "../../Style%20Library/Images/error-24.png";
                errImg.CssClass = "errImg";
                errPnl.Controls.Add(errImg);

                Literal errMsg = new Literal();
                errMsg.Text = @"<strong>Bookmarks configuration for this contract template is incorrect. Please correct the following errors before using this template:</strong><br/><br/>"
                                + ex.Message +
                                "<br/><br/> Contact the system administrator for support <br/>(Template name: " + templateName + ")";

                pnlStepThree.Controls.Clear();
                pnlStepFour.Controls.Clear();
                errPnl.Controls.Add(errMsg);
                pnlStepThree.Controls.Add(errPnl);
                pnlStepThree.Visible = true;
                pnlStepCloneContract.Visible = false;
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);

            }

            //hdnBookmarksShown.Value = "true";
        }

        private string EmitJSCallback(string jsOld, string jsAdd)
        {
            if (jsOld.StartsWith("function(){"))
                jsOld = jsOld.Replace("function(){", "").TrimEnd('}');

            return String.Format("function(){{{0}{1}}}", jsOld, jsAdd);
        }

        protected void btnCreateCtrls(object sender, EventArgs e)
        {
            try
            {
                string selectACountry = "Select a country...";

                BindDropDownList(ddlCountry, ECContext.Current.Lists.Translations.GetItems(new SPQuery() { Query = string.Format("<Where><And><Eq><FieldRef Name=\"Translation_x0020_Type\" /><Value Type=\"Choice\">Country</Value></Eq><Eq><FieldRef Name=\"Language\" /><Value Type=\"Lookup\">{0}</Value></Eq></And></Where><OrderBy><FieldRef Name='Title' Ascending='True' /></OrderBy>", ddlLanguage.SelectedItem.Text) }), "Value", "Field");
                ddlCountry.Items.Add(selectACountry);
                ddlCountry.SelectedValue = selectACountry;
                ddlCountry_SelectedIndexChanged(sender, e);
                //}
                CreateQuestions();

                if (pnlStepFour.Visible)
                    CreateBookmark();

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        protected void ddlDocType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                InitTemplateQuestions();
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Unexpected error ocurred selecting new document type." + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }
        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                BindDropDownList(ddlMonsantoEntity, ECContext.Current.Lists.MonsantoEntity.GetItems(new SPQuery() { RowLimit = 1000, Query = string.Format("<Where><Eq><FieldRef Name='Country' /><Value Type='Lookup'>{0}</Value></Eq></Where>", ddlCountry.SelectedItem.Value) }));
                ddlMonsantoEntity_SelectedIndexChanged(sender, e);
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Unexpected error ocurred selecting new country." + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }
        protected void ddlMonsantoEntity_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (CreateQuestions())
                {
                    //pnlStepThree.Visible = true;
                    SetMonsantoEntityValues();
                    CreateBookmark();
                    //pnlStepCloneContract.Visible = true;
                    //DCCCEJSUtil.AddJSBlock(Page, "$(loadJsonModel);");
                    CEJSUtil.AddJSBlockAsync(Page, "loadJsonModel();");
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Unexpected error ocurred selecting new entity." + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }
        protected void ddlLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                InitTemplateQuestions();
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Unexpected error ocurred selecting new language." + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void InitTemplateQuestions()
        {
            hdnQuestions.Value = string.Empty;
            pnlStepThree.Visible = false;
            pnlStepFour.Visible = false;
            pnlCloneContractSelection.Visible = false;
            pnlStepCloneContract.Visible = false;

            CreateQuestions();
            //DCCCEJSUtil.AddJSBlock(Page, "$(clearJsonModel);");
            CEJSUtil.AddJSBlockAsync(Page, "loadJsonModel();");
        }

        private void SetMonsantoEntityValues()
        {
            try
            {
                if (ddlMonsantoEntity.SelectedItem != null)
                {
                    SPListItem item = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));
                    lblMonsantoAddress.Text = Convert.ToString(item["Address"]);
                    lblMonsantoCapitalAmount.Text = Convert.ToString(item["Capital_x0020_Amount"]);
                    lblMonsantoIdNr.Text = Convert.ToString(item["Id_x0020_Number"]);
                    lblMonsantoRegistration.Text = Convert.ToString(item["Registration_x0020__x0023_"]);
                    //  lblMonsantoReprese.Text = Convert.ToString(item["Monsanto_x0020_Entity_x0020_Repr"]);
                    // lblMonsantoRepreseTitle.Text = Convert.ToString(item["Monsanto_x0020_Entity_x0020_Repr0"]);
                    lblMonsantoEntityType.Text = new SPFieldLookupValue(Convert.ToString(item["Entity_x0020_Type"])).LookupValue;
                    try
                    {
                        SPListItemCollection collection = ECContext.Current.Lists.Translations.GetItems(new SPQuery() { Query = string.Format("<Where><And><Eq><FieldRef Name=\"Translation_x0020_Type\" /><Value Type=\"Choice\">Jurisdiction</Value></Eq><And><Eq><FieldRef Name=\"Language\" /><Value Type=\"Lookup\">{0}</Value></Eq><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{1}</Value></Eq></And></And></Where></Query>", ddlLanguage.SelectedItem.Text, Convert.ToString(item["Jurisdiction"])) });
                        if (collection.Count > 0)
                        {
                            SPListItem jursidiction = collection[0];
                            lblMonsantoJurisdiction.Text = Convert.ToString(jursidiction["Value"]);
                        }
                        else
                        {
                            lblMonsantoJurisdiction.Text = Convert.ToString(item["Jurisdiction"]);
                        }
                    }
                    catch
                    {
                        lblMonsantoJurisdiction.Text = Convert.ToString(item["Jurisdiction"]);
                    }

                    txtFilename.Text = string.Format("{0}_{1}_{2}_{3}", DateTime.Now.ToString("yyMMddHHmm"), ddlDocType.SelectedItem.Text, string.IsNullOrEmpty(hdnCounterparty.Value) ? "[counterparty]" : hdnCounterparty.Value, Convert.ToString(item["Abbreviation"]));
                }
                else
                {
                    txtFilename.Text = string.Format("{0}_{1}_{2}_[Monsanto entity]", DateTime.Now.ToString("yyMMddHHmm"), ddlDocType.SelectedItem.Text, string.IsNullOrEmpty(hdnCounterparty.Value) ? "[counterparty]" : hdnCounterparty.Value);
                    lblMonsantoAddress.Text = string.Empty;
                    lblMonsantoJurisdiction.Text = string.Empty;
                    lblMonsantoCapitalAmount.Text = string.Empty;
                    lblMonsantoIdNr.Text = string.Empty;
                    lblMonsantoRegistration.Text = string.Empty;
                    //lblMonsantoReprese.Text = string.Empty;
                    //lblMonsantoRepreseTitle.Text = string.Empty;
                    lblMonsantoEntityType.Text = string.Empty;
                }


            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error getting the values of the selected Monsanto Entity. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

        }

        // MAIN CONTRACT CREATION METHOD
        protected void SubmitContract(object sender, EventArgs e)
        {

            SPFile contractFile = null;
            Dictionary<string, string> bookmarks;
            Dictionary<string, string> rtfBookmarks;
            bool bOk = false;
            try
            {
                // 0. Validation
                if (!DoaAdmin.IsValid)
                    throw new ECValidationException("DOA Approver", "Please select a valid DOA approver");

                // 1. Load values from model, and validate against template. Will throw ECValidationException on validation error.
                CompileBookmarkData(out bookmarks, out rtfBookmarks);

                // 2. Elevate privileges...

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    //everis-052814 Fix 'Access Denied' issue
                    using (SPSite curSite = new SPSite(SPContext.Current.Site.ID))
                    {
                        using (SPWeb currweb = curSite.OpenWeb(SPContext.Current.Web.ID))
                        {
                            try
                            {
                                // 3. Generate word document
                                contractFile = SaveContract(bookmarks, rtfBookmarks, currweb);

                                // 4. Populate contract metadata columns
                                bOk = SaveContractMeta(contractFile.Item, currweb);
                                if (!bOk)
                                    throw new Exception("There was a problem saving metadata or uploading attachment files");
                            }
                            catch (Exception ecp)
                            {
                                if (contractFile != null)
                                {
                                    currweb.AllowUnsafeUpdates = true;
                                    contractFile.Delete();
                                    currweb.AllowUnsafeUpdates = false;
                                }
                            }

                        }
                    }
                }
            );




                //3. FCPA questions
                List<string> lst = FailCheckOnEmpty();
                if (lst.Count > 0)
                {
                    string str = string.Empty;
                    foreach (string itm in lst)
                    {
                        if (!string.IsNullOrEmpty(str))
                            str += "," + itm;
                        else
                            str = itm;

                    }

                    CEJSUtil.PopError(Page, "There were validation errors. Please review the problems listed below.", "<ul class=\"ms-dlg-error-list\"><li>Please complete all questions, and enter N/A for non-applicable question.</li></ul>");
                    CreateFCPAQuestions();
                    CreateQuestions();
                    return;
                }

                SPSite site = SPContext.Current.Site;
                SPWeb web = SPContext.Current.Web;

                SPListItem item = null;

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite ElevatedSite = new SPSite(site.ID))
                    using (SPWeb ElevatedWeb = ElevatedSite.OpenWeb(web.ID))
                    {


                        item = ElevatedWeb.Lists[ECContext.Current.Configuration.ExpressContractLibraryName].GetItemById(contractFile.Item.ID);
                        if (CheckFCPAApproval())
                        {
                            item[ECContext.Current.Configuration.ECFields.FCPA] = "FCPA APPROVAL REQUIRED";
                            SaveFCPAMailAsWordDocument(item);
                        }
                        else
                        {
                            item[ECContext.Current.Configuration.ECFields.FCPA] = "NOT FCPA RELEVANT";
                            item[ECContext.Current.Configuration.ECFields.FCPAApproval] = "N/A";
                        }

                        item["Sap Vendor Number"] = sapVendorNumberTxt.Text;
                        ElevatedWeb.AllowUnsafeUpdates = true;

                        DisabledItemEventsScope disEvnt = new DisabledItemEventsScope();
                        try
                        {
                            disEvnt.DisabledItemEvents();
                            item.SystemUpdate(false);
                        }
                        catch (Exception ex)
                        {
                            int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                            CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                        }
                        finally
                        {
                            disEvnt.Dispose();
                        }

                        ElevatedWeb.AllowUnsafeUpdates = false;

                    }
                });


                // 4. Redirect to summary
                if (bOk)
                    //SPUtility.Redirect(string.Format("ContractExpressSystem/FCPAQuestionForm.aspx?itemid={0}{1}", Convert.ToString(contractFile.Item.ID), _clonedContractItem != null ? "&clonedContractId=" + _clonedContractItem.ID.ToString() : String.Empty), SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);
                    SPUtility.Redirect(string.Format("ContractExpressSystem/ContractSummary.aspx?itemid={0}{1}", Convert.ToString(item.ID), _clonedContractItem != null ? "&clonedContractId=" + _clonedContractItem.ID.ToString() : String.Empty), SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);

            }
            catch (ECValidationException ex)
            {
                CEJSUtil.PopError(Page, "Validation error", ex.Message);
                btnCreateCtrls(sender, e);
                //DCCCEJSUtil.AddJSBlock(Page, "$(loadJsonModel);");
                CEJSUtil.AddJSBlockAsync(Page, "loadJsonModel();");
            }
            catch (ThreadAbortException)
            {
                // Swallow bogus exception caused by redirect
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                btnCreateCtrls(sender, e);
                //DCCCEJSUtil.AddJSBlock(Page, "$(loadJsonModel);");
                CEJSUtil.AddJSBlockAsync(Page, "loadJsonModel();");
            }


        }


        private bool CompileBookmarkData(out Dictionary<string, string> bookmarkList, out Dictionary<string, string> rtfBookmarkList)
        {
            try
            {
                StringBuilder emtpyFields = new StringBuilder();

                if (ddlMonsantoEntity.SelectedItem == null)
                    throw new ECValidationException("Entity", "No Monsanto entity selected.");


                //SPListItem entityitem = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));
                string templateName = new SPFieldLookupValue(Convert.ToString(ECContext.Current.Lists.Question.GetItemById(Convert.ToInt32(hdnQuestions.Value))["Template"])).LookupValue;
                DataTable filteredBookmarks = ECContext.Current.Lists.Bookmark.GetItems(new SPQuery { Query = String.Format("<Where><Eq><FieldRef Name=\"Template\"/><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) }).GetDataTable();
                Dictionary<string, string> replacements = new Dictionary<string, string>();

                DateTime EffectiveDate = DateTime.Now;
                Dictionary<string, string> descriptionReplacements = new Dictionary<string, string>();
                Dictionary<string, string> richTextDescriptionReplacements = new Dictionary<string, string>();


                DateTimeFormatInfo dtfi = new DateTimeFormatInfo { ShortDatePattern = "dd-MM-yyyy", DateSeparator = "-" };

                // Fetch JSON-encoded values from page, deserialize into dictionary. Keys in dictionary are mangled with Dyna_* prefixes.
                var bmData = JsonConvert.DeserializeObject<Dictionary<string, string>>(hdnBookmarkValues.Value);

                // Fetch bookmarks
                var bookmarks = from bookmark in filteredBookmarks.AsEnumerable()
                                select new
                                {
                                    Name = bookmark.Field<string>("Title"),
                                    DataValue = bookmark.Field<string>("Data_x0020_Value"),
                                    Description = bookmark.Field<string>("Bookmark_x0020_Description"),
                                    Required = bookmark.Field<string>("Required"),
                                    Mapping = bookmark.Field<string>("FieldMapping")
                                };

                foreach (var bm in bookmarks)
                {
                    string pfx;
                    string bmValue;


                    // If field is mapped, assign it
                    if (!String.IsNullOrEmpty(bm.Mapping))
                    {
                        Func<string> h;
                        if (!field_mappings.TryGetValue(bm.Mapping, out h) && bm.Mapping != "Counterparty")
                            throw new ECValidationException(bm.Name, "Unable to find mapping information for field '{0}'.<br/>Please contact the system administrator.", bm.Description != null ? bm.Description : bm.Name);
                        if (h != null)
                        {
                            replacements.Add(bm.Name, h.Invoke());
                            continue;
                        }
                    }

                    if (GetJsonModelValue(bmData, bm.Name, out pfx, out bmValue))
                    {
                        // Bail out early if missing fields
                        if (String.IsNullOrEmpty(bmValue) && bm.Required == "1" && bm.Mapping == null)
                            throw new ECValidationException(bm.Description, "Cannot be empty");

                        // Field found, unmarshal value
                        switch (pfx)
                        {
                            case "Dyna_date_":
                                {
                                    DateTime objDate = Convert.ToDateTime(bmValue, dtfi);

                                    if (bm.Name == "EffectiveDate")
                                        EffectiveDate = objDate;

                                    string val = objDate.ToString("dd MMMM yyyy", new System.Globalization.CultureInfo(ddlLanguage.SelectedItem.Value));

                                    replacements.Add(bm.Name, val);

                                    if (!string.IsNullOrEmpty(bm.Description) && !descriptionReplacements.ContainsKey(bm.Description))
                                        descriptionReplacements.Add(bm.Description, val);

                                    break;
                                }
                            case "Dyna_RichText_":
                                {
                                    richTextDescriptionReplacements.Add(bm.Name, bmValue);
                                    break;
                                }
                            case "":
                                {
                                    replacements.Add(bm.Name, bmValue);

                                    if (!string.IsNullOrEmpty(bm.Description) && !descriptionReplacements.ContainsKey(bm.Description))
                                        descriptionReplacements.Add(bm.Description, bmValue);

                                    break;
                                }
                        }
                    }
                    else
                    {
                        // Field not found & not mapped - generate error
                        if (bm.Required == "1" && String.IsNullOrEmpty(bm.Mapping))
                        {
                            throw new ECValidationException(bm.Description, "Cannot be empty");
                        }
                    }
                }

                if (!string.IsNullOrEmpty(emtpyFields.ToString()))
                    throw new ECValidationException("Form", string.Concat("Please complete all fields, and enter \"N/A\" for non-applicable fields. Incomplete fields are ", emtpyFields.ToString()));


                bookmarkList = replacements;
                rtfBookmarkList = richTextDescriptionReplacements;

                return true;
            }
            catch (Exception ex)
            {
                bookmarkList = null;
                rtfBookmarkList = null;
                throw ex;
            }
        }

        //
        // Generate Word document
        //
        private SPFile SaveContract(Dictionary<string, string> bookmarks, Dictionary<string, string> rtfBookmarks, SPWeb elevatedWeb)
        {
            try
            {
                SPListItem entityitem = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));
                string templateName = new SPFieldLookupValue(Convert.ToString(ECContext.Current.Lists.Question.GetItemById(Convert.ToInt32(hdnQuestions.Value))["Template"])).LookupValue;

                String fileName = String.Format("{0:yyyyMMdd}_{0:hhmm}_{1}_{2}_{3}",
                                DateTime.Now,
                                ddlDocType.SelectedItem.Text,
                                string.IsNullOrEmpty(hdnCounterparty.Value) ? "[counterparty]" : hdnCounterparty.Value,
                                Convert.ToString(entityitem["Abbreviation"]));

                fileName = CESPUtil.NormalizeFilename(fileName);


                SPFile destination = new ECContext(SPContext.GetContext(elevatedWeb)).CreateNewExpressContractFromTemplate(fileName, templateName, elevatedWeb);

                try
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        byte[] buffer = destination.OpenBinary();
                        ms.Write(buffer, 0, buffer.Length);

                        if (rtfBookmarks.Count == 0)
                            ECContext.OpenXml.ProcessTemplate(ms, bookmarks);
                        else
                            ECContext.OpenXml.ProcessTemplate(ms, bookmarks, rtfBookmarks);

                        //Activate Track Changes
                        if (_clonedContractItem != null)
                        {
                            using (WordprocessingDocument docPart = WordprocessingDocument.Open(ms, true))
                            {
                                TrackRevisions newrevision = new TrackRevisions();
                                newrevision.Val = new DocumentFormat.OpenXml.OnOffValue(true);
                                docPart.MainDocumentPart.DocumentSettingsPart.Settings.AppendChild(newrevision);
                                docPart.MainDocumentPart.DocumentSettingsPart.Settings.Save();
                            }
                        }

                        elevatedWeb.AllowUnsafeUpdates = true;
                        destination.SaveBinary(ms);
                        elevatedWeb.AllowUnsafeUpdates = false;
                    }
                    ECContext.LogEvent("Contract created: " + destination.Url, null, ECContext.TraceLevel.Information, elevatedWeb);
                }
                catch (Exception ecp)
                {
                    if (destination != null)
                    {
                        elevatedWeb.AllowUnsafeUpdates = true;
                        destination.Delete();
                        elevatedWeb.AllowUnsafeUpdates = false;
                    }
                    throw ecp;
                }




                return elevatedWeb.GetFile(destination.Url);
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error saving contract. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);

            }

            return null;
        }

        private bool SaveContractMeta(SPListItem itm, SPWeb elevatedWeb)
        {
            bool bOk = false;
            try
            {
                elevatedWeb.AllowUnsafeUpdates = true;

                // Set basic properties
                itm[ECContext.Current.Configuration.ECFields.Function] = new SPFieldLookupValue(Convert.ToInt32(ddlFunction.SelectedItem.Value), ddlFunction.SelectedItem.Value);
                itm[ECContext.Current.Configuration.ECFields.MonsantoEntity] = new SPFieldLookupValue(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value), ddlMonsantoEntity.SelectedItem.Value);
                itm[ECContext.Current.Configuration.ECFields.DocumentType] = new SPFieldLookupValue(Convert.ToInt32(ddlDocType.SelectedItem.Value), ddlDocType.SelectedItem.Value);
                itm[ECContext.Current.Configuration.ECFields.MonsantoDivision] = new SPFieldLookupValue(Convert.ToInt32(ddlMonsantoDivision.SelectedItem.Value), ddlMonsantoDivision.SelectedItem.Value);
                //itm[ECContext.Current.Configuration.ECFields.NegotiationPosition] = new SPFieldLookupValue(Convert.ToInt32(ddlNegotiation.SelectedItem.Value), ddlNegotiation.SelectedItem.Value);
                itm[ECContext.Current.Configuration.ECFields.BusinessUser] = new SPFieldUserValue(itm.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName);
                //itm[ECContext.Current.Configuration.ECFields.TemplateChoices] = hdnTemplateChoices.Value;
//                itm[ECContext.Current.Configuration.ECFields.Draft] = true;
                itm["CounterParty"] = hdnCounterparty.Value;
                SPListItem entityitem = ECContext.Current.Lists.MonsantoEntity.GetItemById(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value));

                itm["Title"] = Path.GetFileNameWithoutExtension(itm.File.Name);

                SPListItem template = ECContext.Current.Lists.ContractTemplate.GetItemById(new SPFieldLookupValue(Convert.ToString(ECContext.Current.Lists.Question.GetItemById(Convert.ToInt32(hdnQuestions.Value))["Template"])).LookupId);
                itm[ECContext.Current.Configuration.ECFields.Template] = new SPFieldLookupValue(template.ID, template.Title);
                SPListItem country = ECContext.Current.Lists.Country.GetItems(new SPQuery() { Query = string.Format("<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>{0}</Value></Eq></where>", ddlCountry.SelectedItem.Value) })[0];
                itm[ECContext.Current.Configuration.ECFields.Country] = new SPFieldLookupValue(country.ID, country.Title);

                // Set DOA approver
                SPUser doaUser = elevatedWeb.EnsureUser(((PickerEntity)DoaAdmin.ResolvedEntities[0]).Key);
                itm[ECContext.Current.Configuration.ECFields.DaoApprover] = new SPFieldUserValue(itm.Web, doaUser.ID, doaUser.LoginName);

                // Update creation date + author
                SPUser creatorUser = elevatedWeb.EnsureUser(new SPFieldUserValue(itm.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName).User.LoginName);
                string value1 = creatorUser.ID + ";#" + creatorUser.Name; //Create in same format
                //ECContext.LogEvent("Contract created on: " + ((DateTime)itm[SPBuiltInFieldId.Created]).ToString(), null, TraceSeverity.Monitorable);
                itm[SPBuiltInFieldId.Created] = DateTime.Now;
                itm[SPBuiltInFieldId.Author] = value1;

                if (_clonedContractItem != null)
                    itm[ECContext.Current.Configuration.ECFields.ClonedFromContractId] = _clonedContractItem.ID;

                //ECContext.LogEvent("Contract creation date updated to: " + ((DateTime)itm[SPBuiltInFieldId.Created]).ToString(), null, TraceSeverity.Monitorable);

                //Add attachments
                try
                {
                    dt = (DataTable)ViewState["Files"];
                    SPFolder attachmentsLibrary = elevatedWeb.Folders["Express contracts attachments"];
                    SPFieldLookupValueCollection valueCol = new SPFieldLookupValueCollection();
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            //1. Add file to 'Express contracts attachments' Document Library
                            string strFilepath = dr["FilePath"].ToString();
                            StreamReader sr = new StreamReader(strFilepath);
                            Stream fStream = sr.BaseStream;

                            MemoryStream ms = new MemoryStream(ECContext.OpenXml.ReadFully(fStream));
                            string sFileName = dr["Filename"].ToString();
                            SPFile file = attachmentsLibrary.Files.Add(sFileName, ms, true);
                            file.Item["Title"] = sFileName;

                            file.Item.Update();
                            attachmentsLibrary.Update();

                            //2. Add link to file in 'Express contracts' Document Library
                            valueCol.Add(new SPFieldLookupValue(file.Item.ID, file.Item.Title.ToString()));
                        }
                        itm["Documents Attached"] = valueCol.ToString();
                    }
                    //Clear Session attachments
                    ViewState.Remove("Files");
                    bOk = true;
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent("Error saving contract attachments. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractAttachmentError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }

                if (bOk)
                {
                    DisabledItemEventsScope disEvnt = new DisabledItemEventsScope();
                    try
                    {
                        disEvnt.DisabledItemEvents();
                        bOk = false;
                        itm.UpdateOverwriteVersion();
                        itm.Update();
                        itm.ParentList.Update();
                        itm.Web.Update();
                        itm.Web.AllowUnsafeUpdates = false;
                        bOk = true;

                        //Send New Contract email
                        SPWeb web = SPContext.Current.Web;
                        ECContext ctx = new ECContext(SPContext.GetContext(web));
                        if (itm[ctx.Configuration.ECFields.DaoApprover] != null) //Disables changes notification when performed by administrator -> && properties.UserDisplayName != "System Account")
                        {
                            List<string> bcc = ECContext.CreateLegalHeader(web);
                            //ECContext.SendMail(web, string.Format("New Express Contract {0} ", itm.File.Title), ContractHelper.CreateChangeMail(itm, ctx, SPContext.Current.Site, web.CurrentUser.Name), bcc);
                        }
                    }
                    catch (Exception ex)
                    {
                        int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                        CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                    }
                    finally
                    {
                        disEvnt.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Error saving contract metadata. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
            return bOk;
        }

        private bool GetJsonModelValue(Dictionary<string, string> dict, string key, out string prefix, out string val)
        {
            if (dict != null)
            {
                string[] prefixes = { pfx_empty, pfx_rtf, pfx_date };

                foreach (var pfx in prefixes)
                {
                    string fullkey = String.Format("{0}{1}", pfx, key);
                    string outval;

                    if (dict.TryGetValue(fullkey, out outval))
                    {
                        prefix = pfx;
                        val = outval;
                        return true;
                    }
                }
            }

            prefix = null;
            val = null;
            return false;
        }

        private void CreateFCPAQuestions()
        {

            Dyna_FCPA_Ctrls.Controls.Clear();

            Dictionary<string, Dictionary<string, string>> sections = GetSections();

            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                Dyna_FCPA_Ctrls.Controls.Add(new LiteralControl("<span class='questionFormSubtitle'>Please fill in these questions, the questions will determine if FCPA approval is needed:</span>"));

                Dyna_FCPA_Ctrls.Controls.Add(new LiteralControl(string.Format("<h2>{0}</h2>", section.Key)));

                Dyna_FCPA_Ctrls.Controls.Add(new LiteralControl("<table class='questionForm'>"));

                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    string answerValue = string.Empty;
                    string yesSelected = string.Empty;
                    string noSelected = "checked";

                    if (_clonedContractId.HasValue)
                    {
                        answerValue = ECContext.GetQuestionAnswer(_clonedContractId.Value, Convert.ToInt32(question.Key), ECContext.QuestionType.FCPA);

                        if (answerValue == "true") { yesSelected = "checked"; noSelected = ""; }

                    }

                    Dyna_FCPA_Ctrls.Controls.Add(new LiteralControl(string.Format("<tr><td style=\"width:90%\"><span>{0}</span></td><td><div css='DynaQuestions' ><input type=\"radio\" name=\"question{1}\" id='{1}yes' value='yes'" + yesSelected + "/>yes<input name=\"question{1}\"  type=\"radio\" id='{1}no' value='no'" + noSelected + " />no</div></td></tr>", question.Value, question.Key)));
                }
                Dyna_FCPA_Ctrls.Controls.Add(new LiteralControl("</table>"));
            }
        }

        public Dictionary<string, Dictionary<string, string>> GetSections()
        {
            Dictionary<string, Dictionary<string, string>> sections = new Dictionary<string, Dictionary<string, string>>();

            foreach (SPListItem item in ECContext.Current.Lists.ApprovalQuestion.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='LinkTitleNoMenu' Ascending='True' /><FieldRef Name='Order0' Ascending='True' /></OrderBy>" }))
            {
                string section = Convert.ToString(item[SPBuiltInFieldId.Title]);
                if (section == ECContext.Current.Configuration.FCPASectionTitle)
                {
                    if (sections.ContainsKey(section))
                        sections[section].Add(Convert.ToString(item[SPBuiltInFieldId.ID]), Convert.ToString(item["Question"]));
                    else
                    {
                        Dictionary<string, string> lst = new Dictionary<string, string>();
                        lst.Add(Convert.ToString(item[SPBuiltInFieldId.ID]), Convert.ToString(item["Question"]));
                        sections.Add(section, lst);
                    }
                }
            }
            return sections;
        }

        private List<string> FailCheckOnEmpty()
        {
            List<string> lst = new List<string>();
            List<string> splits = new List<string>();
            splits.AddRange(hdnAnswers.Value.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));
            Dictionary<string, Dictionary<string, string>> sections = ECContext.GetSections();

            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    string key = string.Format("<answer>{0}|", question.Key);

                    if (splits.Exists(a => a.StartsWith(key)))
                        if (string.IsNullOrEmpty(splits.First(a => a.StartsWith(key)).Replace(key, string.Empty).Replace("\r\n", string.Empty)))
                            lst.Add(question.Key);
                }
            }
            return lst;
        }

        private bool CheckFCPAApproval()
        {
            List<string> splits = new List<string>();
            splits.AddRange(hdn_FCPA_Answers.Value.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));
            foreach (var item in splits)
                if (item.EndsWith("yes|true"))
                    return true;

            return false;

        }

        public void SaveFCPAMailAsWordDocument(SPListItem item)
        {
            string url = string.Concat(SPContext.Current.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = SPContext.Current.Site.Url;
            string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
            string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
            string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;
            Dictionary<string, Dictionary<string, string>> sections = GetSections();

            using (MemoryStream generatedDocument = new MemoryStream())
            {
                using (WordprocessingDocument package = WordprocessingDocument.Create(generatedDocument, DocumentFormat.OpenXml.WordprocessingDocumentType.Document))
                {
                    MainDocumentPart mainPart = package.MainDocumentPart;
                    if (mainPart == null)
                    {
                        mainPart = package.AddMainDocumentPart();
                        new Document(new Body()).Save(mainPart);
                    }

                    Body body = mainPart.Document.Body;

                    body.Append(CreateWordHeader("Request for approval"));


                    List<string> splits = new List<string>();
                    splits.AddRange(hdn_FCPA_Answers.Value.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));
                    HtmlConverter converter = new HtmlConverter(mainPart);
                    CreateAndConvertWordContent(string.Format("{0} has created a new express contract '{1}' and requests your approval. Please navigate to this <a href=\"{2}\" >approval form</a> to approve it. To navigate to an overview of the contracts you can use this <a href=\"{3}\" >link</a>.<br /><br />The country that was selected for this contract is '{4}' and the entity is '{5}''.", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Name, item.File.Title, string.Format("{0}/_layouts/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", SPContext.Current.Site.Url, item.ID.ToString(), "DOA"), SPContext.Current.Site.Url, country, Entity), body, converter);

                    foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
                    {
                        body.Append(CreateWordHeader(section.Key));

                        foreach (KeyValuePair<string, string> question in section.Value)
                        {
                            CreateAndConvertWordContent(question.Value, body, converter);
                            string yeskey = string.Format("<answer>{0}yes|true", question.Key);
                            string nokey = string.Format("<answer>{0}no|true", question.Key);

                            if (splits.Exists(a => a.StartsWith(yeskey)))
                                body.Append(CreateWordContent("answer was YES"));
                            if (splits.Exists(a => a.StartsWith(nokey)))
                                body.Append(CreateWordContent("answer was no"));
                        }
                    }

                    mainPart.Document.Save();
                }
                SPWeb ElevatedWeb = item.Web;

                ElevatedWeb.AllowUnsafeUpdates = true;

                SPFile file = ElevatedWeb.Lists[ECContext.Current.Configuration.ApprovalAnswerlistName].RootFolder.Files.Add(string.Concat("FCPA_", item.File.Name), generatedDocument.ToArray(), true);
                SPListItem lstitem = file.Item;
                lstitem[SPBuiltInFieldId.Title] = file.Name;
                lstitem["Answers"] = hdn_FCPA_Answers.Value;
                lstitem["Contract"] = new SPFieldLookupValue(item.ID, item.Title);

                DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                try
                {
                    lstitem.Update();
                }
                catch (Exception ex)
                {
                    int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                }
                finally
                {
                    disEvt.Dispose();
                }

                SPFieldLookupValue lookUpVal = new SPFieldLookupValue(lstitem.ID, lstitem.Title);
                item[ECContext.Current.Configuration.ECFields.FcpaApprovalAnswer] = lookUpVal;
                item.SystemUpdate();
                ElevatedWeb.AllowUnsafeUpdates = false;
            }

        }

        private void CreateAndConvertWordContent(string html, Body body, HtmlConverter converter)
        {
            html = html.Replace("<br/>", string.Empty);
            var paragraphs = converter.Parse(html);
            for (int i = 0; i < paragraphs.Count; i++)
                body.Append(paragraphs[i]);
        }
        private Paragraph CreateWordContent(string content)
        {
            Paragraph p = new Paragraph();
            Run r = new Run();
            r.Append(new Text(content));
            p.Append(r);
            return p;
        }
        private Paragraph CreateWordHeader(string text)
        {
            Paragraph p = new Paragraph();
            Run r = new Run();
            r.Append(new Text(text));
            p.Append(r);
            return p;
        }

        #region File Upload

        private void dgdUpload_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int recordToDelete = e.RowIndex;
            dt = (DataTable)ViewState["Files"];
            int cn = dt.Rows.Count;
            dt.Rows.RemoveAt(recordToDelete);
            dt.AcceptChanges();
            ViewState["Files"] = dt;
            this.dgdUpload.DataSource = dt;
            this.dgdUpload.DataBind();

            try
            {
                if (CreateQuestions())
                {
                    SetMonsantoEntityValues();
                    CreateBookmark();
                    //DCCCEJSUtil.AddJSBlock(Page, "$(loadJsonModel);");
                    CEJSUtil.AddJSBlockAsync(Page, "loadJsonModel();");
                }
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent("Unexpected error ocurred deleting attached file. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        protected void btnUploadUploadClick(object sender, EventArgs e)
        {
            try
            {
                fileName = System.IO.Path.GetFileName(inputFile.PostedFile.FileName);

                if (fileName != "")
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        //double dlength = (double)inputFile.PostedFile.InputStream.Length / 1048576; //SIze in MB
                        //int iMaxLength = 4;
                        //if (dlength > iMaxLength)
                        //    throw new Exception("File attached length is " + dlength.ToString("#.00") + "MB.<br />Attachment max length is " + iMaxLength.ToString() + "MB.");
                        if (inputFile.PostedFile.FileName.EndsWith(".exe"))
                            throw new Exception("File type (.exe) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".msi"))
                            throw new Exception("File type (.msi) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".config"))
                            throw new Exception("File type (.config) not supported.");
                        else if (inputFile.PostedFile.FileName.EndsWith(".dll"))
                            throw new Exception("File type (.dll) not supported.");
                        else
                        {
                            string _fileTime = DateTime.Now.ToFileTime().ToString();
                            string _fileorgPath = System.IO.Path.GetFullPath(inputFile.PostedFile.FileName);
                            string _newfilePath = _fileTime + "~" + fileName;
                            string tempFolder = Environment.GetEnvironmentVariable("TEMP");
                            string _filepath = tempFolder + _newfilePath;
                            inputFile.PostedFile.SaveAs(_filepath);
                            AddRow(fileName, _filepath);
                            //lblMessage.Text = "Successfully Added in List";
                        }
                    });
                }

                if (CreateQuestions())
                {
                    SetMonsantoEntityValues();
                    CreateBookmark();
                    //DCCCEJSUtil.AddJSBlock(Page, "$(loadJsonModel);");
                    CEJSUtil.AddJSBlockAsync(Page, "loadJsonModel();");
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.StartsWith("File attached length is") || ex.Message.StartsWith("File type (."))
                {
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ex.Message);
                }
                else
                {
                    int logId = ECContext.LogEvent("Unexpected error ocurred uploading attached file. " + ex.Message, ex, ECContext.TraceLevel.Unexpected);
                    CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
                }
            }
        }

        private void AddMoreColumns()
        {
            dt = new DataTable("Files");
            dc = new DataColumn("FileName", Type.GetType("System.String"));
            dt.Columns.Add(dc);
            dc = new DataColumn("FilePath", Type.GetType("System.String"));
            dt.Columns.Add(dc);
            //dc = new DataColumn("FileSize", Type.GetType("System.String"));
            //dt.Columns.Add(dc);
            //dc = new DataColumn("KB", Type.GetType("System.String"));
            //dt.Columns.Add(dc);
            ViewState["Files"] = dt;
        }

        private void AddRow(string file, string path)
        {
            dt = (DataTable)ViewState["Files"];
            if (dt == null)
            {
                AddMoreColumns();
            }
            dr = dt.NewRow();
            dr["FileName"] = file;
            dr["FilePath"] = path;
            //dr["FileSize"] = Convert.ToString(length);
            //dr["KB"] = "KB";
            dt.Rows.Add(dr);
            ViewState["Files"] = dt;
            this.dgdUpload.DataSource = dt;
            this.dgdUpload.DataBind();//bind in grid
        }

        protected void onShowRegularContract(object sender, EventArgs e)
        {
            LinkButton showRegularBtn = (LinkButton)sender;

            try
            {
                //Highlight button
                pnlStepThree.Visible = true;
                pnlStepFour.Visible = true;
                showRegular.Style.Add("border", "1px solid #666666");
                showCloned.Style.Remove("border");

                //Init controls
                _clonedContractItem = null;
                hdnCloneContractParentId.Value = String.Empty;
                SetMonsantoEntityValues();
                CreateQuestions();
                CreateBookmark();

                //Hide/Show panels
                pnlStepThree.Visible = true;
                pnlStepFour.Visible = true;
                pnlStepCloneContract.Visible = true;
                pnlCloneContractSelection.Visible = false;
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        protected void onContractToCloneSelected(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;

            try
            {
                //Set HdnValue
                hdnCloneContractParentId.Value = btn.Attributes["data-listitemid"];


                //Get clone info
                if (!String.IsNullOrEmpty(hdnCloneContractParentId.Value))
                {
                    _clonedContractItem = ECContext.Current.Lists.ExpressContract.GetItemById(int.Parse(hdnCloneContractParentId.Value));
                    _clonedContractBookmarks = ECContext.OpenXml.FindBookmarksAndContent(_clonedContractItem.File.OpenBinaryStream());
                }

                //Init controls
                if (_clonedContractItem != null)
                {
                    ddlCountry.SelectedValue = new SPFieldLookupValue((string)_clonedContractItem[ECContext.Current.Configuration.ECFields.Country]).LookupValue;
                    BindDropDownList(ddlMonsantoEntity, ECContext.Current.Lists.MonsantoEntity.GetItems(new SPQuery() { RowLimit = 1000, Query = string.Format("<Where><Eq><FieldRef Name='Country' /><Value Type='Lookup'>{0}</Value></Eq></Where>", ddlCountry.SelectedItem.Value) }));

                    string ddlMonsantoEntityLookupValue = new SPFieldLookupValue((string)_clonedContractItem[ECContext.Current.Configuration.ECFields.MonsantoEntity]).LookupValue;
                    if (ddlMonsantoEntity.Items.FindByValue(ddlMonsantoEntityLookupValue) != null)
                        ddlMonsantoEntity.SelectedValue = ddlMonsantoEntityLookupValue;
                }

                CreateQuestions();
                CreateBookmark();
                SetMonsantoEntityValues();

                //Hide/Show panels
                pnlStepThree.Visible = true;
                pnlStepFour.Visible = true;
                pnlStepCloneContract.Visible = true;
                pnlCloneContractSelection.Visible = true;

            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CloneContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }


        protected void listViewContractSelection_SelectedIndexChanging(object sender, ListViewSelectEventArgs e)
        {

            listViewContractSelection.SelectedIndex = e.NewSelectedIndex;
            FindContractsToClone();

        }

        protected void onShowClonedContract(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;

            try
            {
                //Highlight button
                showCloned.Style.Add("border", "1px solid #666666");
                showRegular.Style.Remove("border");

                //Init controls
                CreateQuestions();
                FindContractsToClone();

                //Hide/Show panels
                pnlStepThree.Visible = false;
                pnlStepFour.Visible = false;
                pnlStepCloneContract.Visible = true;
                pnlCloneContractSelection.Visible = true;
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CloneContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }
        }

        private void FindContractsToClone()
        {
            SPFieldLookupValue templateLkp = new SPFieldLookupValue(Convert.ToString(ECContext.Current.Lists.Question.GetItemById(Convert.ToInt32(hdnQuestions.Value))["Template"]));
            SPListItem template = ECContext.Current.Lists.ContractTemplate.GetItemById(templateLkp.LookupId);

            //Get approved and owned contracts
            SPQuery query = new SPQuery();
            query.Query = "<Where><And>" +
                            "<Eq><FieldRef Name='Author' /><Value Type='User'>" + ECContext.Current.CurrentWeb.CurrentUser.Name + "</Value></Eq>" +
                            "<And><Eq><FieldRef Name='_ModerationStatus' /><Value Type='ModStat'>Approved</Value></Eq>" +
                            "<And><Eq><FieldRef Name='Template' /><Value Type='Lookup'>" + templateLkp.LookupValue + "</Value></Eq>" +
                            "<Geq><FieldRef Name='Created' /><Value IncludeTimeValue='TRUE' Type='DateTime'>" + ((DateTime)template["Modified"]).ToString("yyyy-MM-ddTHH:mm:ssZ") + "</Value></Geq>" +
                "</And></And></And></Where>";

            SPListItemCollection source = ECContext.Current.Lists.ExpressContract.GetItems(query);
            listViewContractSelection.DataSource = source;

            listViewContractSelection.DataBind();

            if (source.Count == 0)
            {
                showCloned.Enabled = false;
                showCloned.ToolTip = "No contracts found for this template";
            }

        }

        #endregion


    }
}
