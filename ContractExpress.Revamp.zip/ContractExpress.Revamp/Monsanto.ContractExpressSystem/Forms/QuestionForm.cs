﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Threading;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using System.Collections;
using DocumentFormat.OpenXml.Packaging;
using System.IO;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Collections.Specialized;
using Bayer.BCS.ContractExpressSsytem.HtmlToOpenXml;
using Bayer.BCS.ContractExpressSsytem;
using System.Web;

namespace Bayer.BCS.ContractExpressSystem
{
    public class QuestionForm : ECFormBase
    {
        #region controls
        protected PlaceHolder DynaCtrls;
        protected HiddenField hdnAnswers;
        private int? _clonedContractId;
        #endregion

        protected override void CreateChildControls()
        {
            try
            {
                if (!IsPostBack)
                    CreateQuestions();
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                Controls.Add(new LiteralControl(string.Format("<Label style='color:red' >{0}</Label>", ex.Message)));
            }
        }

        protected override void OnInit(EventArgs e)
        {
            try
            {
                int clonedContractId;
                if (int.TryParse((string)Request.QueryString["clonedContractId"], out clonedContractId))
                    _clonedContractId = clonedContractId;
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }
        

        /// <summary>
        /// request approval
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Submit(object sender, EventArgs e)
        {
            try
            {
                List<string> lst = FailCheckOnEmpty();
                if (lst.Count > 0)
                {
                    string str = string.Empty;
                    foreach (string itm in lst)
                    {
                        if (!string.IsNullOrEmpty(str))
                            str += "," + itm;
                        else
                            str = itm;

                    }

                    CEJSUtil.PopError(Page, "There were validation errors. Please review the problems listed below.", "<ul class=\"ms-dlg-error-list\"><li>Please complete all questions, and enter N/A for non-applicable question.</li></ul>");
                    CreateQuestions();
                    return;
                }


                SPSite site = SPContext.Current.Site;
                SPWeb web = SPContext.Current.Web;
                SPListItem item = null;

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite ElevatedSite = new SPSite(site.ID))
                    using (SPWeb ElevatedWeb = ElevatedSite.OpenWeb(web.ID))
                    {
                        item = ElevatedWeb.Lists[ECContext.Current.Configuration.ExpressContractLibraryName].GetItemById(Convert.ToInt32(Request.QueryString["itemid"]));
                        //string templateQuestions = Convert.ToString(item[ECContext.Current.Configuration.ECFields.TemplateChoices]);
                        //Dictionary<string, string> tQlist = new Dictionary<string, string>();

                        //if (!string.IsNullOrEmpty(templateQuestions))
                        //{
                        //    foreach (string template in templateQuestions.Split(new string[] { "</question>" }, StringSplitOptions.RemoveEmptyEntries))
                        //    {
                        //        SPListItem q = ECContext.Current.Lists.Question.GetItemById(Convert.ToInt32(template.Replace("<question>", "")));
                        //        tQlist.Add(Convert.ToString(q["Question"]), Convert.ToString(q["Answer"]));
                        //    }
                        //}

//                        item[ECContext.Current.Configuration.ECFields.Draft] = false;
                        SaveMailAsWordDocument(item);

                        //everis - CONTRACTS CHANGE NOT ALLOWED/DO NOT START APPROVAL AT THIS POINT
                        //if (Request.QueryString["changed"] == "true")
                        //{
                        //    if (string.IsNullOrEmpty(Convert.ToString(item[ECContext.Current.Configuration.ECFields.DocumentRejection])))
                        //    {
                        //        if (Convert.ToString(item[ECContext.Current.Configuration.ECFields.LegalApproval]) == "Rejected")
                        //            ECContext.SendMail(ElevatedWeb, string.Format("Amended Express Contract {0} Request for Legal approval", item.File.Title), ECContext.CreateMailForApproval(item, ECContext.ECLegalType, hdnAnswers.Value, tQlist, true), ECContext.CreateLegalHeader(item));
                        //        else if (Convert.ToString(item[ECContext.Current.Configuration.ECFields.DoaApproval]) == "Rejected")
                        //            ECContext.SendMail(ElevatedWeb, string.Format("Amended Express Contract {0} Request for DOA approval", item.File.Title), ECContext.CreateMailForApproval(item, ECContext.ECDoaType, hdnAnswers.Value, tQlist, true), ECContext.CreateDOAHeader(item));
                        //        else if (Convert.ToString(item[ECContext.Current.Configuration.ECFields.FCPAApproval]) == "Rejected")
                        //            ECContext.SendMail(ElevatedWeb, string.Format("Amended Express Contract {0} Request for FCPA approval", item.File.Title), ECContext.CreateMailForApproval(item, ECContext.ECFcpaType, hdnAnswers.Value, tQlist, true), ECContext.CreateFCPAHeader(item));
                        //    }
                        //    ElevatedWeb.AllowUnsafeUpdates = true;
                        //    item[ECContext.Current.Configuration.ECFields.QuestionRejection] = string.Empty;


                        //    item.SystemUpdate(true);
                        //    if (item.File.CheckOutType != SPFile.SPCheckOutType.None)
                        //        item.File.CheckIn("Express Contract approval");

                        //    ElevatedWeb.AllowUnsafeUpdates = false;
                        //}
                        //else
                        //{

                        //    ECContext.SendMail(ElevatedWeb, string.Format("Express Contract {0}, request for Legal approval", item.File.Title), ECContext.CreateMailForApproval(item, ECContext.ECLegalType, hdnAnswers.Value, tQlist, false), ECContext.CreateLegalHeader(item));
                        //}

                        //everis - DO NOT START APPROVAL AT THIS POINT
                        //SPUtility.SendEmail(ElevatedWeb, ECContext.CreateLegalHeader(item), ECContext.CreateMailForApproval(item, ECContext.ECLegalType, hdnAnswers.Value));
                    }
                });

                SPUtility.Redirect(string.Format("ContractExpressSystem/ContractSummary.aspx?itemid={0}{1}", Convert.ToString(item.ID), _clonedContractId.HasValue ? "&clonedContractId=" + _clonedContractId : String.Empty), SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);

            }
            catch (ThreadAbortException)
            {
                // Swallow bogus redirect exception
            }
            catch (Exception ex)
            {
                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
                CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);
            }

        }

        private List<string> FailCheckOnEmpty()
        {
            List<string> lst = new List<string>();
            List<string> splits = new List<string>();
            splits.AddRange(hdnAnswers.Value.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));
            Dictionary<string, Dictionary<string, string>> sections = ECContext.GetSections();

            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    string key = string.Format("<answer>{0}|", question.Key);

                    if (splits.Exists(a => a.StartsWith(key)))
                        if (string.IsNullOrEmpty(splits.First(a => a.StartsWith(key)).Replace(key, string.Empty).Replace("\r\n", string.Empty)))
                            lst.Add(question.Key);
                }
            }
            return lst;
        }


        private void
        SendApprovalMail(SPListItem itm, string type, string answers, Dictionary<string, string> questions)
        {
            var sbTplQuestions = new StringBuilder();
            var sbAnswers = new StringBuilder();
            var syms = CEMailer.NewContext();
            var dictAnswers = new Dictionary<string, string>();

            // Fill general symbols
            syms.Add(CEMailSymbol.User.ToString(), SPContext.Current.Web.CurrentUser.LoginName);
            syms.Add(CEMailSymbol.ContractUrl.ToString(), string.Concat(SPContext.Current.Site.Url, "/", itm.ParentList.RootFolder.Url, "/", itm.File.Name));
            syms.Add(CEMailSymbol.ContractTitle.ToString(), itm.Title);
            syms.Add(CEMailSymbol.Country.ToString(), new SPFieldLookupValue(Convert.ToString(itm["Country"])).LookupValue);
            syms.Add(CEMailSymbol.Entity.ToString(), new SPFieldLookupValue(Convert.ToString(itm["Monsanto_x0020_Entity"])).LookupValue);
            syms.Add(CEMailSymbol.Function.ToString(), new SPFieldLookupValue(Convert.ToString(itm["Function"])).LookupValue);

            // Fill template questions			
            foreach (KeyValuePair<string, string> kvp in questions)
                sbTplQuestions.Append(String.Format("Q: {0} - A: {1} <br />", kvp.Key, kvp.Value));
            syms.Add(CEMailSymbol.TemplateQuestions.ToString(), sbTplQuestions.ToString());


            // Fill approval answers
            foreach (string s in answers.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries))
            {
                string[] toks = s.Replace("<answer>", String.Empty).Split('|');
                dictAnswers.Add(toks[0], toks[1]);
            }


            //splits.AddRange(answers.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));

            foreach (KeyValuePair<string, Dictionary<string, string>> section in ECContext.GetSections())
            {
                sbAnswers.AppendFormat("<div class=\"foo\">{0}</div>", section.Key);

                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    string val;

                    sbAnswers.AppendFormat("<b>{0}</b>", question.Value);

                    dictAnswers.TryGetValue(question.Key, out val);

                    sbAnswers.AppendFormat("<div>{0}</div>", dictAnswers[question.Key].Replace("\r\n", "<br/>"));
                }
            }

            syms.Add(CEMailSymbol.ApprovalAnswers.ToString(), sbAnswers.ToString());

            var mailer = new CEMailer();
            var to = new List<string>();

            to.Add("foo@lalala.com");
            to.Add("ble@lalala.com");

            mailer.Send(SPContext.Current.Web, to, to, "ApprovalMailTemplate", syms);
        }

        #region create word document
        public void SaveMailAsWordDocument(SPListItem item)
        {
            string url = string.Concat(SPContext.Current.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = SPContext.Current.Site.Url;
            string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
            string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
            string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;
            Dictionary<string, Dictionary<string, string>> sections = ECContext.GetSections();

            using (MemoryStream generatedDocument = new MemoryStream())
            {
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    using (WordprocessingDocument package = WordprocessingDocument.Create(generatedDocument, WordprocessingDocumentType.Document))
                    {
                        MainDocumentPart mainPart = package.MainDocumentPart;
                        if (mainPart == null)
                        {
                            mainPart = package.AddMainDocumentPart();
                            new Document(new Body()).Save(mainPart);
                        }

                        Body body = mainPart.Document.Body;

                        body.Append(CreateWordHeader("Request for approval"));


                        List<string> splits = new List<string>();
                        splits.AddRange(hdnAnswers.Value.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));
                        HtmlConverter converter = new HtmlConverter(mainPart);
                        CreateAndConvertWordContent(string.Format("{0} has created a new express contract '{1}' and requests your approval. Please navigate to this <a href=\"{2}\" >approval form</a> to approve it. To navigate to an overview of the contracts you can use this <a href=\"{3}\" >link</a>.<br /><br />The country that was selected for this contract is '{4}', the entity is '{5}' and the selected function is '{6}'.", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Name, item.File.Title, string.Format("{0}/_layouts/15/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", SPContext.Current.Site.Url, item.ID.ToString(), "DOA"), SPContext.Current.Site.Url, country, Entity, function), body, converter);

                        foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
                        {
                            body.Append(CreateWordHeader(section.Key));

                            foreach (KeyValuePair<string, string> question in section.Value)
                            {
                                CreateAndConvertWordContent(question.Value, body, converter);
                                string key = string.Format("<answer>{0}|", question.Key);

                                if (splits.Exists(a => a.StartsWith(key)))
                                    body.Append(CreateWordContent(splits.First(a => a.StartsWith(key)).Replace(key, string.Empty)));
                            }
                        }

                        mainPart.Document.Save();
                    }
                });
                SPWeb ElevatedWeb = item.Web;
                ElevatedWeb.AllowUnsafeUpdates = true;

                SPFile file = null;
                if (string.IsNullOrEmpty(Convert.ToString(item[ECContext.Current.Configuration.ECFields.ApprovalAnswer])))
                    file = ElevatedWeb.Lists[ECContext.Current.Configuration.ApprovalAnswerlistName].RootFolder.Files.Add(item.File.Name, generatedDocument.ToArray(), true);
                else
                    file = ElevatedWeb.Lists[ECContext.Current.Configuration.ApprovalAnswerlistName].RootFolder.Files.Add(new SPFieldLookupValue(Convert.ToString(item[ECContext.Current.Configuration.ECFields.ApprovalAnswer])).LookupValue, generatedDocument.ToArray(), true);

                SPListItem lstitem = file.Item;
                lstitem[SPBuiltInFieldId.Title] = file.Name;
                lstitem["Answers"] = hdnAnswers.Value;
                lstitem["Contract"] = new SPFieldLookupValue(item.ID, item.Title);
                lstitem.Update();

                SPFieldLookupValue lookUpVal = new SPFieldLookupValue(lstitem.ID, lstitem.Title);
                item[ECContext.Current.Configuration.ECFields.ApprovalAnswer] = lookUpVal;
                item.SystemUpdate();
                ElevatedWeb.AllowUnsafeUpdates = false;
            }

        }
        private void CreateAndConvertWordContent(string html, Body body, HtmlConverter converter)
        {
            html = html.Replace("<br/>", string.Empty);
            var paragraphs = converter.Parse(html);
            for (int i = 0; i < paragraphs.Count; i++)
                body.Append(paragraphs[i]);
        }
        private Paragraph CreateWordContent(string content)
        {
            Paragraph p = new Paragraph();
            Run r = new Run();
            r.Append(new Text(content));
            p.Append(r);
            return p;
        }
        private Paragraph CreateWordHeader(string text)
        {
            Paragraph p = new Paragraph();
            Run r = new Run();
            r.Append(new Text(text));
            p.Append(r);
            return p;
        }
        #endregion

        private void CreateQuestions()
        {
            DynaCtrls.Controls.Clear();

            Dictionary<string, Dictionary<string, string>> sections = ECContext.GetSections();
            List<string> answers = new List<string>();

            SPListItem contractItem = ECContext.Current.Lists.ExpressContract.GetItemById(Convert.ToInt32(Request.QueryString["itemid"]));


            //everis - CONTRACT CHANGE NOT ALLOWED
            //if (Request.QueryString["changed"] == "true")
            //{

            //    // ECContext.Current.Lists.ApprovalAnswer.GetItems(new SPQuery() { Query = string.Format("<Where><And><Eq><FieldRef Name=\"Contract\" /><Value Type=\"Lookup\">{0}</Value></Eq><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{1}</Value></Eq></And></Where>", contractItem.Title, contractItem.File.Name) })[0];
            //    SPListItem answeritem = ECContext.Current.Lists.ApprovalAnswer.GetItemById(new SPFieldLookupValue(Convert.ToString(contractItem[ECContext.Current.Configuration.ECFields.ApprovalAnswer])).LookupId);

            //    answers.AddRange(Convert.ToString(answeritem["Answers"]).Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));
            //}

            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                DynaCtrls.Controls.Add(new LiteralControl(string.Format("<h2>{0}</h2>", section.Key)));
                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    string answerValue = string.Empty;

                    if (_clonedContractId.HasValue)
                    {
                        answerValue = ECContext.GetQuestionAnswer(_clonedContractId.Value, Convert.ToInt32(question.Key), ECContext.QuestionType.Approval);
                    }

                    DynaCtrls.Controls.Add(new LiteralControl(string.Format("<div class=\"DynaQuestions\"><span>{0}</span></div>", question.Value)));
                    string key = string.Format("<answer>{0}|", question.Key);
                    string cols = "88";

                    if (answers.Exists(a => a.StartsWith(key)))
                        DynaCtrls.Controls.Add(new LiteralControl(string.Format("<div class=\"DynaAnswer\"><textarea id='{0}' class=\"DynaTextBox\" cols=\"" + cols + "\" rows=\"5\">{1}</textarea></div>", question.Key, answers.First(a => a.StartsWith(key)).Replace(key, string.Empty))));
                    else
                        DynaCtrls.Controls.Add(new LiteralControl(string.Format("<div class=\"DynaAnswer\"><textarea id='{0}' class=\"DynaTextBox\" cols=\"" + cols + "\" rows=\"5\">{1}</textarea></div>", question.Key, answerValue)));
                }
            }
        }

    }
}
