﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using System.Data;
using System.Threading;

namespace Bayer.BCS.ContractExpressSystem
{
	public class ArchiveContractForm : ECFormBase
	{
		protected int contract_id = 0;
		protected SPListItem src_contract = null;
        
        #region HTML CONTROLS
        
        protected DropDownList ddlMonsantoEntity;
        //protected DropDownList ddlCountry;
		protected DropDownList ddlMonsantoDivision= new DropDownList();
        protected DropDownList ddlDocType = new DropDownList();
        protected DropDownList ddlBusinessFunction = new DropDownList();
		protected HtmlInputFile pdfFile;
		protected Panel errorsArea;
        protected Panel div_messageok;
        protected Panel div_main;
        protected Label lblEffectiveDate;
		protected LinkButton ArchiveContractBtn;
        protected TextBox txtKeyWords=new TextBox();
        protected TextBox txtAgreementName = new TextBox();
        protected TextBox txtComments = new TextBox();
        protected TextBox txtCounterparty = new TextBox();
        protected TextBox txtContractReference = new TextBox();
        protected TextBox txtContractBarCode = new TextBox();
        protected Label lblContractID;
        protected HyperLink hlContract;
        protected HiddenField hdnDays;
        protected HiddenField hdnMonths;
        protected HiddenField hdnContractID;
        protected HiddenField hdnTitle;
        protected HiddenField hdnLink;
        protected CheckBox chkFCPA;
        protected CheckBox chkDataPrivacy;
        protected CheckBox chkEffectiveDate;
        //the below control is added newly --Nats
        protected CheckBox chnCtrl;
        protected HtmlInputText txtEffectiveDate;
        protected HtmlInputText txtEndContract;
        protected HtmlInputText txtSignatureDate;
        protected HtmlInputText txtActionDate;
        protected PeopleEditor peBusinessPerson;
        protected PeopleEditor peDoaApprover;
        protected PeopleEditor peAccessDelegation;
        protected CheckBox chkLawyer;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //Add tooltips
                AddTooltips();
            }
            try
            {
                if (errorsArea.Controls.Count > 0)
                {
                    //Hide error panel
                    Type ControlType = errorsArea.Controls[0].GetType();
                    if (ControlType == typeof(System.Web.UI.LiteralControl))
                    {
                        System.Web.UI.LiteralControl literal = (System.Web.UI.LiteralControl)errorsArea.Controls[0];
                        errorsArea.Visible = (literal.Text.Trim() != "");
                    }
                }
                string tmp;

                hdnMonths.Value = string.Join(" ", new System.Globalization.CultureInfo("en-GB").DateTimeFormat.MonthNames);
                hdnDays.Value = string.Join(" ", new System.Globalization.CultureInfo("en-GB").DateTimeFormat.ShortestDayNames);

                if ((tmp = HttpContext.Current.Request.QueryString["cid"]) != null && Int32.TryParse(tmp, out contract_id))
                {
                    src_contract = LoadContract(contract_id);
                    if (src_contract != null)
                    {
                        if (!Page.IsPostBack)
                        {
                            FillFormWithContractValues();
                        }
                        return;
                    }
                    else
                        throw new Exception("Contract not found.");
                }
                else
                {
                    NoContract();
                }
            }
            catch (Exception ex)
            {
                errorsArea.CssClass = "errPnl";

                Image errImg = new Image();
                errImg.ImageUrl = "/sites/270106/Style%20Library/Images/error-24.png";
                errImg.CssClass = "errImg";
                errorsArea.Controls.Add(errImg);

                Literal errMsg = new Literal();
                errMsg.Text = @"<strong>Following errors were found while trying to archive contract:</strong><br/><br/>"
                                + ex.Message +
                                "<br/><br/>";
                errorsArea.Controls.Add(errMsg);

                errorsArea.Visible = true;

                int logId = ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }

        private void AddTooltips()
        {
            string sTT = "";
            string sKey = "";
            SPList ecList = ECContext.Current.CurrentWeb.Lists.TryGetList("Configuration");

            if (ecList != null)
            {
                sKey = "Archiving - Agreement Name";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtAgreementName.Attributes.Add("Title", sTT);

                sKey = "Archiving - Key words";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtKeyWords.Attributes.Add("Title", sTT);

                sKey = "Archiving - Effective Date";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtEffectiveDate.Attributes.Add("Title", sTT);
                
                sKey = "Archiving - End of contract";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtEndContract.Attributes.Add("Title", sTT);

                sKey = "Archiving - Signature date";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtSignatureDate.Attributes.Add("Title", sTT);

                sKey = "Archiving - FCPA Action date";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtActionDate.Attributes.Add("Title", sTT);
                //newly added -Nats
                sKey = "Archiving - Change of controle";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    chnCtrl.Attributes.Add("Title", sTT);

                sKey = "Archiving - Counterparty";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtCounterparty.Attributes.Add("Title", sTT);

                sKey = "Archiving - Business user";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    peBusinessPerson.Attributes.Add("Title", sTT);

                sKey = "Archiving - DOA Approver";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    peDoaApprover.Attributes.Add("Title", sTT);

                sKey = "Archiving - Contract vault reference";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtContractReference.Attributes.Add("Title", sTT);

                sKey = "Archiving - Bar code";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    txtContractBarCode.Attributes.Add("Title", sTT);

                sKey = "Archiving - Data privacy";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    chkDataPrivacy.Attributes.Add("Title", sTT);

                sKey = "Archiving - Access delegation";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    peAccessDelegation.Attributes.Add("Title", sTT);

                sKey = "Archiving - Lawyers confidential";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    chkLawyer.Attributes.Add("Title", sTT);

                sKey = "Effective Date Archiving Tooltip";
                sTT = GetTooltip(sKey, ecList);
                if (!string.IsNullOrEmpty(sTT))
                    lblEffectiveDate.Text = sTT;
            }
                
            
            
        }

        private string GetTooltip(string sKey, SPList list)
        {
            string sRet = "";
            SPQuery q = new SPQuery();
            q.Query = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">" + sKey + "</Value></Eq></Where>";
            SPListItemCollection itemCol = list.GetItems(q);
            if (itemCol.Count > 0)
            {
                sRet = Convert.ToString(itemCol[0]["Value"]);
            }
            return sRet;
        }

        private void NoContract()
        {
            lblContractID.Text = " - No ID -";
            hlContract.NavigateUrl = "";
            hlContract.Text = " - No name -";
            txtAgreementName.ReadOnly = false;
            chkEffectiveDate.Visible = false;
            lblEffectiveDate.Visible = false;
        }

        private void FillFormWithContractValues()
        {
            string sDivision = Convert.ToString(src_contract[ECContext.Current.Configuration.ECFields.MonsantoDivision]);
            if (sDivision.LastIndexOf(";#") >= 0)
                sDivision = sDivision.Substring(sDivision.LastIndexOf(";#") + 2).Trim();

            string sEntity = Convert.ToString(src_contract[ECContext.Current.Configuration.ECFields.MonsantoEntity]);
            if (sEntity.LastIndexOf(";#") >= 0)
                sEntity = sEntity.Substring(sEntity.LastIndexOf(";#") + 2).Trim();

            string sDocType = Convert.ToString(src_contract[ECContext.Current.Configuration.ECFields.DocumentType]);
            if (sDocType.LastIndexOf(";#") >= 0)
                sDocType = sDocType.Substring(sDocType.LastIndexOf(";#") + 2).Trim();

            string sFunction = Convert.ToString(src_contract[ECContext.Current.Configuration.ECFields.Function]);
            if (sFunction.LastIndexOf(";#") >= 0)
                sFunction = sFunction.Substring(sFunction.LastIndexOf(";#") + 2).Trim();

            txtAgreementName.ReadOnly = true;
            lblContractID.Text = src_contract.ID.ToString();
            hlContract.NavigateUrl = src_contract.File.ServerRelativeUrl;
            hlContract.Text = src_contract.Title;

            ddlMonsantoEntity.ClearSelection();
            if (ddlMonsantoEntity.Items.OfType<ListItem>().FirstOrDefault(_string => _string.Text.Equals(sEntity, StringComparison.CurrentCultureIgnoreCase)) != null)
                ddlMonsantoEntity.Items.OfType<ListItem>().FirstOrDefault(_string => _string.Text.Equals(sEntity, StringComparison.CurrentCultureIgnoreCase)).Selected = true;
            else
                ddlMonsantoEntity.SelectedIndex = 0;

            ddlMonsantoDivision.ClearSelection();
            if (ddlMonsantoDivision.Items.OfType<ListItem>().FirstOrDefault(_string => _string.Text.Equals(sDivision, StringComparison.CurrentCultureIgnoreCase)) != null)
                ddlMonsantoDivision.Items.OfType<ListItem>().FirstOrDefault(_string => _string.Text.Equals(sDivision, StringComparison.CurrentCultureIgnoreCase)).Selected = true;
            else
                ddlMonsantoDivision.SelectedIndex = 0;

            ddlDocType.ClearSelection();
            if (ddlDocType.Items.OfType<ListItem>().FirstOrDefault(_string => _string.Text.Equals(sDocType, StringComparison.CurrentCultureIgnoreCase)) != null)
                ddlDocType.Items.OfType<ListItem>().FirstOrDefault(_string => _string.Text.Equals(sDocType, StringComparison.CurrentCultureIgnoreCase)).Selected = true;
            else
                ddlDocType.SelectedIndex = 0;

            ddlBusinessFunction.ClearSelection();
            if (ddlBusinessFunction.Items.OfType<ListItem>().FirstOrDefault(_string => _string.Text.Equals(sFunction, StringComparison.CurrentCultureIgnoreCase)) != null)
                ddlBusinessFunction.Items.OfType<ListItem>().FirstOrDefault(_string => _string.Text.Equals(sFunction, StringComparison.CurrentCultureIgnoreCase)).Selected = true;
            else
                ddlBusinessFunction.SelectedIndex = 0;

            txtAgreementName.Text = src_contract.Title + ".pdf";
            txtCounterparty.Text = (String)src_contract["CounterParty"];

            //Get effective date from bookmark
            string effDate = "";
            Dictionary<string, ECContext.Bookmark> templateBookmarks = ECContext.OpenXml.FindBookmarksAndContent(src_contract.File.OpenBinaryStream());
            if (templateBookmarks.ContainsKey("EffectiveDate"))
            {
                effDate = templateBookmarks["EffectiveDate"].Content;
            }
            txtEffectiveDate.Value = effDate;

            //If EffectiveDate is informed, check is visible
            chkEffectiveDate.Visible = !string.IsNullOrEmpty(effDate);
            lblEffectiveDate.Visible = !string.IsNullOrEmpty(effDate);

            SPUser user = null;

            string sBPerson = (string)src_contract[ECContext.Current.Configuration.ECFields.BusinessUser];
            sBPerson = sBPerson.Substring(sBPerson.LastIndexOf("#") + 1);
            try
            {
                user = (from SPUser c in ECContext.Current.CurrentWeb.SiteUsers
                        where c.Name == sBPerson.Substring(sBPerson.LastIndexOf("#") + 1)
                        select c).First();
            }
            catch { }
            if (user != null)
            {
                peBusinessPerson.CommaSeparatedAccounts = user.LoginName;
                peBusinessPerson.Validate();
            }

            user = null;
            string sDoa = (string)src_contract[ECContext.Current.Configuration.ECFields.DaoApprover];
            sDoa = sDoa.Substring(sDoa.LastIndexOf("#") + 1);
            try
            {
                user = (from SPUser c in ECContext.Current.CurrentWeb.SiteUsers
                        where c.Name == sDoa.Substring(sDoa.LastIndexOf("#") + 1)
                        select c).First();
            }
            catch { }
            if (user != null)
            {
                peDoaApprover.CommaSeparatedAccounts = user.LoginName;
                peDoaApprover.Validate();
            }

            //FCPA
            if (src_contract["FCPA"].ToString().Trim() == "FCPA APPROVAL REQUIRED")
            {
                chkFCPA.Checked = true;
                txtActionDate.Disabled = false;
                txtActionDate.Value = Convert.ToDateTime(src_contract["FCPA action date"]).ToString("MMMM dd, yyyy"); ;
            }

        }

		protected override void OnInit(EventArgs e)
		{
            
            CESPUtil.BindDropdownList(ddlDocType, ECContext.Current.CurrentWeb.Lists["Archived contract types"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
			CESPUtil.BindDropdownList(ddlMonsantoDivision, ECContext.Current.CurrentWeb.Lists["Monsanto Division"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
            CESPUtil.BindDropdownList(ddlMonsantoEntity, ECContext.Current.CurrentWeb.Lists["Archived Monsanto Entity"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
            //CESPUtil.BindDropdownList(ddlCountry, ECContext.Current.Lists.Country.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
            //CESPUtil.BindDropdownList(ddlCountry, ECContext.Current.Lists.Translations.GetItems(new SPQuery() { Query = "<Where><Eq><FieldRef Name=\"Translation_x0020_Type\" /><Value Type=\"Choice\">Country</Value></Eq></Where><OrderBy><FieldRef Name='Title' Ascending='True' /></OrderBy>" }));
            CESPUtil.BindDropdownList(ddlBusinessFunction, ECContext.Current.Lists.Function.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));
         //   CESPUtil.BindDropdownList(ddlBusinessFunction, ECContext.Current.CurrentWeb.Lists["Functions"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='Title' /></OrderBy>", RowLimit = 1000 }));

            ddlDocType.Items.Insert(0, "");
            ddlBusinessFunction.Items.Insert(0, "");
            ddlMonsantoDivision.Items.Insert(0, "");
            ddlMonsantoEntity.Items.Insert(0, "");

            ddlBusinessFunction.Attributes.Add("data-name", "Function");
            ddlDocType.Attributes.Add("data-name", "Document type");
            ddlMonsantoDivision.Attributes.Add("data-name", "Monsanto Division");
            ddlMonsantoEntity.Attributes.Add("data-name", "Monsanto Entity");
		}


		private SPListItem LoadContract(int cid)
		{
			var ecList = ECContext.Current.Lists.ExpressContract;

			var citem = ecList.GetItemById(cid);

            return citem;
		}

		private void ArchiveContract()
		{
			try
			{
				ValidateForm();
			}
			catch (ECValidationException ex)
			{
				errorsArea.CssClass = "errPnl";

				Image errImg = new Image();
				errImg.ImageUrl = "/sites/270106/Style%20Library/Images/error-24.png";
				errImg.CssClass = "errImg";
				errorsArea.Controls.Add(errImg);

				Literal errMsg = new Literal();
				errMsg.Text = @"<strong>Following errors were found while trying to archive contract:</strong><br/><br/>"
								+ ex.Message +
								"<br/><br/>";
				errorsArea.Controls.Add(errMsg);

				errorsArea.Visible = true;

				return;
			}
		}
		
		private void ValidateForm()
		{
			var sb = new StringBuilder();
			
			// Ensure file attached
			if (pdfFile.PostedFile == null)
				sb.AppendLine("No file attached.<br />");

			// Ensure valid PDF
			if (pdfFile.PostedFile != null && (pdfFile.PostedFile.ContentLength <= 0 || !pdfFile.PostedFile.FileName.ToLower().EndsWith(".pdf")))
                sb.AppendLine("Invalid file attached -- please make sure a valid PDF file is used.<br />");

            // Check Agreement Name
            if (txtAgreementName.Text.Trim() == "")
                sb.AppendLine("Field <strong>Agreement Name</strong> can't be empty.<br />");

            // Check Effective date
            if (chkEffectiveDate.Visible && !chkEffectiveDate.Checked)
            {
                if (!CanParseToDate(txtEndContract.Value))
                    sb.AppendLine("Field <strong>End of contract</strong> has invalid data value.<br />");
            }

            // Check End of Contract (Expiry date)
            if (!CanParseToDate(txtEndContract.Value))
                sb.AppendLine("Field <strong>End of contract</strong> has invalid data value.<br />");

            // Check Signature date
            if (!CanParseToDate(txtSignatureDate.Value))
                sb.AppendLine("Field <strong>Signature date</strong> has invalid data value.<br />");

            // Check FCPA Action Date
            if (chkFCPA.Checked)
            {
                if (!CanParseToDate(txtActionDate.Value))
                    sb.AppendLine("Field <strong>FCPA Action Date</strong> has invalid data value.<br />");
            }

            // Check contract status
            if (src_contract != null && src_contract["Approval Status"].ToString() != "0") //0 = Approved
                sb.AppendLine("Contract must be Approved to Archive it");

            // Check Product Sub-Type
            if (txtKeyWords.Text.Trim() == "")
                sb.AppendLine("Field <strong>Key words</strong> can't be empty.<br />");

            // Check Counterparty
            if (txtCounterparty.Text.Trim() == "")
                sb.AppendLine("Field <strong>Counterparty</strong> can't be empty.<br />");

            // Check Business Person
            if (peBusinessPerson.ResolvedEntities.Count <= 0)
                sb.AppendLine("Field <strong>Business User</strong> can't be empty.<br />");

            // Check DOA Authorisation Person
            if (peDoaApprover.ResolvedEntities.Count <= 0)
                sb.AppendLine("Field <strong>DOA Approver</strong> can't be empty.<br />");
            
            if (sb.Length > 0)
                throw new ECValidationException("", sb.ToString());
            else
                GenerateArchivedContract();
		}

        private bool CanParseToNumber(string p)
        {
            bool bReturn = false;
            try
            {
                Convert.ToInt32(p);
                bReturn = true;
            }
            catch
            {
                bReturn = false;
            }

            return bReturn;
        }

        private bool CanParseToDate(string p)
        {
            bool bReturn = false;
            try
            {
                Convert.ToDateTime(p);
                bReturn = true;
            }
            catch
            {
                bReturn = false;
            }

            return bReturn;
        }

        private void GenerateArchivedContract()
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                Guid siteId = ECContext.Current.CurrentWeb.Site.ID;
                Guid webId = ECContext.Current.CurrentWeb.ID;
                SPUserToken token = ECContext.Current.CurrentWeb.Site.SystemAccount.UserToken;
                SPFile file = null;
                string sAgreementName = "";
                string url = "";
                using (SPSite site = new SPSite(siteId, token))
                {
                    using (SPWeb web = site.OpenWeb(webId))
                    {
                        web.AllowUnsafeUpdates = true;

                        SPDocumentLibrary archList = (SPDocumentLibrary)web.Lists.TryGetList(ECContext.Current.Lists.ArchivedContracts.Title);

                        sAgreementName = txtAgreementName.Text;
                        sAgreementName = CESPUtil.NormalizeFilename(sAgreementName);
                        if (!sAgreementName.ToLower().EndsWith(".pdf"))
                            sAgreementName = sAgreementName + ".pdf";

                        url = String.Format("{0}/{1}", archList.RootFolder.Url, sAgreementName);
                        file = web.GetFile(url);

                        //Change name if it already exists
                        int i = 1;
                        while (file.Exists)
                        {
                            string sOriginalName = txtAgreementName.Text.Replace(".pdf", "");
                            sOriginalName = CESPUtil.NormalizeFilename(sOriginalName);
                            sAgreementName = sOriginalName + "_" + i + ".pdf";
                            url = String.Format("{0}/{1}", archList.RootFolder.Url, sAgreementName);
                            file = web.GetFile(url);
                            i++;
                        }

                        web.AllowUnsafeUpdates = false;
                    }
                }

                SPWeb currweb = ECContext.Current.CurrentWeb;
                currweb.AllowUnsafeUpdates = true;
                try
                {
                    if (ddlDocType.SelectedIndex == 0 || ddlMonsantoDivision.SelectedIndex == 0)
                        throw new Exception();


                    SPDocumentLibrary archiveList = (SPDocumentLibrary)currweb.Lists.TryGetList(ECContext.Current.Lists.ArchivedContracts.Title);

                    file = archiveList.RootFolder.Files.Add(url, pdfFile.PostedFile.InputStream);
                    SPListItem doc = file.Item;

                    doc["Reference Number"] = (src_contract != null ? Convert.ToString(src_contract.ID) : "");
                    doc["Agreement Name"] = sAgreementName;
                    doc["Title"] = sAgreementName;
                    doc["Name"] = sAgreementName;
                    doc["Document Type"] = new SPFieldLookupValue(Convert.ToInt32(ddlDocType.SelectedItem.Value), ddlDocType.SelectedItem.Value);
                    doc["Monsanto Division"] = new SPFieldLookupValue(Convert.ToInt32(ddlMonsantoDivision.SelectedItem.Value), ddlMonsantoDivision.SelectedItem.Value);
                    doc["Key words"] = txtKeyWords.Text;
                    doc["Effective Date"] = (txtEffectiveDate.Value == "" ? null : txtEffectiveDate.Value);
                    doc["End of contract"] = (txtEndContract.Value == "" ? null : txtEndContract.Value);
                    doc["Signature Date"] = (txtSignatureDate.Value == "" ? null : txtSignatureDate.Value);
                    doc["FCPA"] = chkFCPA.Checked;
                    // newly added -Nats
                    doc["Change of controle"] = chnCtrl.Checked;

                    if (chkFCPA.Checked)
                        doc["FCPA Action Date"] = (txtActionDate.Value == "" ? null : txtActionDate.Value);

                    doc["Comments"] = txtComments.Text;
                    doc[ECContext.Current.Configuration.ECFields.MonsantoEntity] = new SPFieldLookupValue(Convert.ToInt32(ddlMonsantoEntity.SelectedItem.Value), ddlMonsantoEntity.SelectedItem.Value);
                    doc["Counterparty"] = txtCounterparty.Text;
                    doc["Function"] = new SPFieldLookupValue(Convert.ToInt32(ddlBusinessFunction.SelectedItem.Value), ddlBusinessFunction.SelectedItem.Value);

                    if (peBusinessPerson.ResolvedEntities.Count > 0)
                    {
                        SPUser BusinessPerson = SPContext.Current.Web.EnsureUser(((PickerEntity)peBusinessPerson.ResolvedEntities[0]).Key);
                        doc["Business user"] = new SPFieldUserValue(SPContext.Current.Web, BusinessPerson.ID, BusinessPerson.LoginName);
                    }

                    if (peDoaApprover.ResolvedEntities.Count > 0)
                    {
                        SPUser DoaApprover = SPContext.Current.Web.EnsureUser(((PickerEntity)peDoaApprover.ResolvedEntities[0]).Key);
                        doc["DOA Approver"] = new SPFieldUserValue(SPContext.Current.Web, DoaApprover.ID, DoaApprover.LoginName);
                    }

                    doc["Contract Vault Reference"] = txtContractReference.Text;
                    doc["Contract Vault Reference Bar Code"] = txtContractBarCode.Text;
                    doc["Data Privacy"] = chkDataPrivacy.Checked;
                    doc["External contract"] = string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["cid"] as string);
                    doc["Lawyer's confidential"] = chkLawyer.Checked;

                    if (peAccessDelegation.ResolvedEntities.Count > 0)
                    {
                        SPUser AccessDelegation = SPContext.Current.Web.EnsureUser(((PickerEntity)peAccessDelegation.ResolvedEntities[0]).Key);
                        doc["Access Delegation"] = new SPFieldUserValue(SPContext.Current.Web, AccessDelegation.ID, AccessDelegation.LoginName);
                    }

                    //Add permissions
                    AddPermissionsToArachivedContract(doc);

                    DisabledItemEventsScope disEvt = new DisabledItemEventsScope();
                    try
                    {
                        //Disable event firing --> no mail when updating item
                        disEvt.DisabledItemEvents();

                        doc.SystemUpdate();

                        //Add link to archived contract in contract express
                        if (src_contract != null)
                        {
                            //src_contract["Contract Archive"] = new SPFieldLookupValue(doc.ID, doc.ID.ToString());
                            src_contract["Contract Archive Link"] = currweb.Url + "/Archived%20Contracts/Forms/DispForm.aspx?ID=" + doc.ID + ", " + doc["Title"].ToString();
                            src_contract.SystemUpdate();
                        }
                    }
                    catch (Exception exx)
                    {
                        int logId = ECContext.LogEvent("Error archiving contract. " + exx.Message, exx, ECContext.TraceLevel.Unexpected);
                        CEJSUtil.PopError(Page, ECContext.Messages.ErrorPopupTitle, ECContext.Messages.CreateContractError + "<br/>" + ECContext.Messages.ErrorReferenceMsg + logId);

                        if (file != null)
                            file.Delete();

                        if (doc != null)
                            doc.Delete();

                        doc.SystemUpdate();
                    }
                    finally
                    {
                        disEvt.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    throw new ECValidationException("", ex.Message);
                }


                currweb.AllowUnsafeUpdates = false;

                div_main.Visible = false;
                div_messageok.Visible = true;

                Literal meta = new Literal();
                meta.Text = "<meta http-equiv=\"refresh\" content=\"5; URL=" + ECContext.Current.CurrentWeb.Site.Url + "/_layouts/15/ContractExpressSystem/ContractSearch.aspx\">";
                Page.Header.Controls.Add(meta);
            });
    
        }

        private void AddPermissionsToArachivedContract(SPListItem doc)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                Guid siteId = doc.Web.Site.ID;
                Guid webId = doc.Web.ID;
                Guid listId = doc.ParentList.ID;
                int itemId = doc.ID;
                SPUserToken token = doc.Web.Site.SystemAccount.UserToken;
                using (SPSite site = new SPSite(siteId, token))
                {
                    using (SPWeb web = site.OpenWeb(webId))
                    {
                        web.AllowUnsafeUpdates = true;
                        SPList list = web.Lists[listId];
                        SPListItem item = list.GetItemById(itemId);
                        item.BreakRoleInheritance(false);
                        
                        SPGroup group = null;
                        SPUser user = null;
                        SPRoleAssignment roleAssign = null;
                        SPRoleDefinition roleDef = null;

                        //Add current user
                        user = ECContext.Current.CurrentWeb.CurrentUser;
                        roleAssign = new SPRoleAssignment(user);
                        roleDef = item.Web.RoleDefinitions.GetByType(SPRoleType.Administrator);
                        roleAssign.RoleDefinitionBindings.Add(roleDef);
                        item.RoleAssignments.Add(roleAssign);

                        //Add access delegation
                        if (peAccessDelegation.ResolvedEntities.Count > 0)
                        {
                            user = SPContext.Current.Web.EnsureUser(((PickerEntity)peAccessDelegation.ResolvedEntities[0]).Key);
                            roleAssign = new SPRoleAssignment(user);
                            roleDef = item.Web.RoleDefinitions.GetByType(SPRoleType.Administrator);
                            roleAssign.RoleDefinitionBindings.Add(roleDef);
                            item.RoleAssignments.Add(roleAssign);
                        }

                        //Add Contract Express System Owners group
                        if (ECContext.Current.CurrentWeb.Groups["Contract Express Owners"] != null)
                        {
                            group = ECContext.Current.CurrentWeb.Groups["Contract Express Owners"];
                            roleAssign = new SPRoleAssignment(group);
                            roleDef = item.Web.RoleDefinitions.GetByType(SPRoleType.Administrator);
                            roleAssign.RoleDefinitionBindings.Add(roleDef);
                            item.RoleAssignments.Add(roleAssign);
                        }

                        if (chkLawyer.Checked)
                        {
                            //Add Lawyers confidential group
                            if (ECContext.Current.CurrentWeb.Groups["Lawyers confidential"] != null)
                            {
                                group = ECContext.Current.CurrentWeb.Groups["Lawyers confidential"];
                                roleAssign = new SPRoleAssignment(group);
                                roleDef = item.Web.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                roleAssign.RoleDefinitionBindings.Add(roleDef);
                                item.RoleAssignments.Add(roleAssign);
                            }
                        }
                        else
                        {
                            //Add Contibutors group
                            if (ECContext.Current.CurrentWeb.Groups["Contributors"] != null)
                            {
                                group = ECContext.Current.CurrentWeb.Groups["Contributors"];
                                roleAssign = new SPRoleAssignment(group);
                                roleDef = item.Web.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                roleAssign.RoleDefinitionBindings.Add(roleDef);
                                item.RoleAssignments.Add(roleAssign);
                            }

                            //Add Legal admin group
                            if (ECContext.Current.CurrentWeb.Groups["Legal admin"] != null)
                            {
                                group = ECContext.Current.CurrentWeb.Groups["Legal admin"];
                                roleAssign = new SPRoleAssignment(group);
                                roleDef = item.Web.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                roleAssign.RoleDefinitionBindings.Add(roleDef);
                                item.RoleAssignments.Add(roleAssign);
                            }

                            //Add Contract Express admin view group
                            if (ECContext.Current.CurrentWeb.Groups["Contract Express Admin View"] != null)
                            {
                                group = ECContext.Current.CurrentWeb.Groups["Contract Express admin view"];
                                roleAssign = new SPRoleAssignment(group);
                                roleDef = item.Web.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                roleAssign.RoleDefinitionBindings.Add(roleDef);
                                item.RoleAssignments.Add(roleAssign);
                            }
                        }
                    }
                }
            });
        }


		protected void ddlDocType_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		protected void ddlMonsantoEntity_SelectedIndexChanged(object sender, EventArgs e)
		{
		}
        
		protected void ArchiveContract_click(object sender, EventArgs e)
		{
			ArchiveContract();
		}

        protected void btnHome_click(object sender, EventArgs e)
        {
            try
            {
                SPUtility.Redirect(SPContext.Current.Site.RootWeb.Url + "/default.aspx", SPRedirectFlags.Default, HttpContext.Current);
            }
            catch (ThreadAbortException)
            {
                // Swallow bogus exception caused by redirect
            }
        }

		private string ExtractDdlValue(string valstr)
		{
			if (String.IsNullOrEmpty(valstr))
				return valstr;

			return valstr.Substring(0, valstr.IndexOf(";"));
		}
	}
}
