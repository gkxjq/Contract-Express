﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;


namespace Bayer.BCS.ContractExpressSystem
{
    public class ContractSearch : ECFormBase
    {
        #region Controls

		protected SPWebPartManager m;
		protected WebPartZone wpZone;
		protected XsltListViewWebPart wpResults;
		
        
		

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
			var SPDataSource1 = new SPDataSource();
			
			SPDataSource1.DataSourceMode = SPDataSourceMode.List;
                SPDataSource1.SelectParameters.Add("WebID", Convert.ToString(ECContext.Current.CurrentWeb.ID));
                SPDataSource1.SelectParameters.Add("ListName", "Archived Contracts");
                SPDataSource1.SelectCommand = "<Query>" +
                     "<Where>" +
                        "<Contains>" +
                          "<FieldRef Name='Key_x0020_words'/>" +
                          "<Value Type='Text'>tete</Value>" +
                        "</Contains>" +
                     "</Where>" +
                     "<OrderBy>" +
                        "<FieldRef Name='ID' Ascending='true' />" +
                     "</OrderBy>" +
                   "</Query>";
        }

        protected override void CreateChildControls()
        {
        }
    }
}
