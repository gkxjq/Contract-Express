﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Web;
using System.IO;
using System.Threading;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Wordprocessing;
using Bayer.BCS.ContractExpressSsytem.HtmlToOpenXml;

namespace Bayer.BCS.ContractExpressSystem
{
    public class FCPAQuestionFrom : ECFormBase
    {
        #region controls
        protected PlaceHolder DynaCtrls;
        protected HiddenField hdnAnswers;
        protected TextBox sapVendorNumberTxt;
        private int? _clonedContractId;
        #endregion

        public FCPAQuestionFrom()
        {


        }

        protected override void OnInit(EventArgs e)
        {
            try
            {
                int clonedContractId;
                if (int.TryParse((string)Request.QueryString["clonedContractId"], out clonedContractId))
                    _clonedContractId = clonedContractId;
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }
        }


        protected void Send(object sender, EventArgs e)
        {
            SPSite site = SPContext.Current.Site;
            SPWeb web = SPContext.Current.Web;

            SPListItem item = null;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite ElevatedSite = new SPSite(site.ID))
                using (SPWeb ElevatedWeb = ElevatedSite.OpenWeb(web.ID))
                {

                   
                    item = ElevatedWeb.Lists[ECContext.Current.Configuration.ExpressContractLibraryName].GetItemById(Convert.ToInt32(Request.QueryString["itemid"]));
                    if (CheckFCPAApproval())
                    {
                        item[ECContext.Current.Configuration.ECFields.FCPA] = "FCPA APPROVAL REQUIRED";
                        SaveMailAsWordDocument(item);
                    }
                    else
                    {
                        item[ECContext.Current.Configuration.ECFields.FCPA] = "NOT FCPA RELEVANT";
                        item[ECContext.Current.Configuration.ECFields.FCPAApproval] = "N/A";
                    }

                    item["Sap Vendor Number"] = sapVendorNumberTxt.Text;
                    ElevatedWeb.AllowUnsafeUpdates = true;
                    item.SystemUpdate(false);
                    ElevatedWeb.AllowUnsafeUpdates = false;

                }
            });
			try
			{
            	SPUtility.Redirect(string.Format("ContractExpressSystem/QuestionForm.aspx?itemid={0}{1}", Convert.ToString(item.ID), _clonedContractId.HasValue ? "&clonedContractId=" + _clonedContractId.Value : ""), SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);
			}
			catch (ThreadAbortException)
			{
				// Swallow bogus exception
			}
            
        }

        private bool CheckFCPAApproval()
        {
            List<string> splits = new List<string>();
            splits.AddRange(hdnAnswers.Value.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));
            foreach (var item in splits)
                if (item.EndsWith("yes|true"))
                    return true;
            
            return false;

        }


        public void SaveMailAsWordDocument(SPListItem item)
        {
            string url = string.Concat(SPContext.Current.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = SPContext.Current.Site.Url;
            string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
            string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
            string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;
            Dictionary<string, Dictionary<string, string>> sections = GetSections();

            using (MemoryStream generatedDocument = new MemoryStream())
            {
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    using (WordprocessingDocument package = WordprocessingDocument.Create(generatedDocument, WordprocessingDocumentType.Document))
                    {
                        MainDocumentPart mainPart = package.MainDocumentPart;
                        if (mainPart == null)
                        {
                            mainPart = package.AddMainDocumentPart();
                            new Document(new Body()).Save(mainPart);
                        }

                        Body body = mainPart.Document.Body;

                        body.Append(CreateWordHeader("Request for approval"));


                        List<string> splits = new List<string>();
                        splits.AddRange(hdnAnswers.Value.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));
                        HtmlConverter converter = new HtmlConverter(mainPart);
                        CreateAndConvertWordContent(string.Format("{0} has created a new express contract '{1}' and requests your approval. Please navigate to this <a href=\"{2}\" >approval form</a> to approve it. To navigate to an overview of the contracts you can use this <a href=\"{3}\" >link</a>.<br /><br />The country that was selected for this contract is '{4}', the entity is '{5}' and the selected function is '{6}'.", new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Name, item.File.Title, string.Format("{0}/_layouts/15/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", SPContext.Current.Site.Url, item.ID.ToString(), "DOA"), SPContext.Current.Site.Url, country, Entity, function), body, converter);

                        foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
                        {
                            body.Append(CreateWordHeader(section.Key));

                            foreach (KeyValuePair<string, string> question in section.Value)
                            {
                                CreateAndConvertWordContent(question.Value, body, converter);
                                string yeskey = string.Format("<answer>{0}yes|true", question.Key);
                                string nokey = string.Format("<answer>{0}no|true", question.Key);

                                if (splits.Exists(a => a.StartsWith(yeskey)))
                                    body.Append(CreateWordContent("answer was YES"));
                                if (splits.Exists(a => a.StartsWith(nokey)))
                                    body.Append(CreateWordContent("answer was no"));
                            }
                        }

                        mainPart.Document.Save();
                    }
                });
                SPWeb ElevatedWeb = item.Web;

                ElevatedWeb.AllowUnsafeUpdates = true;

                SPFile file = ElevatedWeb.Lists[ECContext.Current.Configuration.ApprovalAnswerlistName].RootFolder.Files.Add(string.Concat("FCPA_",item.File.Name), generatedDocument.ToArray(), true);
                SPListItem lstitem = file.Item;
                lstitem[SPBuiltInFieldId.Title] = file.Name;
                lstitem["Answers"] = hdnAnswers.Value;
                lstitem["Contract"] = new SPFieldLookupValue(item.ID, item.Title);
                lstitem.Update();

                SPFieldLookupValue lookUpVal = new SPFieldLookupValue(lstitem.ID, lstitem.Title);
                item[ECContext.Current.Configuration.ECFields.FcpaApprovalAnswer] = lookUpVal;
                item.SystemUpdate();

                ElevatedWeb.AllowUnsafeUpdates = false;
            }

        }

        protected override void CreateChildControls()
        {
            try
            {
                if (!IsPostBack)
                {
                    //Init questions
                    CreateQuestions();

                    //Init Sap Vendor
                    if (_clonedContractId.HasValue)
                    {
                        SPList expresscontractList = ECContext.Current.Lists.ExpressContract;
                        SPListItem contractItem = expresscontractList.GetItemById(_clonedContractId.Value);
                        if (contractItem != null)
                            sapVendorNumberTxt.Text = (string)contractItem["Sap Vendor Number"];
            }
                }
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex,ECContext.TraceLevel.Unexpected); 
                Controls.Add(new LiteralControl(string.Format("<Label style='color:red' >{0}</Label>", ex.Message)));
            }
        }

        private void CreateQuestions()
        {

            DynaCtrls.Controls.Clear();

            Dictionary<string, Dictionary<string, string>> sections = GetSections();

            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                DynaCtrls.Controls.Add(new LiteralControl("<span class='questionFormSubtitle'>Please fill in these questions, the questions will determine if FCPA approval is needed:</span>"));

                DynaCtrls.Controls.Add(new LiteralControl(string.Format("<h2>{0}</h2>", section.Key)));
               
                DynaCtrls.Controls.Add(new LiteralControl("<table class='questionForm'>"));

                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    string answerValue = string.Empty;
                    string yesSelected = string.Empty;
                    string noSelected = "checked";

                    if (_clonedContractId.HasValue)
                    {
                        answerValue = ECContext.GetQuestionAnswer(_clonedContractId.Value, Convert.ToInt32(question.Key), ECContext.QuestionType.FCPA);

                        if (answerValue == "true") { yesSelected = "checked"; noSelected = ""; }

                }

                    DynaCtrls.Controls.Add(new LiteralControl(string.Format("<tr><td style=\"width:90%\"><span>{0}</span></td><td><div css='DynaQuestions' ><input type=\"radio\" name=\"question{1}\" id='{1}yes' value='yes'" + yesSelected + "/>yes<input name=\"question{1}\"  type=\"radio\" id='{1}no' value='no'" + noSelected + " />no</div></td></tr>", question.Value, question.Key)));
                }
                DynaCtrls.Controls.Add(new LiteralControl("</table>"));
            }
        }

        public Dictionary<string, Dictionary<string, string>> GetSections()
        {
            Dictionary<string, Dictionary<string, string>> sections = new Dictionary<string, Dictionary<string, string>>();

            foreach (SPListItem item in ECContext.Current.Lists.ApprovalQuestion.GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='LinkTitleNoMenu' Ascending='True' /><FieldRef Name='Order0' Ascending='True' /></OrderBy>" }))
            {
                string section = Convert.ToString(item[SPBuiltInFieldId.Title]);
                if (section == ECContext.Current.Configuration.FCPASectionTitle)
                {
                    if (sections.ContainsKey(section))
                        sections[section].Add(Convert.ToString(item[SPBuiltInFieldId.ID]), Convert.ToString(item["Question"]));
                    else
                    {
                        Dictionary<string, string> lst = new Dictionary<string, string>();
                        lst.Add(Convert.ToString(item[SPBuiltInFieldId.ID]), Convert.ToString(item["Question"]));
                        sections.Add(section, lst);
                    }
                }
            }
            return sections;

        }

        private void CreateAndConvertWordContent(string html, Body body, HtmlConverter converter)
        {
            html = html.Replace("<br/>", string.Empty);
            var paragraphs = converter.Parse(html);
            for (int i = 0; i < paragraphs.Count; i++)
                body.Append(paragraphs[i]);
        }
        private Paragraph CreateWordContent(string content)
        {
            Paragraph p = new Paragraph();
            Run r = new Run();
            r.Append(new Text(content));
            p.Append(r);
            return p;
        }
        private Paragraph CreateWordHeader(string text)
        {
            Paragraph p = new Paragraph();
            Run r = new Run();
            r.Append(new Text(text));
            p.Append(r);
            return p;
        }
    }
}
