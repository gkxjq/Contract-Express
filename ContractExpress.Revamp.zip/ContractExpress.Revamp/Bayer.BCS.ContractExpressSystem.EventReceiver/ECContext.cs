﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;
using System.Web;
using Microsoft.SharePoint.Utilities;
using System.Collections.Specialized;
using System.Net.Mail;

using Microsoft.Office.Server.Diagnostics;

namespace Bayer.BCS.ContractExpressSystem.EventReceiver
{
    public sealed class ECContext
    {

        public enum TraceLevel { Information, Template, Unexpected };

        public static class Messages
        {
            public const string CloneContractError = "There was a problem cloning the contract. Please, contact system administrator for support.";
            public const string CreateContractError = "There was a problem creating this contract. Please, contact system administrator for support.";
            public const string CreateContractAttachmentError = "There was a problem with attachments in this contract. Please, contact system administrator for support.";
            public const string CreateBookmarksError = "There was a problem setting up current template bookmarks. Please, contact system administrator for support.";
            public const string MissingBookmarksOnListInfo = "We have detected that selected template contains bookmarks that are not present on bookmarks list. You can go ahead creating your contract. <br/> If you want all bookmarks to be filled in, please contact system administrator.";
            public const string UploadTemplateError = "There was a problem uploading this contract. Please, contact system administrator for support.";
            public const string ErrorReferenceMsg = "Error reference ID:";
            public const string ErrorPopupTitle = "Contract Express error";
            public const string InfoPopupTitle = "Contract Express";
            public const string SubmitForApprovalError = "This contract can't be submited due to missing required fields:<br /><br />{0}<br /><br />Please, contact system administrator for support.";
        }

        [Serializable]
        public class BookmarkGridItem
        {
            public string BookmarkDescription { get; set; }
            public string MainBookmarkDescription { get; set; }
            public string SecBookmarkDescription { get; set; }
            public string Language { get; set; }
            public bool Required { get; set; }
            public string DataType { get; set; }
            public string FieldMapping { get; set; }
            public int OrderPosition { get; set; }
            public string InternalName { get; set; }
            public string Value { get; set; }
            public string LongDescription { get; set; }
        }

        [Serializable]
        public class ContractDynamicPortion
        {
            public string BookMarkCode { get; set; }
            public string DisplayText { get; set; }
            public string DocumentType { get; set; }
            public string Language { get; set; }
            public string Portion { get; set; }
            public bool Mandatory { get; set; }
            public string FieldType { get; set; }
        }

        public sealed class EntityTAGStoReplace
        {
            public static readonly string COUNTRY = "[#COUNTRY#]";
            public static readonly string ENTITY_NAME = "[#ENTITY_NAME#]";
            public static readonly string ABBREVIATION = "[#ABBREVIATION#]";
            public static readonly string IBAN = "[#IBAN#]";
            public static readonly string ADDRESS = "[#ADDRESS#]";
            public static readonly string COMPANY_REGISTRATION_NO = "[#COMPANY_REGISTRATION_NO#]";
            public static readonly string VAT = "[#VAT#]";
            public static readonly string JURISDICTION = "[#JURISDICTION#]";
            public static readonly string INCORPORATION = "[#INCORPORATION#]";
            public static readonly string SIGNATORY = "[#SIGNATORY#]";
            public static readonly string BANK_NAME_ADDRESS = "[#BANK_NAME_ADDRESS#]";
            public static readonly string BANK_AC_NO = "[#BANK_AC_NO#]";
            public static readonly string SWIFT = "[#SWIFT#]";
            public static readonly string BIC = "[#BIC#]";
            public static readonly string CORRESPONDENT_BANK_AC_NO = "[#CORRESPONDENT_BANK_AC_NO#]";
            public static readonly string ID_NUMBER = "[#ID_NUMBER#]";
            public static readonly string CAPITAL_AMOUNT = "[#CAPITAL_AMOUNT#]";
            public static readonly string ENTITY_TYPE = "[#ENTITY_TYPE#]";
            public static readonly string REPRESENTATIVE = "[#REPRESENTATIVE#]";
            public static readonly string ANNUAL_RETURN_FILING_DATE = "[#ANNUAL_RETURN_FILING_DATE#]";
            public static readonly string OWNERSHIP = "[#OWNERSHIP#]";
            public static readonly string REGISTRATION_ADDRESS = "[#REGISTRATION_ADDRESS#]";
            public static readonly string USE_IN_CE = "[#USE_IN_CE#]";
            public static readonly string BANK_DETAILS = "[#BANK_DETAILS#]";
            public static readonly string SIGNATORIES = "[#SIGNATORIES#]";
            public static readonly string DECLINATED_COUNTRY_NAME = "[#DECLINATED_COUNTRY_NAME#]";
            public static readonly string ADDITIONAL_INFO = "[#ADDITIONAL_INFO#]";


        }
      
        public struct Bookmark
        {
            public string Name { get; set; }
            //public BookmarkEnd End { get; set; }
            //public BookmarkStart Start { get; set; }
            public string Content { get; set; }
            public bool IsBulletedList { get; set; }

            public string DataValue { get; set; }
            public string DataType { get; set; }
            public string Mapping { get; set; }
            public string Description { get; set; }
            public string LongDescription { get; set; }

            public int ItemID { get; set; }
        }

        public ECContext(SPContext sharepointContext)
        {

            context = sharepointContext;
        }

        private SPContext context;
        public SPContext SPContext
        {
            get { return context; }
        }

        public static ECContext Current
        {
            get
            {
                return new ECContext(SPContext.Current);
            }
        }

        public SPWeb CurrentWeb
        {
            get { return context.Web; }
        }
        public ECLists Lists
        {
            get
            {
                return new ECLists(this);

            }
        }

        public ECConfiguration _Configuration;
        public ECConfiguration Configuration
        {
            get
            {
                if (_Configuration == null)
                    _Configuration = new ECConfiguration(context.Web);
                return _Configuration;
            }
        }

        private string _ECMasterpageUrl;
        private string ECMasterpageUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_ECMasterpageUrl))
                    _ECMasterpageUrl = Current.Configuration.MasterpageUrl;
                return _ECMasterpageUrl;
            }
        }

        private static string _ECDoaType;
        public static string ECDoaType
        {
            get
            {
                if (string.IsNullOrEmpty(_ECDoaType))
                    _ECDoaType = Current.Configuration.DOATypeKey;
                return _ECDoaType;
            }
        }

        private static string _ECFcpaType;
        public static string ECFcpaType
        {
            get
            {
                if (string.IsNullOrEmpty(_ECFcpaType))
                    _ECFcpaType = Current.Configuration.FCPATypeKey;
                return _ECFcpaType;
            }
        }
        private static string _ContractChange;
        public static string ContractChange
        {
            get
            {
                if (string.IsNullOrEmpty(_ContractChange))
                    _ContractChange = Current.Configuration.contractorChangesEmail;
                return _ContractChange;
            }
        }

        private static string _ECLegalType;
        public static string ECLegalType
        {
            get
            {
                if (string.IsNullOrEmpty(_ECLegalType))
                    _ECLegalType = Current.Configuration.LegalTypeKey;
                return _ECLegalType;
            }
        }

        public string MasterPageUrl(HttpContext context)
        {
            using (SPWeb web = SPControl.GetContextSite(context).OpenWeb())
                return string.Concat(web.ServerRelativeUrl, Configuration.MasterpageUrl);

        }

     

        public SPFile CreateNewExpressContractFromClone(SPListItem originalContract, string newContractName, SPWeb elevated)
        {
            string newUrl = string.Empty;


            SPFile sourcefile;
            try
            {

                sourcefile = originalContract.File;
            }
            catch (Exception)
            {
                throw new ApplicationException("Contract template not found, please verify that you have selected the template related question.");
                //ECContext.LogEvent(ex.Message, "Contract template not found, please verify that you have selected the template related question.");
            }

            newUrl = string.Format("{0}/{1}{2}", Lists.ExpressContract.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            //DCC New contracts are created in draft mode list newUrl = string.Format("{0}/{1}{2}", Lists.DraftContracts.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            if (sourcefile.CheckOutType != SPFile.SPCheckOutType.None)
                throw new ApplicationException(string.Concat("Template is not checked in. Please check this template ", sourcefile.Name));
            elevated.AllowUnsafeUpdates = true;

            SPFolder CEFolder = elevated.GetFolder(Lists.ExpressContract.RootFolder.Url);
            CEFolder.Files.Add(newUrl, sourcefile.OpenBinary(), SPContext.Current.Web.CurrentUser, SPContext.Current.Web.CurrentUser, DateTime.Now, DateTime.Now);

            //sourcefile.CopyTo(newUrl, true);
            elevated.AllowUnsafeUpdates = false;

            return elevated.GetFile(newUrl);
        }

        public SPFile CreateNewExpressContractCoverPageFromTemplate(string newContractName, string templateName, SPWeb elevated, string ContractID)
        {

            string newUrl = string.Empty;
            SPList eccpList = elevated.Lists.TryGetList("ExpressContractCoverPage");

            SPFile sourcefile;
            try
            {

                sourcefile = elevated.Lists[Configuration.ContractTemplateLibraryName].GetItems(new SPQuery() { RowLimit = 1, Query = string.Format("<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) })[0].File;
                //sourcefile = ECContext.Current.Lists.ContractTemplate.GetItems(new SPQuery() { RowLimit = 1, Query = string.Format("<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) })[0].File;
            }
            catch (Exception)
            {
                throw new ApplicationException("Contract template not found, please verify that you have selected the template related question.");
                //ECContext.LogEvent(ex.Message, "Contract template not found, please verify that you have selected the template related question.");
            }

            newUrl = string.Format("{0}/{1}{2}", eccpList.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            //DCC New contracts are created in draft mode list newUrl = string.Format("{0}/{1}{2}", Lists.DraftContracts.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            if (sourcefile.CheckOutType != SPFile.SPCheckOutType.None)
                throw new ApplicationException(string.Concat("Template is not checked in. Please check this template ", sourcefile.Name));
            elevated.AllowUnsafeUpdates = true;

            SPFolder CEFolder = elevated.GetFolder(eccpList.RootFolder.Url);
            CEFolder.Files.Add(newUrl, sourcefile.OpenBinary(), true);
            SPListItem itemCP = elevated.GetFile(newUrl).Item;
            itemCP["ContractID"] = ContractID;
            itemCP.Update();
            //sourcefile.CopyTo(newUrl, true);
            elevated.AllowUnsafeUpdates = false;

            return elevated.GetFile(newUrl);
        }

        public SPFile CreateNewExpressContractFromTemplate(string newContractName, string templateName, SPWeb elevated)
        {

            string newUrl = string.Empty;


            SPFile sourcefile;
            try
            {

                sourcefile = elevated.Lists[Configuration.ContractTemplateLibraryName].GetItems(new SPQuery() { RowLimit = 1, Query = string.Format("<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) })[0].File;
                //sourcefile = ECContext.Current.Lists.ContractTemplate.GetItems(new SPQuery() { RowLimit = 1, Query = string.Format("<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>", templateName) })[0].File;
            }
            catch (Exception)
            {
                throw new ApplicationException("Contract template not found, please verify that you have selected the template related question.");
                //ECContext.LogEvent(ex.Message, "Contract template not found, please verify that you have selected the template related question.");
            }

            newUrl = string.Format("{0}/{1}{2}", Lists.ExpressContract.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            //DCC New contracts are created in draft mode list newUrl = string.Format("{0}/{1}{2}", Lists.DraftContracts.RootFolder.Url, newContractName, newContractName.EndsWith(".docx") ? string.Empty : ".docx");
            if (sourcefile.CheckOutType != SPFile.SPCheckOutType.None)
                throw new ApplicationException(string.Concat("Template is not checked in. Please check this template ", sourcefile.Name));
            elevated.AllowUnsafeUpdates = true;

            SPFolder CEFolder = elevated.GetFolder(Lists.ExpressContract.RootFolder.Url);
            CEFolder.Files.Add(newUrl, sourcefile.OpenBinary(), SPContext.Current.Web.CurrentUser, SPContext.Current.Web.CurrentUser, DateTime.Now, DateTime.Now);

            //sourcefile.CopyTo(newUrl, true);
            elevated.AllowUnsafeUpdates = false;

            return elevated.GetFile(newUrl);
        }

        public void HandleException(Exception ex)
        {
            SPUtility.SendEmail(Current.context.Web, false, false, Current.Configuration.SupportMail, "Express contract Exception", ex.Message);
        }

        public static int LogEvent(string message, Exception ex, TraceLevel traceLevel)
        {
            return LogEvent(message, ex, traceLevel, SPContext.Current.Web);
        }

        public static int LogEvent(string message, Exception ex, TraceLevel traceLevel, SPWeb web)
        {
            string logMessage = ex == null ? message : ex.Message;
            string logTrace = ex == null ? string.Empty : ex.ToString();

            //Log into Logging List
            int logId = AddLogListEntry(logMessage, logTrace, traceLevel, web);

            //Log into SP
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ContactExpress", TraceSeverity.High, EventSeverity.Error), TraceSeverity.High, logMessage + " " + logTrace, null);

            // Return logId for referencing in error messages
            return logId;
        }

        private static int AddLogListEntry(string logMessage, string logTrace, TraceLevel traceLevel, SPWeb web)
        {
            try
            {
                SPList logList = web.Lists["Logging"];

                web.AllowUnsafeUpdates = true;

                if (logList != null)
                {
                    web.AllowUnsafeUpdates = true;

                    SPListItem logEntry = logList.Items.Add();

                    logEntry["Level"] = traceLevel;
                    logEntry["Message"] = logMessage;
                    logEntry["StackTrace"] = logTrace;
                    logEntry["TimeStamp"] = DateTime.Now;


                    logEntry.Update();

                    return logEntry.ID;
                }

                return 0;
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ContractExpress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message + ex.StackTrace, null);
                return 0;
            }
            finally
            {
                web.AllowUnsafeUpdates = false;
            }
        }

        public static int AddLogEntry(string logMessage, SPWeb web)
        {
            try
            {
                SPList logList = web.Lists["Logging"];

                web.AllowUnsafeUpdates = true;

                if (logList != null)
                {
                    web.AllowUnsafeUpdates = true;

                    SPListItem logEntry = logList.Items.Add();

                    logEntry["Message"] = logMessage;
                    logEntry["TimeStamp"] = DateTime.Now;


                    logEntry.Update();

                    return logEntry.ID;
                }

                return 0;
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ContractExpress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message + ex.StackTrace, null);
                return 0;
            }
            finally
            {
                web.AllowUnsafeUpdates = false;
            }
        }

        #region mail

        public static string CreateMailForApproval(SPListItem item, string type, string answers, bool isAmended)
        {
            string siteUrl = SPContext.Current.Site.Url;
            return CreateMailForApproval(siteUrl, item, type, answers, isAmended);
        }

        public static string CreateMailForApproval(string sUrl, SPListItem item, string type, string answers, bool isAmended)
        {
            string url = string.Concat(sUrl, "/Style%20Library/Images/Mail/");
            string siteUrl = sUrl;
            string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
            string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
            //string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;
            Dictionary<string, Dictionary<string, string>> sections = GetSections(siteUrl);

            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            string selectedEmailTemplate = "";

            selectedEmailTemplate = CETemplateMails.MailForApprovalEmailTemplate;

            valuesToReplace.Add(CEMailSymbol.mailforApproval_Action, !isAmended ? "created a new express" : "has amended an express");
            valuesToReplace.Add(CEMailSymbol.mailforApproval_ApprovalURL, string.Format("{0}/_layouts/15/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", sUrl, item.ID.ToString(), type));
            valuesToReplace.Add(CEMailSymbol.mailforApproval_BU, new SPFieldUserValue(item.Web, Convert.ToString(item["Business user"])).User.Name);
            valuesToReplace.Add(CEMailSymbol.mailforApproval_ContractTitle, item.File.Title);
            valuesToReplace.Add(CEMailSymbol.mailforApproval_ContractURL, string.Concat(sUrl, "/", item.ParentList.RootFolder.Url, "/", item.File.Name));
            valuesToReplace.Add(CEMailSymbol.mailforApproval_Country, country);
            valuesToReplace.Add(CEMailSymbol.mailforApproval_Entity, Entity);
            valuesToReplace.Add(CEMailSymbol.mailforApproval_Header, "Request for approval");
            valuesToReplace.Add(CEMailSymbol.mailforApproval_SiteURL, sUrl);

            StringBuilder sb = new StringBuilder();


            List<string> splits = new List<string>();
            splits.AddRange(answers.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));

            //Comment this section to hide questions in Approval email.


            foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
            {
                valuesToReplace.Add(CEMailSymbol.mailforApproval_FCPAQuestionsTitle, section.Key);
                //sb.Append(CreateSectionHead(section.Key));
                foreach (KeyValuePair<string, string> question in section.Value)
                {
                    sb.Append(CreateContent(question.Value));
                    string key = string.Format("<answer>{0}|", question.Key);

                    if (splits.Exists(a => a.StartsWith(key)))
                        sb.Append(CreateContent(splits.First(a => a.StartsWith(key)).Replace(key, string.Empty).Replace("\r\n", "<br />")));
                }
            }
            valuesToReplace.Add(CEMailSymbol.mailforApproval_FCPAQuestions, sb.ToString());

            //sb.AppendLine(" </table> </td> </tr> <tr>");
            //sb.AppendLine("<td valign=\"top\"> <table cellspacing=\"0\" border=\"0\" cellpadding=\"0\" width=\"675\"> <tr> <td valign=\"top\"> </td> </tr> <tr> <td align=\"center\" class=\"footer\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <img src=\"images/double-line.gif\" alt=\"\" width=\"675\" style=\"display: block;\" /> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> </td> </tr> </table> </td> </tr>  </table> </td> </tr> </table> </body> </html>");

            CEEmail email = mailSystem.GetEmailMessageFromTemplate(item.Web, selectedEmailTemplate, valuesToReplace);
            email.EmailBody = email.EmailBody.Replace("images/", url);

            //return sb.ToString().Replace("images/", url);
            return email.EmailBody;
        }

        public static List<string> CreateLegalHeader(SPWeb web)
        {
            List<string> bcc = new List<string>();

            SPSecurity.RunWithElevatedPrivileges(delegate()
               {
                   using (SPSite newSite = new SPSite(web.Site.ID))
                   {
                       using (SPWeb webElevated = newSite.OpenWeb(web.ID))
                       {
                           SPGroup group = webElevated.Groups["Legal admin"];

                           foreach (SPUser user in group.Users)
                               if (!string.IsNullOrEmpty(user.Email))
                                   bcc.Add(user.Email);

                       }
                   }
               });

            return bcc;
        }

        public static List<string> CreateDOAHeader(SPListItem item, SPWeb web)
        {
            List<string> bcc = new List<string>();

            SPSecurity.RunWithElevatedPrivileges(delegate()
               {
                   using (SPSite newSite = new SPSite(web.Site.ID))
                   {
                       using (SPWeb webElevated = newSite.OpenWeb(web.ID))
                       {
                           SPUser user = new SPFieldUserValue(webElevated, Convert.ToString(item[ECContext.Current.Configuration.ECFields.DaoApprover])).User;
                           if (!string.IsNullOrEmpty(user.Email))
                               bcc.Add(user.Email);
                       }
                   }
               });

            return bcc;
        }




        public static List<string> CreateFCPAHeader(SPWeb web)
        {
            List<string> bcc = new List<string>();

            SPSecurity.RunWithElevatedPrivileges(delegate()
             {
                 using (SPSite newSite = new SPSite(web.Site.ID))
                 {
                     using (SPWeb webElevated = newSite.OpenWeb(web.ID))
                     {
                         StringDictionary headers = new StringDictionary();
                         SPGroup group = webElevated.Groups["FCPA Approver"];

                         foreach (SPUser user in group.Users)
                             if (!string.IsNullOrEmpty(user.Email))
                                 bcc.Add(user.Email);

                     }
                 }
             });

            return bcc;
        }

        private static string CreateSectionHead(string section)
        {
            return string.Format("  <tr> <td valign=\"top\"> <img src=\"images/double-line.gif\" alt=\"\" style=\"display: block;\" /> </td> </tr> <tr><td class=\"article-title\" height=\"30\" valign=\"middle\" style=\"text-transform: uppercase; font-family: Georgia, serif; font-size: 16px; color: #2b2b2b; font-style: italic; border-bottom: 1px solid #c1c1c1;\"> {0} </td> </tr>", section);
        }

        private static string CreateContent(string message)
        {
            return string.Format("<tr><td class=\"copy\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <p>{0}</p> <br /> </td> </tr>", message);
        }


        public static string CreateMail(SPListItem item, string answers, string type, string selectedEmailTemplate)
        {
            StringBuilder sb = new StringBuilder();
            string url = string.Concat(SPContext.Current.Site.Url, "/Style%20Library/Images/Mail/");
            string siteUrl = SPContext.Current.Site.Url;

            CETemplateMails mailTemplates = new CETemplateMails();
            CEMailer mailSystem = new CEMailer();
            Dictionary<string, string> valuesToReplace = new Dictionary<string, string>();
            //string selectedEmailTemplate = "";

            //selectedEmailTemplate = CETemplateMails.RequestApprovalEmailTemplate;



            try
            {
                string country = new SPFieldLookupValue(Convert.ToString(item["Country"])).LookupValue;
                string Entity = new SPFieldLookupValue(Convert.ToString(item["Monsanto_x0020_Entity"])).LookupValue;
                //string function = new SPFieldLookupValue(Convert.ToString(item["Function"])).LookupValue;
                Dictionary<string, Dictionary<string, string>> sections = GetSections();
                string sUserName = new SPFieldUserValue(item.Web, Convert.ToString(item[ECContext.Current.Configuration.ECFields.BusinessUser])).User.Name;
                string sFileUrl = string.Concat(SPContext.Current.Site.Url, "/", item.File.Url);
                string sApprovalUrl = string.Format("{0}/_layouts/15/ContractExpressSystem/ApprovalForm.aspx?ItemId={1}&type={2}", SPContext.Current.Site.Url, item.ID.ToString(), type);


                valuesToReplace.Add(CEMailSymbol.requestApproval_ContractURL, string.Concat(item.Web.Site.Url, "/", item.File.Url));
                valuesToReplace.Add(CEMailSymbol.requestApproval_ContractTitle, item.File.Title);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Header, "Request for approval");
                valuesToReplace.Add(CEMailSymbol.requestApproval_BU, sUserName);
                valuesToReplace.Add(CEMailSymbol.requestApproval_ApprovalURL, sApprovalUrl);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Entity, Entity);
                valuesToReplace.Add(CEMailSymbol.requestApproval_Country, country);
                valuesToReplace.Add(CEMailSymbol.requestApproval_SiteURL, SPContext.Current.Site.Url);


                List<string> splits = new List<string>();
                splits.AddRange(answers.Split(new string[] { "</answer>" }, StringSplitOptions.RemoveEmptyEntries));

                if (type == ECContext.ECFcpaType)
                {
                    SPFieldLookupValue lv = new SPFieldLookupValue(Convert.ToString(item[ECContext.Current.Configuration.ECFields.ApprovalAnswer]));
                    if (lv.LookupId != 0)
                    {
                        try
                        {
                            string sUrl = ECContext.Current.Lists.ApprovalAnswer.GetItemById(lv.LookupId).File.Url;
                            //sb.Append(CreateContent(string.Format("To review the approval answers please follow <a href ='{0}' >this</a> link. </br>", string.Concat(SPContext.Current.Site.Url, "/", sUrl))));
                            valuesToReplace.Add(CEMailSymbol.requestApproval_ApprovalQuestions, string.Format("To review the approval answers please follow <a href ='{0}' >this</a> link. </br>", string.Concat(SPContext.Current.Site.Url, "/", sUrl)));
                        }
                        catch (Exception ex)
                        {
                            ECContext.LogEvent("Contract " + item.ID + " has no approval answers", ex, ECContext.TraceLevel.Information);
                        }
                    }
                }
                foreach (KeyValuePair<string, Dictionary<string, string>> section in sections)
                {
                    sb.Append(CreateSectionHead(section.Key));
                    if (type == ECContext.ECFcpaType)
                    {
                        foreach (KeyValuePair<string, string> question in section.Value)
                        {
                            sb.Append(CreateContent(question.Value));
                            string yeskey = string.Format("<answer>{0}yes|true", question.Key);
                            string nokey = string.Format("<answer>{0}no|true", question.Key);

                            if (splits.Exists(a => a.StartsWith(yeskey)))
                                sb.Append(CreateContent("answer was YES"));
                            if (splits.Exists(a => a.StartsWith(nokey)))
                                sb.Append(CreateContent("answer was no"));
                        }
                    }
                    else
                        foreach (KeyValuePair<string, string> question in section.Value)
                        {
                            sb.Append(CreateContent(question.Value));
                            string key = string.Format("<answer>{0}|", question.Key);

                            if (splits.Exists(a => a.StartsWith(key)))
                                sb.Append(CreateContent(splits.First(a => a.StartsWith(key)).Replace(key, string.Empty).Replace("\r\n", "<br />")));
                        }
                }
                valuesToReplace.Add(CEMailSymbol.requestApproval_FCPAQuestions, sb.ToString());

                //sb.AppendLine(" </table> </td> </tr> <tr>");
                //sb.AppendLine("<td valign=\"top\"> <table cellspacing=\"0\" border=\"0\" cellpadding=\"0\" width=\"675\"> <tr> <td valign=\"top\"> </td> </tr> <tr> <td align=\"center\" class=\"footer\" valign=\"top\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #2b2b2b; line-height: 18px;\"> <img src=\"images/double-line.gif\" alt=\"\" width=\"675\" style=\"display: block;\" /> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tr> <td height=\"15\"></td> </tr> </table> </td> </tr> </table> </td> </tr>  </table> </td> </tr> </table> </body> </html>");
            }
            catch (Exception ex)
            {
                ECContext.LogEvent("Approval Form. Error creating mail for contract " + item.ID, ex, ECContext.TraceLevel.Information);
            }
            CEEmail email = mailSystem.GetEmailMessageFromTemplate(ECContext.Current.CurrentWeb, selectedEmailTemplate, valuesToReplace);
            email.EmailBody = email.EmailBody.Replace("images/", url);
            //return sb.ToString().Replace("images/", url);
            return email.EmailBody;
        }


        public static bool SendMail(SPWeb web, string Subject, string Body, bool IsBodyHtml, string From, List<string> To, List<string> Cc, List<string> Bcc)
        {
            bool mailSent = false;
            try
            {
                SmtpClient smtpClient = new SmtpClient();

                //Comment Venu, Date 22 March, Added below try catch finally block to change the SMPTHost as per the configuration list. 
                string strGUID = string.Empty;
                try
                {
                    strGUID = Guid.NewGuid().ToString();
                    Body = Body + "<span style='font-size:1px;display:none;'>" + strGUID + "</span>";
                    SPList ecList = ECContext.Current.CurrentWeb.Lists.TryGetList("Configuration");
                    SPQuery queryConfiguration = new SPQuery();
                    queryConfiguration.Query = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">SMTPHost</Value></Eq></Where>";

                    SPListItemCollection itemCol = ecList.GetItems(queryConfiguration);
                    if (itemCol.Count > 0)
                    {
                        smtpClient.Host = Convert.ToString(itemCol[0]["Value"]);
                    }
                    else
                    {
                        smtpClient.Host = web.Site.WebApplication.OutboundMailServiceInstance.Server.Address;
                    }
                }
                catch (Exception ex)
                {
                    smtpClient.Host = web.Site.WebApplication.OutboundMailServiceInstance.Server.Address;
                    LogEvent("smtpClient.Host - " + smtpClient.Host + "Mail Sent - Subject - " + Subject + " - strGUID - " + strGUID, ex, ECContext.TraceLevel.Unexpected, web);
                }
                finally
                {
                }

                MailMessage mailMessage = null;

                String contactList = string.Empty;

                //DCC
                mailMessage = new MailMessage();
                mailMessage.Subject = Subject;
                mailMessage.Body = Body;
                mailMessage.From = new MailAddress(From);


                foreach (string toAddress in To)
                {
                    contactList += toAddress + ";";
                    MailAddress TOAddress = new MailAddress(toAddress);
                    mailMessage.To.Add(TOAddress);
                }

                contactList = string.Empty;
                foreach (string ccAddress in Cc)
                {
                    contactList += ccAddress + ";";
                    MailAddress CCAddress = new MailAddress(ccAddress);
                    mailMessage.CC.Add(CCAddress);
                }

                contactList = string.Empty;
                foreach (string bccAddress in Bcc)
                {
                    contactList += bccAddress + ";";
                    MailAddress BcCAddress = new MailAddress(bccAddress);
                    mailMessage.Bcc.Add(BcCAddress);
                }

                mailMessage.IsBodyHtml = IsBodyHtml;
                smtpClient.Send(mailMessage);
                mailSent = true;

                //Comment Venu, Date 21 March, Added try catch to check multiple mails are triggered or not
                try
                {
                    ECContext.AddLogEntry("SendMail - Mail Sent - Subject - " + Subject + " - strGUID - " + strGUID + " - smtpClient.Host " + smtpClient.Host, SPContext.Current.Web);
                }
                catch (Exception ex)
                {
                    LogEvent("Mail Sent - Subject - " + Subject + " - strGUID - " + strGUID, ex, ECContext.TraceLevel.Unexpected, web);
                }

                //LogEvent(String.Format("Mail {0} sent to:{1}", Subject, mailMessage.Bcc.ToString()), null, ECContext.TraceLevel.Information);
            }
            catch (Exception ecp)
            {
                LogEvent(String.Format("Mail error: {0}", ecp.Message), ecp, ECContext.TraceLevel.Unexpected, web);
                return mailSent;
            }
            return mailSent;
        }

        public static bool SendMail(SPWeb web, string Subject, string Body, List<string> Bcc)
        {
            return SendMail(web, Subject, Body, true, "ExpressContractSystem@bayer.com", new List<string>(), new List<string>(), Bcc);
        }

        public static bool SendMail(SPWeb web, string Subject, string Body, string To)
        {
            List<string> toList = new List<string>();
            toList.Add(To);
            return SendMail(web, Subject, Body, true, "ExpressContractSystem@bayer.com", toList, new List<string>(), new List<string>());
        }

        private static string GetSharePointMailService(string mysite)
        {
            string address;
            using (SPSite site = new SPSite(mysite))
            {
                address = site.WebApplication.OutboundMailServiceInstance.Server.Address;
            }
            return address;
        }
        private enum LogType
        {
            Information,
            Error
        }
        public static void LogErrorEvent(string message)
        {
            // Call the LogEvent method with the log type of Information.
            LogEvent(message, LogType.Information);
        }
        private static void LogEvent(string message, LogType type)
        {
            try
            {
                // Run the portal logging with elevated priveleges, so that the error can be sucessfully logged.
                SPSecurity.RunWithElevatedPrivileges(delegate ()
                {
                    // Call the PortalLog LogString method. Use the format string to format the log type, source and message.
                    PortalLog.LogString("Bayer.BCS.ContractExpressEMEA {0} Message - Source: {1}", type.ToString(), message);
                });
            }
            catch (Exception)
            {
                // Not sure where to log if we can't log here
            }
        }
        #endregion

        #region ApprovalQuestions

        public enum QuestionType { FCPA, Approval };

        public static Dictionary<string, Dictionary<string, string>> GetSections()
        {
            string siteUrl = SPContext.Current.Site.Url;
            return GetSections(siteUrl);
        }

        public static Dictionary<string, Dictionary<string, string>> GetSections(string siteUrl)
        {
            Dictionary<string, Dictionary<string, string>> sections = new Dictionary<string, Dictionary<string, string>>();
            string section = "";
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    if (web.Lists.TryGetList("Approval Questions") != null)
                    {
                        foreach (SPListItem item in web.Lists["Approval Questions"].GetItems(new SPQuery() { Query = "<OrderBy><FieldRef Name='LinkTitleNoMenu' Ascending='True' /><FieldRef Name='Order0' Ascending='True' /></OrderBy>" }))
                        {
                            section = Convert.ToString(item[SPBuiltInFieldId.Title]);
                            if (section != "FCPA relevance:")
                            {
                                if (sections.ContainsKey(section))
                                    sections[section].Add(Convert.ToString(item[SPBuiltInFieldId.ID]), Convert.ToString(item["Question"]));
                                else
                                {
                                    Dictionary<string, string> lst = new Dictionary<string, string>();
                                    lst.Add(Convert.ToString(item[SPBuiltInFieldId.ID]), Convert.ToString(item["Question"]));
                                    sections.Add(section, lst);
                                }
                            }
                        }
                    }
                }
            }
            return sections;
        }

        public static string GetQuestionAnswer(int contractItemId, int questionItemId, QuestionType questionType)
        {
            string answer = string.Empty;

            try
            {
                ECFields fields = new ECFields();
                string answerField = string.Empty;
                string answerValue = string.Empty;
                SPList contractExpress = ECContext.Current.Lists.ExpressContract;
                SPList approvalAnswers = ECContext.Current.Lists.ApprovalAnswer;
                SPListItem contractItem = contractExpress.GetItemById(contractItemId);

                switch (questionType)
                {
                    case QuestionType.Approval:
                        answerField = "Approval Answers";
                        break;
                    case QuestionType.FCPA:
                        answerField = "FCPA Approval Answers"; //_x0020_
                        break;
                }

                if (!string.IsNullOrEmpty(answerField))
                {
                    SPFieldLookupValue lookupApprovalAnswer = new SPFieldLookupValue((string)contractItem[answerField]);
                    SPListItem questionAnswerItem = approvalAnswers.GetItemById(lookupApprovalAnswer.LookupId);
                    answerValue = (string)questionAnswerItem["Answers"];

                    List<string> answersTagContent = answerValue.Split(new string[] { "<answer>" }, StringSplitOptions.RemoveEmptyEntries).ToList();

                    foreach (string content in answersTagContent)
                    {
                        List<string> answerTagContentSplitted = content.Split('|').ToList();

                        string key = answerTagContentSplitted[0];
                        string val = answerTagContentSplitted[1].Replace("</answer>", "");

                        //FCPA question format treatment
                        switch (questionType)
                        {
                            case QuestionType.FCPA:
                                if (key.Contains("yes") && val == "true")
                                {
                                    key = key.Replace("yes", "");
                                    val = "true";

                                }
                                else if (key.Contains("no") && val == "true")
                                {   //FCPA question format
                                    key = key.Replace("no", "");
                                    val = "false";

                                }
                                break;
                        }

                        if (key == questionItemId.ToString())
                        {
                            answer = val;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ECContext.LogEvent(ex.Message, ex, ECContext.TraceLevel.Unexpected);
            }

            return answer;

        }

        #endregion
    }
}