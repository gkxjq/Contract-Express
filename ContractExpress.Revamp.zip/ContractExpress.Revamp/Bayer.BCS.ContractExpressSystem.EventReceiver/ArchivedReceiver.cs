﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bayer.BCS.ContractExpressSystem.EventReceiver
{
    public class ArchivedReceiver : SPItemEventReceiver
    {
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            try
            {
                if (properties.List.Title == "Archived Contracts")
                {
                    base.ItemUpdated(properties);
                    this.EventFiringEnabled = false;
                    SPWeb ieweb = properties.Web;
                    ECContext ctx = new ECContext(SPContext.GetContext(ieweb));
                    string contentchanges = ctx.Configuration.ECFields.GetChangeContract;
                    if (contentchanges == "Yes")
                    {
                        SPRoleAssignment roleAssign = null;
                        SPRoleDefinition roleDef = null;


                       
                        //ECContext ctx = new ECContext(SPContext.GetContext(ieweb));


                        //Obtain  New user - DLH - 17/11/14
                        string userAccessDl = Convert.ToString(properties.ListItem[ctx.Configuration.ECFields.AccessDelegation]);
                        if (!string.IsNullOrEmpty(userAccessDl))
                        {
                            SPUser AccessDelegation = ieweb.SiteUsers.GetByID(Convert.ToInt32(Convert.ToString(userAccessDl).Split(';')[0]));
                            //Add permission to new user - DLH - 17/11/14
                            roleAssign = new SPRoleAssignment(AccessDelegation);
                            roleDef = properties.ListItem.Web.RoleDefinitions.GetByType(SPRoleType.Administrator);
                            roleAssign.RoleDefinitionBindings.Add(roleDef);
                            properties.ListItem.RoleAssignments.Add(roleAssign);
                        }

                        //Obtain previous user
                        string userAccessdlBefore = Convert.ToString(properties.BeforeProperties[ctx.Configuration.ECFields.AccessDelegation]);
                        if (!string.IsNullOrEmpty(userAccessdlBefore))
                        {
                            SPUser AccessDelegationBeforeUser = ieweb.SiteUsers.GetByID(Convert.ToInt32(userAccessdlBefore));
                            //Remove permission to previous user - DLH - 17/11/14
                            properties.ListItem.RoleAssignments.Remove(AccessDelegationBeforeUser);
                        }

                        //Update list - DLH - 17/11/14
                        properties.ListItem.SystemUpdate();

                    }
                    this.EventFiringEnabled = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
