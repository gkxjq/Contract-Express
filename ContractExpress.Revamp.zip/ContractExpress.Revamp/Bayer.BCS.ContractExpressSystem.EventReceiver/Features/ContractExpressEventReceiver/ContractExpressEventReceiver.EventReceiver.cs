using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;

namespace Bayer.BCS.ContractExpressSystem.EventReceiver.Features.ContractExpressEventReceiver
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("8b94ad43-7d5b-4c6b-b230-045ddd20de25")]
    public class ContractExpressEventReceiverEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                Logger.LogErrorEvent("Bayer.BCS.ContractExpressSystem.EventReceiver - new project created12345");
                SPWeb web = (SPWeb)properties.Feature.Parent;
                Logger.LogErrorEvent("Bayer.BCS.ContractExpressSystem.EventReceiver - " + web + " testing");
                //// Add Event for Transmittal list
                AttachReceiver(web, "Archived Contracts", SPEventReceiverType.ItemUpdated, "Bayer.BCS.ContractExpressSystem.EventReceiver", "ArchivedReceiver", 1000);
                Logger.LogErrorEvent("Bayer.BCS.ContractExpressSys.Receiver - Archived Contracts attached");
                AttachReceiver(web, "Express contracts", SPEventReceiverType.ItemUpdated, "Bayer.BCS.ContractExpressSystem.EventReceiver", "ContractsReceiver", 1000);
                Logger.LogErrorEvent("Bayer.BCS.ContractExpressSys.Receiver - Express contracts attached");
            }
            catch (Exception ex)
            {
                Logger.LogErrorEvent("Bayer.BCS.ContractExpressSys.Receiver - " + ex.Message + "");
            }
        }

        private void AttachReceiver(SPWeb web, string ListName, SPEventReceiverType eventtype, string namespaceName, string classname, int sequence)
        {
            SPList list = web.Lists.TryGetList(ListName);
            string fullclassname = namespaceName + "." + classname;
            //first detach from list. In case it was already attached.
            DetachReceiver(web, list, eventtype, namespaceName, classname);

            //now attach to list.
            SPEventReceiverDefinition def = list.EventReceivers.Add();

            def.Name = string.Format("{0}_{1}", classname, eventtype.ToString());
            def.Class = fullclassname;
            def.Assembly = this.GetType().Assembly.FullName;
            def.SequenceNumber = sequence;
            def.Type = eventtype;
            def.Update();
        }
        private void DetachReceiver(SPWeb web, SPList ListName, SPEventReceiverType eventtype, string namespaceName, string classname)
        {
            //  SPList list = web.Lists.TryGetList(ListName);
            string fullclassname = namespaceName + "." + classname;
            if (ListName != null)
            {
                for (int i = ListName.EventReceivers.Count - 1; i >= 0; i--)
                {
                    SPEventReceiverDefinition def = ListName.EventReceivers[i];
                    if (def.Class == fullclassname && def.Type == eventtype)
                    {
                        ListName.EventReceivers[i].Delete();
                    }
                }
            }
        }

        // Uncomment the method below to handle the event raised after a feature has been activated.

        //public override void FeatureActivated(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
